package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text as M3Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * A frame around the big cover on the Now Playing screen. Polaroid, Stamp, Film and Gallery are made for a rectangular
 * cover (Rounded or Squircle) and are left out for the other shapes; Lifted and Neon follow any cover shape.
 */
enum class CoverFrame(val label: String, val blurb: String, val needsRect: Boolean) {
    NONE("None", "Just the cover.", false),
    LIFTED("Lifted", "The cover floats above the page on a deep soft shadow tinted with its own colour.", false),
    NEON("Neon", "A glowing neon outline around the cover, in the colour of the theme.", false),
    POLAROID("Polaroid", "A white instant photo, tilted a little, with the name of the song written underneath.", true),
    STAMP("Stamp", "A postage stamp with a perforated edge all the way round.", true),
    FILM("Film", "A strip of film with sprocket holes down both sides.", true),
    GALLERY("Gallery", "A cream matte and a thin line, like a print on a gallery wall.", true),
}

/** The frame that is really drawn: the rectangular ones fall back to None for round covers. */
fun effectiveFrame(frame: CoverFrame, shape: ArtShape): CoverFrame =
    if (frame.needsRect && shape != ArtShape.ROUNDED && shape != ArtShape.SQUIRCLE) CoverFrame.NONE else frame

/** The outline the cover has on the Now Playing screen for each cover shape (the same maths as the player uses). */
fun npArtShape(shape: ArtShape, corner: Float): Shape = when (shape) {
    ArtShape.ROUNDED -> RoundedCornerShape((corner * 1.3f).dp)
    ArtShape.CIRCLE, ArtShape.VINYL -> androidx.compose.foundation.shape.CircleShape
    ArtShape.SQUIRCLE -> RoundedCornerShape(percent = 30)
    ArtShape.COOKIE -> CookieShape
}

/**
 * A postage stamp outline: a rectangle with a row of half circles bitten out of every edge, spaced about [pitch] apart.
 * Same arc maths as tools/atmosphere_check.py, which draws it in Python.
 */
class StampShape(private val pitch: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val p = with(density) { pitch.toPx() }
        val nx = maxOf(2, (size.width / p).roundToInt())
        val ny = maxOf(2, (size.height / p).roundToInt())
        val sx = size.width / nx
        val sy = size.height / ny
        val rx = sx * 0.28f
        val ry = sy * 0.28f
        val w = size.width
        val h = size.height
        val path = Path()
        path.moveTo(0f, 0f)
        for (i in 0 until nx) { // top edge, left to right
            val cx = (i + 0.5f) * sx
            path.lineTo(cx - rx, 0f)
            path.arcTo(Rect(Offset(cx, 0f), rx), 180f, -180f, false)
        }
        path.lineTo(w, 0f)
        for (j in 0 until ny) { // right edge, top to bottom
            val cy = (j + 0.5f) * sy
            path.lineTo(w, cy - ry)
            path.arcTo(Rect(Offset(w, cy), ry), 270f, -180f, false)
        }
        path.lineTo(w, h)
        for (i in nx - 1 downTo 0) { // bottom edge, right to left
            val cx = (i + 0.5f) * sx
            path.lineTo(cx + rx, h)
            path.arcTo(Rect(Offset(cx, h), rx), 0f, -180f, false)
        }
        path.lineTo(0f, h)
        for (j in ny - 1 downTo 0) { // left edge, bottom to top
            val cy = (j + 0.5f) * sy
            path.lineTo(0f, cy + ry)
            path.arcTo(Rect(Offset(0f, cy), ry), 90f, -180f, false)
        }
        path.close()
        return Outline.Generic(path)
    }
}

/**
 * Draws [content] (the cover) inside the chosen frame. The frame says what shape the cover itself gets, so the
 * content receives it. [modifier] sizes the whole thing (the caller makes it square). [caption] is written on a Polaroid.
 */
@Composable
internal fun CoverFrameBox(
    frame: CoverFrame,
    shape: Shape,
    accent: Color,
    caption: String?,
    modifier: Modifier = Modifier,
    content: @Composable (Shape) -> Unit,
) {
    when (frame) {
        CoverFrame.NONE -> Box(modifier) { content(shape) }

        CoverFrame.LIFTED -> Box(
            modifier
                .shadow(22.dp, shape, ambientColor = accent.copy(alpha = 0.35f), spotColor = accent.copy(alpha = 0.7f))
                .border(1.dp, Color.White.copy(alpha = 0.16f), shape),
        ) { content(shape) }

        CoverFrame.NEON -> {
            val tube = lerp(accent, Color.White, 0.2f)
            Box(
                modifier.drawWithContent {
                    drawContent()
                    val outline = shape.createOutline(size, layoutDirection, this)
                    val line = 2.dp.toPx()
                    drawOutline(outline, tube.copy(alpha = 0.10f), style = Stroke(line * 6f))
                    drawOutline(outline, tube.copy(alpha = 0.22f), style = Stroke(line * 3.2f))
                    drawOutline(outline, tube, style = Stroke(line))
                },
            ) { content(shape) }
        }

        CoverFrame.POLAROID -> BoxWithConstraints(modifier) {
            val w = maxWidth
            val card = RoundedCornerShape(3.dp)
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationZ = -1.6f }
                    .shadow(10.dp, card)
                    .background(Color(0xFFF8F4EA), card),
            ) {
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = w * 0.07f)
                        .fillMaxWidth(0.82f)
                        .aspectRatio(1f),
                ) { content(RoundedCornerShape(2.dp)) }
                if (caption != null) {
                    M3Text(
                        caption,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(start = w * 0.09f, end = w * 0.09f, bottom = w * 0.02f),
                        color = Color(0xFF3B3B3B),
                        fontFamily = FontFamily.Cursive,
                        fontSize = (w.value * 0.052f).sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        CoverFrame.STAMP -> BoxWithConstraints(modifier) {
            val w = maxWidth
            val stamp = remember { StampShape(15.dp) }
            Box(
                Modifier
                    .fillMaxSize()
                    .shadow(8.dp, stamp)
                    .background(Color(0xFFFBF7EF), stamp),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(w * 0.09f)
                        .border(1.dp, Color(0xFF2B2B2B).copy(alpha = 0.35f)),
                ) { content(RoundedCornerShape(1.dp)) }
            }
        }

        CoverFrame.FILM -> BoxWithConstraints(modifier) {
            val w = maxWidth
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF121212))
                    .drawBehind {
                        val holeW = size.width * 0.045f
                        val holeH = size.width * 0.065f
                        val step = size.width * 0.105f
                        val margin = size.width * 0.04f
                        val n = (size.height / step).toInt().coerceAtLeast(2)
                        val first = (size.height - (n - 1) * step) / 2f
                        val hole = Color(0xFFE9E1D1).copy(alpha = 0.92f)
                        val round = CornerRadius(holeW * 0.3f, holeW * 0.3f)
                        for (i in 0 until n) {
                            val y = first + i * step - holeH / 2f
                            drawRoundRect(hole, Offset(margin, y), Size(holeW, holeH), round)
                            drawRoundRect(hole, Offset(size.width - margin - holeW, y), Size(holeW, holeH), round)
                        }
                    },
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = w * 0.155f, vertical = w * 0.055f),
                ) { content(RoundedCornerShape(2.dp)) }
            }
        }

        CoverFrame.GALLERY -> BoxWithConstraints(modifier) {
            val w = maxWidth
            val mat = RoundedCornerShape(2.dp)
            Box(
                Modifier
                    .fillMaxSize()
                    .shadow(8.dp, mat)
                    .background(Color(0xFFF3EEE3), mat),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(w * 0.085f)
                        .border(1.dp, Color(0xFF2B2B2B).copy(alpha = 0.55f))
                        .padding(3.dp),
                ) { content(RoundedCornerShape(1.dp)) }
            }
        }
    }
}
