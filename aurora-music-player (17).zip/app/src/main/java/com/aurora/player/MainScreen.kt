package com.aurora.player

import android.Manifest
import android.app.Activity
import android.widget.Toast
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.core.content.ContextCompat
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

class MusicPermission(val granted: Boolean, val request: () -> Unit)

@Composable
fun rememberMusicPermission(): MusicPermission {
    val context = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val perms = remember {
        buildList {
            add(audioPerm)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED
    }
    return MusicPermission(granted) { launcher.launch(perms) }
}

@Composable
fun AuroraApp(vm: PlayerViewModel) {
    val rawSettings by vm.settings.collectAsState()
    val loaded by vm.settingsLoaded.collectAsState()
    val context = LocalContext.current
    val autoLite = remember { isLowEndDevice(context) }
    val lite = when (rawSettings.perfMode) {
        PerfMode.LITE -> true
        PerfMode.FULL -> false
        PerfMode.AUTO -> autoLite
    }
    val systemSaver = rememberPowerSaveMode()
    val liteSettings = (if (lite) rawSettings.asLite() else rawSettings).withPower(systemSaver)
    // The Current UI uses rounder surfaces. The Settings sliders keep showing the value you chose.
    val settings = if (liteSettings.uiVersion == UiVersion.CURRENT) {
        liteSettings.copy(corner = (liteSettings.corner * 1.2f).coerceAtMost(44f))
    } else liteSettings
    val motion = remember(settings.animSet, settings.animSpeed, settings.animIntensity, settings.pageStyle) {
        Motion(settings.animSet, settings.animSpeed, settings.animIntensity, settings.pageStyle)
    }
    val perm = rememberMusicPermission()
    var introDone by rememberSaveable { mutableStateOf(false) }
    val lang = resolveLanguage(settings.language)

    AuroraTheme(settings) {
        CompositionLocalProvider(
            LocalAppSettings provides settings,
            LocalMotion provides motion,
            LocalLang provides lang,
            LocalLite provides lite,
        ) {
            when {
                !loaded -> AuroraBackground(null)
                !introDone && settings.showIntro -> IntroScreen { introDone = true }
                !settings.setupDone -> SetupScreen(
                    s = rawSettings,
                    granted = perm.granted,
                    onRequest = perm.request,
                    onUpdate = { vm.updateSettings(it) },
                )
                else -> Root(vm, perm)
            }
        }
    }
}

private data class Page(val tab: AppTab, val detail: DetailRef?)

/** Pages are centred and never wider than this, so tablets do not stretch lists edge to edge. */
private val PAGE_MAX_WIDTH = 900.dp

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
private fun Root(vm: PlayerViewModel, perm: MusicPermission) {
    val settings = LocalAppSettings.current
    val rawSettings by vm.settings.collectAsState()
    val motion = LocalMotion.current
    val songs by vm.songs.collectAsState()
    val allSongs by vm.allSongs.collectAsState()
    val ui by vm.ui.collectAsState()
    val lib by vm.library.collectAsState()
    val detail by vm.detail.collectAsState()
    val haze = remember { HazeState() }
    var tab by rememberSaveable { mutableIntStateOf(settings.startTab.ordinal) }
    var showNow by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    // The Radial dock's fan of tabs
    var radialOpen by rememberSaveable { mutableStateOf(false) }
    // A tap on the media notification asks for the full player. Wait until a song is known, then open it.
    val openReq by vm.openPlayer.collectAsState()
    LaunchedEffect(openReq, ui.current) {
        if (openReq && ui.current != null) {
            showSettings = false
            showNow = true
            vm.consumeOpenPlayer()
        }
    }
    // The home screen widget follows the app's colours.
    val widgetContext = LocalContext.current
    val widgetScheme = MaterialTheme.colorScheme
    LaunchedEffect(
        widgetScheme.primary, widgetScheme.surfaceContainerHigh, widgetScheme.onSurface,
        settings.buttonShape, settings.playShape, settings.playColor, settings.playStyle,
    ) {
        WidgetState.saveTheme(
            widgetContext,
            widgetScheme.primary.toArgb(),
            widgetScheme.surfaceContainerHigh.toArgb(),
            widgetScheme.onSurface.toArgb(),
        )
        val play = if (settings.playStyle == PlayStyle.TONAL) settings.playColor.tonal(widgetScheme) else settings.playColor.solid(widgetScheme)
        val playPct = when (settings.playShape) {
            PlayShape.CIRCLE, PlayShape.LEAF, PlayShape.MORPH -> 50f
            PlayShape.SQUIRCLE -> 32f
            PlayShape.SOFT -> 22f
            PlayShape.SQUARE -> 14f
            PlayShape.SHARP -> 6f
        }
        WidgetState.saveControls(
            widgetContext,
            widgetScheme.secondaryContainer.toArgb(),
            widgetScheme.onSecondaryContainer.toArgb(),
            play.first.toArgb(),
            play.second.toArgb(),
            settings.buttonShape.pct,
            playPct,
            settings.playStyle == PlayStyle.OUTLINE,
        )
    }
    // The Lumi widgets draw her with the same look as in the app.
    LaunchedEffect(settings.mascotLook(), settings.mascotNotes) {
        WidgetState.saveLumi(widgetContext, settings)
    }
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var createSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var selectedIds by remember { mutableStateOf(emptySet<Long>()) }
    var visibleSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var showAddSheet by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var editingSongId by remember { mutableStateOf<Long?>(null) }
    var pendingDelete by remember { mutableStateOf<List<Song>>(emptyList()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val selecting = selectedIds.isNotEmpty()
    val selectedSongs = remember(songs, selectedIds) { songs.filter { it.id in selectedIds } }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            vm.songsDeleted(pendingDelete.map { it.id }.toSet())
            selectedIds = emptySet()
        }
        pendingDelete = emptyList()
    }

    LaunchedEffect(perm.granted) {
        if (perm.granted) vm.loadSongs() else perm.request()
    }

    BackHandler(enabled = detail != null) { vm.closeDetail() }
    BackHandler(enabled = showNow) { showNow = false }
    BackHandler(enabled = selecting && !showNow && !showSettings) { selectedIds = emptySet() }

    val songActions = remember(lib.favorites, lib.playlists) {
        SongActions(
            favorites = lib.favorites,
            playlists = lib.playlists,
            toggleFavorite = { vm.toggleFavorite(it.id) },
            playNext = { vm.playNext(it) },
            addToQueue = { vm.addToQueue(it) },
            addToPlaylist = { pl, song -> vm.addToPlaylist(pl.id, song.id) },
            newPlaylistWith = { createSongs = listOf(it); showCreate = true },
            edit = { editingSongId = it.id },
        )
    }

    // "Hide bars while scrolling": the dock and/or header slide away when the list moves down and return when it moves up.
    var barsAway by remember { mutableStateOf(false) }
    val hideMode = settings.hideBars
    val hideConnection = remember(hideMode) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (hideMode != HideBars.OFF) {
                    if (available.y < -6f && !barsAway) barsAway = true
                    else if (available.y > 6f && barsAway) barsAway = false
                }
                return Offset.Zero
            }
        }
    }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val miniExtra by animateDpAsState(
        targetValue = if (ui.current != null) 82.dp else 0.dp,
        animationSpec = motion.spatial(),
        label = "miniExtra",
    )
    val modern = settings.uiVersion == UiVersion.CURRENT
    val attachedDock = modern && settings.dockStyle == DockStyle.ATTACHED
    val radial = modern && settings.dockStyle == DockStyle.RADIAL
    val contentPadding = if (modern) {
        PaddingValues(
            top = topInset + modernHeaderHeight(settings) + 8.dp,
            // Radial: the mini player sits beside the corner button, so it adds no height
            bottom = (if (attachedDock) bottomInset + 80.dp else bottomInset + 92.dp) +
                (if (radial) 0.dp else miniExtra.coerceAtLeast(0.dp)),
        )
    } else {
        PaddingValues(
            top = topInset + 82.dp,
            bottom = bottomInset + 84.dp + miniExtra.coerceAtLeast(0.dp),
        )
    }
    val barShape = RoundedCornerShape((settings.corner * 1.2f).dp)
    val editing = lib.playlists.firstOrNull { it.id == editingId }
    val overlayOpen = showNow || showSettings || editing != null
    // Back closes the fan first; a full-screen page or leaving Radial closes it too
    BackHandler(enabled = radialOpen && !overlayOpen) { radialOpen = false }
    LaunchedEffect(overlayOpen, radial) { if (overlayOpen || !radial) radialOpen = false }
    val currentTab = AppTab.entries[tab.coerceIn(0, AppTab.entries.size - 1)]
    val page = Page(currentTab, detail)
    LaunchedEffect(currentTab, detail) {
        if (currentTab != AppTab.SONGS || detail != null) selectedIds = emptySet()
    }
    LaunchedEffect(currentTab, detail, hideMode) { barsAway = false }

    // While the app is in the background nobody sees the progress bar, so the player is checked less often
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) vm.uiVisible = true
            else if (event == Lifecycle.Event.ON_STOP) vm.uiVisible = false
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val coverSeed = if (settings.glowTint == GlowTint.COVER) rememberCoverSeed(ui.current) else null
    val glowState = rememberGlowState(coverSeed, ui.isPlaying)
    CompositionLocalProvider(
        LocalHazeState provides haze,
        LocalSongActions provides songActions,
        LocalGlow provides glowState,
        LocalIsPlaying provides ui.isPlaying,
    ) {
        SharedTransitionLayout(Modifier.fillMaxSize()) {
        // The mini player and the full player are one shared element: opening the player grows it out of the mini player.
        val morph = BoundsTransform { _, _ -> androidx.compose.animation.core.spring(dampingRatio = 0.82f, stiffness = 380f) }
        Box(Modifier.fillMaxSize()) {
            // Everything that bars and panels blur lives inside the haze source.
            Box(Modifier.fillMaxSize().hazeSource(haze).nestedScroll(hideConnection)) {
                CompositionLocalProvider(LocalBackgroundPaused provides overlayOpen) {
                    AuroraBackground(ui.current)
                }
                AnimatedContent(
                    targetState = page,
                    transitionSpec = {
                        val forward = when {
                            initialState.detail == null && targetState.detail != null -> true
                            initialState.detail != null && targetState.detail == null -> false
                            else -> targetState.tab.ordinal > initialState.tab.ordinal
                        }
                        motion.tab(forward)
                    },
                    label = "pages",
                    modifier = Modifier.fillMaxSize(),
                ) { pg ->
                  ContentWidth(PAGE_MAX_WIDTH) {
                    val d = pg.detail
                    if (d != null) {
                        val list = remember(d, songs, lib) { songsFor(d, songs, lib) }
                        DetailScreen(
                            subtitle = when (d.kind) {
                                DetailKind.ALBUM -> list.firstOrNull()?.artist ?: ""
                                DetailKind.ARTIST -> "Artist"
                                DetailKind.FOLDER -> d.key
                                DetailKind.PLAYLIST -> "Playlist"
                                DetailKind.SMART -> "Made for you"
                            },
                            songs = list,
                            padding = contentPadding,
                            currentId = ui.current?.id,
                            playing = ui.isPlaying,
                            onPlay = { s, q -> vm.play(s, q) },
                            onPlayAll = { vm.playAll(it) },
                            onShuffle = { vm.shuffleAll(it) },
                            onRemove = if (d.kind == DetailKind.PLAYLIST) {
                                { song -> vm.removeFromPlaylist(d.key, song.id) }
                            } else null,
                        )
                    } else {
                        when (pg.tab) {
                            AppTab.HOME -> HomeScreen(
                                songs = songs,
                                lib = lib,
                                currentId = ui.current?.id,
                                playing = ui.isPlaying,
                                granted = perm.granted,
                                onRequest = perm.request,
                                padding = contentPadding,
                                onPlay = { s, q -> vm.play(s, q) },
                                onPlayAll = { vm.playAll(it) },
                                onShuffle = { vm.shuffleAll(it) },
                                onOpen = { vm.openDetail(it) },
                            )
                            AppTab.SONGS -> SongsScreen(
                                songs = songs,
                                lib = lib,
                                onUpdate = { vm.updateSettings(it) },
                                currentId = ui.current?.id,
                                playing = ui.isPlaying,
                                granted = perm.granted,
                                onRequest = perm.request,
                                padding = contentPadding,
                                selected = selectedIds,
                                onToggleSelect = { song ->
                                    selectedIds = if (song.id in selectedIds) selectedIds - song.id else selectedIds + song.id
                                },
                                onVisible = { visibleSongs = it },
                                onPlay = { s, q -> vm.play(s, q) },
                                onShuffleAll = { vm.shuffleAll(it) },
                            )
                            AppTab.PLAYLISTS -> PlaylistsScreen(
                                songs = songs,
                                lib = lib,
                                padding = contentPadding,
                                onOpen = { vm.openDetail(it) },
                                onCreate = { createSongs = emptyList(); showCreate = true },
                                onEdit = { editingId = it },
                                onDelete = { vm.deletePlaylist(it) },
                                onPlay = { vm.playAll(it) },
                                onShuffle = { vm.shuffleAll(it) },
                                onPin = { vm.togglePin(it) },
                                onDuplicate = { vm.duplicatePlaylist(it) },
                                onSettings = { vm.updateSettings(it) },
                            )
                            AppTab.ALBUMS -> {
                                val groups = remember(songs) { albumsOf(songs) }
                                AlbumsScreen(groups, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.ALBUM, g.key, g.title))
                                }
                            }
                            AppTab.FOLDERS -> {
                                val groups = remember(songs) { foldersOf(songs) }
                                GroupListScreen(groups, true, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.FOLDER, g.key, g.title))
                                }
                            }
                            AppTab.ARTISTS -> {
                                val groups = remember(songs) { artistsOf(songs) }
                                GroupListScreen(groups, false, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.ARTIST, g.key, g.title))
                                }
                            }
                        }
                    }
                  }
                }
            }

            // Top bar
            val headerAway = barsAway && (hideMode == HideBars.HEADER || hideMode == HideBars.BOTH) && !selecting
            AnimatedVisibility(
                visible = !headerAway,
                enter = slideInVertically(motion.spatial()) { -it } + fadeIn(motion.effects()),
                exit = slideOutVertically(motion.effects()) { -it } + fadeOut(motion.effects()),
                modifier = Modifier.align(Alignment.TopCenter),
            ) {
                if (modern) {
                    ModernHeader(
                        title = detail?.title?.let { verbatim(it) } ?: currentTab.label,
                        onBack = if (detail != null) {
                            { vm.closeDetail() }
                        } else null,
                    ) {
                        val d = detail
                        if (d != null && d.kind == DetailKind.PLAYLIST) {
                            RoundIconButton(Icons.Rounded.Edit, "Customize", { editingId = d.key })
                        } else if (d == null) {
                            RoundIconButton(Icons.Rounded.Settings, "Settings", { showSettings = true })
                        }
                    }
                } else {
                    AuroraTopBar(
                        title = detail?.title?.let { verbatim(it) } ?: currentTab.label,
                        onBack = if (detail != null) {
                            { vm.closeDetail() }
                        } else null,
                        modifier = Modifier
                            .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp)
                            .widthIn(max = PAGE_MAX_WIDTH - 32.dp),
                    ) {
                        val d = detail
                        if (d != null && d.kind == DetailKind.PLAYLIST) {
                            RoundIconButton(Icons.Rounded.Edit, "Customize", { editingId = d.key })
                        } else if (d == null) {
                            RoundIconButton(Icons.Rounded.Settings, "Settings", { showSettings = true })
                        }
                    }
                }
            }

            // Selection bar: replaces the top bar while songs are selected
            AnimatedVisibility(
                visible = selecting,
                enter = fadeIn(motion.effects()),
                exit = fadeOut(motion.effects()),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp)
                    .widthIn(max = PAGE_MAX_WIDTH - 32.dp),
            ) {
                SelectionBar(
                    count = selectedIds.size,
                    shape = barShape,
                    onClose = { selectedIds = emptySet() },
                    onSelectAll = { selectedIds = visibleSongs.map { it.id }.toSet() },
                    onAdd = { showAddSheet = true },
                    onDelete = { confirmDelete = true },
                )
            }

            // Mini player + navigation
            if (radial) {
                RadialDock(
                    tab = currentTab,
                    open = radialOpen,
                    onOpenChange = { radialOpen = it },
                    onSelect = { picked ->
                        tab = picked.ordinal
                        vm.closeDetail()
                    },
                    hideButton = barsAway && (hideMode == HideBars.DOCK || hideMode == HideBars.BOTH),
                ) { slot, narrow ->
                    // The mini player sits beside the corner button and gets shorter while the fan is open
                    AnimatedVisibility(
                        visible = ui.current != null,
                        modifier = slot,
                        enter = motion.miniEnter(),
                        exit = motion.miniExit(),
                    ) {
                        ui.current?.let { song ->
                            AnimatedVisibility(visible = !showNow, enter = fadeIn(), exit = fadeOut()) {
                                val miniModifier = Modifier.sharedBounds(
                                    rememberSharedContentState(key = "player"),
                                    animatedVisibilityScope = this@AnimatedVisibility,
                                    enter = fadeIn(),
                                    exit = fadeOut(),
                                    boundsTransform = morph,
                                    clipInOverlayDuringTransition = OverlayClip(barShape),
                                )
                                ModernMiniPlayer(song, ui.isPlaying, ui.duration, vm, barShape, miniModifier, narrow = narrow) { showNow = true }
                            }
                        }
                    }
                }
            } else {
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(
                            start = if (attachedDock) 0.dp else 12.dp,
                            end = if (attachedDock) 0.dp else 12.dp,
                            bottom = if (attachedDock) 0.dp else bottomInset + 8.dp,
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    AnimatedVisibility(
                        visible = ui.current != null,
                        modifier = Modifier.padding(horizontal = if (attachedDock) 12.dp else 0.dp),
                        enter = motion.miniEnter(),
                        exit = motion.miniExit(),
                    ) {
                        ui.current?.let { song ->
                            AnimatedVisibility(visible = !showNow, enter = fadeIn(), exit = fadeOut()) {
                                val miniModifier = Modifier.sharedBounds(
                                    rememberSharedContentState(key = "player"),
                                    animatedVisibilityScope = this@AnimatedVisibility,
                                    enter = fadeIn(),
                                    exit = fadeOut(),
                                    boundsTransform = morph,
                                    clipInOverlayDuringTransition = OverlayClip(barShape),
                                )
                                if (modern) {
                                    ModernMiniPlayer(song, ui.isPlaying, ui.duration, vm, barShape, miniModifier) { showNow = true }
                                } else {
                                    MiniPlayer(song, ui.isPlaying, ui.duration, vm, barShape, miniModifier) { showNow = true }
                                }
                            }
                        }
                    }
                    val onTabSelect: (AppTab) -> Unit = {
                        tab = it.ordinal
                        vm.closeDetail()
                    }
                    val dockAway = barsAway && (hideMode == HideBars.DOCK || hideMode == HideBars.BOTH)
                    AnimatedVisibility(
                        visible = !dockAway,
                        enter = slideInVertically(motion.spatial()) { it } + fadeIn(motion.effects()),
                        exit = slideOutVertically(motion.effects()) { it } + fadeOut(motion.effects()),
                    ) {
                        if (modern) {
                            ModernDock(tab = currentTab, onSelect = onTabSelect)
                        } else {
                            BottomNav(tab = currentTab, onSelect = onTabSelect)
                        }
                    }
                }

            }
            AnimatedVisibility(
                visible = showNow,
                enter = fadeIn(motion.effects()),
                exit = fadeOut(motion.effects()),
            ) {
                Box(
                    Modifier
                        .sharedBounds(
                            rememberSharedContentState(key = "player"),
                            animatedVisibilityScope = this@AnimatedVisibility,
                            enter = fadeIn(),
                            exit = fadeOut(),
                            boundsTransform = morph,
                            clipInOverlayDuringTransition = OverlayClip(barShape),
                        )
                        .fillMaxSize(),
                ) {
                    NowPlayingScreen(vm) { showNow = false }
                }
            }

            AnimatedVisibility(
                visible = editing != null,
                enter = fadeIn(motion.effects()) + slideInVertically(motion.spatial()) { (it * 0.08f).toInt() },
                exit = fadeOut(motion.effects()) + slideOutVertically(motion.effects()) { (it * 0.08f).toInt() },
            ) {
                if (editing != null) {
                    val byId = allSongs.associateBy { it.id }
                    PlaylistEditor(
                        pl = editing,
                        songs = editing.songIds.mapNotNull { byId[it] },
                        current = ui.current,
                        onUpdate = { t -> vm.updatePlaylist(editing.id, t) },
                        onDelete = {
                            vm.deletePlaylist(editing.id)
                            if (detail?.key == editing.id) vm.closeDetail()
                            editingId = null
                        },
                        onBack = { editingId = null },
                    )
                }
            }

            AnimatedVisibility(
                visible = showSettings,
                enter = fadeIn(motion.effects()) + slideInVertically(motion.spatial()) { (it * 0.08f).toInt() },
                exit = fadeOut(motion.effects()) + slideOutVertically(motion.effects()) { (it * 0.08f).toInt() },
            ) {
                SettingsPage(
                    s = rawSettings,
                    allSongs = allSongs,
                    lib = lib,
                    song = ui.current,
                    onUpdate = { vm.updateSettings(it) },
                    onRescan = { vm.loadSongs() },
                    onBackup = { vm.createBackup() },
                    onRestore = { vm.restoreBackup(it) },
                    onRunSetup = {
                        showSettings = false
                        vm.updateSettings { it.copy(setupDone = false) }
                    },
                    onBack = { showSettings = false },
                )
            }

            if (!settings.tutorialDone) {
                TourOverlay(
                    onTab = { t ->
                        showNow = false
                        showSettings = false
                        if (detail != null) vm.closeDetail()
                        tab = t.ordinal
                    },
                    onDone = { vm.updateSettings { it.copy(tutorialDone = true) } },
                )
            }
        }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "New playlist",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { name ->
                val id = vm.createPlaylist(name, createSongs.map { it.id })
                showCreate = false
                createSongs = emptyList()
                selectedIds = emptySet()
                tab = AppTab.PLAYLISTS.ordinal
                editingId = id
            },
            onDismiss = { showCreate = false; createSongs = emptyList() },
        )
    }

    if (showAddSheet && selecting) {
        AddToPlaylistSheet(
            count = selectedIds.size,
            playlists = lib.playlists,
            onPick = { pl ->
                vm.addSongsToPlaylist(pl.id, selectedSongs.map { it.id })
                Toast.makeText(context, "Added ${selectedSongs.size} to ${pl.name}", Toast.LENGTH_SHORT).show()
                showAddSheet = false
                selectedIds = emptySet()
            },
            onNew = {
                createSongs = selectedSongs
                showAddSheet = false
                showCreate = true
            },
            onDismiss = { showAddSheet = false },
        )
    }

    val editTarget = editingSongId?.let { id -> allSongs.firstOrNull { it.id == id } }
    if (editTarget != null) {
        SongEditSheet(
            song = editTarget,
            onSave = { title, artist, album, newArt, resetArt ->
                vm.saveSongEdit(editTarget, title, artist, album, newArt, resetArt)
                editingSongId = null
            },
            onRestoreAll = {
                vm.restoreSong(editTarget.id)
                editingSongId = null
            },
            onDismiss = { editingSongId = null },
        )
    }

    if (confirmDelete && selecting) {
        val n = selectedSongs.size
        val cs = MaterialTheme.colorScheme
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            shape = RoundedCornerShape((settings.corner * 1.2f).coerceAtLeast(20f).dp),
            containerColor = cs.surfaceContainerHigh,
            title = { Text(if (n == 1) "Delete 1 song?" else "Delete $n songs?") },
            text = { Text("The audio files will be permanently deleted from your phone. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val list = selectedSongs
                    val sender = vm.deleteIntent(list)
                    if (sender != null) {
                        pendingDelete = list
                        deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                    } else {
                        scope.launch {
                            val done = vm.deleteLegacy(list)
                            if (done.isEmpty()) {
                                Toast.makeText(context, "Android did not allow deleting these files.", Toast.LENGTH_LONG).show()
                            } else {
                                vm.songsDeleted(done)
                                selectedIds = emptySet()
                            }
                        }
                    }
                }) { Text("Delete", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    shape: Shape,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onAdd: () -> Unit,
    onDelete: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .finish(shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        RoundIconButton(Icons.Rounded.Close, "Cancel selection", onClose)
        Text(
            "$count selected",
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = 6.dp),
        )
        RoundIconButton(Icons.Rounded.DoneAll, "Select all", onSelectAll)
        RoundIconButton(Icons.Rounded.Add, "Add to playlist", onAdd)
        RoundIconButton(Icons.Rounded.Delete, "Delete", onDelete)
    }
}

@Composable
private fun MiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
) {
    val s = LocalAppSettings.current
    val corner = s.corner
    val artSize = when (s.miniSize) {
        MiniSize.SLIM -> 38.dp
        MiniSize.NORMAL -> 48.dp
        MiniSize.LARGE -> 60.dp
    }
    val pad = if (s.miniSize == MiniSize.SLIM) 6.dp else 10.dp
    val button = when (s.miniSize) {
        MiniSize.SLIM -> 40.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 52.dp
    }
    Column(modifier.widthIn(max = 640.dp).fillMaxWidth().finish(shape).clickable(onClick = onOpen)) {
        Row(Modifier.padding(pad), verticalAlignment = Alignment.CenterVertically) {
            if (s.miniArt) Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((corner * 0.5f).dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    verbatim(song.title),
                    modifier = Modifier.titleMarquee(s.marqueeTitles),
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = if (s.marqueeTitles) TextOverflow.Clip else TextOverflow.Ellipsis,
                )
                Text(
                    verbatim(song.artist),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            PlayPauseButton(
                playing = playing,
                onClick = { vm.togglePlay() },
                modifier = Modifier.size(button),
                iconSize = 20.dp,
                tonal = true,
            )
            if (s.miniSkip) {
                Spacer(Modifier.width(8.dp))
                SkipButton(
                    forward = true,
                    onClick = { vm.next() },
                    modifier = Modifier.size(button),
                    iconSize = 24.dp,
                )
            }
        }
        if (s.miniProgress) MiniProgress(vm, duration)
    }
}

/** Follows the playback position on its own, so the rest of the mini player is not redrawn every 400 ms. */
@Composable
private fun MiniProgress(vm: PlayerViewModel, duration: Long) {
    val pos by vm.position.collectAsState()
    LinearProgressIndicator(
        progress = { if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f },
        modifier = Modifier.fillMaxWidth().height(3.dp),
        color = MaterialTheme.colorScheme.primary,
        trackColor = Color.Transparent,
    )
}
