package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Height of the Current header below the status bar. The large title needs more room. */
fun modernHeaderHeight(s: AppSettings): Dp = if (s.headerStyle == HeaderStyle.LARGE) 92.dp else 64.dp

/** Height of the Current dock (without the system navigation inset). */
val ModernDockHeight: Dp = 68.dp

/**
 * The Current UI's top bar. Large title: a big bold title with a glowing accent bar that fades into the page. Frosted
 * bar: full width and blurred. Clean: just a fade.
 */
@Composable
fun ModernHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val g = LocalGlow.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val large = s.headerStyle == HeaderStyle.LARGE
    val base = modifier.fillMaxWidth().height(topInset + modernHeaderHeight(s))
    val surface = when (s.headerStyle) {
        HeaderStyle.FROSTED -> base.finish(RectangleShape)
        HeaderStyle.CLEAN -> base.background(Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.92f), Color.Transparent)))
        HeaderStyle.LARGE -> base.background(
            Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.96f), cs.background.copy(alpha = 0.80f), Color.Transparent)),
        )
    }
    Row(
        surface.padding(top = topInset + if (large) 8.dp else 0.dp, start = 12.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(8.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        AnimatedContent(
            targetState = title,
            transitionSpec = { motion.text() },
            label = "modernTitle",
            modifier = Modifier.weight(1f),
        ) { t ->
            Column {
                Text(
                    t,
                    style = if (large) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.headlineSmall,
                    fontWeight = if (large) FontWeight.ExtraBold else FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (large) {
                    Spacer(Modifier.height(3.dp))
                    Box(
                        Modifier
                            .size(width = 34.dp, height = 4.dp)
                            .drawBehind {
                                val c = g?.color?.invoke() ?: cs.primary
                                val r = 26.dp.toPx()
                                drawCircle(
                                    Brush.radialGradient(listOf(c.copy(alpha = 0.55f * s.glowStrength.coerceAtMost(1f)), Color.Transparent), center = center, radius = r),
                                    radius = r,
                                    center = center,
                                )
                            }
                            .clip(CircleShape)
                            .background(cs.primary),
                    )
                }
            }
        }
        actions()
    }
}

/**
 * The Current UI's navigation: one slim dock with every tab as an icon. A glowing marker slides to the selected tab
 * with a springy overshoot and the icon lifts. Floating or attached to the screen edge.
 */
@Composable
fun ModernDock(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    val s = LocalAppSettings.current
    val attached = s.dockStyle == DockStyle.ATTACHED
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    if (attached) {
        val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        Box(
            modifier
                .fillMaxWidth()
                .height(ModernDockHeight + bottomInset)
                .glow(shape, s.glowDock)
                .finish(shape),
        ) {
            DockBody(tab, onSelect, Modifier.fillMaxWidth().height(ModernDockHeight).padding(horizontal = 8.dp))
        }
    } else {
        val shape = RoundedCornerShape(percent = 50)
        Box(
            modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .height(ModernDockHeight)
                .glow(shape, s.glowDock)
                .finish(shape),
        ) {
            DockBody(tab, onSelect, Modifier.fillMaxSize().padding(horizontal = 8.dp))
        }
    }
}

/** Label size that ignores the system font scale, so a big font setting cannot push the labels into the icons. */
@Composable
private fun dockLabelSp(): androidx.compose.ui.unit.TextUnit {
    val fs = LocalDensity.current.fontScale
    return (10.5f / fs.coerceAtLeast(1f)).sp
}

@Composable
private fun DockBody(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier) {
    val s = LocalAppSettings.current
    if (s.dockIndicator == DockIndicator.PILL) {
        // Pill: the selected tab grows into a filled capsule with its name inside. Everything else stays a plain icon.
        Row(modifier.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            AppTab.entries.forEach { t -> PillItem(t, t == tab) { onSelect(t) } }
        }
        return
    }
    val cs = MaterialTheme.colorScheme
    val g = LocalGlow.current
    val attached = s.dockStyle == DockStyle.ATTACHED
    val tabs = AppTab.entries
    BoxWithConstraints(modifier) {
        val itemW = maxWidth / tabs.size
        val x by animateDpAsState(
            targetValue = itemW * tab.ordinal,
            animationSpec = spring(dampingRatio = 0.62f, stiffness = 380f),
            label = "dockX",
        )
        // A short bar on the top edge with a soft cone of light under it. The cone fades out before it reaches the
        // icon and never leaves the dock.
        val barY = if (attached) 2.dp else 6.dp
        Box(
            Modifier
                .offset(x = x + (itemW - 64.dp) / 2, y = barY)
                .size(width = 64.dp, height = 34.dp)
                .drawBehind {
                    val c = g?.color?.invoke() ?: cs.primary
                    val a = 0.5f * s.glowStrength.coerceAtMost(1f) * (if (s.glowOn && s.glowDock) 1f else 0f)
                    drawRect(
                        Brush.radialGradient(
                            listOf(c.copy(alpha = a), Color.Transparent),
                            center = Offset(size.width / 2f, 0f),
                            radius = size.width / 2f,
                        ),
                    )
                },
        )
        Box(
            Modifier
                .offset(x = x + (itemW - 24.dp) / 2, y = barY)
                .size(width = 24.dp, height = 3.dp)
                .clip(CircleShape)
                .background(cs.primary),
        )
        Row(Modifier.fillMaxSize().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { t -> DockItem(t, t == tab, Modifier.weight(1f)) { onSelect(t) } }
        }
    }
}

@Composable
private fun DockItem(tab: AppTab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val tint by animateColorAsState(
        targetValue = if (selected) cs.primary else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "dockTint",
    )
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.12f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 420f),
        label = "dockScale",
    )
    val lift by animateFloatAsState(
        targetValue = if (selected) -1.5f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "dockLift",
    )
    val labelSp = dockLabelSp()
    Column(
        modifier
            .fillMaxHeight()
            .padding(bottom = 4.dp, start = 1.dp, end = 1.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(20.dp))
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            tab.icon(),
            contentDescription = tab.label,
            tint = tint,
            modifier = Modifier.size(24.dp).graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationY = lift * density
            },
        )
        if (s.navLabels) {
            Text(
                tab.label,
                color = tint,
                fontSize = labelSp,
                maxLines = 1,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            )
        }
    }
}

/** One tab of the pill dock. The selected one widens into a capsule and shows its name next to the icon. */
@Composable
private fun RowScope.PillItem(tab: AppTab, selected: Boolean, onClick: () -> Unit) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val accent = s.navColor.tonal(cs)
    val showName = selected && s.navLabels
    val weight by animateFloatAsState(
        targetValue = if (showName) 2.4f else if (selected) 1.4f else 1f,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 360f),
        label = "pillWeight",
    )
    val container by animateColorAsState(
        targetValue = if (selected) accent.first.copy(alpha = 0.96f) else Color.Transparent,
        animationSpec = motion.effects(),
        label = "pillContainer",
    )
    val tint by animateColorAsState(
        targetValue = if (selected) accent.second else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "pillTint",
    )
    val labelSp = dockLabelSp()
    Box(
        Modifier
            .weight(weight.coerceAtLeast(0.1f))
            .fillMaxHeight()
            .padding(horizontal = 2.dp)
            .pressScale(source)
            .glow(CircleShape, selected && s.glowDock, 0.5f)
            .clip(CircleShape)
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(tab.icon(), contentDescription = tab.label, tint = tint, modifier = Modifier.size(24.dp))
            if (showName) {
                Spacer(Modifier.width(6.dp))
                Text(
                    tab.label,
                    color = tint,
                    fontSize = (labelSp.value * 1.1f).sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                )
            }
        }
    }
}

/**
 * The Current UI's mini player: a capsule with the cover, the song and a play button wrapped in a progress ring.
 * Follows the same Layout settings as before (size, cover, skip button, progress).
 */
@Composable
fun ModernMiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
) {
    val s = LocalAppSettings.current
    val artSize = when (s.miniSize) {
        MiniSize.SLIM -> 38.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 56.dp
    }
    val pad = if (s.miniSize == MiniSize.SLIM) 6.dp else 8.dp
    val button = when (s.miniSize) {
        MiniSize.SLIM -> 40.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 52.dp
    }
    // Swipe the mini player sideways to skip: right goes back, left goes forward. It follows the finger and springs back.
    var drag by remember { mutableFloatStateOf(0f) }
    val shownDrag by animateFloatAsState(
        targetValue = drag,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "miniDrag",
    )
    val swipe = if (s.miniSwipe) {
        Modifier.pointerInput(song.id) {
            detectHorizontalDragGestures(
                onDragStart = { drag = 0f },
                onDragEnd = {
                    if (drag > 140f) vm.previous() else if (drag < -140f) vm.next()
                    drag = 0f
                },
                onDragCancel = { drag = 0f },
                onHorizontalDrag = { change, amount ->
                    change.consume()
                    drag = (drag + amount).coerceIn(-320f, 320f)
                },
            )
        }
    } else Modifier
    Row(
        modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .graphicsLayer {
                translationX = shownDrag * 0.5f
                alpha = 1f - (abs(shownDrag) / 900f).coerceAtMost(0.3f)
            }
            .glow(shape, s.glowMini, if (playing) 1f else 0.45f)
            .finish(shape)
            .then(swipe)
            .clickable(onClick = onOpen)
            .padding(pad),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((s.corner * 0.55f).dp))
            Spacer(Modifier.width(12.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                verbatim(song.title),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                verbatim(song.artist),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(Modifier.size(button + 8.dp), contentAlignment = Alignment.Center) {
            if (s.miniProgress) ShapeProgress(vm, duration, playing, Modifier.fillMaxSize())
            PlayPauseButton(
                playing = playing,
                onClick = { vm.togglePlay() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 20.dp,
                tonal = true,
                showGlow = false,
            )
        }
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(
                forward = true,
                onClick = { vm.next() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 24.dp,
            )
        }
    }
}

/**
 * A rounded outline of the same shape as the play button (circle, squircle, leaf and so on, following the setting) that
 * fills up with the song's progress, starting at the top and going clockwise. It follows the playback position on its
 * own, so the rest of the mini player is not redrawn every few milliseconds.
 */
@Composable
private fun ShapeProgress(vm: PlayerViewModel, duration: Long, playing: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val corners = rememberPlayCorners(playing)
    val pos by vm.position.collectAsState()
    val progress = if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val measure = remember { PathMeasure() }
    val seg = remember { Path() }
    val color = cs.primary
    val track = color.copy(alpha = 0.16f)
    Canvas(modifier) {
        val stroke = 2.5.dp.toPx()
        val path = shapeOutlinePath(size.width, size.height, stroke / 2f, corners)
        drawPath(path, track, style = Stroke(width = stroke, cap = StrokeCap.Round))
        if (progress > 0.002f) {
            measure.setPath(path, false)
            seg.reset()
            measure.getSegment(0f, measure.length * progress, seg, true)
            drawPath(seg, color, style = Stroke(width = stroke, cap = StrokeCap.Round))
        }
    }
}

/** A rounded rectangle path with a separate radius per corner (as a percentage of the short side), starting at the top middle. */
private fun shapeOutlinePath(w: Float, h: Float, inset: Float, c: PlayCorners): Path {
    val l = inset
    val t = inset
    val r = w - inset
    val b = h - inset
    val m = minOf(r - l, b - t)
    fun rad(p: Float) = (p / 100f * m).coerceIn(0f, m / 2f)
    val rtl = rad(c.tl)
    val rtr = rad(c.tr)
    val rbr = rad(c.br)
    val rbl = rad(c.bl)
    return Path().apply {
        moveTo((l + r) / 2f, t)
        lineTo(r - rtr, t)
        if (rtr > 0f) arcTo(Rect(r - 2 * rtr, t, r, t + 2 * rtr), -90f, 90f, false)
        lineTo(r, b - rbr)
        if (rbr > 0f) arcTo(Rect(r - 2 * rbr, b - 2 * rbr, r, b), 0f, 90f, false)
        lineTo(l + rbl, b)
        if (rbl > 0f) arcTo(Rect(l, b - 2 * rbl, l + 2 * rbl, b), 90f, 90f, false)
        lineTo(l, t + rtl)
        if (rtl > 0f) arcTo(Rect(l, t, l + 2 * rtl, t + 2 * rtl), 180f, 90f, false)
        close()
    }
}

/** The Current Home screen's opening card: greeting, library numbers, a Play all button and Lumi. */
@Composable
fun ModernHomeHero(
    greeting: String?,
    subtitle: String,
    showMascot: Boolean,
    asleep: Boolean,
    drowsy: Boolean,
    playing: Boolean,
    canPlay: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape((s.corner * 1.1f).dp)
    Box(
        Modifier
            .fillMaxWidth()
            .cardGlow(shape)
            .cardFinish(shape)
            .background(
                Brush.linearGradient(
                    listOf(cs.primaryContainer.copy(alpha = 0.65f), cs.tertiaryContainer.copy(alpha = 0.45f)),
                ),
            ),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, top = 18.dp, bottom = 18.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (greeting != null) {
                    Text(
                        greeting,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer,
                    )
                }
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                if (canPlay) {
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = onPlayAll) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Play all", maxLines = 1)
                        }
                        FilledTonalIconButton(onClick = onShuffle) {
                            Icon(Icons.Rounded.Shuffle, "Shuffle", Modifier.size(20.dp))
                        }
                    }
                }
            }
            if (showMascot) {
                AuroraCat(
                    Modifier.size((s.mascotSize * 1.5f).dp),
                    asleep = asleep,
                    drowsy = drowsy,
                    bounce = playing,
                )
            }
        }
    }
}
