package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * The Current UI's player: a round cover with the progress as a ring around it. Drag the ring to seek, double tap the
 * left or right side of the cover to jump 10 seconds, press and hold the cover to favorite. The record spins while music
 * plays and everything glows in the glow colour.
 */
@Composable
fun OrbitPlayer(
    vm: PlayerViewModel,
    ui: PlayerUi,
    lib: LibraryData,
    song: Song?,
    sleepLeft: Long?,
    artScale: Float,
    landscape: Boolean,
    compact: Boolean,
    onClose: () -> Unit,
    onSleep: () -> Unit,
    onSound: () -> Unit,
    onQueue: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalAppSettings.current
    val preview = remember { mutableStateOf<Float?>(null) }
    val mainH = if (compact) 60.dp else 76.dp
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        if (landscape) {
            Column(Modifier.widthIn(max = 1100.dp).fillMaxSize()) {
                OrbitTopBar(song, onClose)
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                        val side = minOf(maxWidth, maxHeight)
                        OrbitDisc(vm, ui, song, artScale, preview, Modifier.size(side))
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically)) {
                        OrbitInfo(song)
                        OrbitTimes(vm, ui, preview)
                        OrbitControls(vm, ui, mainH)
                        OrbitChips(vm, lib, song, sleepLeft, onSleep, onSound, onQueue)
                    }
                }
            }
        } else {
            Column(Modifier.widthIn(max = 560.dp).fillMaxSize()) {
                OrbitTopBar(song, onClose)
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    val side = minOf(maxWidth, maxHeight)
                    OrbitDisc(vm, ui, song, artScale, preview, Modifier.size(side))
                }
                OrbitInfo(song)
                Spacer(Modifier.height(if (compact) 4.dp else 10.dp))
                OrbitTimes(vm, ui, preview)
                Spacer(Modifier.height(if (compact) 2.dp else 8.dp))
                OrbitControls(vm, ui, mainH)
                Spacer(Modifier.height(if (compact) 6.dp else 14.dp))
                OrbitChips(vm, lib, song, sleepLeft, onSleep, onSound, onQueue)
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

@Composable
private fun OrbitTopBar(song: Song?, onClose: () -> Unit) {
    val s = LocalAppSettings.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundIconButton(Icons.Rounded.KeyboardArrowDown, "Close", onClose)
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            if (s.npTopTitle) {
                Text(
                    "NOW PLAYING",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                )
            }
        }
        if (song != null) {
            SongMenu(song, null) { open -> RoundIconButton(Icons.Rounded.MoreVert, "More", open) }
        } else {
            Spacer(Modifier.size(44.dp))
        }
    }
}

private fun ringFraction(o: Offset, w: Float, h: Float): Float {
    var a = atan2(o.y - h / 2f, o.x - w / 2f) + (PI / 2).toFloat()
    if (a < 0f) a += (2 * PI).toFloat()
    return (a / (2 * PI).toFloat()).coerceIn(0f, 1f)
}

/** The cover as a round record inside the progress ring. */
@Composable
private fun OrbitDisc(
    vm: PlayerViewModel,
    ui: PlayerUi,
    song: Song?,
    artScale: Float,
    preview: MutableState<Float?>,
    modifier: Modifier,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val paused = LocalBackgroundPaused.current
    val spinning = s.orbitSpin && ui.isPlaying && !s.batterySaver && !paused
    val angle = remember { mutableFloatStateOf(0f) }
    val spinMs = s.spinFrameMs()
    LaunchedEffect(spinning, spinMs) {
        if (!spinning) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) angle.floatValue = (angle.floatValue + (now - last) / 1_000_000_000f * 14f) % 360f
                last = now
            }
            delay(spinMs)
        }
    }
    var flash by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(flash) {
        if (flash != null) {
            delay(650)
            flash = null
        }
    }
    val duration = ui.duration
    val inset = s.orbitRing.dp + 16.dp
    Box(modifier, contentAlignment = Alignment.Center) {
        OrbitRing(vm, duration, preview, Modifier.fillMaxSize())
        Box(
            Modifier
                .fillMaxSize()
                .padding(inset)
                .graphicsLayer {
                    scaleX = artScale
                    scaleY = artScale
                }
                .glow(CircleShape, s.glowArt, if (ui.isPlaying) 1.3f else 0.5f)
                .pointerInput(song?.id, s.orbitGestures, duration) {
                    if (!s.orbitGestures) return@pointerInput
                    detectTapGestures(
                        onDoubleTap = { o ->
                            val back = o.x < size.width / 2f
                            val to = (vm.position.value + if (back) -10_000L else 10_000L).coerceIn(0L, duration.coerceAtLeast(0L))
                            vm.seekTo(to)
                            flash = if (back) "−10s" else "+10s"
                            haptic()
                        },
                        onLongPress = {
                            song?.let { vm.toggleFavorite(it.id) }
                            flash = "♥"
                            haptic()
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = angle.floatValue }) {
                AnimatedContent(
                    targetState = song?.artUri,
                    transitionSpec = { motion.songChange() },
                    label = "orbitArt",
                    modifier = Modifier.fillMaxSize(),
                ) { uri ->
                    if (uri != null) {
                        Art(uri, Modifier.fillMaxSize(), CircleShape)
                    } else {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(cs.surfaceContainerHigh), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.MusicNote, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(64.dp))
                        }
                    }
                }
            }
            if (s.orbitSpin) {
                Box(
                    Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(cs.background.copy(alpha = 0.9f))
                        .border(2.dp, Color.White.copy(alpha = 0.25f), CircleShape),
                )
            }
            AnimatedVisibility(
                visible = flash != null,
                enter = fadeIn(tween(120)) + scaleIn(initialScale = 0.6f),
                exit = fadeOut(tween(300)),
            ) {
                Box(
                    Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 18.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(verbatim(flash ?: ""), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
            }
        }
    }
}

/** The progress ring. Follows the playback position by itself so only the ring is redrawn while music plays. */
@Composable
private fun OrbitRing(vm: PlayerViewModel, duration: Long, preview: MutableState<Float?>, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val g = LocalGlow.current
    val haptic = rememberHaptic()
    val pos by vm.position.collectAsState()
    val live = if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shown = preview.value ?: live
    val dragging = preview.value != null
    val primary = cs.primary
    val tertiary = cs.tertiary
    val track = cs.onSurface.copy(alpha = 0.12f)
    Canvas(
        modifier
            .pointerInput(duration) {
                detectDragGestures(
                    onDragStart = { o ->
                        preview.value = ringFraction(o, size.width.toFloat(), size.height.toFloat())
                        haptic()
                    },
                    onDragEnd = {
                        preview.value?.let { if (duration > 0) vm.seekTo((it * duration).toLong()) }
                        preview.value = null
                    },
                    onDragCancel = { preview.value = null },
                    onDrag = { change, _ ->
                        change.consume()
                        preview.value = ringFraction(change.position, size.width.toFloat(), size.height.toFloat())
                    },
                )
            }
            .pointerInput(duration) {
                detectTapGestures(
                    onTap = { o ->
                        if (duration > 0) {
                            haptic()
                            vm.seekTo((ringFraction(o, size.width.toFloat(), size.height.toFloat()) * duration).toLong())
                        }
                    },
                )
            },
    ) {
        val stroke = s.orbitRing.dp.toPx()
        val r = (size.minDimension - stroke) / 2f
        val c = center
        val tl = Offset(c.x - r, c.y - r)
        val sz = Size(r * 2f, r * 2f)
        val twoPi = (2 * PI).toFloat()
        when (s.orbitRingStyle) {
            RingStyle.DOTS -> {
                val n = 72
                for (i in 0 until n) {
                    val f = i / n.toFloat()
                    val a = f * twoPi - (PI / 2).toFloat()
                    drawCircle(
                        color = if (f < shown) primary else track,
                        radius = stroke * 0.38f,
                        center = Offset(c.x + cos(a) * r, c.y + sin(a) * r),
                    )
                }
            }
            else -> {
                drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                if (shown > 0.002f) {
                    if (s.glowOn && s.glowArt && g != null) {
                        val a = (0.18f * s.glowStrength * g.pulse.value).coerceIn(0f, 0.6f)
                        drawArc(g.color().copy(alpha = a), -90f, 360f * shown, false, tl, sz, style = Stroke(stroke * 2.4f, cap = StrokeCap.Round))
                    }
                    if (s.orbitRingStyle == RingStyle.GRADIENT) {
                        withTransform({ rotate(-90f, pivot = c) }) {
                            drawArc(
                                Brush.sweepGradient(listOf(primary, tertiary, primary), c),
                                0f,
                                360f * shown,
                                false,
                                tl,
                                sz,
                                style = Stroke(stroke, cap = StrokeCap.Round),
                            )
                        }
                    } else {
                        drawArc(primary, -90f, 360f * shown, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
            }
        }
        // the handle you drag
        val ta = shown * twoPi - (PI / 2).toFloat()
        val tp = Offset(c.x + cos(ta) * r, c.y + sin(ta) * r)
        val k = if (dragging) 1.35f else 1f
        drawCircle(primary.copy(alpha = if (dragging) 0.35f else 0.22f), stroke * 1.7f * k, tp)
        drawCircle(Color.White, stroke * 0.75f * k, tp)
        drawCircle(primary, stroke * 0.4f * k, tp)
    }
}

@Composable
private fun OrbitInfo(song: Song?) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    AnimatedContent(
        targetState = song,
        transitionSpec = { motion.text() },
        label = "orbitInfo",
        modifier = Modifier.fillMaxWidth(),
    ) { sg ->
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            if (sg == null) {
                Text("Nothing playing", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            } else {
                Text(
                    verbatim(sg.title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontSize = MaterialTheme.typography.headlineSmall.fontSize * s.npTitleScale,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    verbatim(sg.artist),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Elapsed time, audio format and time left. While you drag the ring it shows where you would land. */
@Composable
private fun OrbitTimes(vm: PlayerViewModel, ui: PlayerUi, preview: MutableState<Float?>) {
    val cs = MaterialTheme.colorScheme
    val pos by vm.position.collectAsState()
    val shownMs = preview.value?.let { (it * ui.duration).toLong() } ?: pos
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            fmt(shownMs),
            style = MaterialTheme.typography.labelLarge,
            color = if (preview.value != null) cs.primary else cs.onSurfaceVariant,
            fontWeight = if (preview.value != null) FontWeight.Bold else FontWeight.Normal,
        )
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            if (LocalAppSettings.current.npAudioChip && ui.audioInfo.isNotBlank()) FormatChip(ui.audioInfo)
        }
        Text("-" + fmt((ui.duration - shownMs).coerceAtLeast(0L)), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun OrbitControls(vm: PlayerViewModel, ui: PlayerUi, mainH: Dp) {
    val s = LocalAppSettings.current
    val scale = s.npButtonScale
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.npShowShuffle) OrbitToggle(Icons.Rounded.Shuffle, "Shuffle", ui.shuffle) { vm.toggleShuffle() }
        if (s.npShowSkip) {
            SkipButton(forward = false, onClick = { vm.previous() }, modifier = Modifier.size(width = 64.dp * scale, height = (mainH - 14.dp) * scale), iconSize = 30.dp)
        }
        OrbitPlay(ui.isPlaying, (mainH + 10.dp) * scale) { vm.togglePlay() }
        if (s.npShowSkip) {
            SkipButton(forward = true, onClick = { vm.next() }, modifier = Modifier.size(width = 64.dp * scale, height = (mainH - 14.dp) * scale), iconSize = 30.dp)
        }
        if (s.npShowRepeat) {
            OrbitToggle(
                if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                "Repeat",
                ui.repeat != Player.REPEAT_MODE_OFF,
            ) { vm.cycleRepeat() }
        }
    }
}

/** The big play button. Every time you play or pause a ring of glow in the button's own shape expands out of it. */
@Composable
private fun OrbitPlay(playing: Boolean, dim: Dp, onClick: () -> Unit) {
    val g = LocalGlow.current
    val shape = rememberPlayCorners(playing).toShape()
    val burst = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(playing) {
        if (first) {
            first = false
        } else {
            burst.snapTo(0f)
            burst.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
        }
    }
    Box(
        Modifier
            .size(dim)
            .drawBehind {
                val b = burst.value
                if (b < 0.999f && g != null) {
                    val w = size.width
                    val h = size.height
                    val outline = shape.createOutline(size, layoutDirection, this)
                    val sc = 1f + b * 0.4f
                    withTransform({ scale(sc, sc, Offset(w / 2f, h / 2f)) }) {
                        strokeOutline(outline, g.color().copy(alpha = (1f - b) * 0.6f), 4.dp.toPx() * (1f - b))
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        PlayPauseButton(
            playing = playing,
            onClick = onClick,
            modifier = Modifier.fillMaxSize(),
            iconSize = 38.dp,
        )
    }
}

@Composable
private fun OrbitToggle(icon: ImageVector, description: String, active: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(46.dp)
            .pressScale(source)
            .clip(CircleShape)
            .background(if (active) cs.primaryContainer else Color.Transparent)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = if (active) cs.onPrimaryContainer else cs.onSurfaceVariant, modifier = Modifier.size(24.dp))
    }
}

private val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

/** Favorite, queue, sleep timer, sound and a playback speed button that cycles through the usual speeds. */
@Composable
private fun OrbitChips(
    vm: PlayerViewModel,
    lib: LibraryData,
    song: Song?,
    sleepLeft: Long?,
    onSleep: () -> Unit,
    onSound: () -> Unit,
    onQueue: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val fav = song != null && song.id in lib.favorites
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.npShowFav) {
            RoundIconButton(
                icon = if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                description = "Favorite",
                onClick = { song?.let { vm.toggleFavorite(it.id) } },
                tint = if (fav) cs.primary else cs.onSecondaryContainer,
            )
        }
        RoundIconButton(Icons.Rounded.QueueMusic, "Queue", onQueue)
        RoundIconButton(
            Icons.Rounded.Bedtime,
            "Sleep timer",
            onSleep,
            tint = if (sleepLeft != null) cs.primary else cs.onSecondaryContainer,
        )
        RoundIconButton(Icons.Rounded.Tune, "Sound: speed, pitch, equalizer", onSound)
        val speed = s.playbackSpeed
        val source = remember { MutableInteractionSource() }
        Box(
            Modifier
                .height(44.dp)
                .pressScale(source)
                .clip(RoundedCornerShape(percent = 50))
                .background(if (speed != 1f) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.7f))
                .clickable(interactionSource = source, indication = LocalIndication.current) {
                    haptic()
                    val idx = speeds.indexOfFirst { kotlin.math.abs(it - speed) < 0.01f }
                    val next = speeds[(idx + 1) % speeds.size]
                    vm.updateSettings { it.copy(playbackSpeed = next) }
                }
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                verbatim(speedLabel(speed)),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = if (speed != 1f) cs.onPrimaryContainer else cs.onSecondaryContainer,
            )
        }
    }
}

private fun speedLabel(v: Float): String =
    String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.') + "x"
