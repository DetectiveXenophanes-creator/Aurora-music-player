#!/usr/bin/env python3
"""Regenerates SettingsIndex.kt, the list the Settings search uses.

Run it from the project root after changing any settings screen:
    python3 tools/gen_settings_index.py

It scans every `XTab` composable for SettingCard("..."), ToggleRow("..."), SliderRow("...") and
Text("...", style = ...labelLarge) titles. Titles that contain a `$` (built at run time) are skipped.
Add words people might type for a setting in KEYWORDS (by title) or TAB_KEYWORDS (by section).
"""
import re, sys, pathlib

SRC = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java/com/aurora/player"
FILES = ["SettingsScreen.kt", "Themes.kt", "IconsTab.kt"]
OUT = SRC / "SettingsIndex.kt"

FUNC_TO_TAB = {
    "InterfaceTab": "INTERFACE", "GlowTab": "GLOW", "BatteryTab": "BATTERY", "ThemesTab": "THEMES",
    "DesignTab": "DESIGN", "LayoutTab": "LAYOUT", "SeekBarTab": "SEEKBAR", "MascotTab": "MASCOT",
    "CustomizationTab": "CUSTOMIZATION", "AnimationsTab": "ANIMATIONS", "AudioTab": "AUDIO",
    "LibraryTab": "LIBRARY", "HomeTab": "HOME", "PlaylistsTab": "PLAYLISTS", "StartupTab": "STARTUP",
    "PlayerTab": "PLAYER", "BackupTab": "BACKUP", "AboutTab": "ABOUT",
    "IconsTab": "ICONS", "IconPresetsPage": "ICONS", "IconCreatePage": "ICONS",
}

TAB_KEYWORDS = {
    "INTERFACE": "ui look current legacy dock header navigation bar size zoom bigger smaller scale hide scroll marquee scrolling titles mini player orbit radial corner fan circle menu dock tabs outline",
    "GLOW": "light halo shine neon pulse orbs touch effect squish grow",
    "BATTERY": "power saver efficient fps frame rate drain animations paused",
    "THEMES": "colour colours color colors dark light amoled preset accent material you wallpaper",
    "DESIGN": "style surface glass frosted matte soft outlined neon candy paper terminal border navigation",
    "LAYOUT": "rows songs list mini player buttons play button controls arrangement size",
    "SEEKBAR": "progress slider wave wavy squiggle thumb time left",
    "MASCOT": "cat lumi mascot hat glasses scarf ears tail eyes pet name",
    "CUSTOMIZATION": "corners round cover shape font text size pattern background cursive density",
    "ANIMATIONS": "motion speed intensity transition page jelly pop glide dreamy entrance",
    "AUDIO": "sound speed pitch equalizer bass loudness silence eq volume",
    "LIBRARY": "folders scan rescan hidden short songs filter exclude",
    "HOME": "greeting name cards sections hero start page",
    "PLAYLISTS": "grid list big cards order sort pin smart favorites count notes size",
    "STARTUP": "first tab setup tour intro language start",
    "PLAYER": "haptic vibration screen on sleep timer fade stop",
    "BACKUP": "export import restore save playlists settings file",
    "ABOUT": "version reset defaults info",
    "ICONS": "app icon launcher home screen logo colour color picture image upload vector trace shortcut alias",
}

# Extra search words for single titles (English). Matching is case and accent insensitive.
KEYWORDS = {
    "Interface size": "zoom scale bigger smaller density display",
    "Hide bars while scrolling": "autohide immersive dock header scroll",
    "Scrolling titles": "marquee ticker long names",
    "Fade out at the end": "sleep timer volume gentle",
    "Skip silence": "gaps quiet",
    "Text size": "font bigger smaller",
    "Tabs in the dock": "hide show remove tabs pages",
    "Outline on the selected tab": "border line pill highlight",
    "Corner": "left right side radial",
}

def functions(text):
    """Yield (name, body) for each top-level `private fun Name(` / `fun Name(` composable."""
    pat = re.compile(r"^(?:private |internal )?fun (?:<[^>]+> )?(\w+)\(", re.M)
    ms = list(pat.finditer(text))
    for i, m in enumerate(ms):
        end = ms[i + 1].start() if i + 1 < len(ms) else len(text)
        yield m.group(1), text[m.start():end]

STR = r'"((?:\\.|[^"\\\n])+)"'   # a Kotlin string literal that may contain \" escapes
CARD = re.compile(r'SettingCard\(\s*' + STR)
ROW = re.compile(r'(?:ToggleRow|SliderRow)\(\s*' + STR)
LABEL = re.compile(r'Text\(\s*' + STR + r'\s*,\s*style\s*=\s*MaterialTheme\.typography\.labelLarge')

def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')

def main():
    entries, seen = [], set()
    def add(tab, card, title):
        if "$" in title or "$" in card:
            return
        key = (tab, card, title)
        if key in seen:
            return
        seen.add(key)
        entries.append(key)

    # one entry per section so "glow" finds the Glow section itself
    labels = re.findall(r'^\s+(\w+)\("([^"]+)", Icons', (SRC / "SettingsScreen.kt").read_text(), re.M)
    tab_order = [n for n, _ in labels if n in FUNC_TO_TAB.values()]
    for tab in tab_order:
        label = dict(labels)[tab]
        entries.append((tab, "", label)); seen.add((tab, "", label))

    for fname in FILES:
        text = (SRC / fname).read_text()
        for name, body in functions(text):
            tab = FUNC_TO_TAB.get(name)
            if not tab:
                continue
            hits = []
            for rx, kind in ((CARD, "card"), (ROW, "row"), (LABEL, "row")):
                for m in rx.finditer(body):
                    hits.append((m.start(), kind, m.group(1).replace('\\"', '"')))
            hits.sort()
            card = ""
            for _, kind, title in hits:
                if kind == "card":
                    card = title
                    add(tab, card, title)
                else:
                    add(tab, card or title, title)

    lines = [
        "package com.aurora.player",
        "",
        "// GENERATED by tools/gen_settings_index.py. Do not edit by hand: run the script again after changing a settings screen.",
        "",
        "internal val SETTINGS_INDEX: List<SettingEntry> = listOf(",
    ]
    for tab, card, title in entries:
        kw = KEYWORDS.get(title, "")
        if card == "":
            kw = (kw + " " + TAB_KEYWORDS.get(tab, "")).strip()
        extra = f', "{esc(kw)}"' if kw else ""
        lines.append(f'    SettingEntry(SettingsTab.{tab}, "{esc(card)}", "{esc(title)}"{extra}),')
    lines.append(")")
    OUT.write_text("\n".join(lines) + "\n")
    print(f"{len(entries)} entries")
    return entries

if __name__ == "__main__":
    main()
