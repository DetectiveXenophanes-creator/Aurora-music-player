"""Python ports of two pieces of the Atmosphere / Frames code, so they can be checked without a phone.
  eveningFactor(): the warm evening schedule in Atmosphere.kt
  stamp_points(): the perforated stamp outline (StampShape in Frames.kt), same arc maths as Compose Path.arcTo
Run:  python3 tools/atmosphere_check.py   -> prints the schedule and writes stamp_check.png"""
import math

START, END, RAMP = 20 * 60, 6 * 60, 60   # night 20:00 to 06:00, one hour of fade each way

def evening_factor(m):
    if m >= START: return 1.0
    if m >= START - RAMP: return (m - (START - RAMP)) / RAMP
    if m < END: return 1.0
    if m < END + RAMP: return 1.0 - (m - END) / RAMP
    return 0.0

def arc(cx, cy, r, start, sweep, n=16):
    """Compose arcTo: angles in degrees, clockwise from 3 o'clock on a y-down screen."""
    return [(cx + r * math.cos(math.radians(start + sweep * i / n)),
             cy + r * math.sin(math.radians(start + sweep * i / n))) for i in range(n + 1)]

def stamp_points(w, h, pitch):
    nx, ny = max(2, round(w / pitch)), max(2, round(h / pitch))
    sx, sy = w / nx, h / ny
    rx, ry = sx * 0.28, sy * 0.28
    pts = [(0.0, 0.0)]
    for i in range(nx):                      # top edge, left to right
        cx = (i + 0.5) * sx
        pts += arc(cx, 0, rx, 180, -180)
    pts.append((w, 0.0))
    for j in range(ny):                      # right edge, top to bottom
        cy = (j + 0.5) * sy
        pts += arc(w, cy, ry, 270, -180)
    pts.append((w, h))
    for i in reversed(range(nx)):            # bottom edge, right to left
        cx = (i + 0.5) * sx
        pts += arc(cx, h, rx, 0, -180)
    pts.append((0.0, h))
    for j in reversed(range(ny)):            # left edge, bottom to top
        cy = (j + 0.5) * sy
        pts += arc(0, cy, ry, 90, -180)
    return pts

if __name__ == "__main__":
    for hh in (0, 4, 5, 5.5, 6, 6.5, 7, 12, 18, 19, 19.5, 20, 23.5):
        print(f"{int(hh):02d}:{int((hh % 1) * 60):02d}  warm = {evening_factor(int(hh * 60)):.2f}")
    from PIL import Image, ImageDraw
    S = 3
    img = Image.new("RGB", (420 * S, 300 * S), (24, 22, 34)); d = ImageDraw.Draw(img)
    for k, (w, h) in enumerate(((240, 240), (120, 160))):
        ox = 20 + k * 270
        pts = [((ox + x) * S, (30 + y) * S) for x, y in stamp_points(w, h, 16)]
        d.polygon(pts, fill=(251, 247, 239))
        inset = w * 0.09
        d.rectangle([(ox + inset) * S, (30 + inset) * S, (ox + w - inset) * S, (30 + h - inset) * S], fill=(120, 90, 200))
    img.save("stamp_check.png")
