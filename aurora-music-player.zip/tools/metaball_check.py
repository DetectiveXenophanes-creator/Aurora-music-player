"""Python port of the metaball bridge in Backdrop.kt (bridgeInto) and of the blob motion (blobState).
Run:  python3 tools/metaball_check.py   -> writes metaball_pairs.png and prints how often blobs touch.
Keep this file in step with Backdrop.kt: same constants, same maths."""
import math, sys
import numpy as np
from PIL import Image, ImageDraw

BRIDGE_V = 0.5       # BRIDGE_V in Backdrop.kt
BRIDGE_HANDLE = 2.4  # BRIDGE_HANDLE
BRIDGE_REACH = 1.9   # BRIDGE_REACH, bridge exists while d < (r1 + r2) * reach

def clamp(x, lo, hi): return max(lo, min(hi, x))

def bridge(c1, r1, c2, r2):
    """Returns (p1, h1, h3, p3, p4, h4, h2, p2) or None. Path: M p1 C h1 h3 p3 L p4 C h4 h2 p2 Z"""
    dx, dy = c2[0]-c1[0], c2[1]-c1[1]
    d = math.hypot(dx, dy)
    s = r1 + r2
    reach = s * BRIDGE_REACH
    if r1 <= 0 or r2 <= 0 or d >= reach or d <= abs(r1 - r2) or d < 1e-3:
        return None
    far = clamp((d - s) / (reach - s), 0.0, 1.0)
    v = BRIDGE_V * (1.0 - far*far*(3.0 - 2.0*far))      # neck fades to nothing at the reach: no popping
    if d < s:
        u1 = math.acos(clamp((r1*r1 + d*d - r2*r2) / (2*r1*d), -1, 1))
        u2 = math.acos(clamp((r2*r2 + d*d - r1*r1) / (2*r2*d), -1, 1))
    else:
        u1 = u2 = 0.0
    base = math.atan2(dy, dx)
    spread = math.acos(clamp((r1 - r2) / d, -1, 1))
    a1 = base + u1 + (spread - u1) * v
    a2 = base - u1 - (spread - u1) * v
    a3 = base + math.pi - u2 - (math.pi - u2 - spread) * v
    a4 = base - math.pi + u2 + (math.pi - u2 - spread) * v
    def vec(c, a, r): return (c[0] + r*math.cos(a), c[1] + r*math.sin(a))
    p1, p2 = vec(c1, a1, r1), vec(c1, a2, r1)
    p3, p4 = vec(c2, a3, r2), vec(c2, a4, r2)
    d2 = min(v * BRIDGE_HANDLE, math.hypot(p1[0]-p3[0], p1[1]-p3[1]) / s) * min(1.0, d*2.0 / s)
    k1, k2 = r1*d2, r2*d2
    h = math.pi/2
    h1, h2 = vec(p1, a1 - h, k1), vec(p2, a2 + h, k1)
    h3, h4 = vec(p3, a3 + h, k2), vec(p4, a4 - h, k2)
    return p1, h1, h3, p3, p4, h4, h2, p2

def cubic(p0, p1, p2, p3, n=24):
    out = []
    for i in range(n+1):
        t = i/n; m = 1-t
        out.append((m**3*p0[0] + 3*m*m*t*p1[0] + 3*m*t*t*p2[0] + t**3*p3[0],
                    m**3*p0[1] + 3*m*m*t*p1[1] + 3*m*t*t*p2[1] + t**3*p3[1]))
    return out

def bridge_polygon(b):
    p1, h1, h3, p3, p4, h4, h2, p2 = b
    return cubic(p1, h1, h3, p3) + cubic(p4, h4, h2, p2)

# ---- blob motion: same numbers as blobState in Backdrop.kt ----
N = 7
FX = [0.23, 0.31, 0.19, 0.27, 0.35, 0.21, 0.29]
FY = [0.17, 0.25, 0.33, 0.20, 0.28, 0.37, 0.22]
def blob_state(i, t, w, h, scale):
    cx = w * (0.5 + 0.36 * math.sin(t * FX[i] + i * 1.9))
    cy = h * (0.5 + 0.34 * math.cos(t * FY[i] + i * 2.7))
    r = w * (0.085 + 0.012 * (i % 5)) * scale * (1.0 + 0.06 * math.sin(t * 0.5 + i))
    return (cx, cy), r

def draw_pair(draw, c1, r1, c2, r2):
    for c, r in ((c1, r1), (c2, r2)):
        draw.ellipse([c[0]-r, c[1]-r, c[0]+r, c[1]+r], fill=(120, 90, 255))
    b = bridge(c1, r1, c2, r2)
    if b: draw.polygon(bridge_polygon(b), fill=(120, 90, 255))
    return b is not None

def sheet():
    cases = [("touching, equal", 100, 100, 190), ("just apart", 100, 100, 215),
             ("stretching", 100, 100, 260), ("near the reach", 100, 100, 375),
             ("overlapping", 100, 100, 130), ("small + big touching", 60, 110, 165),
             ("small + big apart", 60, 110, 240), ("small inside big", 40, 110, 60)]
    W, H = 520, 300
    img = Image.new("RGB", (W*4, H*2), (14, 12, 28)); dr = ImageDraw.Draw(img)
    for k, (name, r1, r2, d) in enumerate(cases):
        ox, oy = (k % 4) * W, (k // 4) * H
        a = (ox + W/2 - d/2, oy + H/2 + 10); b = (a[0] + d, a[1])
        sub = Image.new("RGB", (W, H), (14, 12, 28)); sd = ImageDraw.Draw(sub)
        # scale so everything fits
        sc = min(1.0, (W - 40) / (d + r1 + r2))
        ca = (W/2 - d*sc/2, H/2 + 10); cb = (ca[0] + d*sc, ca[1])
        joined = draw_pair(sd, ca, r1*sc, cb, r2*sc)
        sd.text((10, 8), f"{name}  d={d}  bridge={'yes' if joined else 'no'}", fill=(220, 220, 255))
        img.paste(sub, (ox, oy))
    img.save("metaball_pairs.png")

def sim():
    w, h = 1080, 2340
    for scale in (0.6, 1.0, 1.6):
        steps = 6000; dt = 0.1   # 10 minutes of drift
        any_join = 0; pairs_total = 0; biggest = 0; none_run = 0; longest_none = 0
        for s in range(steps):
            t = s * dt
            st = [blob_state(i, t, w, h, scale) for i in range(N)]
            j = [[] for _ in range(N)]; n = 0
            for a in range(N):
                for b in range(a+1, N):
                    d = math.hypot(st[a][0][0]-st[b][0][0], st[a][0][1]-st[b][0][1])
                    # "visible" join = the neck is clearly there (blobs touching or very close), not just a thin strand
                    if d < (st[a][1] + st[b][1]) * 1.3 and bridge(st[a][0], st[a][1], st[b][0], st[b][1]):
                        n += 1; j[a].append(b); j[b].append(a)
            pairs_total += n
            if n: any_join += 1; none_run = 0
            else:
                none_run += 1; longest_none = max(longest_none, none_run)
            # biggest connected cluster
            seen = set()
            for a in range(N):
                if a in seen: continue
                comp = {a}; stack = [a]
                while stack:
                    x = stack.pop()
                    for y in j[x]:
                        if y not in comp: comp.add(y); stack.append(y)
                seen |= comp; biggest = max(biggest, len(comp))
        print(f"scale {scale}: a visible join exists {100*any_join/steps:.0f}% of the time, avg joined pairs {pairs_total/steps:.2f}, "
              f"biggest cluster {biggest} blobs, longest gap with nothing joined {longest_none*dt:.0f}s")

def frames():
    w, h = 1080, 2340; sc = 0.3
    img = Image.new("RGB", (int(w*sc)*4, int(h*sc)), (14, 12, 28))
    for k, t in enumerate((0, 37, 74, 111)):
        sub = Image.new("RGB", (int(w*sc), int(h*sc)), (14, 12, 28)); d = ImageDraw.Draw(sub)
        for i in range(N):
            c, r = blob_state(i, t, w, h, 1.0)
            c = (c[0]*sc, c[1]*sc); r *= sc
            d.ellipse([c[0]-r, c[1]-r, c[0]+r, c[1]+r], fill=(120, 90, 255))
        sts = [blob_state(i, t, w, h, 1.0) for i in range(N)]
        for a in range(N):
            for b in range(a+1, N):
                (ca, ra), (cb, rb) = sts[a], sts[b]
                br = bridge((ca[0]*sc, ca[1]*sc), ra*sc, (cb[0]*sc, cb[1]*sc), rb*sc)
                if br: d.polygon(bridge_polygon(br), fill=(120, 90, 255))
        img.paste(sub, (k * int(w*sc), 0))
    img.save("metaball_screen.png")

if __name__ == "__main__":
    sheet(); sim(); frames()
