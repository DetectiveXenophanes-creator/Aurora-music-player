#!/usr/bin/env python3
"""Python port of the pure logic in PlayerLook.kt and Tilt.kt, so it can be tested without a compiler.

    python3 tools/playerlook_check.py
"""
import math

SECTIONS = ["TITLE", "SEEK", "CONTROLS"]

def parse_order(raw):
    out = []
    for part in raw.split(","):
        p = part.strip()
        if p in SECTIONS and p not in out:
            out.append(p)
    for s in SECTIONS:
        if s not in out:
            out.append(s)
    return out

def move_section(raw, sec, delta):
    lst = parse_order(raw)
    frm = lst.index(sec)
    to = frm + delta
    if to < 0 or to >= len(lst):
        return ",".join(lst)
    lst[to], lst[frm] = lst[frm], lst[to]
    return ",".join(lst)

def stack_words(text):
    words = [w for w in text.strip().split(" ") if w]
    if len(words) < 2:
        return text
    cut = (len(words) + 1) // 2
    return " ".join(words[:cut]) + "\n" + " ".join(words[cut:])

def check(name, got, want):
    ok = got == want
    print(("ok   " if ok else "FAIL ") + name + ("" if ok else f"  got={got!r} want={want!r}"))
    return ok

class Tilt:
    """Same maths as TiltListener."""
    FULL = 20.0
    def __init__(self, max_deg=8.0):
        self.max = max_deg
        self.g = None
        self.have = False
        self.np = self.nr = 0.0
        self.rx = self.ry = self.shine = 0.0
    def feed(self, a, dt=0.02):
        if self.g is None:
            self.g = list(a)
        k = 1 - math.exp(-dt / 0.08)
        self.g = [g + (x - g) * k for g, x in zip(self.g, a)]
        gx, gy, gz = self.g
        n = math.sqrt(gx*gx + gy*gy + gz*gz)
        if n < 1:
            return
        if gy > 0.25 * n:
            pitch = math.degrees(math.atan2(gz, gy))
            roll = math.degrees(math.atan2(gx, gy))
            if not self.have:
                self.np, self.nr, self.have = pitch, roll, True
            m = 1 - math.exp(-dt / 4.0)
            self.np += (pitch - self.np) * m
            self.nr += (roll - self.nr) * m
            self.rx = max(-self.max, min(self.max, (pitch - self.np) / self.FULL * self.max))
            self.ry = max(-self.max, min(self.max, (roll - self.nr) / self.FULL * self.max))
            self.shine = max(-1, min(1, (roll - self.nr) / self.FULL))
        else:
            self.have = False
            self.rx *= 0.9; self.ry *= 0.9; self.shine *= 0.9

def vec(pitch_deg, roll_deg):
    """Gravity as the accelerometer reports it for a phone held upright then pitched / rolled."""
    p, r = math.radians(pitch_deg), math.radians(roll_deg)
    gy = 9.81 * math.cos(p) * math.cos(r)
    gz = 9.81 * math.sin(p) * math.cos(r)
    gx = 9.81 * math.sin(r)
    return (gx, gy, gz)

def main():
    ok = True
    ok &= check("default order", parse_order("TITLE,SEEK,CONTROLS"), SECTIONS)
    ok &= check("empty text repairs", parse_order(""), SECTIONS)
    ok &= check("junk repairs", parse_order("FOO,,SEEK,SEEK,BAR"), ["SEEK", "TITLE", "CONTROLS"])
    ok &= check("missing added at end", parse_order("CONTROLS"), ["CONTROLS", "TITLE", "SEEK"])
    ok &= check("spaces ok", parse_order(" CONTROLS , TITLE "), ["CONTROLS", "TITLE", "SEEK"])
    ok &= check("move down", move_section("TITLE,SEEK,CONTROLS", "TITLE", 1), "SEEK,TITLE,CONTROLS")
    ok &= check("move up", move_section("TITLE,SEEK,CONTROLS", "CONTROLS", -1), "TITLE,CONTROLS,SEEK")
    ok &= check("cannot move first up", move_section("TITLE,SEEK,CONTROLS", "TITLE", -1), "TITLE,SEEK,CONTROLS")
    ok &= check("cannot move last down", move_section("TITLE,SEEK,CONTROLS", "CONTROLS", 1), "TITLE,SEEK,CONTROLS")
    import itertools
    perms = set(",".join(p) for p in itertools.permutations(SECTIONS))
    reach = set(["TITLE,SEEK,CONTROLS"]); frontier = list(reach)
    while frontier:
        cur = frontier.pop()
        for s in SECTIONS:
            for d in (-1, 1):
                n = move_section(cur, s, d)
                if n not in reach:
                    reach.add(n); frontier.append(n)
    ok &= check("all 6 orders reachable and valid", reach, perms)
    ok &= check("stack 4 words", stack_words("Dancing in the Dark"), "Dancing in\nthe Dark")
    ok &= check("stack 3 words", stack_words("Blue Monday Remix"), "Blue Monday\nRemix")
    ok &= check("stack 1 word", stack_words("Intro"), "Intro")

    # steady hold settles flat
    t = Tilt()
    for _ in range(50 * 12):
        t.feed(vec(40, 5))
    ok &= check("steady hold settles flat", (abs(t.rx) < 0.3 and abs(t.ry) < 0.3), True)
    # a quick lean right shows a turn, never more than max
    for _ in range(25):
        t.feed(vec(40, 5 + 25))
    ok &= check("quick roll turns the cover", abs(t.ry) > 3.0, True)
    ok &= check("never above max", max(abs(t.rx), abs(t.ry)) <= 8.0 + 1e-6, True)
    ok &= check("shine moves", abs(t.shine) > 0.3, True)
    # then it settles again
    for _ in range(50 * 15):
        t.feed(vec(40, 30))
    ok &= check("settles again after a lean", abs(t.ry) < 0.4, True)
    # lying flat eases to zero
    for _ in range(100):
        t.feed((0.0, 0.2, 9.8))
    ok &= check("flat on a table eases to rest", abs(t.rx) < 0.05 and abs(t.ry) < 0.05, True)
    # landscape also eases to rest
    t2 = Tilt()
    for _ in range(100):
        t2.feed(vec(40, 0))
    for _ in range(100):
        t2.feed((9.8, 0.3, 0.5))
    ok &= check("landscape eases to rest", abs(t2.rx) < 0.05 and abs(t2.ry) < 0.05, True)
    # strength 0.3 limits to 2.4 degrees
    t3 = Tilt(8.0 * 0.3)
    for _ in range(30):
        t3.feed(vec(40, 0))
    for _ in range(25):
        t3.feed(vec(40, 60))
    ok &= check("strength 0.3 stays under 2.4 deg", max(abs(t3.rx), abs(t3.ry)) <= 2.4 + 1e-6, True)
    print("ALL OK" if ok else "SOME FAILED")
    raise SystemExit(0 if ok else 1)

if __name__ == "__main__":
    main()
