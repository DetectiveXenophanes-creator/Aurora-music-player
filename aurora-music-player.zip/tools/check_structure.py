#!/usr/bin/env python3
"""Cheap structural checks (there is no Kotlin compiler in the sandbox): bracket balance, duplicate imports,
duplicate top-level declarations. Run: python3 tools/check_structure.py"""
import re, pathlib, sys, collections
SRC = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java/com/aurora/player"
bad = 0
def strip(s):
    s = re.sub(r'""".*?"""', '""', s, flags=re.S)
    s = re.sub(r'//[^\n]*', '', s)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r"'(\\.|[^'\\])'", "' '", s)
    s = re.sub(r'"(\\.|[^"\\\n])*"', '""', s)
    return s
for f in sorted(SRC.glob("*.kt")):
    raw = f.read_text()
    s = strip(raw)
    for a, b in ("()", "{}", "[]"):
        if s.count(a) != s.count(b):
            print(f"{f.name}: unbalanced {a}{b}: {s.count(a)} vs {s.count(b)}"); bad += 1
    imps = re.findall(r"^import (\S+)", raw, re.M)
    for k, v in collections.Counter(imps).items():
        if v > 1: print(f"{f.name}: duplicate import {k}"); bad += 1
    decl = re.findall(r"^(?:private |internal |public )?(?:fun|class|object|enum class|data class|val|const val|typealias) (?:<[^>]+> )?(\w+)", raw, re.M)
    for k, v in collections.Counter(decl).items():
        if v > 1 and not k.startswith("TABLE"): print(f"{f.name}: duplicate top-level {k} x{v}"); bad += 1
print("ok" if not bad else f"{bad} problem(s)")
