package com.aurora.player

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import kotlin.math.roundToInt

/** Built-in colour themes. Each one is just a seed colour plus a few knobs, so they are tiny and cheap to apply. */
val presetThemes: List<CustomTheme> = listOf(
    CustomTheme("p_borealis", "Aurora Borealis", 0xFF2EE6A6.toInt(), 1.6f, 1.1f, ThemeMode.DARK, true),
    CustomTheme("p_midnight", "Midnight", 0xFF8B7BFF.toInt(), 1.0f, 1.0f, ThemeMode.DARK, true),
    CustomTheme("p_sunset", "Sunset", 0xFFFF7A45.toInt(), -1.0f, 1.0f, ThemeMode.DARK, false),
    CustomTheme("p_ocean", "Ocean", 0xFF2D9CFF.toInt(), -0.8f, 1.0f, ThemeMode.DARK, false),
    CustomTheme("p_forest", "Forest", 0xFF4CAF50.toInt(), 0.8f, 0.9f, ThemeMode.DARK, false),
    CustomTheme("p_synthwave", "Synthwave", 0xFFB026FF.toInt(), -1.2f, 1.2f, ThemeMode.DARK, true),
    CustomTheme("p_ember", "Ember", 0xFFFF5252.toInt(), 0.8f, 1.0f, ThemeMode.DARK, true),
    CustomTheme("p_golden", "Golden hour", 0xFFFFC107.toInt(), -0.5f, 1.0f, ThemeMode.DARK, false),
    CustomTheme("p_mono", "Mono", 0xFF9E9E9E.toInt(), 1.0f, 0.0f, ThemeMode.DARK, true),
    CustomTheme("p_sakura", "Sakura", 0xFFFF8FB8.toInt(), 0.6f, 1.0f, ThemeMode.LIGHT, false),
    CustomTheme("p_lavender", "Lavender", 0xFF9575CD.toInt(), 1.0f, 1.0f, ThemeMode.LIGHT, false),
    CustomTheme("p_mint", "Mint", 0xFF1FBF9A.toInt(), 1.0f, 1.0f, ThemeMode.LIGHT, false),
    CustomTheme("p_paper", "Paper", 0xFF8D6E63.toInt(), 0.5f, 0.25f, ThemeMode.LIGHT, false),
    CustomTheme("p_bubblegum", "Bubblegum", 0xFFFF4DA6.toInt(), 0.8f, 1.2f, ThemeMode.LIGHT, false),
    CustomTheme("p_cotton", "Cotton candy", 0xFF7FD1FF.toInt(), -1.4f, 0.9f, ThemeMode.LIGHT, false),
    CustomTheme("p_lava", "Lava lamp", 0xFFFF3D00.toInt(), -1.6f, 1.2f, ThemeMode.DARK, true),
    CustomTheme("p_deepsea", "Deep sea", 0xFF00B8D4.toInt(), 0.6f, 1.0f, ThemeMode.DARK, true),
    CustomTheme("p_matcha", "Matcha latte", 0xFF8BC34A.toInt(), 0.4f, 0.55f, ThemeMode.LIGHT, false),
    CustomTheme("p_cyber", "Cyber lime", 0xFFC6FF00.toInt(), -1.2f, 1.1f, ThemeMode.DARK, true),
    CustomTheme("p_peach", "Peach fizz", 0xFFFF8A65.toInt(), 1.0f, 0.9f, ThemeMode.LIGHT, false),
    CustomTheme("p_galaxy", "Galaxy", 0xFF6A5CFF.toInt(), -2.0f, 1.3f, ThemeMode.DARK, true),
)

private val quickAccents = listOf(
    0xFFE53935, 0xFFFF7043, 0xFFFFB300, 0xFF7CB342, 0xFF2EE6A6, 0xFF00ACC1,
    0xFF1E88E5, 0xFF5C6BC0, 0xFF8E24AA, 0xFFD81B60, 0xFF8D6E63, 0xFF90A4AE,
).map { it.toInt() }

fun AppSettings.withTheme(t: CustomTheme): AppSettings = copy(
    accent = t.accent,
    spread = t.spread,
    vibrancy = t.vibrancy,
    themeMode = t.mode,
    amoled = t.amoled,
    dynamicColor = false,
    activeTheme = t.id,
)

private fun hueOf(argb: Int): Float {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, hsv)
    return hsv[0]
}

private fun accentFromHue(h: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 360f), 0.65f, 0.95f))

private const val THEME_CODE_PREFIX = "aurora-theme:"

@Composable
fun ThemesTab(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    var name by remember { mutableStateOf("") }
    var codeMessage by remember { mutableStateOf<String?>(null) }
    val dynamicActive = s.dynamicColor && canDynamic

    SettingCard("Mode") {
        Segmented(
            options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
            selected = s.themeMode,
            onSelect = { v -> onUpdate { it.copy(themeMode = v) } },
        )
        ToggleRow("True black (AMOLED)", "Pure black backgrounds in dark mode", s.amoled, true) { v ->
            onUpdate { it.copy(amoled = v) }
        }
    }

    SettingCard("Presets") {
        if (canDynamic) {
            val dyn = if (s.themeMode == ThemeMode.LIGHT) dynamicLightColorScheme(context) else dynamicDarkColorScheme(context)
            ThemeCard(
                name = "Material You (wallpaper)",
                colors = listOf(dyn.primary, dyn.secondary, dyn.tertiary),
                bg = dyn.surfaceContainer,
                fg = dyn.onSurface,
                selected = dynamicActive,
                modifier = Modifier.fillMaxWidth(),
            ) { onUpdate { it.copy(dynamicColor = true, activeTheme = "dynamic") } }
        }
        presetThemes.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    PresetCard(t, selected = !dynamicActive && s.activeTheme == t.id, modifier = Modifier.weight(1f)) {
                        onUpdate { it.withTheme(t) }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }

    if (s.customThemes.isNotEmpty()) {
        SettingCard("My themes") {
            s.customThemes.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { t ->
                        PresetCard(
                            t,
                            selected = !dynamicActive && s.activeTheme == t.id,
                            modifier = Modifier.weight(1f),
                            onDelete = {
                                onUpdate { cur ->
                                    cur.copy(
                                        customThemes = cur.customThemes.filter { it.id != t.id },
                                        activeTheme = if (cur.activeTheme == t.id) "" else cur.activeTheme,
                                    )
                                }
                            },
                        ) { onUpdate { it.withTheme(t) } }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }

    SettingCard("Create your own") {
        // live preview of the colours you are building
        val dark = s.themeMode != ThemeMode.LIGHT
        val scheme = remember(s.accent, s.spread, s.vibrancy, dark) { seedScheme(Color(s.accent), dark, s.spread, s.vibrancy) }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(scheme.surfaceContainer)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            listOf(scheme.primary, scheme.secondary, scheme.tertiary, scheme.primaryContainer).forEach {
                Box(Modifier.size(34.dp).clip(CircleShape).background(it))
            }
            Spacer(Modifier.weight(1f))
            Text("Preview", style = MaterialTheme.typography.labelLarge, color = scheme.onSurface)
        }

        val hue = remember(s.accent) { hueOf(s.accent) }
        Box(
            Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(CircleShape)
                .background(
                    Brush.horizontalGradient(
                        listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color(accentFromHue(it)) }
                    )
                )
        )
        SliderRow("Hue", hue, 0f..360f, "${hue.roundToInt()}°") { v ->
            onUpdate { it.copy(accent = accentFromHue(v), dynamicColor = false, activeTheme = "") }
        }
        SliderRow("Vibrancy", s.vibrancy, 0f..1.4f, "${(s.vibrancy * 100).roundToInt()}%") { v ->
            onUpdate { it.copy(vibrancy = (v * 20).roundToInt() / 20f, dynamicColor = false, activeTheme = "") }
        }
        SliderRow("Colour spread", s.spread, -3f..3f, "%+.1f".format(s.spread)) { v ->
            onUpdate { it.copy(spread = (v * 10).roundToInt() / 10f, dynamicColor = false, activeTheme = "") }
        }
        Text("Quick accent", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            quickAccents.forEach { c ->
                val picked = !dynamicActive && s.accent == c
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (picked) 3.dp else 0.dp, cs.onSurface, CircleShape)
                        .clickable { onUpdate { it.copy(accent = c, dynamicColor = false, activeTheme = "") } }
                )
            }
        }

        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24) },
            singleLine = true,
            label = { Text("Theme name") },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                enabled = name.isNotBlank(),
                onClick = {
                    val t = CustomTheme(
                        id = "c" + System.currentTimeMillis(),
                        name = name.trim(),
                        accent = s.accent,
                        spread = s.spread,
                        vibrancy = s.vibrancy,
                        mode = s.themeMode,
                        amoled = s.amoled,
                    )
                    onUpdate { it.copy(customThemes = it.customThemes + t, activeTheme = t.id, dynamicColor = false) }
                    name = ""
                },
            ) { Text("Save theme") }
            OutlinedButton(onClick = {
                val t = CustomTheme("share", name.ifBlank { "Shared theme" }, s.accent, s.spread, s.vibrancy, s.themeMode, s.amoled)
                clipboard.setText(AnnotatedString(THEME_CODE_PREFIX + themeToJson(t).toString()))
                codeMessage = "Theme code copied."
            }) { Text("Copy code") }
            OutlinedButton(onClick = {
                val raw = clipboard.getText()?.text.orEmpty().trim()
                val parsed = if (raw.startsWith(THEME_CODE_PREFIX)) {
                    runCatching { themeFromJson(JSONObject(raw.removePrefix(THEME_CODE_PREFIX))) }.getOrNull()
                } else null
                if (parsed == null) {
                    codeMessage = "No theme code found on the clipboard."
                } else {
                    val t = parsed.copy(id = "c" + System.currentTimeMillis())
                    onUpdate { it.copy(customThemes = it.customThemes + t).withTheme(t) }
                    codeMessage = "Theme added."
                }
            }) { Text("Paste code") }
        }
        codeMessage?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = cs.primary)
        }
        Text(
            "A theme code is a short piece of text. Send it to a friend and they can paste it to get the same colours.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }
}

@Composable
private fun PresetCard(
    t: CustomTheme,
    selected: Boolean,
    modifier: Modifier,
    onDelete: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val dark = t.mode != ThemeMode.LIGHT
    val scheme = remember(t) { seedScheme(Color(t.accent), dark, t.spread, t.vibrancy) }
    ThemeCard(
        name = t.name,
        colors = listOf(scheme.primary, scheme.secondary, scheme.tertiary),
        bg = if (dark && t.amoled) Color(0xFF0C0C0C) else scheme.surfaceContainer,
        fg = scheme.onSurface,
        selected = selected,
        modifier = modifier,
        onDelete = onDelete,
        onClick = onClick,
    )
}

@Composable
private fun ThemeCard(
    name: String,
    colors: List<Color>,
    bg: Color,
    fg: Color,
    selected: Boolean,
    modifier: Modifier,
    onDelete: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(bg)
            .border(BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row {
                colors.forEachIndexed { i, c ->
                    Box(
                        Modifier
                            .offset(x = (-8 * i).dp)
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(2.dp, bg, CircleShape)
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            if (selected) {
                Icon(Icons.Rounded.Check, null, tint = fg, modifier = Modifier.size(20.dp))
            }
            if (onDelete != null) {
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Rounded.Close,
                    "Delete theme",
                    tint = fg.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp).clickable(onClick = onDelete),
                )
            }
        }
        androidx.compose.material3.Text(
            tr(name),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
