package com.aurora.player

import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun rememberHaptic(): () -> Unit {
    val h = LocalHapticFeedback.current
    val on = LocalAppSettings.current.haptics
    return remember(h, on) {
        {
            if (on) h.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }
}

/** Squishes the element while it is pressed. Strength depends on the animation set and intensity. */
@Composable
fun Modifier.pressScale(source: InteractionSource): Modifier {
    val motion = LocalMotion.current
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) motion.pressScale else 1f,
        animationSpec = motion.spatial(),
        label = "press",
    )
    return this.graphicsLayer {
        scaleX = s
        scaleY = s
    }
}

/** Fade and rise in, staggered by index. Only used for the first rows that appear. */
@Composable
fun Modifier.enterAnim(enabled: Boolean, index: Int): Modifier {
    val motion = LocalMotion.current
    if (!enabled || !motion.enabled) return this
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((index.coerceAtMost(12) * motion.staggerMs).toLong())
        p.animateTo(1f, motion.spatial())
    }
    return this.graphicsLayer {
        alpha = p.value.coerceIn(0f, 1f)
        translationY = (1f - p.value) * 40f * motion.travel
    }
}

/** A small springy pop: starts a little smaller, overshoots, then settles. Used by the intro, setup and tutorial. */
@Composable
fun Modifier.popIn(delayMs: Int = 0): Modifier {
    val sc = remember { Animatable(0.6f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        sc.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.42f, stiffness = 200f))
    }
    return this.graphicsLayer {
        scaleX = sc.value
        scaleY = sc.value
        alpha = ((sc.value - 0.6f) / 0.3f).coerceIn(0f, 1f)
    }
}

// ---------------------------------------------------------------- play / pause

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

private val pauseLeft = floatArrayOf(0f, 0f, 0.36f, 0f, 0.36f, 1f, 0f, 1f)
private val playLeft = floatArrayOf(0f, 0f, 0.5f, 0.25f, 0.5f, 0.75f, 0f, 1f)
private val pauseRight = floatArrayOf(0.64f, 0f, 1f, 0f, 1f, 1f, 0.64f, 1f)
private val playRight = floatArrayOf(0.5f, 0.25f, 1f, 0.5f, 1f, 0.5f, 0.5f, 0.75f)

private fun DrawScope.morphQuad(a: FloatArray, b: FloatArray, t: Float, shiftX: Float, color: Color, inset: Float) {
    val path = Path()
    val w = size.width - 2 * inset
    val h = size.height - 2 * inset
    for (i in 0 until 4) {
        val x = inset + lerpF(a[i * 2], b[i * 2], t) * w + shiftX
        val y = inset + lerpF(a[i * 2 + 1], b[i * 2 + 1], t) * h
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color)
    // A round-joined outline softens every corner of the icon.
    drawPath(path, color, style = Stroke(width = inset * 1.2f, join = StrokeJoin.Round))
}

/** Pause bars that morph into a rounded play triangle (and back). */
@Composable
fun PlayPauseIcon(playing: Boolean, tint: Color, iconSize: Dp) {
    val motion = LocalMotion.current
    val t by animateFloatAsState(
        targetValue = if (playing) 0f else 1f,
        animationSpec = motion.spatial(),
        label = "playPauseMorph",
    )
    Canvas(Modifier.size(iconSize)) {
        val inset = size.width * 0.14f
        val shift = t * size.width * 0.04f
        morphQuad(pauseLeft, playLeft, t, shift, tint, inset)
        morphQuad(pauseRight, playRight, t, shift, tint, inset)
    }
}

/** Size comes from [modifier]. The shape morphs from circle/pill to squircle when playing. */
@Composable
fun PlayPauseButton(
    playing: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 36.dp,
    tonal: Boolean = false,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val pct by animateFloatAsState(
        targetValue = when (s.playShape) {
            PlayShape.CIRCLE -> 50f
            PlayShape.SQUIRCLE -> 32f
            PlayShape.MORPH -> if (playing) 32f else 50f
        },
        animationSpec = motion.spatial(),
        label = "playShape",
    )
    val shape = RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50))
    val container = if (tonal) cs.primaryContainer else cs.primary
    val content = if (tonal) cs.onPrimaryContainer else cs.onPrimary
    Box(
        modifier
            .pressScale(source)
            .clip(shape)
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        PlayPauseIcon(playing, content, iconSize)
    }
}

// ---------------------------------------------------------------- skip

/** Pill shaped skip button. Size comes from [modifier]. The icon slides out and back in when tapped. */
@Composable
fun SkipButton(
    forward: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 30.dp,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val scope = rememberCoroutineScope()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val basePct = LocalAppSettings.current.buttonShape.pct
    val pct by animateFloatAsState(
        targetValue = if (pressed) basePct * 0.6f else basePct,
        animationSpec = motion.spatial(),
        label = "skipShape",
    )
    val nudge = remember { Animatable(0f) }
    val dist = with(LocalDensity.current) { (14.dp * motion.travel.coerceAtLeast(0.3f)).toPx() }
    val dir = if (forward) 1f else -1f

    Box(
        modifier
            .pressScale(source)
            .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
            .background(cs.secondaryContainer)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
                if (motion.enabled) {
                    scope.launch {
                        nudge.snapTo(0f)
                        nudge.animateTo(dir * dist, tween(120))
                        nudge.snapTo(-dir * dist)
                        nudge.animateTo(0f, motion.spatial())
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (forward) Icons.Rounded.SkipNext else Icons.Rounded.SkipPrevious,
            contentDescription = if (forward) "Next" else "Previous",
            tint = cs.onSecondaryContainer,
            modifier = Modifier
                .size(iconSize)
                .graphicsLayer {
                    translationX = nudge.value
                    alpha = (1f - abs(nudge.value) / dist).coerceIn(0f, 1f)
                },
        )
    }
}

/** Wide pill toggle (shuffle, repeat, favourite). Size comes from [modifier]. */
@Composable
fun ActionPill(
    active: Boolean,
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val container by animateColorAsState(
        targetValue = if (active) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.6f),
        animationSpec = motion.effects(),
        label = "pillContainer",
    )
    val tint by animateColorAsState(
        targetValue = if (active) cs.onPrimaryContainer else cs.onSecondaryContainer,
        animationSpec = motion.effects(),
        label = "pillTint",
    )
    val basePct = LocalAppSettings.current.buttonShape.pct
    val pct by animateFloatAsState(
        targetValue = if (active) basePct * 0.64f else basePct,
        animationSpec = motion.spatial(),
        label = "pillShape",
    )
    Box(
        modifier
            .pressScale(source)
            .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = tint)
    }
}

/** Small tonal rounded-square button used in top bars. */
@Composable
fun RoundIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSecondaryContainer,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(44.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(percent = (LocalAppSettings.current.buttonShape.pct * 0.72f).roundToInt()))
            .background(cs.secondaryContainer.copy(alpha = 0.7f))
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun FormatChip(text: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(cs.secondaryContainer.copy(alpha = 0.7f))
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = cs.onSecondaryContainer, maxLines = 1)
    }
}

// ---------------------------------------------------------------- equalizer

@Composable
fun EqualizerBars(active: Boolean, color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(
        0.25f, 1f,
        infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "a",
    )
    val b by t.animateFloat(
        0.30f, 1f,
        infiniteRepeatable(tween(690, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b",
    )
    val c by t.animateFloat(
        0.20f, 1f,
        infiniteRepeatable(tween(410, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "c",
    )
    val level by animateFloatAsState(if (active) 1f else 0f, animationSpec = tween(250), label = "eqLevel")
    Canvas(modifier) {
        val bw = size.width / 5f
        val hs = floatArrayOf(a, b, c)
        for (i in 0 until 3) {
            val hh = size.height * (0.25f + (hs[i] - 0.25f) * level)
            drawRoundRect(
                color,
                topLeft = Offset(bw * i * 2f, size.height - hh),
                size = Size(bw, hh),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}

// ---------------------------------------------------------------- seek bar

private fun fracOf(x: Float, width: Int, pad: Float): Float =
    if (width <= 2 * pad) 0f else ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)

private fun smooth(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

private fun hash01(i: Int): Float {
    var h = i * 374761393 + 668265263
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0xFFFF) / 65535f
}

private fun wavePath(
    x0: Float,
    x1: Float,
    calmLo: Float,
    calmHi: Float,
    cy: Float,
    ampPx: Float,
    wavelength: Float,
    edge: Float,
    phase: Float,
): Path {
    val path = Path()
    path.moveTo(x0, cy)
    var px = x0
    while (px < x1) {
        px = min(px + 3f, x1)
        val calm = min(smooth((px - calmLo) / edge), smooth((calmHi - px) / edge))
        path.lineTo(px, cy + ampPx * calm * sin((px - calmLo) / wavelength * 2f * PI.toFloat() - phase))
    }
    return path
}

/**
 * Seek bar with eight looks (Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars, Steps). Thickness, thumb shape,
 * colour and wave size come from settings. Only Wavy and Squiggle animate, and only while playing, so every other
 * style costs no frames at all.
 */
@Composable
fun SeekBar(
    progress: Float,
    playing: Boolean,
    onPreview: (Float?) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val s = LocalAppSettings.current
    val style = s.seekStyle
    val moving = style == SeekStyle.WAVY || style == SeekStyle.SQUIGGLE
    var dragging by remember { mutableStateOf<Float?>(null) }
    val currentOnSeek by rememberUpdatedState(onSeek)
    val currentOnPreview by rememberUpdatedState(onPreview)

    val amp by animateFloatAsState(
        targetValue = if (moving && playing && dragging == null) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "waveAmp",
    )
    val thumbGrow by animateFloatAsState(
        targetValue = if (dragging != null) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "thumbGrow",
    )
    val shown by animateFloatAsState(
        targetValue = dragging ?: progress,
        animationSpec = if (dragging != null) snap() else tween(420, easing = LinearEasing),
        label = "seekProgress",
    )
    val speed = motion.waveSpeed
    val phase = remember { mutableFloatStateOf(0f) }
    val waving = moving && playing && dragging == null && speed > 0f && !s.batterySaver
    LaunchedEffect(waving, speed) {
        if (!waving) return@LaunchedEffect
        val full = 2f * PI.toFloat()
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    var p = phase.floatValue + (now - last) / 1_000_000_000f * full * speed / 2.6f
                    if (p > full) p -= full
                    phase.floatValue = p
                }
                last = now
            }
        }
    }
    val base = when (s.seekColor) {
        SeekColor.PRIMARY, SeekColor.GRADIENT -> cs.primary
        SeekColor.SECONDARY -> cs.secondary
        SeekColor.TERTIARY -> cs.tertiary
    }
    val end = if (s.seekColor == SeekColor.GRADIENT) cs.tertiary else base
    val track = base.copy(alpha = 0.22f)
    val boxH = if (style == SeekStyle.THICK || style == SeekStyle.BARS) 44.dp else 36.dp

    Canvas(
        modifier
            .fillMaxWidth()
            .height(boxH)
            .pointerInput(Unit) {
                val pad = 10.dp.toPx()
                detectTapGestures { o -> currentOnSeek(fracOf(o.x, size.width, pad)) }
            }
            .pointerInput(Unit) {
                val pad = 10.dp.toPx()
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val f = fracOf(o.x, size.width, pad)
                        dragging = f
                        currentOnPreview(f)
                    },
                    onDragEnd = {
                        dragging?.let { currentOnSeek(it) }
                        dragging = null
                        currentOnPreview(null)
                    },
                    onDragCancel = {
                        dragging = null
                        currentOnPreview(null)
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val f = fracOf(change.position.x, size.width, pad)
                        dragging = f
                        currentOnPreview(f)
                    },
                )
            },
    ) {
        val pad = 10.dp.toPx()
        val w = size.width
        val trackW = (w - 2 * pad).coerceAtLeast(1f)
        val cy = size.height / 2f
        val th = s.seekThickness.dp.toPx()
        val x = pad + trackW * shown.coerceIn(0f, 1f)
        val fill: Brush = if (s.seekColor == SeekColor.GRADIENT) {
            Brush.horizontalGradient(listOf(cs.primary, cs.tertiary), startX = pad, endX = w - pad)
        } else SolidColor(base)
        val ampPx = 3.dp.toPx() * amp * motion.waveAmp * s.seekWave
        val wl = 36.dp.toPx() * s.seekWaveLen
        val edge = 22.dp.toPx()
        val ph = phase.floatValue

        when (style) {
            SeekStyle.LINE, SeekStyle.THIN, SeekStyle.WAVY -> {
                val stroke = if (style == SeekStyle.THIN) 1.5.dp.toPx() else th
                if (x < w - pad) drawLine(track, Offset(x, cy), Offset(w - pad, cy), stroke, StrokeCap.Round)
                if (style != SeekStyle.WAVY || ampPx < 0.2f || x - pad < 2f) {
                    drawLine(fill, Offset(pad, cy), Offset(x, cy), stroke, StrokeCap.Round)
                } else {
                    drawPath(
                        wavePath(pad, x, pad, x, cy, ampPx, wl, edge, ph),
                        fill,
                        style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
            }
            SeekStyle.SQUIGGLE -> {
                if (ampPx < 0.2f) {
                    drawLine(track, Offset(x, cy), Offset(w - pad, cy), th, StrokeCap.Round)
                    drawLine(fill, Offset(pad, cy), Offset(x, cy), th, StrokeCap.Round)
                } else {
                    val path = wavePath(pad, w - pad, pad, w - pad, cy, ampPx * 1.3f, wl * 0.8f, edge, ph)
                    val st = Stroke(width = th, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    clipRect(left = x, top = 0f, right = w, bottom = size.height) { drawPath(path, track, style = st) }
                    clipRect(left = 0f, top = 0f, right = x, bottom = size.height) { drawPath(path, fill, style = st) }
                }
            }
            SeekStyle.THICK -> {
                val hh = maxOf(th * 3f, 14.dp.toPx())
                val top = cy - hh / 2f
                drawRoundRect(track, Offset(pad, top), Size(trackW, hh), CornerRadius(hh / 2f))
                val fw = (x - pad).coerceIn(hh, trackW)
                drawRoundRect(fill, Offset(pad, top), Size(fw, hh), CornerRadius(hh / 2f))
            }
            SeekStyle.DOTS -> {
                val n = (trackW / 12.dp.toPx()).toInt().coerceAtLeast(2)
                val gap = trackW / n
                val r = (th / 2f).coerceAtLeast(1.5.dp.toPx())
                for (i in 0..n) {
                    val cx = pad + gap * i
                    if (cx <= x) drawCircle(fill, r, Offset(cx, cy)) else drawCircle(track, r, Offset(cx, cy))
                }
            }
            SeekStyle.BARS -> {
                val bw = (th * 0.75f).coerceAtLeast(2.dp.toPx())
                val n = (trackW / (bw * 1.9f)).toInt().coerceAtLeast(4)
                val g = trackW / n
                val maxH = size.height * 0.9f
                for (i in 0 until n) {
                    val cx = pad + g * i + g / 2f
                    val hh = maxH * (0.30f + 0.70f * hash01(i))
                    val tl = Offset(cx - bw / 2f, cy - hh / 2f)
                    val sz = Size(bw, hh)
                    if (cx <= x) drawRoundRect(fill, tl, sz, CornerRadius(bw / 2f)) else drawRoundRect(track, tl, sz, CornerRadius(bw / 2f))
                }
            }
            SeekStyle.STEPS -> {
                val n = 16
                val gap = 4.dp.toPx()
                val sw = (trackW - gap * (n - 1)) / n
                val hh = maxOf(th * 1.6f, 6.dp.toPx())
                for (i in 0 until n) {
                    val left = pad + i * (sw + gap)
                    drawRoundRect(track, Offset(left, cy - hh / 2f), Size(sw, hh), CornerRadius(hh / 2f))
                    val f = ((x - left) / sw).coerceIn(0f, 1f)
                    if (f > 0f) drawRoundRect(fill, Offset(left, cy - hh / 2f), Size((sw * f).coerceAtLeast(hh / 2f).coerceAtMost(sw), hh), CornerRadius(hh / 2f))
                }
            }
        }

        if (style != SeekStyle.THICK && s.seekThumb != SeekThumb.NONE) {
            val tr = maxOf(6.dp.toPx(), th * 0.9f) + 3.dp.toPx() * thumbGrow
            val tc = lerp(cs.primary, end, shown.coerceIn(0f, 1f))
            when (s.seekThumb) {
                SeekThumb.CIRCLE -> drawCircle(tc, radius = tr, center = Offset(x, cy))
                SeekThumb.PILL -> {
                    val pw = tr * 0.8f
                    val ph2 = tr * 3.2f
                    drawRoundRect(tc, Offset(x - pw / 2f, cy - ph2 / 2f), Size(pw, ph2), CornerRadius(pw / 2f))
                }
                SeekThumb.SQUARE -> {
                    val sd = tr * 1.8f
                    drawRoundRect(tc, Offset(x - sd / 2f, cy - sd / 2f), Size(sd, sd), CornerRadius(tr * 0.45f))
                }
                SeekThumb.NONE -> {}
            }
        }
    }
}


/** Small previous/next arrow that sits beside the artwork. The touch area is exactly the arrow, nothing more. */
@Composable
fun ArtArrow(forward: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(width = 30.dp, height = 46.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(14.dp))
            .background(cs.secondaryContainer.copy(alpha = 0.55f))
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (forward) Icons.Rounded.ChevronRight else Icons.Rounded.ChevronLeft,
            contentDescription = if (forward) "Next song" else "Previous song",
            tint = cs.onSecondaryContainer,
            modifier = Modifier.size(26.dp),
        )
    }
}
