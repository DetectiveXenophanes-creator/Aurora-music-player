package com.aurora.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

private fun clock(minute: Int) = String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60)

/** Settings > Look profiles: save how Aurora looks under a name, switch with one tap or by the time of day. */
@Composable
internal fun ProfilesTab() {
    val context = LocalContext.current
    val store = remember { ProfileStore(context) }
    val prefs by store.flow.collectAsState(initial = ProfilePrefs(emptyList(), false))
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<LookProfile?>(null) }
    var timing by remember { mutableStateOf<LookProfile?>(null) }

    note?.let { msg ->
        SettingCard("Status") { Text(msg, style = MaterialTheme.typography.bodyMedium, color = cs.primary) }
    }

    SettingCard("Save this look") {
        Text(
            "Saves your colours, fonts, layouts, glow, mascot and Home cards under a name. It does not save what plays (equalizer, speed), your music folders or your language.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24) },
            label = { Text("Profile name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            enabled = name.isNotBlank(),
            onClick = {
                val saved = name.trim()
                scope.launch {
                    store.save(saved)
                    note = "Saved $saved. Change anything you like, then switch back to it here."
                }
                name = ""
            },
        ) { Text("Save profile") }
    }

    SettingCard("My profiles") {
        if (prefs.profiles.isEmpty()) {
            Text(
                "No profiles yet. Set Aurora up the way you like it, then save it above. Make one for the night, one for the car, one for work.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
        }
        prefs.profiles.forEach { p ->
            var menu by remember(p.id) { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(
                        if (p.atMinute >= 0) "Switches on at ${clock(p.atMinute)}" else "No time set",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                FilledTonalButton(onClick = {
                    scope.launch {
                        val ok = store.apply(p.id)
                        note = if (ok) "Switched to ${p.name}." else "That profile is gone."
                    }
                }) { Text("Apply") }
                Column {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Update to my current look") },
                            onClick = {
                                menu = false
                                scope.launch {
                                    store.update(p.id)
                                    note = "${p.name} now holds your current look."
                                }
                            },
                        )
                        DropdownMenuItem(text = { Text("Set a time") }, onClick = {
                            menu = false
                            timing = p
                        })
                        if (p.atMinute >= 0) {
                            DropdownMenuItem(text = { Text("Remove the time") }, onClick = {
                                menu = false
                                scope.launch { store.setTime(p.id, -1) }
                            })
                        }
                        DropdownMenuItem(text = { Text("Rename") }, onClick = {
                            menu = false
                            renaming = p
                        })
                        DropdownMenuItem(text = { Text("Delete") }, onClick = {
                            menu = false
                            scope.launch { store.remove(p.id) }
                        })
                    }
                }
            }
        }
    }

    SettingCard("By time of day") {
        ToggleRow(
            "Switch automatically",
            "A profile with a time switches on at that time. The newest time that has passed is the one that shows. It checks while Aurora is open.",
            prefs.auto,
            true,
        ) { on ->
            scope.launch {
                store.setAuto(on)
                if (on) {
                    val now = java.time.LocalTime.now()
                    store.runSchedule(now.hour * 60 + now.minute)
                }
            }
        }
    }

    val ren = renaming
    if (ren != null) {
        var text by remember(ren.id) { mutableStateOf(ren.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename profile") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(24) }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { store.rename(ren.id, text.trim().ifBlank { "My look" }) }
                    renaming = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }

    val tim = timing
    if (tim != null) {
        val start = if (tim.atMinute >= 0) tim.atMinute else 22 * 60
        var hour by remember(tim.id) { mutableFloatStateOf((start / 60).toFloat()) }
        var minute by remember(tim.id) { mutableFloatStateOf(((start % 60) / 5 * 5).toFloat()) }
        val picked = hour.roundToInt() * 60 + (minute.roundToInt() / 5 * 5)
        AlertDialog(
            onDismissRequest = { timing = null },
            title = { Text("Switch on at") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(clock(picked), style = MaterialTheme.typography.headlineMedium, color = cs.primary)
                    SliderRow("Hour", hour, 0f..23f, "${hour.roundToInt()}") { hour = it }
                    SliderRow("Minute", minute, 0f..55f, "${minute.roundToInt() / 5 * 5}") { minute = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { store.setTime(tim.id, picked) }
                    timing = null
                }) { Text("Set") }
            },
            dismissButton = { TextButton(onClick = { timing = null }) { Text("Cancel") } },
        )
    }
}
