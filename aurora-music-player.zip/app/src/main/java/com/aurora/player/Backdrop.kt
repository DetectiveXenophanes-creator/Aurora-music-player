package com.aurora.player

import androidx.compose.foundation.Canvas
import kotlin.math.roundToInt
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** The moving background of the Current interface. The Legacy interface keeps the old background settings. */
enum class BackdropStyle(val label: String) {
    ORBS("Liquid light"), CURTAINS("Curtains"), WAVES("Waves"), NIGHT("Night sky"), PLAIN("Plain")
}

enum class BackdropPalette(val label: String) {
    THEME("Theme"), AURORA("Aurora"), SUNSET("Sunset"), OCEAN("Ocean"), CANDY("Candy"), RAINBOW("Rainbow"), CUSTOM("Custom")
}

private fun backdropColors(p: BackdropPalette, cs: ColorScheme, a: Int, b: Int): List<Color> = when (p) {
    BackdropPalette.THEME -> listOf(cs.primary, cs.tertiary, cs.secondary)
    BackdropPalette.AURORA -> listOf(Color(0xFF2EE6A6), Color(0xFF3AA9FF), Color(0xFF8A5CFF))
    BackdropPalette.SUNSET -> listOf(Color(0xFFFF7A59), Color(0xFFFF4F9A), Color(0xFF8E44FF))
    BackdropPalette.OCEAN -> listOf(Color(0xFF00C2FF), Color(0xFF00E5B0), Color(0xFF2F5BFF))
    BackdropPalette.CANDY -> listOf(Color(0xFFFF6FD8), Color(0xFF7AF0FF), Color(0xFFFFE066))
    BackdropPalette.RAINBOW -> listOf(
        Color(0xFFFF5A5A), Color(0xFFFFC93C), Color(0xFF4CE08B), Color(0xFF3AA9FF), Color(0xFFB45CFF),
    )
    BackdropPalette.CUSTOM -> listOf(Color(a), Color(b), lerp(Color(a), Color(b), 0.5f))
}

/**
 * Moving light behind the whole Current interface. Five styles, all drawn with a handful of shapes and redrawn at the
 * background frame rate. It stands still in battery saver, under full-screen pages, and (unless "Animate when paused"
 * is on) while the music is paused.
 */
@Composable
fun AuroraBackdrop() {
    val s = LocalAppSettings.current
    if (s.backdrop == BackdropStyle.PLAIN) return
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val paused = LocalBackgroundPaused.current
    val playing = LocalIsPlaying.current
    val running = !paused && !s.batterySaver && (playing || s.ambientWhenPaused)
    val clock = rememberThrottledClock(running, s.bgFps.coerceIn(8, 30))
    val colors = remember(s.backdropPalette, s.backdropColorA, s.backdropColorB, cs.primary, cs.secondary, cs.tertiary) {
        backdropColors(s.backdropPalette, cs, s.backdropColorA, s.backdropColorB)
    }
    val k = s.backdropIntensity * if (dark) 0.55f else 0.40f
    val blend = if (dark) BlendMode.Plus else BlendMode.SrcOver
    // Gradients are built once per palette: they are one unit big and are moved and scaled while drawing, so a tick
    // allocates nothing (before, every tick made a dozen new shaders and paths, which is what makes a phone stutter)
    val orbBrushes = remember(colors) { colors.map { unitGlow(it) } }
    val faceBrushes = remember(colors) { colors.map { unitFace(it) } }
    val rayBrushes = remember(colors) { colors.map { unitRay(it) } }
    val scratch = remember { BlobScratch() }
    val style = s.backdrop
    val speed = s.backdropSpeed
    val scale = s.backdropScale
    if (style == BackdropStyle.ORBS) {
        // Liquid light: a dim soft glow underneath, and solid blobs on top that join when they touch.
        val blobAlpha = (s.backdropIntensity * if (dark) 0.42f else 0.32f).coerceIn(0f, 1f)
        Canvas(Modifier.fillMaxSize()) {
            drawOrbs(clock.value * speed, orbBrushes, k * 0.45f, scale, blend)
        }
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // everything inside is drawn opaque; the brightness is the alpha of the whole layer, so there are
                    // no seams where blobs and bridges overlap
                    alpha = blobAlpha
                    compositingStrategy = CompositingStrategy.Offscreen
                }
        ) {
            drawBlobs(clock.value * speed, colors, faceBrushes, scratch, scale)
        }
    } else {
        Canvas(Modifier.fillMaxSize()) {
            val t = clock.value * speed
            when (style) {
                BackdropStyle.ORBS, BackdropStyle.PLAIN -> Unit
                BackdropStyle.CURTAINS -> drawCurtainBands(t, colors, rayBrushes, k, scale, blend)
                BackdropStyle.WAVES -> drawWaves(t, colors, k, scale, blend)
                BackdropStyle.NIGHT -> drawNight(t, colors, k, scale, dark, blend)
            }
        }
    }
}

/** A soft ball of colour, one unit big, fading to nothing at the edge. Moved and scaled while drawing. */
private fun unitGlow(c: Color): Brush =
    Brush.radialGradient(listOf(c.copy(alpha = 1f), Color.Transparent), center = Offset.Zero, radius = 1f)

/** A solid dot, one unit big, a little lighter in the middle. */
private fun unitFace(c: Color): Brush {
    val solid = c.copy(alpha = 1f)
    return Brush.radialGradient(listOf(lerp(solid, Color.White, 0.28f), solid), center = Offset.Zero, radius = 1f)
}

/** A ray that fades out downwards, one unit long. */
private fun unitRay(c: Color): Brush =
    Brush.verticalGradient(listOf(c.copy(alpha = 1f), Color.Transparent), startY = 0f, endY = 1f)

/** The ambient part of Liquid light: big soft balls of colour on slow loops, kept dim so the blobs above stand out. */
private fun DrawScope.drawOrbs(t: Float, brushes: List<Brush>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val m = max(w, h)
    for (i in 0 until 6) {
        val sp = 0.07f + 0.035f * (i % 3)
        val cx = w * (0.5f + 0.44f * sin(t * sp * 2.1f + i * 1.7f))
        val cy = h * (0.5f + 0.42f * cos(t * sp * 1.7f + i * 2.3f))
        val r = m * (0.30f + 0.08f * (i % 4)) * scale
        val pulse = 0.85f + 0.15f * sin(t * 0.35f + i)
        withTransform({
            translate(cx, cy)
            scale(r, r, Offset.Zero)
        }) {
            drawCircle(
                brush = brushes[i % brushes.size],
                radius = 1f,
                center = Offset.Zero,
                alpha = (k * pulse).coerceIn(0f, 1f),
                blendMode = blend,
            )
        }
    }
}

private const val BLOB_COUNT = 7
private const val BRIDGE_V = 0.5f        // how far round the circles the neck starts
private const val BRIDGE_HANDLE = 2.4f   // how round the neck curves are
private const val BRIDGE_REACH = 1.9f    // a bridge exists while the distance is below (r1 + r2) * this
private val PI_F = PI.toFloat()
private val BLOB_FX = floatArrayOf(0.23f, 0.31f, 0.19f, 0.27f, 0.35f, 0.21f, 0.29f)
private val BLOB_FY = floatArrayOf(0.17f, 0.25f, 0.33f, 0.20f, 0.28f, 0.37f, 0.22f)

private fun ringX(c: Float, a: Float, r: Float): Float = c + r * cos(a)
private fun ringY(c: Float, a: Float, r: Float): Float = c + r * sin(a)

/** Everything Liquid light needs every tick, made once: the positions and one path for every pair of dots. */
private class BlobScratch {
    val xs = FloatArray(BLOB_COUNT)
    val ys = FloatArray(BLOB_COUNT)
    val rs = FloatArray(BLOB_COUNT)
    val paths = Array(BLOB_COUNT * (BLOB_COUNT - 1) / 2) { Path() }
}

/**
 * Builds the neck between two blobs (classic metaball bridge) into [path]: two curves joined by two lines, starting on
 * the tangent points of the circles. False when they are too far apart or one sits inside the other. The neck gets
 * thinner as the blobs pull apart and is gone at the reach, so a bridge never pops in or out.
 * Same maths as tools/metaball_check.py, which draws it in Python so the shape can be checked without a phone.
 */
private fun bridgeInto(path: Path, x1: Float, y1: Float, r1: Float, x2: Float, y2: Float, r2: Float): Boolean {
    val dx = x2 - x1
    val dy = y2 - y1
    val d = hypot(dx, dy)
    val sum = r1 + r2
    val reach = sum * BRIDGE_REACH
    if (r1 <= 0f || r2 <= 0f || d >= reach || d <= abs(r1 - r2) || d < 0.001f) return false
    val far = ((d - sum) / (reach - sum)).coerceIn(0f, 1f)
    val v = BRIDGE_V * (1f - far * far * (3f - 2f * far))
    val u1: Float
    val u2: Float
    if (d < sum) {
        u1 = acos(((r1 * r1 + d * d - r2 * r2) / (2f * r1 * d)).coerceIn(-1f, 1f))
        u2 = acos(((r2 * r2 + d * d - r1 * r1) / (2f * r2 * d)).coerceIn(-1f, 1f))
    } else {
        u1 = 0f
        u2 = 0f
    }
    val base = atan2(dy, dx)
    val spread = acos(((r1 - r2) / d).coerceIn(-1f, 1f))
    val a1 = base + u1 + (spread - u1) * v
    val a2 = base - u1 - (spread - u1) * v
    val a3 = base + PI_F - u2 - (PI_F - u2 - spread) * v
    val a4 = base - PI_F + u2 + (PI_F - u2 - spread) * v
    val p1x = ringX(x1, a1, r1)
    val p1y = ringY(y1, a1, r1)
    val p2x = ringX(x1, a2, r1)
    val p2y = ringY(y1, a2, r1)
    val p3x = ringX(x2, a3, r2)
    val p3y = ringY(y2, a3, r2)
    val p4x = ringX(x2, a4, r2)
    val p4y = ringY(y2, a4, r2)
    val d2 = min(v * BRIDGE_HANDLE, hypot(p1x - p3x, p1y - p3y) / sum) * min(1f, d * 2f / sum)
    val k1 = r1 * d2
    val k2 = r2 * d2
    val quarter = PI_F / 2f
    path.rewind()
    path.moveTo(p1x, p1y)
    path.cubicTo(
        ringX(p1x, a1 - quarter, k1), ringY(p1y, a1 - quarter, k1),
        ringX(p3x, a3 + quarter, k2), ringY(p3y, a3 + quarter, k2),
        p3x, p3y,
    )
    path.lineTo(p4x, p4y)
    path.cubicTo(
        ringX(p4x, a4 - quarter, k2), ringY(p4y, a4 - quarter, k2),
        ringX(p2x, a2 + quarter, k1), ringY(p2y, a2 + quarter, k1),
        p2x, p2y,
    )
    path.close()
    return true
}

/**
 * Liquid light: seven solid dots drifting on slow looping paths. When two get close a neck grows between them and they
 * join into one shape, then stretch, thin out and pull apart again (lava lamp). Everything here is drawn opaque inside
 * its own layer; the layer's alpha is the Brightness slider. It allocates nothing per tick: the gradients are built once
 * and moved with the canvas, the paths are reused, and a neck takes the average colour of the two dots it joins.
 */
private fun DrawScope.drawBlobs(t: Float, colors: List<Color>, faces: List<Brush>, scratch: BlobScratch, scale: Float) {
    val w = size.width
    val h = size.height
    val xs = scratch.xs
    val ys = scratch.ys
    val rs = scratch.rs
    for (i in 0 until BLOB_COUNT) {
        xs[i] = w * (0.5f + 0.36f * sin(t * BLOB_FX[i] + i * 1.9f))
        ys[i] = h * (0.5f + 0.34f * cos(t * BLOB_FY[i] + i * 2.7f))
        rs[i] = w * (0.085f + 0.012f * (i % 5)) * scale * (1f + 0.06f * sin(t * 0.5f + i))
    }
    // necks first, so the faces of the dots sit on top of them
    var n = 0
    for (a in 0 until BLOB_COUNT) {
        for (b in a + 1 until BLOB_COUNT) {
            val path = scratch.paths[n++]
            if (!bridgeInto(path, xs[a], ys[a], rs[a], xs[b], ys[b], rs[b])) continue
            val ca = colors[a % colors.size].copy(alpha = 1f)
            val cb = colors[b % colors.size].copy(alpha = 1f)
            drawPath(path, if (ca == cb) ca else lerp(ca, cb, 0.5f))
        }
    }
    for (i in 0 until BLOB_COUNT) {
        withTransform({
            translate(xs[i], ys[i])
            scale(rs[i], rs[i], Offset.Zero)
        }) {
            drawCircle(faces[i % faces.size], radius = 1f, center = Offset.Zero)
        }
    }
}

/** Northern-light bands that ripple across the upper part of the screen, with thin rays hanging from them. */
private fun DrawScope.drawCurtainBands(t: Float, colors: List<Color>, rays: List<Brush>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val steps = 28
    for (i in 0 until 4) {
        val c = colors[i % colors.size]
        val baseY = h * (0.16f + 0.09f * i)
        val amp = h * 0.07f * scale
        val band = h * (0.30f + 0.06f * i) * scale
        val path = Path()
        for (s in 0..steps) {
            val u = s / steps.toFloat()
            val y = baseY + amp * sin(u * (3.2f + i) + t * (0.20f + 0.05f * i) + i * 1.9f) +
                amp * 0.5f * sin(u * 9f - t * 0.33f + i)
            if (s == 0) path.moveTo(w * u, y) else path.lineTo(w * u, y)
        }
        for (s in steps downTo 0) {
            val u = s / steps.toFloat()
            val y = baseY + band * (0.6f + 0.4f * sin(u * 5.5f + t * 0.17f + i * 2.4f)) +
                amp * sin(u * (3.2f + i) + t * (0.20f + 0.05f * i) + i * 1.9f)
            path.lineTo(w * u, y)
        }
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(c.copy(alpha = 0f), c.copy(alpha = (k * 0.95f).coerceIn(0f, 1f)), c.copy(alpha = 0f)),
                startY = baseY - amp * 1.5f,
                endY = baseY + band * 1.1f,
            ),
            blendMode = blend,
        )
        // thin rays that shimmer under the top edge of the band
        val rayCount = 7
        for (j in 0 until rayCount) {
            val u = (j + 0.5f) / rayCount
            val top = baseY + amp * sin(u * (3.2f + i) + t * (0.20f + 0.05f * i) + i * 1.9f) +
                amp * 0.5f * sin(u * 9f - t * 0.33f + i)
            val len = band * (0.45f + 0.35f * sin(u * 13f + t * 0.5f + i * 1.3f + j))
            val shimmer = 0.5f + 0.5f * sin(t * 0.8f + j * 1.7f + i)
            val a = ((0.3f + 0.7f * shimmer) * k * 0.9f).coerceIn(0f, 1f)
            // one unit long ray, moved to the spot and stretched to its length (no new shader per ray)
            withTransform({
                translate(w * u, top)
                scale(1f, len, Offset.Zero)
            }) {
                drawLine(
                    brush = rays[i % rays.size],
                    start = Offset.Zero,
                    end = Offset(0f, 1f),
                    strokeWidth = w * 0.004f,
                    alpha = a,
                    blendMode = blend,
                )
            }
        }
    }
}

/** Layers of slow waves rising from the bottom, with a soft glow high up like a low sun. */
private fun DrawScope.drawWaves(t: Float, colors: List<Color>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    drawCircle(
        brush = Brush.radialGradient(
            listOf(colors[0].copy(alpha = (k * 0.7f).coerceIn(0f, 1f)), Color.Transparent),
            center = Offset(w * 0.5f, h * 0.22f),
            radius = w * 0.7f * scale,
        ),
        radius = w * 0.7f * scale,
        center = Offset(w * 0.5f, h * 0.22f),
        blendMode = blend,
    )
    val step = max(8f, w / 40f)
    for (i in 0 until 5) {
        val c = colors[(i + 1) % colors.size]
        val base = h * (0.52f + 0.09f * i)
        val amp = h * (0.035f + 0.008f * i) * scale
        val dir = if (i % 2 == 0) 1f else -1f
        val path = Path()
        val crest = Path()
        path.moveTo(0f, h)
        var x = 0f
        var first = true
        while (x <= w + step) {
            val u = x / w
            val y = base + amp * sin(u * (2.2f + 0.7f * i) * PI.toFloat() + t * (0.25f + 0.07f * i) * dir + i * 1.3f) +
                amp * 0.4f * sin(u * 11f + t * 0.4f + i)
            path.lineTo(x, y)
            if (first) crest.moveTo(x, y) else crest.lineTo(x, y)
            first = false
            x += step
        }
        path.lineTo(w, h)
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(c.copy(alpha = (k * (0.55f + 0.1f * i)).coerceIn(0f, 1f)), c.copy(alpha = 0f)),
                startY = base - amp,
                endY = h,
            ),
            blendMode = blend,
        )
        // a thin bright line along the top of each wave
        drawPath(
            crest,
            c.copy(alpha = (k * 1.3f).coerceIn(0f, 1f)),
            style = Stroke(width = 1.4.dp.toPx()),
            blendMode = blend,
        )
    }
}

private class Sparkle(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float)

private val sparkles = Random(7).let { rnd ->
    List(110) { Sparkle(rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * 1.6f, 0.4f + rnd.nextFloat() * 1.6f, rnd.nextFloat() * 6.28f) }
}

private fun fract(v: Float): Float = v - kotlin.math.floor(v)

/** Twinkling stars that drift sideways under two slow clouds of colour, with a shooting star now and then. */
private fun DrawScope.drawNight(t: Float, colors: List<Color>, k: Float, scale: Float, dark: Boolean, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val m = max(w, h)
    for (i in 0 until 2) {
        val c = colors[i % colors.size]
        val cx = w * (0.3f + 0.4f * i + 0.12f * sin(t * 0.05f + i * 2f))
        val cy = h * (0.25f + 0.35f * i + 0.08f * cos(t * 0.04f + i))
        drawCircle(
            brush = Brush.radialGradient(
                listOf(c.copy(alpha = (k * 0.8f).coerceIn(0f, 1f)), Color.Transparent),
                center = Offset(cx, cy),
                radius = m * 0.55f * scale,
            ),
            radius = m * 0.55f * scale,
            center = Offset(cx, cy),
            blendMode = blend,
        )
    }
    val bright = (0.35f + 0.65f * min(1f, k * 1.8f))
    for ((i, st) in sparkles.withIndex()) {
        val tw = 0.5f + 0.5f * sin(t * st.speed + st.phase)
        val px = fract(st.x + t * 0.004f * (0.4f + st.r * 0.3f)) * w
        val base = if (dark) Color.White else colors[i % colors.size]
        val tint = if (dark) lerp(base, colors[i % colors.size], 0.3f) else base
        drawCircle(
            tint.copy(alpha = ((0.15f + 0.85f * tw) * bright).coerceIn(0f, 1f)),
            radius = st.r * scale * (0.8f + 0.4f * tw),
            center = Offset(px, st.y * h),
        )
    }
    // a shooting star every nine seconds
    val cycle = (t / 9f).toInt()
    val p = (t % 9f) / 1.2f
    if (p in 0f..1f) {
        val sx = fract(sin(cycle * 12.9898f) * 43758.547f) * w * 0.8f + w * 0.2f
        val sy = fract(sin(cycle * 78.233f) * 12345.679f) * h * 0.4f
        val len = w * 0.22f
        val head = Offset(sx - p * len * 1.6f, sy + p * len * 0.8f)
        val tail = Offset(head.x + len * 0.5f, head.y - len * 0.25f)
        val a = (1f - p) * bright
        drawLine(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, (if (dark) Color.White else colors[0]).copy(alpha = a)),
                start = tail,
                end = head,
            ),
            start = tail,
            end = head,
            strokeWidth = 2.2f * scale,
            cap = StrokeCap.Round,
        )
    }
}

/** A rainbow bar and a hue slider for picking one of the two custom backdrop colours. */
@Composable
fun BackdropHueRow(label: String, color: Int, onPick: (Int) -> Unit) {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(color, hsv)
    val hue = hsv[0]
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .background(
                Brush.horizontalGradient(
                    listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map {
                        Color(android.graphics.Color.HSVToColor(floatArrayOf(it, 0.7f, 1f)))
                    }
                )
            )
    )
    SliderRow(label, hue, 0f..360f, "${hue.roundToInt()}°") { v ->
        onPick(android.graphics.Color.HSVToColor(floatArrayOf(v.coerceIn(0f, 360f), 0.7f, 1f)))
    }
}
