package com.aurora.player

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** True when Aurora runs in Lite mode (low-end phones, or when the user picked it). Heavy effects are off. */
val LocalLite = staticCompositionLocalOf { false }

/** Older or low-memory phones: little RAM, flagged by Android as low-RAM, or older than Android 9. */
fun isLowEndDevice(context: Context): Boolean {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
    val info = ActivityManager.MemoryInfo()
    am.getMemoryInfo(info)
    return am.isLowRamDevice || info.totalMem < 3L * 1024 * 1024 * 1024 || Build.VERSION.SDK_INT < 28
}

/** Settings as the UI should see them in Lite mode: no blur, no drifting background, no staggered entrances. */
fun AppSettings.asLite(): AppSettings = copy(
    style = SurfaceStyle.MATTE,
    batterySaver = true,
    bgFps = 12,
    listEntrance = false,
    artBreathing = false,
    auroraGlow = 0f,
    artEdge = 0f,
    squiggles = if (squiggles == SquiggleMode.ANIMATED) SquiggleMode.STATIC else squiggles,
)

/** Small colour tweaks that give the non-Material design styles their own character. */
internal fun designTweak(scheme: ColorScheme, design: DesignStyle): ColorScheme = when (design) {
    DesignStyle.OUTLINE -> scheme.copy(
        surfaceContainerLow = scheme.surface,
        surfaceContainer = scheme.surface,
        surfaceContainerHigh = scheme.surface,
        surfaceContainerHighest = scheme.surface,
        outline = scheme.onSurfaceVariant.copy(alpha = 0.75f),
    )
    DesignStyle.BRUTAL -> scheme.copy(
        surfaceContainerHigh = scheme.secondaryContainer,
        surfaceContainerHighest = scheme.tertiaryContainer,
        outline = scheme.onSurface,
    )
    DesignStyle.TERMINAL -> scheme.copy(
        surfaceContainerLow = scheme.surface,
        surfaceContainer = scheme.surface,
        surfaceContainerHigh = scheme.surface,
        surfaceContainerHighest = scheme.surface,
        outline = scheme.primary,
    )
    DesignStyle.NEON -> scheme.copy(outline = scheme.primary)
    else -> scheme
}

// ---------------------------------------------------------------- cover colours

/**
 * The dominant colour of the current cover, found by loading a tiny copy of it. Returns null while loading, when
 * there is no cover, or when the cover is nearly grey (the normal theme is kept then).
 */
@Composable
fun rememberCoverSeed(song: Song?): Color? {
    val context = LocalContext.current
    var seed by remember { mutableStateOf<Color?>(null) }
    LaunchedEffect(song?.albumId) {
        val uri = song?.artUri
        seed = if (uri == null) null else withContext(Dispatchers.Default) { loadSeed(context, uri) }
    }
    return seed
}

private suspend fun loadSeed(context: Context, uri: Uri): Color? = runCatching {
    val req = ImageRequest.Builder(context).data(uri).size(48).allowHardware(false).build()
    val drawable = (context.imageLoader.execute(req) as? SuccessResult)?.drawable ?: return@runCatching null
    val bmp = drawable.toBitmap(48, 48)
    val px = IntArray(48 * 48)
    bmp.getPixels(px, 0, 48, 0, 0, 48, 48)
    val weight = FloatArray(12)
    val hueSum = FloatArray(12)
    val hsv = FloatArray(3)
    var total = 0f
    for (c in px) {
        android.graphics.Color.colorToHSV(c, hsv)
        if (hsv[1] < 0.25f || hsv[2] < 0.25f) continue
        val w = hsv[1] * hsv[2]
        val b = (hsv[0] / 30f).toInt().coerceIn(0, 11)
        weight[b] += w
        hueSum[b] += hsv[0] * w
        total += w
    }
    if (total < 20f) return@runCatching null
    var best = 0
    for (i in 1 until 12) if (weight[i] > weight[best]) best = i
    val hue = hueSum[best] / weight[best]
    Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.7f, 0.9f)))
}.getOrNull()

/** Theme for Now Playing built from the cover's colour. Keeps pure-black AMOLED backgrounds black. */
internal fun coverScheme(base: ColorScheme, seed: Color, spread: Float): ColorScheme {
    val dark = base.background.luminance() < 0.5f
    val scheme = seedScheme(seed, dark, spread, 1f)
    return if (dark && base.background == Color.Black) {
        scheme.copy(background = Color.Black, surface = Color.Black)
    } else scheme
}

/** A scalloped, cookie-like circle used as a cover shape. */
val CookieShape: Shape = object : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = size.minDimension / 2f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val path = Path()
        val steps = 160
        for (i in 0..steps) {
            val a = i / steps.toFloat() * 2f * PI.toFloat()
            val rr = r * (0.945f + 0.055f * cos(12f * a))
            val x = cx + rr * cos(a)
            val y = cy + rr * sin(a)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}
