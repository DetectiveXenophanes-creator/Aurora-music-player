package com.aurora.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

private val skyGreen = Color(0xFF3DFFB5)
private val skyTeal = Color(0xFF2ED9FF)
private val skyViolet = Color(0xFF8A5CFF)
private val skyPink = Color(0xFFFF5CC8)

/** One curtain of light: where it hangs, how tall it is and how it sways. */
private class Curtain(
    val colorIndex: Int,
    val base: Float,    // top edge, as a fraction of the height
    val reach: Float,   // curtain height, as a fraction of the height
    val freq: Float,
    val speed: Float,
    val phase: Float,
    val amp: Float,
)

private val curtains = listOf(
    Curtain(0, 0.34f, 0.30f, 1.6f, 0.35f, 0.0f, 0.055f),
    Curtain(1, 0.28f, 0.26f, 2.3f, -0.28f, 1.7f, 0.045f),
    Curtain(2, 0.22f, 0.24f, 1.1f, 0.22f, 3.1f, 0.060f),
    Curtain(3, 0.40f, 0.14f, 2.9f, -0.40f, 4.4f, 0.035f),
)

/** A unit-height gradient: clear at the top, glowing near the bottom edge, like real curtains of aurora. */
private fun curtainBrush(c: Color): Brush = Brush.verticalGradient(
    0f to Color.Transparent,
    0.55f to c.copy(alpha = 0.35f),
    0.92f to c.copy(alpha = 0.95f),
    1f to Color.Transparent,
    startY = 0f,
    endY = 1f,
)

/**
 * Draws the curtains as many thin vertical strands that share one gradient per curtain.
 * Each strand is a rectangle squeezed into place with a transform, so no shaders are created per frame.
 */
private fun DrawScope.drawCurtains(
    t: Float,
    brushes: List<Brush>,
    strands: Int,
    strength: Float,
    yShift: Float,
    blend: BlendMode,
) {
    val w = size.width
    val h = size.height
    val sw = w / strands
    curtains.forEach { c ->
        val brush = brushes[c.colorIndex % brushes.size]
        for (i in 0..strands) {
            val u = i / strands.toFloat()
            val wave = 0.6f * sin(u * 6.2832f * c.freq + t * c.speed + c.phase) +
                0.4f * sin(u * 6.2832f * c.freq * 2.3f - t * c.speed * 0.7f)
            val top = h * (c.base + yShift + c.amp * wave)
            val reach = h * c.reach * (0.7f + 0.3f * sin(u * 8f + t * 0.2f + c.phase))
            val ray = 0.5f + 0.5f * sin(u * 38f + t * 0.9f + c.phase * 2f)
            val a = ((0.25f + 0.75f * ray) * strength).coerceIn(0f, 1f)
            translate(left = 0f, top = top) {
                scale(scaleX = 1f, scaleY = reach, pivot = Offset.Zero) {
                    drawRect(
                        brush = brush,
                        topLeft = Offset(u * w - sw * 0.5f, 0f),
                        size = Size(sw * 1.6f, 1f),
                        alpha = a,
                        blendMode = blend,
                    )
                }
            }
        }
    }
}

/**
 * Soft northern lights behind the whole app, painted in the current theme's colours.
 * Cheap on purpose: a few dozen strands, redrawn at the chosen background frame rate,
 * stopped under full-screen pages, and stopped completely in battery saver.
 */
@Composable
fun AuroraGlowLayer(strength: Float) {
    if (strength <= 0.02f) return
    val s = LocalAppSettings.current
    val paused = LocalBackgroundPaused.current
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val running = !paused && !s.batterySaver
    val frameMs = 1000L / s.bgFps.coerceIn(8, 30)
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running, frameMs) {
        if (!running) return@LaunchedEffect
        while (true) {
            delay(frameMs)
            withFrameNanos { n -> clock.floatValue = (n / 1_000_000L % 3_600_000L) / 1000f }
        }
    }
    val brushes = remember(cs.primary, cs.secondary, cs.tertiary) {
        listOf(cs.primary, cs.tertiary, cs.secondary, cs.primary).map { curtainBrush(it) }
    }
    val k = strength * if (dark) 0.6f else 0.4f
    Canvas(Modifier.fillMaxSize()) {
        drawCurtains(
            t = clock.floatValue,
            brushes = brushes,
            strands = 44,
            strength = k,
            yShift = -0.06f,
            blend = if (dark) BlendMode.Plus else BlendMode.SrcOver,
        )
    }
}

// ------------------------------------------------------------------ intro

private class Star(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float)

private val stars = Random(11).let { rnd ->
    List(90) {
        Star(rnd.nextFloat(), rnd.nextFloat() * 0.72f, 0.5f + rnd.nextFloat() * 1.3f, 0.6f + rnd.nextFloat() * 1.8f, rnd.nextFloat() * 6.28f)
    }
}

private fun DrawScope.drawMountains() {
    val w = size.width
    val h = size.height
    fun ridge(base: Float, amp: Float, seed: Float, color: Color) {
        val path = Path()
        path.moveTo(0f, h)
        var x = 0f
        while (x <= w + 8f) {
            val u = x / w
            val peak = 0.5f * abs(sin(u * 5f + seed)) + 0.3f * abs(sin(u * 13f + seed * 2f)) + 0.2f * sin(u * 37f + seed * 3f)
            path.lineTo(x, h * base - h * amp * peak)
            x += 8f
        }
        path.lineTo(w, h)
        path.close()
        drawPath(path, color)
    }
    // faint glow where the lights meet the horizon
    drawRect(
        Brush.verticalGradient(
            listOf(Color.Transparent, skyGreen.copy(alpha = 0.10f), skyTeal.copy(alpha = 0.18f)),
            startY = h * 0.62f,
            endY = h * 0.90f,
        ),
        topLeft = Offset(0f, h * 0.62f),
        size = Size(w, h * 0.38f),
    )
    ridge(0.82f, 0.07f, 1f, Color(0xFF0A1424))
    ridge(0.90f, 0.06f, 4f, Color(0xFF05080F))
}

/** Opening screen: northern lights ripple over a night sky and the name fades in. Tap to skip. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val progress = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(5400, easing = LinearEasing))
        onDone()
    }
    LaunchedEffect(skip) { if (skip) onDone() }

    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var start = 0L
        while (true) {
            withFrameNanos { n ->
                if (start == 0L) start = n
                clock.floatValue = (n - start) / 1_000_000_000f
            }
            delay(14)
        }
    }
    val brushes = remember { listOf(skyGreen, skyTeal, skyViolet, skyPink).map { curtainBrush(it) } }

    val p = progress.value
    val ramp = (p / 0.28f).coerceIn(0f, 1f)
    val fade = if (p > 0.9f) 1f - (p - 0.9f) / 0.1f else 1f
    val titleA = ((p - 0.30f) / 0.22f).coerceIn(0f, 1f)
    val tagA = ((p - 0.50f) / 0.22f).coerceIn(0f, 1f)
    val hintA = ((p - 0.68f) / 0.2f).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.coerceIn(0f, 1f) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { skip = true },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.verticalGradient(
                    0f to Color(0xFF02030C),
                    0.55f to Color(0xFF071330),
                    1f to Color(0xFF0A2630),
                )
            )
            val t = clock.floatValue
            stars.forEach { st ->
                val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * st.speed + st.phase))
                drawCircle(
                    Color.White.copy(alpha = tw * 0.85f * ramp),
                    radius = st.r.dp.toPx(),
                    center = Offset(st.x * size.width, st.y * size.height),
                )
            }
        }
        Canvas(Modifier.fillMaxSize().blur(14.dp)) {
            drawCurtains(
                t = clock.floatValue,
                brushes = brushes,
                strands = 110,
                strength = 0.95f * ramp,
                yShift = (1f - ramp) * 0.22f,
                blend = BlendMode.Plus,
            )
        }
        Canvas(Modifier.fillMaxSize()) { drawMountains() }

        Column(
            Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(0.60f))
            Text(
                "Aurora",
                style = MaterialTheme.typography.displayLarge.copy(
                    brush = Brush.horizontalGradient(listOf(skyGreen, skyTeal, skyViolet)),
                ),
                fontWeight = FontWeight.Bold,
                letterSpacing = (16f - 12f * titleA).sp,
                modifier = Modifier.graphicsLayer {
                    alpha = titleA
                    val sc = 0.94f + 0.06f * titleA
                    scaleX = sc
                    scaleY = sc
                },
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Music, in colour",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White.copy(alpha = 0.78f),
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = tagA },
            )
            Spacer(Modifier.weight(0.40f))
            Text(
                "Tap to continue",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.graphicsLayer { alpha = hintA }.padding(bottom = 20.dp),
            )
        }
    }
}
