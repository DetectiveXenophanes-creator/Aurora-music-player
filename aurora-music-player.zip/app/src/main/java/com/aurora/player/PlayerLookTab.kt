package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/**
 * Settings > Player look: control skins, title styles, depth tilt, the layout composer and stage backgrounds for the
 * Now Playing screen. Every preview here is built from the same composables the real player uses.
 */
@Composable
internal fun PlayerLookTab(s: AppSettings, song: Song?, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    val lite = LocalLite.current
    val sampleTitle = song?.title ?: "Northern lights"
    val sampleArtist = song?.artist ?: "Aurora"

    // ---------------------------------------------------------------- control skins
    SettingCard("Control skins") {
        var demoPlaying by remember { mutableStateOf(true) }
        Row(
            Modifier.fillMaxWidth().height(80.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SkinSkip(s.controlSkin, false, {}, Modifier.weight(1f).height(60.dp), 28.dp)
            SkinPlay(s.controlSkin, demoPlaying, { demoPlaying = !demoPlaying }, Modifier.weight(1.4f).height(76.dp), 32.dp)
            SkinSkip(s.controlSkin, true, {}, Modifier.weight(1f).height(60.dp), 28.dp)
        }
        ChipPicker(ControlSkin.entries.map { it.label to it }, s.controlSkin) { v -> onUpdate { it.copy(controlSkin = v) } }
        Text(s.controlSkin.blurb, style = MaterialTheme.typography.bodyMedium)
        Text(
            "Only previous, play and next change. Shuffle, repeat and favourite keep their look. Tap the play button above to try it.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    // ---------------------------------------------------------------- title styles
    SettingCard("Title styles") {
        val align = s.titleAlign.textAlign(true)
        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = s.titleAlign.horizontal(true)) {
            StyledTitle(
                title = sampleTitle,
                base = MaterialTheme.typography.headlineSmall.let { it.copy(fontSize = it.fontSize * s.npTitleScale) },
                style = s.titleStyle,
                align = align,
                weight = FontWeight.ExtraBold,
                marquee = s.marqueeTitles,
            )
            StyledArtist(sampleArtist, MaterialTheme.typography.titleMedium, cs.primary, align, s.artistChip)
        }
        ChipPicker(TitleStyle.entries.map { it.label to it }, s.titleStyle) { v -> onUpdate { it.copy(titleStyle = v) } }
        Text(s.titleStyle.blurb, style = MaterialTheme.typography.bodyMedium)
        Text("Alignment", style = MaterialTheme.typography.labelLarge)
        Segmented(TitleAlign.entries.map { it.label to it }, s.titleAlign) { v -> onUpdate { it.copy(titleAlign = v) } }
        ToggleRow(
            "Artist chip",
            "Show the artist in a small rounded chip",
            s.artistChip,
            true,
        ) { v -> onUpdate { it.copy(artistChip = v) } }
        Text(
            "Auto keeps what your player design does. The scrolling titles setting and the title size still work.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    // ---------------------------------------------------------------- depth tilt
    SettingCard("Depth tilt") {
        val tilt = rememberTilt(s.depthTilt && !s.batterySaver && !lite, s.tiltStrength)
        val shape = npArtShape(s.artShape, s.corner)
        Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(150.dp).depthTilt(tilt)) {
                MiniArt(song?.artUri, Modifier.fillMaxSize(), shape)
                TiltShine(tilt, shape, Modifier.fillMaxSize())
            }
        }
        ToggleRow(
            "Tilt the cover",
            "The cover turns a little when you move the phone and a soft shine slides across it",
            s.depthTilt,
            true,
        ) { v -> onUpdate { it.copy(depthTilt = v) } }
        if (s.depthTilt) {
            SliderRow("Strength", s.tiltStrength, 0.3f..1f, "${(s.tiltStrength * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(tiltStrength = (v * 10).roundToInt() / 10f) }
            }
        }
        Text(
            "Hold the phone upright and move it gently: the cover above follows. A phone held still settles flat after a few seconds. " +
                "It listens to the sensor only while the Now Playing screen is open, and never in battery saver or Lite mode.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    // ---------------------------------------------------------------- layout composer
    SettingCard("Layout composer") {
        val order = parseOrder(s.npOrder)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            LayoutSchematic(order, s.npCoverSize, s.npDensity, Modifier.width(120.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                order.forEachIndexed { i, sec ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. ${sec.label}", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                        RoundIconButton(Icons.Rounded.KeyboardArrowUp, "Move up", {
                            if (i > 0) onUpdate { it.copy(npOrder = moveNpSection(it.npOrder, sec, -1)) }
                        })
                        Spacer(Modifier.width(4.dp))
                        RoundIconButton(Icons.Rounded.KeyboardArrowDown, "Move down", {
                            if (i < order.lastIndex) onUpdate { it.copy(npOrder = moveNpSection(it.npOrder, sec, 1)) }
                        })
                    }
                }
            }
        }
        Text("Cover size", style = MaterialTheme.typography.labelLarge)
        Segmented(CoverSize.entries.map { it.label to it }, s.npCoverSize) { v -> onUpdate { it.copy(npCoverSize = v) } }
        Text("Spacing", style = MaterialTheme.typography.labelLarge)
        Segmented(NpDensity.entries.map { it.label to it }, s.npDensity) { v -> onUpdate { it.copy(npDensity = v) } }
        TextButton(onClick = {
            onUpdate { it.copy(npOrder = DEFAULT_NP_ORDER, npCoverSize = CoverSize.MEDIUM, npDensity = NpDensity.NORMAL) }
        }) { Text("Reset layout") }
        Text(
            "The order applies to the portrait player (Orbit and Panel). In landscape only the cover size and the spacing apply. " +
                "Large lets the cover use every spare pixel by trimming the gaps around it.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    // ---------------------------------------------------------------- stage backgrounds
    SettingCard("Stage backgrounds") {
        Box(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(cs.background),
        ) {
            StageBackground(s.npStage, song, true)
        }
        ChipPicker(NpStage.entries.map { it.label to it }, s.npStage) { v -> onUpdate { it.copy(npStage = v) } }
        Text(s.npStage.blurb, style = MaterialTheme.typography.bodyMedium)
        Text(
            "Drawn behind the player, above your background. It moves only while music plays, rests in battery saver and is off in Lite mode.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }
}

/** A small drawing of the player: the cover and the three blocks in the chosen order, with the chosen spacing. */
@Composable
private fun LayoutSchematic(order: List<NpSection>, cover: CoverSize, density: NpDensity, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val gap = (5f * density.factor).dp
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(cs.surfaceContainerHighest)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .fillMaxWidth(cover.scale)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(cs.primary.copy(alpha = 0.35f)),
        )
        for (sec in order) {
            Spacer(Modifier.height(gap))
            val barHeight = when (sec) {
                NpSection.TITLE -> 22.dp
                NpSection.SEEK -> 16.dp
                NpSection.CONTROLS -> 30.dp
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(barHeight)
                    .clip(RoundedCornerShape(8.dp))
                    .background(cs.secondaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    sec.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSecondaryContainer,
                    maxLines = 1,
                )
            }
        }
    }
}
