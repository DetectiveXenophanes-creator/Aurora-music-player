package com.aurora.player

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils

/** Opens when you add the widget (and again from its settings). Pick a look, then tap Save. */
class WidgetConfigActivity : ComponentActivity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        // If the person backs out, the widget is not added.
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val start = WidgetStore.load(this, widgetId)
        val store = SettingsStore(this)
        setContent {
            val settings by store.flow.collectAsState(initial = AppSettings())
            CompositionLocalProvider(LocalAppSettings provides settings) {
                AuroraTheme(settings) {
                    ConfigScreen(
                        start = start,
                        onSave = { opts ->
                            WidgetStore.save(this, widgetId, opts)
                            AuroraWidget.refreshAll(this)
                            setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                            finish()
                        },
                    )
                }
            }
        }
    }
}

private val bgNames = listOf("App theme", "Accent", "Dark", "Light", "Custom")
private val layoutNames = listOf("Classic", "Compact", "Cover")
private val radiusNames = listOf("Square", "Soft", "Round", "Pill")
private val shapeNames = listOf("Square", "Rounded", "Circle")
private val sizeNames = listOf("Small", "Medium", "Large")

@Composable
private fun <T> Chips(names: List<String>, values: List<T>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n -> AuroraChip(n, values[i] == selected) { onSelect(values[i]) } }
    }
}

@Composable
private fun ConfigScreen(start: WidgetOpts, onSave: (WidgetOpts) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var o by remember { mutableStateOf(start) }
    val theme = remember { WidgetState.theme(context) }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Customize widget", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            WidgetPreview(o, theme)

            SettingCard("Layout") {
                Chips(layoutNames, listOf(0, 1, 2), o.layout) { v -> o = o.copy(layout = v) }
                Text(
                    when (o.layout) {
                        0 -> "Cover, title, artist and all three buttons."
                        1 -> "A slim bar. Good for one row of icons."
                        else -> "The album art fills the whole widget."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            SettingCard("Background") {
                Chips(bgNames.take(3), listOf(0, 1, 2), o.bg) { v -> o = o.copy(bg = v) }
                Chips(bgNames.drop(3), listOf(3, 4), o.bg) { v -> o = o.copy(bg = v) }
                if (o.bg == 4) {
                    SliderRow("Colour", o.hue, 0f..359f, "${o.hue.toInt()}") { v -> o = o.copy(hue = v) }
                    SliderRow("Brightness", o.shade, 0.15f..0.95f, "${(o.shade * 100).toInt()}%") { v -> o = o.copy(shade = v) }
                }
                SliderRow("Opacity", o.opacity, 0.1f..1f, "${(o.opacity * 100).toInt()}%") { v -> o = o.copy(opacity = v) }
            }
            SettingCard("Corners") {
                Chips(radiusNames, listOf(0, 1, 2, 3), o.radius) { v -> o = o.copy(radius = v) }
            }
            SettingCard("Cover art") {
                ToggleRow("Show cover", "The album picture", o.showArt || o.layout == 2, o.layout != 2) { v -> o = o.copy(showArt = v) }
                if (o.layout != 2) Chips(shapeNames, listOf(0, 1, 2), o.artShape) { v -> o = o.copy(artShape = v) }
            }
            SettingCard("Text") {
                Chips(sizeNames, listOf(0, 1, 2), o.textSize) { v -> o = o.copy(textSize = v) }
                ToggleRow("Show artist", "Under the song title", o.showArtist, true) { v -> o = o.copy(showArtist = v) }
            }
            SettingCard("Buttons") {
                ToggleRow("Previous and next", "Turn off to keep only play and pause", o.showButtons, true) { v -> o = o.copy(showButtons = v) }
                ToggleRow("Round play button", "A coloured circle behind play", o.plate, true) { v -> o = o.copy(plate = v) }
            }
            Button(onClick = { onSave(o) }, modifier = Modifier.fillMaxWidth()) { Text("Save widget") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

/** A drawn stand-in for the real widget so you see changes as you make them. */
@Composable
private fun WidgetPreview(o: WidgetOpts, theme: WidgetState.Theme) {
    val bg = WidgetRender.backgroundColor(o, theme)
    val bgColor = Color(bg).copy(alpha = o.opacity.coerceIn(0.1f, 1f))
    val radius = WidgetRender.RADII[o.radius.coerceIn(0, 3)].dp
    val cover = o.layout == 2
    val text = if (cover) Color.White else Color(WidgetRender.readableOn(bg))
    val shape = RoundedCornerShape(radius)
    val plate = Color(theme.primary)
    val artShape = when (o.artShape) {
        0 -> RoundedCornerShape(0.dp)
        1 -> RoundedCornerShape(10.dp)
        else -> CircleShape
    }
    val height = when (o.layout) {
        1 -> 62.dp
        2 -> 150.dp
        else -> 92.dp
    }
    Box(Modifier.fillMaxWidth().height(height).clip(shape).background(bgColor)) {
        if (cover) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color(theme.primary).copy(alpha = 0.55f), Color(ColorUtils.blendARGB(theme.primary, android.graphics.Color.BLACK, 0.6f))),
                    ),
                ),
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)))))
        }
        Row(
            Modifier.fillMaxSize().padding(if (o.layout == 1) 8.dp else 10.dp),
            verticalAlignment = if (cover) Alignment.Bottom else Alignment.CenterVertically,
        ) {
            if (!cover && o.showArt) {
                val side = if (o.layout == 1) 44.dp else 64.dp
                Box(Modifier.size(side).clip(artShape).background(text.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MusicNote, null, tint = text, modifier = Modifier.size(side / 2))
                }
                Spacer(Modifier.size(10.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("Song title", color = text, fontWeight = FontWeight.Bold, maxLines = 1)
                if (o.showArtist) Text("Artist name", color = text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (o.layout == 0) {
                    Spacer(Modifier.height(4.dp))
                    PreviewButtons(o, text, plate)
                }
            }
            if (o.layout != 0) PreviewButtons(o, text, plate)
        }
    }
}

@Composable
private fun PreviewButtons(o: WidgetOpts, text: Color, plate: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (o.showButtons) Icon(Icons.Rounded.SkipPrevious, null, tint = text, modifier = Modifier.size(28.dp))
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (o.plate) plate else Color.Transparent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.PlayArrow,
                null,
                tint = if (o.plate) Color(WidgetRender.readableOn(plate.toArgb())) else text,
                modifier = Modifier.size(24.dp),
            )
        }
        if (o.showButtons) Icon(Icons.Rounded.SkipNext, null, tint = text, modifier = Modifier.size(28.dp))
    }
}
