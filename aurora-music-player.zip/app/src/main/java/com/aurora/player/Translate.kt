package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import java.util.Locale

/** The languages Aurora ships with. Names are written in their own language so anyone can find theirs. */
enum class AppLanguage(val code: String, val native: String) {
    SYSTEM("system", "System default"),
    EN("en", "English"),
    PL("pl", "Polski"),
    ES("es", "Español"),
    FR("fr", "Français"),
    DE("de", "Deutsch"),
    PT("pt", "Português"),
    IT("it", "Italiano"),
    TR("tr", "Türkçe"),
    RU("ru", "Русский"),
    JA("ja", "日本語"),
    ZH("zh", "简体中文"),
}

/** The language code in use right now ("en", "pl", ...). "System default" follows the phone, falling back to English. */
fun resolveLanguage(l: AppLanguage): String {
    if (l != AppLanguage.SYSTEM) return l.code
    val sys = Locale.getDefault().language
    return if (AppLanguage.entries.any { it.code == sys && it != AppLanguage.SYSTEM }) sys else "en"
}

val LocalLang = staticCompositionLocalOf { "en" }

/** Translate one string for the current language. Use this where text is built from pieces. */
@Composable
fun tr(text: String): String = translate(LocalLang.current, text)

private const val RAW = '\u200B'

/** Marks a string (a song title, playlist name, ...) as data that must never be translated. */
fun verbatim(text: String): String = RAW + text

fun translate(lang: String, text: String): String {
    if (text.isNotEmpty() && text[0] == RAW) return text.substring(1)
    if (lang == "en" || text.isEmpty()) return text
    val table = Translations.table(lang) ?: return text
    table[text]?.let { return it }
    val lead = text.takeWhile { it.isWhitespace() }
    val trail = text.takeLastWhile { it.isWhitespace() }
    val core = text.trim()
    if (core.isEmpty()) return text
    if (core != text) table[core]?.let { return lead + it + trail }
    if (core.none { it.isDigit() }) return text
    // Numbers become "#" so "12 songs" finds the entry "# songs", then the numbers are put back in order.
    val nums = ArrayList<String>(4)
    val key = StringBuilder(core.length)
    var i = 0
    while (i < core.length) {
        if (core[i].isDigit()) {
            var j = i
            while (j < core.length && core[j].isDigit()) j++
            nums.add(core.substring(i, j))
            key.append('#')
            i = j
        } else {
            key.append(core[i])
            i++
        }
    }
    val pattern = table[key.toString()] ?: return text
    val out = StringBuilder(pattern.length + 8)
    var k = 0
    for (ch in pattern) {
        if (ch == '#' && k < nums.size) out.append(nums[k++]) else out.append(ch)
    }
    return lead + out + trail
}

/**
 * Drop-in replacement for material3 Text. Every string drawn with it is translated for the chosen language,
 * so screens do not need to know about languages. Files import nothing for Text: this one wins by package.
 */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current,
) {
    androidx.compose.material3.Text(
        text = translate(LocalLang.current, text),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style,
    )
}

/** Small pill showing the current language; tapping it opens the language sheet. */
@Composable
fun LanguageButton(current: AppLanguage, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val label = if (current == AppLanguage.SYSTEM) {
        AppLanguage.entries.first { it.code == resolveLanguage(current) }.native
    } else current.native
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(cs.secondaryContainer.copy(alpha = 0.6f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Language, null, tint = cs.onSecondaryContainer, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        androidx.compose.material3.Text(label, style = MaterialTheme.typography.labelLarge, color = cs.onSecondaryContainer, maxLines = 1)
    }
}

@Composable
fun LanguageSheet(current: AppLanguage, onPick: (AppLanguage) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape((LocalAppSettings.current.corner * 0.7f).coerceAtLeast(14f).dp)
    AuroraSheet(onDismiss = onDismiss, title = "Language") {
        Column(
            Modifier
                .heightIn(max = 520.dp)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            AppLanguage.entries.forEach { lang ->
                val selected = lang == current
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (selected) cs.primaryContainer.copy(alpha = 0.7f) else cs.surfaceContainerHighest.copy(alpha = 0.55f))
                        .clickable { onPick(lang) }
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (lang == AppLanguage.SYSTEM) {
                        Text(lang.native, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    } else {
                        androidx.compose.material3.Text(
                            lang.native,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (selected) cs.onPrimaryContainer else cs.onSurface,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (selected) Icon(Icons.Rounded.Check, null, tint = cs.primary, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

object Translations {
    private val order = listOf("pl", "es", "fr", "de", "pt", "it", "tr", "ru", "ja", "zh")
    private val tables: Map<String, HashMap<String, String>> by lazy {
        val maps = order.associateWith { HashMap<String, String>(512) }
        for (chunk in listOf(TABLE_1, TABLE_2, TABLE_3)) {
            for (line in chunk.lineSequence()) {
                if (line.isBlank()) continue
                val parts = line.split('|')
                val key = parts[0].trim()
                if (key.isEmpty()) continue
                for (i in order.indices) {
                    val v = parts.getOrNull(i + 1)?.trim()
                    if (!v.isNullOrEmpty()) maps.getValue(order[i])[key] = v
                }
            }
        }
        maps
    }

    fun table(lang: String): Map<String, String>? = tables[lang]
}
