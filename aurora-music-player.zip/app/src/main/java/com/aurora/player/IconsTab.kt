package com.aurora.player

import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.roundToInt

/** Background colours to pick from for an icon you make. */
private val iconBgs = listOf(
    0xFF0E1330, 0xFF000000, 0xFFFFFFFF, 0xFFE53935, 0xFFFB8C00, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A,
).map { it.toInt() }

/** Settings > Icons: colour icons for the home screen, and icons you make from your own pictures. */
@Composable
internal fun IconsTab(s: AppSettings) {
    val context = LocalContext.current
    val store = remember { IconStore(context) }
    val prefs by store.flow.collectAsState(initial = IconPrefs(emptyList(), false))
    var page by rememberSaveable { mutableStateOf(0) }
    var note by remember { mutableStateOf<String?>(null) }

    Segmented(listOf("Presets" to 0, "Make your own" to 1), page) { page = it }
    note?.let { msg ->
        SettingCard("Status") { Text(msg, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
    }
    if (page == 0) {
        IconPresetsPage(s, prefs, store) { note = it }
    } else {
        IconCreatePage(store) {
            note = it
            page = 0
        }
    }
}

@Composable
private fun IconPresetsPage(s: AppSettings, prefs: IconPrefs, store: IconStore, onNote: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var current by remember { mutableStateOf(AppIcons.current(context)) }
    var picked by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<VectorIcon?>(null) }

    SettingCard("Colour icons") {
        Text(
            "Pick a colour and the Aurora icon on your home screen changes. It can take a few seconds, and some launchers briefly hide or move the icon when it switches.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        AppIcons.presets.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { p ->
                    PresetTile(p, p == current, Modifier.weight(1f)) {
                        if (AppIcons.apply(context, p)) {
                            current = p
                            onNote("The home screen icon is now ${p.label}.")
                        } else {
                            onNote("Android would not switch the icon.")
                        }
                    }
                }
            }
        }
    }

    SettingCard("Follow my colour") {
        ToggleRow(
            "Match my accent colour",
            "Switches to the colour icon closest to your theme colour whenever you change it",
            prefs.auto,
            true,
        ) { on ->
            scope.launch { store.setAuto(on) }
            if (on) {
                val n = AppIcons.nearest(s.accent)
                if (AppIcons.apply(context, n)) {
                    current = n
                    onNote("The icon now follows your accent colour (${n.label} for now).")
                }
            }
        }
    }

    SettingCard("My icons") {
        if (prefs.icons.isEmpty()) {
            Text(
                "Icons you make show up here. Open Make your own, pick a picture and Aurora turns it into a vector icon.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
        } else {
            prefs.icons.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { ic ->
                        MineTile(ic, ic.id == picked, Modifier.weight(1f)) {
                            picked = if (picked == ic.id) null else ic.id
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            val sel = prefs.icons.firstOrNull { it.id == picked }
            if (sel != null) {
                Text(
                    "Android only lets the real home screen icon come from inside the app, so your own icons are added as a shortcut that opens Aurora. You can then remove the original icon from your home screen yourself.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                FilledTonalButton(onClick = {
                    val ok = AppIcons.pinCustom(context, sel)
                    onNote(
                        if (ok) "Your launcher is asking to add ${sel.name} to the home screen."
                        else "This launcher cannot add shortcuts like this.",
                    )
                }) {
                    Icon(Icons.Rounded.AddToHomeScreen, null, Modifier.size(18.dp))
                    Text("  Add to home screen")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { renaming = sel }) {
                        Icon(Icons.Rounded.Edit, null, Modifier.size(18.dp))
                        Text("  Rename")
                    }
                    TextButton(onClick = {
                        scope.launch { store.remove(sel.id) }
                        picked = null
                    }) {
                        Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                        Text("  Delete")
                    }
                }
            }
        }
    }

    val ren = renaming
    if (ren != null) {
        var text by remember(ren.id) { mutableStateOf(ren.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename icon") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it.take(24) }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { store.rename(ren.id, text.trim().ifBlank { "My icon" }) }
                    renaming = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun IconCreatePage(store: IconStore, onSaved: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var grid by remember { mutableStateOf<IntArray?>(null) }
    var layers by remember { mutableStateOf<List<IconLayer>>(emptyList()) }
    var colors by remember { mutableFloatStateOf(4f) }
    var removeBg by remember { mutableStateOf(true) }
    var bg by remember { mutableIntStateOf(iconBgs[0]) }
    var name by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                error = null
                val px = withContext(Dispatchers.IO) {
                    runCatching { IconTracer.decode(context, uri)?.let { IconTracer.toGrid(it) } }.getOrNull()
                }
                if (px == null) {
                    error = "Aurora could not read that file as a picture. Try a PNG or JPG."
                    busy = false
                } else {
                    grid = px
                }
            }
        }
    }

    val steps = colors.roundToInt()
    LaunchedEffect(grid, steps, removeBg) {
        val px = grid ?: return@LaunchedEffect
        busy = true
        layers = withContext(Dispatchers.Default) { IconTracer.trace(px, steps, removeBg) }
        busy = false
    }

    SettingCard("Your picture") {
        Text(
            "Pick a logo, drawing or photo. Aurora shrinks it, picks a few colours and traces each colour into a vector shape, all on your phone. Simple pictures with clear shapes work best.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        FilledTonalButton(enabled = !busy, onClick = { picker.launch("image/*") }) {
            Icon(Icons.Rounded.Image, null, Modifier.size(18.dp))
            Text("  Choose a picture")
        }
        error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.error) }
    }

    if (grid != null) {
        SettingCard("Look") {
            SliderRow("Colours", colors, 2f..8f, "$steps") { colors = it }
            ToggleRow("Remove the background", "Clears the colour that fills the edges of the picture", removeBg, true) {
                removeBg = it
            }
            Text("Background colour", style = MaterialTheme.typography.labelLarge)
            iconBgs.chunked(5).forEach { r ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    r.forEach { c ->
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(if (c == bg) 3.dp else 1.dp, if (c == bg) cs.primary else cs.outline, CircleShape)
                                .clickable { bg = c },
                        )
                    }
                }
            }
        }
        SettingCard("Preview") {
            val icon = VectorIcon("preview", name, IconTracer.GRID, bg, layers)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                VectorIconView(icon, Modifier.size(132.dp))
            }
            Text(
                if (busy) "Tracing..." else "${layers.sumOf { it.loops.size }} shapes in ${layers.size} colours",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(24) },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                enabled = !busy && layers.isNotEmpty(),
                onClick = {
                    val made = VectorIcon(
                        UUID.randomUUID().toString().take(8),
                        name.trim().ifBlank { "My icon" },
                        IconTracer.GRID,
                        bg,
                        layers,
                    )
                    scope.launch {
                        store.upsert(made)
                        onSaved("Saved ${made.name} to Presets, under My icons.")
                    }
                },
            ) { Text("Save to My icons") }
        }
    }
}

@Composable
private fun PresetTile(p: IconPreset, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) cs.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(64.dp)) {
            AndroidView(
                factory = { ctx -> ImageView(ctx).apply { setImageResource(p.res) } },
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().clickable(onClick = onClick))
        }
        Text(
            p.label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface,
        )
    }
}

@Composable
private fun MineTile(icon: VectorIcon, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) cs.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        VectorIconView(icon, Modifier.size(64.dp))
        Text(
            icon.name,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface,
        )
    }
}
