package com.aurora.player

import androidx.compose.foundation.LocalIndication
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

@Composable
fun AlbumsScreen(groups: List<Group>, padding: PaddingValues, onOpen: (Group) -> Unit) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(s.corner.dp)
    val seen = remember { HashSet<String>() }
    if (groups.isEmpty()) {
        EmptyBrowse("No albums yet", padding)
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(groups, key = { it.key }) { g ->
            val animate = remember { seen.add(g.key) } && s.listEntrance
            val source = remember { MutableInteractionSource() }
            Column(
                Modifier
                    .animateItem(
                        fadeInSpec = if (motion.enabled) motion.effects<Float>() else null,
                        placementSpec = if (motion.enabled) motion.spatial<IntOffset>() else null,
                        fadeOutSpec = if (motion.enabled) motion.effects<Float>() else null,
                    )
                    .enterAnim(animate, 0)
                    .pressScale(source)
                    .cardFinish(shape)
                    .clickable(interactionSource = source, indication = LocalIndication.current) { onOpen(g) }
                    .padding(10.dp),
            ) {
                val art = g.art
                if (art != null) {
                    Art(art.artUri, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape((s.corner * 0.7f).dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(verbatim(g.title), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${g.subtitle} • ${g.songs.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Artists (round photo) and folders (folder icon) share one list layout. */
@Composable
fun GroupListScreen(groups: List<Group>, folders: Boolean, padding: PaddingValues, onOpen: (Group) -> Unit) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(s.corner.dp)
    val seen = remember { HashSet<String>() }
    if (groups.isEmpty()) {
        EmptyBrowse(if (folders) "No folders yet" else "No artists yet", padding)
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        itemsIndexed(groups, key = { _, g -> g.key }) { index, g ->
            val animate = remember { seen.add(g.key) } && s.listEntrance
            val source = remember { MutableInteractionSource() }
            Row(
                Modifier
                    .animateItem(
                        fadeInSpec = if (motion.enabled) motion.effects<Float>() else null,
                        placementSpec = if (motion.enabled) motion.spatial<IntOffset>() else null,
                        fadeOutSpec = if (motion.enabled) motion.effects<Float>() else null,
                    )
                    .enterAnim(animate, index)
                    .fillMaxWidth()
                    .pressScale(source)
                    .cardFinish(shape)
                    .clickable(interactionSource = source, indication = LocalIndication.current) { onOpen(g) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (folders) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape((s.corner * 0.5f).dp)).background(cs.secondaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Folder, null, tint = cs.onSecondaryContainer)
                    }
                } else {
                    g.art?.let { Art(it.artUri, Modifier.size(52.dp), CircleShape) }
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(verbatim(g.title), style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (folders) g.subtitle else "${g.songs.size} songs",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (folders) {
                    Text("${g.songs.size}", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                    Spacer(Modifier.width(6.dp))
                }
            }
        }
    }
}

@Composable
private fun EmptyBrowse(text: String, padding: PaddingValues) {
    Box(
        Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding()),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Songs of one album, artist, folder or playlist. The title lives in the top bar. */
/**
 * A list of songs (album, artist, folder, playlist...). With [tools] on (playlists and "made for you" lists) it also gets a
 * search box and a Sort and filter sheet. Those only change what you see: the playlist itself is not touched, and Play,
 * Shuffle and tapping a song use the list as it is shown.
 */
@Composable
fun DetailScreen(
    subtitle: String,
    songs: List<Song>,
    padding: PaddingValues,
    currentId: Long?,
    playing: Boolean,
    onPlay: (Song, List<Song>) -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onRemove: ((Song) -> Unit)? = null,
    lib: LibraryData? = null,
    tools: Boolean = false,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(s.corner.dp)
    val seen = remember { HashSet<Long>() }
    val showTools = tools && lib != null
    var query by rememberSaveable { mutableStateOf("") }
    var sortIdx by rememberSaveable { mutableStateOf(0) }
    var asc by rememberSaveable { mutableStateOf(true) }
    var favOnly by rememberSaveable { mutableStateOf(false) }
    var unplayed by rememberSaveable { mutableStateOf(false) }
    var lenIdx by rememberSaveable { mutableStateOf(0) }
    var showSheet by rememberSaveable { mutableStateOf(false) }
    val view = ListView(query, ListSort.entries[sortIdx], asc, favOnly, unplayed, LenFilter.entries[lenIdx])
    val shown = remember(songs, showTools, view, lib?.plays, lib?.favorites) {
        if (showTools && lib != null) applyListView(songs, view, lib) else songs
    }
    if (showSheet) {
        ListViewSheet(
            view = view,
            shown = shown.size,
            onChange = { v ->
                sortIdx = v.sort.ordinal
                asc = v.asc
                favOnly = v.favOnly
                unplayed = v.neverPlayed
                lenIdx = v.len.ordinal
            },
            onDismiss = { showSheet = false },
        )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    songs.firstOrNull()?.let { Art(it.artUri, Modifier.size(84.dp), RoundedCornerShape((s.corner * 0.8f).dp)) }
                    Column(Modifier.padding(start = 14.dp)) {
                        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${songs.size} songs  •  ${fmt(songs.sumOf { it.durationMs })}",
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.primary,
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onPlayAll(shown) }, enabled = shown.isNotEmpty()) {
                        Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Play")
                    }
                    FilledTonalButton(onClick = { onShuffle(shown) }, enabled = shown.isNotEmpty()) {
                        Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Shuffle")
                    }
                }
            }
        }
        if (showTools && songs.isNotEmpty()) {
            item {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search this list") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth().cardFinish(shape),
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(onClick = { showSheet = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.FilterList, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Sort and filter", maxLines = 1)
                    }
                    if (view.active) {
                        TextButton(onClick = {
                            query = ""
                            sortIdx = 0
                            asc = true
                            favOnly = false
                            unplayed = false
                            lenIdx = 0
                        }) { Text("Clear") }
                    }
                }
            }
            if (view.active) {
                item {
                    val (low, high) = listDirectionLabels(view.sort)
                    Text(
                        buildString {
                            append("${shown.size} of ${songs.size} songs  •  ${view.sort.label}, ${if (view.asc) low else high}")
                            if (view.favOnly) append("  •  Favorites")
                            if (view.neverPlayed) append("  •  Never played")
                            if (view.len != LenFilter.ANY) append("  •  ${view.len.label}")
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (songs.isEmpty()) {
            item { InfoCard("Nothing here yet", "Songs you add or play will show up in this list.", null) {} }
        } else if (shown.isEmpty()) {
            item { InfoCard("No songs match", "Try a different search, or clear the filters in Sort and filter.", null) {} }
        }
        itemsIndexed(shown, key = { _, song -> song.id }) { index, song ->
            val animate = remember { seen.add(song.id) } && s.listEntrance
            SongRow(
                song = song,
                current = song.id == currentId,
                playing = playing,
                modifier = Modifier.enterAnim(animate, index),
                onRemove = onRemove?.let { f -> { f(song) } },
            ) { onPlay(song, shown) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ListViewSheet(view: ListView, shown: Int, onChange: (ListView) -> Unit, onDismiss: () -> Unit) {
    val (lowLabel, highLabel) = listDirectionLabels(view.sort)
    AuroraSheet(onDismiss = onDismiss, title = "Sort and filter") {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SheetLabel("Sort by")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ListSort.entries.forEach { k ->
                    AuroraChip(k.label, view.sort == k) {
                        if (view.sort != k) {
                            // plays and date added start with the biggest first, like the Songs tab
                            val first = k != ListSort.PLAYS && k != ListSort.ADDED
                            onChange(view.copy(sort = k, asc = first))
                        }
                    }
                }
            }
            SheetLabel("Order")
            Segmented(
                options = listOf(lowLabel to true, highLabel to false),
                selected = view.asc,
                onSelect = { v -> onChange(view.copy(asc = v)) },
            )
            SheetLabel("Filter")
            ToggleRow("Favorites only", "Hide songs you have not hearted", view.favOnly, true) { v ->
                onChange(view.copy(favOnly = v))
            }
            ToggleRow("Never played", "Only songs you have not played yet", view.neverPlayed, true) { v ->
                onChange(view.copy(neverPlayed = v))
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LenFilter.entries.forEach { f ->
                    AuroraChip(f.label, view.len == f) { onChange(view.copy(len = f)) }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onChange(ListView(query = view.query)) }) { Text("Reset") }
                Spacer(Modifier.weight(1f))
                Button(onClick = onDismiss) { Text("Show $shown songs") }
            }
        }
    }
}
