package com.aurora.player

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Lyrics for the song that is playing. Synced lyrics follow the music; tap a line to jump to it. */
@Composable
fun LyricsSheet(
    vm: PlayerViewModel,
    song: Song,
    settings: AppSettings,
    onUpdate: ((AppSettings) -> AppSettings) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var reload by remember { mutableStateOf(0) }
    var lyrics by remember(song.id) { mutableStateOf<Lyrics?>(null) }
    var loading by remember(song.id) { mutableStateOf(true) }
    LaunchedEffect(song.id, reload) {
        loading = true
        lyrics = LyricsStore.load(context, song)
        loading = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                if (LyricsStore.import(context, song.id, uri)) reload++
                else Toast.makeText(context, "Could not read that file", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val pos by vm.position.collectAsState()
    val imported = LyricsStore.hasImported(context, song.id)

    AuroraSheet(onDismiss = onDismiss, title = "Lyrics") {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text(song.title, style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant, maxLines = 1)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilledTonalButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(if (imported) "Replace file" else "Add lyrics file") }
                if (imported) TextButton(onClick = { LyricsStore.remove(context, song.id); reload++ }) { Text("Remove") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { onUpdate { it.copy(lyricsSize = (it.lyricsSize + 1) % 3) } }) { Text("Size") }
                TextButton(onClick = { onUpdate { it.copy(lyricsCenter = !it.lyricsCenter) } }) {
                    Text(if (settings.lyricsCenter) "Centre" else "Left")
                }
            }
            val l = lyrics
            when {
                loading -> Text("Looking for lyrics…", color = cs.onSurfaceVariant, modifier = Modifier.padding(vertical = 24.dp))
                l == null -> Text(
                    "No lyrics found. Aurora reads lyrics saved inside MP3 files and a .lrc file next to the song. " +
                        "You can also add an .lrc or .txt file yourself.",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp),
                )
                else -> {
                    val size = listOf(17.sp, 22.sp, 28.sp)[settings.lyricsSize.coerceIn(0, 2)]
                    val idx = if (l.synced) l.lines.indexOfLast { it.timeMs <= pos + 200 } else -1
                    val state = rememberLazyListState()
                    LaunchedEffect(idx) { if (idx >= 0) state.animateScrollToItem((idx - 2).coerceAtLeast(0)) }
                    LazyColumn(
                        Modifier.fillMaxWidth().height(420.dp),
                        state = state,
                        contentPadding = PaddingValues(vertical = 60.dp),
                    ) {
                        itemsIndexed(l.lines) { i, line ->
                            Text(
                                verbatim(line.text.ifBlank { "♪" }),
                                fontSize = size,
                                fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Medium,
                                color = when {
                                    !l.synced -> cs.onSurface
                                    i == idx -> cs.primary
                                    else -> cs.onSurface.copy(alpha = 0.55f)
                                },
                                textAlign = if (settings.lyricsCenter) TextAlign.Center else TextAlign.Start,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = l.synced) { vm.seekTo(line.timeMs) }
                                    .padding(vertical = 8.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
