package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import kotlin.math.max

@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val pos by vm.position.collectAsState()
    val settings = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val haze = remember { HazeState() }
    val song = ui.current
    val panelShape = RoundedCornerShape((settings.corner * 1.4f).dp)
    var dragging by remember { mutableStateOf<Float?>(null) }

    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize().background(cs.background)) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground()
                if (song != null) {
                    AsyncImage(
                        model = song.artUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        alpha = 0.5f,
                        modifier = Modifier.fillMaxSize().blur(40.dp, BlurredEdgeTreatment.Unbounded),
                    )
                }
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }
                    Text("Now playing", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.weight(1f))
                if (song != null) {
                    Art(song.artUri, Modifier.fillMaxWidth(0.82f).aspectRatio(1f), panelShape)
                }
                Spacer(Modifier.weight(1f))

                Column(Modifier.fillMaxWidth().finish(panelShape).padding(20.dp)) {
                    Text(
                        song?.title ?: "Nothing playing",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        song?.artist ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Slider(
                        value = dragging ?: pos.toFloat(),
                        onValueChange = { dragging = it },
                        onValueChangeFinished = {
                            dragging?.let { vm.seekTo(it.toLong()) }
                            dragging = null
                        },
                        valueRange = 0f..max(1f, ui.duration.toFloat()),
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmt((dragging ?: pos.toFloat()).toLong()), style = MaterialTheme.typography.labelMedium)
                        Text(fmt(ui.duration), style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { vm.toggleShuffle() }) {
                            Icon(
                                Icons.Rounded.Shuffle, "Shuffle",
                                tint = if (ui.shuffle) cs.primary else cs.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { vm.previous() }, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(32.dp))
                        }
                        FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(72.dp)) {
                            Icon(
                                if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                "Play or pause",
                                Modifier.size(38.dp),
                            )
                        }
                        IconButton(onClick = { vm.next() }, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(32.dp))
                        }
                        IconButton(onClick = { vm.cycleRepeat() }) {
                            Icon(
                                if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                                "Repeat",
                                tint = if (ui.repeat != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurfaceVariant,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
