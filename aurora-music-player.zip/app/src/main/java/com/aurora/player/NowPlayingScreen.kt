package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val pos by vm.position.collectAsState()
    val lib by vm.library.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val settings = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val haze = remember { HazeState() }
    val song = ui.current
    val artShape = RoundedCornerShape((settings.corner * 1.3f).dp)
    var preview by remember { mutableStateOf<Float?>(null) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }

    val view = LocalView.current
    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    val progress = if (ui.duration > 0) (pos.toFloat() / ui.duration).coerceIn(0f, 1f) else 0f
    val artScale by animateFloatAsState(
        targetValue = if (!settings.artBreathing || ui.isPlaying) 1f else 1f - 0.12f * motion.amount.coerceAtMost(1f),
        animationSpec = motion.spatial(),
        label = "artScale",
    )

    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(song, overlayArt = true)
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
            ) {
                // top bar
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(Icons.Rounded.KeyboardArrowDown, "Close", onClose)
                    Text(
                        "Now Playing",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f).padding(start = 14.dp),
                    )
                    RoundIconButton(Icons.Rounded.Bedtime, "Sleep timer", { showSleep = true })
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    RoundIconButton(Icons.Rounded.QueueMusic, "Queue", { showQueue = true })
                }
                Spacer(Modifier.height(16.dp))

                // artwork
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .graphicsLayer {
                                scaleX = artScale
                                scaleY = artScale
                            },
                    ) {
                        AnimatedContent(
                            targetState = song,
                            transitionSpec = { motion.songChange() },
                            label = "art",
                            modifier = Modifier.fillMaxSize(),
                        ) { s ->
                            if (s != null) Art(s.artUri, Modifier.fillMaxSize(), artShape)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))

                // title and actions
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 12.dp)) {
                        AnimatedContent(
                            targetState = song?.title ?: "Nothing playing",
                            transitionSpec = { motion.text() },
                            label = "title",
                        ) { t ->
                            Text(
                                t,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        AnimatedContent(
                            targetState = song?.artist ?: "",
                            transitionSpec = { motion.text() },
                            label = "artist",
                        ) { a ->
                            Text(
                                a,
                                style = MaterialTheme.typography.bodyLarge,
                                color = cs.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    if (song != null) {
                        SongMenu(song, null) { open ->
                            RoundIconButton(Icons.Rounded.MoreVert, "More", open)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))

                // seek bar, times and format
                SeekBar(
                    progress = progress,
                    playing = ui.isPlaying,
                    wavy = settings.seekStyle == SeekStyle.WAVY,
                    onPreview = { preview = it },
                    onSeek = { f -> vm.seekTo((f * ui.duration).toLong()) },
                )
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        fmt(((preview ?: progress) * ui.duration).toLong()),
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                    )
                    if (ui.audioInfo.isNotEmpty()) FormatChip(ui.audioInfo)
                    Text(fmt(ui.duration), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(16.dp))

                // main controls
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SkipButton(
                        forward = false,
                        onClick = { vm.previous() },
                        modifier = Modifier.weight(1f).height(72.dp),
                        iconSize = 32.dp,
                    )
                    PlayPauseButton(
                        playing = ui.isPlaying,
                        onClick = { vm.togglePlay() },
                        modifier = Modifier.weight(1f).height(72.dp),
                        iconSize = 34.dp,
                    )
                    SkipButton(
                        forward = true,
                        onClick = { vm.next() },
                        modifier = Modifier.weight(1f).height(72.dp),
                        iconSize = 32.dp,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionPill(
                        active = ui.shuffle,
                        icon = Icons.Rounded.Shuffle,
                        description = "Shuffle",
                        onClick = { vm.toggleShuffle() },
                        modifier = Modifier.weight(1f).height(52.dp),
                    )
                    ActionPill(
                        active = ui.repeat != Player.REPEAT_MODE_OFF,
                        icon = if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        description = "Repeat",
                        onClick = { vm.cycleRepeat() },
                        modifier = Modifier.weight(1f).height(52.dp),
                    )
                    val fav = song != null && song.id in lib.favorites
                    ActionPill(
                        active = fav,
                        icon = if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        description = "Favorite",
                        onClick = { song?.let { vm.toggleFavorite(it.id) } },
                        modifier = Modifier.weight(1f).height(52.dp),
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showSleep) {
        AlertDialog(
            onDismissRequest = { showSleep = false },
            title = { Text("Sleep timer") },
            text = {
                Column {
                    sleepLeft?.let {
                        Text(
                            "Music stops in ${(it / 60_000) + 1} min",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.primary,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    listOf(15, 30, 45, 60, 90).forEach { m ->
                        TextButton(onClick = { vm.setSleepTimer(m); showSleep = false }) { Text("$m minutes") }
                    }
                    if (sleepLeft != null) {
                        TextButton(onClick = { vm.setSleepTimer(null); showSleep = false }) { Text("Turn off") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSleep = false }) { Text("Close") } },
        )
    }

    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }) {
            val queue = remember { vm.queueSnapshot() }
            val index = remember { vm.currentIndex() }
            val listState = rememberLazyListState(initialFirstVisibleItemIndex = index.coerceIn(0, (queue.size - 1).coerceAtLeast(0)))
            Text(
                "Up next",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp), state = listState) {
                itemsIndexed(queue) { i, q ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.jumpTo(i); showQueue = false }
                            .padding(horizontal = 24.dp, vertical = 10.dp),
                    ) {
                        Text(
                            q.title,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (i == index) cs.primary else cs.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(q.artist, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
