package com.aurora.player

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * A saved look: a name and the appearance settings as they were when it was saved.
 * [atMinute] is the time of day it switches on by itself (minutes after midnight), or -1 for no time.
 */
class LookProfile(val id: String, val name: String, val look: JSONArray, val atMinute: Int) {
    fun copy(name: String = this.name, look: JSONArray = this.look, atMinute: Int = this.atMinute) =
        LookProfile(id, name, look, atMinute)
}

data class ProfilePrefs(val profiles: List<LookProfile>, val auto: Boolean)

private val Context.profileStore by preferencesDataStore(name = "aurora_profiles")

/** Saves, applies and schedules look profiles. Applying one only touches appearance settings (see SettingsStore.applyLook). */
class ProfileStore(context: Context) {
    private val context = context.applicationContext

    private object K {
        val list = stringPreferencesKey("profiles")
        val auto = booleanPreferencesKey("auto_switch")
        val lastAuto = stringPreferencesKey("last_auto")
    }

    val flow: Flow<ProfilePrefs> = this.context.profileStore.data.map { p ->
        ProfilePrefs(readProfiles(p), p[K.auto] ?: false)
    }

    suspend fun snapshot(): List<LookProfile> = flow.first().profiles

    /** Saves the look the app has right now under [name]. */
    suspend fun save(name: String) {
        val look = SettingsStore(context).captureLook()
        val profile = LookProfile(UUID.randomUUID().toString().take(8), name, look, -1)
        change { list -> (list + profile).takeLast(MAX_PROFILES) }
    }

    /** Replaces what a profile holds with the look the app has right now. */
    suspend fun update(id: String) {
        val look = SettingsStore(context).captureLook()
        change { list -> list.map { if (it.id == id) it.copy(look = look) else it } }
    }

    suspend fun rename(id: String, name: String) = change { list -> list.map { if (it.id == id) it.copy(name = name) else it } }

    suspend fun setTime(id: String, minute: Int) = change { list -> list.map { if (it.id == id) it.copy(atMinute = minute) else it } }

    suspend fun remove(id: String) = change { list -> list.filter { it.id != id } }

    /** Adds the profiles from a backup that are not here yet. */
    suspend fun merge(extra: List<LookProfile>) = change { list ->
        val have = list.map { it.id }.toSet()
        (list + extra.filter { it.id !in have }).takeLast(MAX_PROFILES)
    }

    /** Switches the whole look to the profile. False when it is gone. */
    suspend fun apply(id: String): Boolean {
        val profile = snapshot().firstOrNull { it.id == id } ?: return false
        SettingsStore(context).applyLook(profile.look)
        return true
    }

    suspend fun setAuto(on: Boolean) {
        context.profileStore.edit { it[K.auto] = on }
    }

    /**
     * With automatic switching on: the profile whose time passed most recently is the one that should be showing.
     * It is applied once per day at its time, so a look you pick by hand stays until the next time comes round.
     */
    suspend fun runSchedule(nowMinute: Int) {
        val prefs = context.profileStore.data.first()
        if (prefs[K.auto] != true) return
        val timed = readProfiles(prefs).filter { it.atMinute >= 0 }
        if (timed.isEmpty()) return
        val due = timed.filter { it.atMinute <= nowMinute }.maxByOrNull { it.atMinute }
            ?: timed.maxByOrNull { it.atMinute }
            ?: return
        val today = java.time.LocalDate.now().toEpochDay()
        val slotDay = if (due.atMinute <= nowMinute) today else today - 1
        val token = "${due.id}:$slotDay"
        if (prefs[K.lastAuto] == token) return
        SettingsStore(context).applyLook(due.look)
        context.profileStore.edit { it[K.lastAuto] = token }
    }

    private suspend fun change(block: (List<LookProfile>) -> List<LookProfile>) {
        context.profileStore.edit { p ->
            val arr = JSONArray()
            block(readProfiles(p)).forEach { arr.put(it.toJson()) }
            p[K.list] = arr.toString()
        }
    }

    private fun readProfiles(p: Preferences): List<LookProfile> {
        val s = p[K.list] ?: return emptyList()
        return runCatching {
            val arr = JSONArray(s)
            (0 until arr.length()).mapNotNull { lookProfileFromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    companion object {
        const val MAX_PROFILES = 20
    }
}

fun LookProfile.toJson(): JSONObject =
    JSONObject().put("id", id).put("name", name).put("at", atMinute).put("look", look)

fun lookProfileFromJson(o: JSONObject): LookProfile? = runCatching {
    LookProfile(o.getString("id"), o.optString("name", "My look"), o.getJSONArray("look"), o.optInt("at", -1))
}.getOrNull()

/** While the app is open, checks once a minute whether a profile's time has come. */
@Composable
fun ProfileAutoEffect() {
    val context = LocalContext.current
    val store = remember { ProfileStore(context) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = java.time.LocalTime.now()
            store.runSchedule(now.hour * 60 + now.minute)
            delay(60_000L)
        }
    }
}
