package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** The library (favourites, play counts, history...) for places deep in the screens that have no direct access to it. */
val LocalLibrary = compositionLocalOf { LibraryData() }

val STICKERS = listOf(
    "😎", "😴", "🔥", "💖", "🎉", "🌧️", "☕", "🚗", "💪", "🌙",
    "😢", "🥳", "🧠", "🎮", "🌊", "👻", "🐱", "🚀", "🍕", "✨",
)

/** Pick one emoji sticker for a song. It shows next to the title, and Home gets a "Mood mix" for each sticker you use. */
@Composable
fun StickerSheet(song: Song, onPick: (String?) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AuroraSheet(onDismiss = onDismiss, title = "Sticker for this song") {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(verbatim(song.title), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            STICKERS.chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { e ->
                        Box(
                            Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (e == song.sticker) cs.primaryContainer else cs.surfaceContainerHigh)
                                .clickable { onPick(e) },
                            contentAlignment = Alignment.Center,
                        ) { Text(verbatim(e), fontSize = 28.sp) }
                    }
                }
            }
            if (song.sticker.isNotEmpty()) TextButton(onClick = { onPick(null) }) { Text("Remove sticker") }
        }
    }
}

private fun storyFacts(song: Song, lib: LibraryData): List<String> = buildList {
    val n = lib.plays[song.id] ?: 0
    if (n == 0) add("Not played yet. Today could be its first time") else add("You have played this $n ${if (n == 1) "time" else "times"}")
    val rank = lib.plays.entries.sortedByDescending { it.value }.indexOfFirst { it.key == song.id } + 1
    if (n > 0 && rank in 1..10) add("Number $rank on your most played list")
    if (song.id in lib.favorites) add("One of your favorites")
    val inLists = lib.playlists.count { song.id in it.songIds }
    if (inLists > 0) add("Lives in $inLists ${if (inLists == 1) "playlist" else "playlists"}")
    val first = lib.playLog.filter { it.first == song.id }.minOfOrNull { it.second }
    if (first != null) add("First counted listen: " + LocalDate.ofEpochDay(first).format(DateTimeFormatter.ofPattern("MMM d, yyyy")))
    if (song.dateAdded > 0) {
        val days = (System.currentTimeMillis() / 1000 - song.dateAdded) / 86_400
        add(if (days < 1) "Added to your phone today" else "Added to your phone $days days ago")
    }
    val min = song.durationMs / 60_000
    if (min >= 10) add("A long one: $min minutes") else if (song.durationMs in 1..90_000) add("A quick one: under two minutes")
    if (song.sticker.isNotEmpty()) add("Your mood sticker: ${song.sticker}")
}

/** A fun fact under the song title. Tap it to see the next one. */
@Composable
fun StoryLine(song: Song, align: TextAlign = TextAlign.Center) {
    if (!LocalAppSettings.current.npStory) return
    val lib = LocalLibrary.current
    val facts = remember(song.id, song.sticker, lib.plays, lib.favorites, lib.playLog, lib.playlists) { storyFacts(song, lib) }
    if (facts.isEmpty()) return
    var i by remember(song.id) { mutableStateOf(0) }
    Text(
        verbatim(facts[i % facts.size]),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = align,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { i++ }
            .padding(vertical = 4.dp),
    )
}
