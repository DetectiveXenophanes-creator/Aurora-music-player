package com.aurora.player

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp

/**
 * The colour and breathing of the glow, shared by everything that glows. Both are functions or states that are only read
 * while drawing, so a colour cycle or a pulse never recomposes the screen.
 */
class GlowState(val color: () -> Color, val pulse: State<Float>)

val LocalGlow = compositionLocalOf<GlowState?> { null }

/** Builds the glow for the whole app from the settings. [seed] is the colour of the current album cover. */
@Composable
fun rememberGlowState(seed: Color?): GlowState {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val paused = LocalBackgroundPaused.current
    val moving = !s.batterySaver && !paused
    val cycle: State<Float> = if (s.glowTint == GlowTint.CYCLE && moving) {
        rememberInfiniteTransition(label = "glowCycle").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
            label = "glowCycleValue",
        )
    } else remember { mutableFloatStateOf(0f) }
    val pulse: State<Float> = if (s.glowPulse && moving) {
        rememberInfiniteTransition(label = "glowPulse").animateFloat(
            initialValue = 0.7f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "glowPulseValue",
        )
    } else remember { mutableFloatStateOf(1f) }
    val primary = cs.primary
    val secondary = cs.secondary
    val tertiary = cs.tertiary
    return remember(s.glowTint, primary, secondary, tertiary, seed, cycle, pulse) {
        val color: () -> Color = when (s.glowTint) {
            GlowTint.PRIMARY -> ({ primary })
            GlowTint.SECONDARY -> ({ secondary })
            GlowTint.TERTIARY -> ({ tertiary })
            GlowTint.COVER -> ({ seed ?: primary })
            GlowTint.CYCLE -> ({ lerp(primary, tertiary, cycle.value) })
        }
        GlowState(color, pulse)
    }
}

private fun DrawScope.strokeOutline(o: Outline, color: Color, width: Float) {
    val st = Stroke(width = width)
    when (o) {
        is Outline.Rectangle -> drawRect(color, Offset(o.rect.left, o.rect.top), Size(o.rect.width, o.rect.height), style = st)
        is Outline.Rounded -> drawRoundRect(
            color,
            Offset(o.roundRect.left, o.roundRect.top),
            Size(o.roundRect.width, o.roundRect.height),
            o.roundRect.topLeftCornerRadius,
            style = st,
        )
        is Outline.Generic -> drawPath(o.path, color, style = st)
    }
}

/**
 * A soft coloured halo around [shape]. Put it before clip, background or border in the chain so it can draw outside the
 * element. [boost] scales it for one element. Only the Current UI glows.
 */
@Composable
fun Modifier.glow(shape: Shape, enabled: Boolean = true, boost: Float = 1f): Modifier {
    val s = LocalAppSettings.current
    if (!enabled || !s.glowOn || s.glowStrength <= 0.01f || s.uiVersion != UiVersion.CURRENT) return this
    val g = LocalGlow.current ?: return this
    val strength = s.glowStrength * boost
    val spread = s.glowSize
    return this.drawBehind {
        val c = g.color()
        val a = strength * g.pulse.value
        val outline = shape.createOutline(size, layoutDirection, this)
        val spreadPx = spread.dp.toPx()
        for (i in 5 downTo 1) {
            val f = i / 5f
            strokeOutline(outline, c.copy(alpha = (0.085f * a * (1.15f - f)).coerceIn(0f, 1f)), spreadPx * f * 2f)
        }
        strokeOutline(outline, c.copy(alpha = (0.55f * a).coerceIn(0f, 1f)), 1.2.dp.toPx())
    }
}

/** The glow for cards on Home and the player panel: softer than the glow on the dock and the mini player. */
@Composable
fun Modifier.cardGlow(shape: Shape): Modifier = glow(shape, LocalAppSettings.current.glowCards, 0.5f)

/** Two big soft blobs of glow colour that drift slowly behind the content. */
@Composable
fun GlowOrbs() {
    val s = LocalAppSettings.current
    val g = LocalGlow.current ?: return
    if (!s.glowOn || !s.glowOrbs || s.uiVersion != UiVersion.CURRENT || s.glowStrength <= 0.01f) return
    val paused = LocalBackgroundPaused.current
    val still = s.batterySaver || paused || LocalLite.current
    val move: State<Float> = if (!still) {
        rememberInfiniteTransition(label = "orbs").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Reverse),
            label = "orbsValue",
        )
    } else remember { mutableFloatStateOf(0.3f) }
    Canvas(Modifier.fillMaxSize()) {
        val c = g.color()
        val a = (0.30f * s.glowStrength).coerceIn(0f, 0.7f)
        val t = move.value
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.15f + 0.55f * t), h * (0.18f + 0.10f * t))
        val c2 = Offset(w * (0.90f - 0.50f * t), h * (0.78f - 0.12f * t))
        drawCircle(
            Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = c1, radius = w * 0.75f),
            radius = w * 0.75f,
            center = c1,
        )
        drawCircle(
            Brush.radialGradient(listOf(c.copy(alpha = a * 0.7f), Color.Transparent), center = c2, radius = w * 0.9f),
            radius = w * 0.9f,
            center = c2,
        )
    }
}
