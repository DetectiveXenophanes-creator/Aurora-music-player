package com.aurora.player

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private val playlistIcons: List<ImageVector>
    get() = listOf(
        Icons.Rounded.QueueMusic, Icons.Rounded.Favorite, Icons.Rounded.Star, Icons.Rounded.Headphones,
        Icons.Rounded.Bedtime, Icons.Rounded.LocalFireDepartment, Icons.Rounded.Celebration, Icons.Rounded.FitnessCenter,
    )

fun playlistIcon(index: Int): ImageVector = playlistIcons[index.coerceIn(0, PLAYLIST_ICON_COUNT - 1)]

@Composable
private fun accentOf(index: Int): Color =
    if (index <= 0) MaterialTheme.colorScheme.primary
    else Color(playlistAccents[index.coerceIn(0, playlistAccents.size - 1)])

private val emojiChoices = listOf("🎧", "🎵", "🔥", "🌙", "☀️", "🌊", "💜", "🎸", "🎹", "🚗", "🏋️", "🎉", "😴", "🌈", "⭐", "🍃")

// ------------------------------------------------------------------ feel

class FeelValues(val scale: Float, val rotation: Float, val glow: Float)

/** How a playlist card reacts under your finger. Each playlist picks its own feel and strength. */
@Composable
fun rememberFeel(source: InteractionSource, feel: PlaylistFeel, response: Float): FeelValues {
    val pressed by source.collectIsPressedAsState()
    val r = response.coerceIn(0f, 1f)
    val spec: AnimationSpec<Float> =
        if (feel == PlaylistFeel.BOUNCE) spring(dampingRatio = 0.3f, stiffness = 380f)
        else spring(dampingRatio = 0.75f, stiffness = 500f)
    val pressedScale = when (feel) {
        PlaylistFeel.SQUISH -> 1f - 0.14f * r
        PlaylistFeel.BOUNCE -> 1f - 0.20f * r
        PlaylistFeel.TILT -> 1f - 0.05f * r
        PlaylistFeel.GLOW -> 1f - 0.02f * r
        PlaylistFeel.LIFT -> 1f + 0.07f * r
        PlaylistFeel.NONE -> 1f
    }
    val scale by animateFloatAsState(if (pressed) pressedScale else 1f, animationSpec = spec, label = "feelScale")
    val rotation by animateFloatAsState(
        if (pressed && feel == PlaylistFeel.TILT) 6f * r else 0f,
        animationSpec = spec,
        label = "feelRotation",
    )
    val glow by animateFloatAsState(
        if (pressed && (feel == PlaylistFeel.GLOW || feel == PlaylistFeel.LIFT)) 1f else 0f,
        animationSpec = spring(dampingRatio = 1f, stiffness = 300f),
        label = "feelGlow",
    )
    return FeelValues(scale, rotation, glow)
}

// ------------------------------------------------------------------ cover and card

/** The cover of a playlist in whichever style it has. [wide] draws the mosaic as one row, for wide banners. */
@Composable
fun PlaylistCover(pl: Playlist, songs: List<Song>, modifier: Modifier, shape: RoundedCornerShape, wide: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val accent = accentOf(pl.accent)
    val accent2 = if (pl.accent2 >= 0) accentOf(pl.accent2) else cs.tertiary.copy(alpha = 0.85f)
    val icon = playlistIcon(pl.icon)
    when {
        pl.cover == CoverStyle.MOSAIC && songs.isNotEmpty() -> {
            if (wide) {
                Row(modifier.clip(shape)) {
                    for (i in 0 until 4) {
                        val song = songs.getOrNull(i)
                        Box(Modifier.weight(1f).fillMaxHeight()) {
                            if (song != null) Art(song.artUri, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                            else Box(Modifier.fillMaxSize().background(accent.copy(alpha = 0.25f)))
                        }
                    }
                }
            } else {
                Column(modifier.clip(shape)) {
                    for (row in 0 until 2) {
                        Row(Modifier.weight(1f)) {
                            for (col in 0 until 2) {
                                val song = songs.getOrNull(row * 2 + col)
                                Box(Modifier.weight(1f).fillMaxSize()) {
                                    if (song != null) Art(song.artUri, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                                    else Box(Modifier.fillMaxSize().background(accent.copy(alpha = 0.25f)))
                                }
                            }
                        }
                    }
                }
            }
        }
        pl.cover == CoverStyle.ART && songs.isNotEmpty() -> Art(songs.first().artUri, modifier, shape)
        pl.cover == CoverStyle.STACK && songs.isNotEmpty() -> {
            Box(modifier.clip(shape).background(accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                val rotations = listOf(0f, -9f, 10f)
                for (i in minOf(2, songs.lastIndex) downTo 0) {
                    Art(
                        songs[i].artUri,
                        Modifier.fillMaxSize(if (wide) 0.9f else 0.7f).graphicsLayer { rotationZ = rotations[i] },
                        RoundedCornerShape(10.dp),
                    )
                }
            }
        }
        pl.cover == CoverStyle.EMOJI && pl.emoji.isNotBlank() -> {
            BoxWithConstraints(
                modifier.clip(shape).background(Brush.linearGradient(listOf(accent.copy(alpha = 0.6f), accent2.copy(alpha = 0.6f)))),
                contentAlignment = Alignment.Center,
            ) {
                Text(verbatim(pl.emoji), fontSize = (minOf(maxWidth, maxHeight).value * 0.5f).sp)
            }
        }
        pl.cover == CoverStyle.GRADIENT || pl.cover == CoverStyle.EMOJI -> {
            Box(
                modifier.clip(shape).background(Brush.linearGradient(listOf(accent, accent2))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = Color.White.copy(alpha = 0.92f), modifier = Modifier.fillMaxSize(0.42f))
            }
        }
        else -> {
            Box(
                modifier.clip(shape).background(accent.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.fillMaxSize(0.42f))
            }
        }
    }
}

@Composable
private fun PinBadge(modifier: Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.PushPin, "Pinned", tint = Color.White, modifier = Modifier.size(14.dp))
    }
}

@Composable
fun PlaylistCard(
    pl: Playlist,
    songs: List<Song>,
    modifier: Modifier = Modifier,
    layout: PlaylistLayout = PlaylistLayout.GRID,
    menu: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val s = LocalAppSettings.current
    val source = remember { MutableInteractionSource() }
    val feel = rememberFeel(source, pl.feel, pl.response)
    val accent = accentOf(pl.accent)
    val corner = pl.shape.corner
    val shape = RoundedCornerShape(corner.dp)
    val coverShape = RoundedCornerShape((corner * 0.7f).dp)
    val countText = "${pl.songIds.size} songs"
    val shell = modifier
        .graphicsLayer {
            scaleX = feel.scale
            scaleY = feel.scale
            rotationZ = feel.rotation
        }
        .clip(shape)
        .background(
            if (s.style == SurfaceStyle.GLASS) cs.surfaceContainerHighest.copy(alpha = 0.45f)
            else cs.surfaceContainerHigh,
        )
        .border(2.dp, accent.copy(alpha = 0.9f * feel.glow), shape)
        .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick)
        .padding(10.dp)
    if (layout == PlaylistLayout.LIST) {
        Row(shell, verticalAlignment = Alignment.CenterVertically) {
            Box {
                PlaylistCover(pl, songs, Modifier.size(64.dp), RoundedCornerShape((corner * 0.5f).dp))
                if (pl.pinned) PinBadge(Modifier.align(Alignment.TopEnd).padding(2.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(verbatim(pl.name), style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (s.playlistShowCount) {
                    Text(countText, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                if (s.playlistShowNote && pl.note.isNotBlank()) {
                    Text(verbatim(pl.note), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            menu?.invoke()
        }
    } else {
        val big = layout == PlaylistLayout.BIG
        Column(shell) {
            Box {
                PlaylistCover(
                    pl,
                    songs,
                    if (big) Modifier.fillMaxWidth().aspectRatio(2.2f) else Modifier.fillMaxWidth().aspectRatio(1f),
                    coverShape,
                    wide = big,
                )
                if (pl.pinned) PinBadge(Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
            Row(Modifier.padding(top = 8.dp, start = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        verbatim(pl.name),
                        style = if (big) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (s.playlistShowCount) {
                        Text(countText, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    if (s.playlistShowNote && pl.note.isNotBlank()) {
                        Text(
                            verbatim(pl.note),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = if (big) 2 else 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                menu?.invoke()
            }
        }
    }
}

// ------------------------------------------------------------------ playlists tab

private val smartPlaylists = listOf(
    Triple(Playlist("smart:fav", "Favorites", accent = 6, icon = 1, cover = CoverStyle.GRADIENT), "fav", "Favorites"),
    Triple(Playlist("smart:top", "Most played", accent = 5, icon = 2, cover = CoverStyle.GRADIENT), "top", "Most played"),
    Triple(Playlist("smart:recent", "Recently played", accent = 2, icon = 3, cover = CoverStyle.GRADIENT), "recent", "Recently played"),
    Triple(Playlist("smart:forgotten", "Forgotten favourites", accent = 4, icon = 4, cover = CoverStyle.GRADIENT), "forgotten", "Forgotten favourites"),
    Triple(Playlist("smart:rightnow", "Right now", accent = 5, icon = 5, cover = CoverStyle.GRADIENT), "rightnow", "Right now"),
    Triple(Playlist("smart:skipped", "Often skipped", accent = 6, icon = 6, cover = CoverStyle.GRADIENT), "skipped", "Often skipped"),
    Triple(Playlist("smart:duel", "Duel champions", accent = 7, icon = 7, cover = CoverStyle.GRADIENT), "duel", "Duel champions"),
)

@Composable
fun PlaylistsScreen(
    songs: List<Song>,
    lib: LibraryData,
    padding: PaddingValues,
    onOpen: (DetailRef) -> Unit,
    onCreate: () -> Unit,
    onEdit: (String) -> Unit,
    onDelete: (String) -> Unit,
    onPlay: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onPin: (String) -> Unit,
    onDuplicate: (String) -> Unit,
    onSettings: ((AppSettings) -> AppSettings) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val s = LocalAppSettings.current
    val byId = remember(songs) { songs.associateBy { it.id } }
    val layout = s.playlistLayout
    // Pinned playlists first, then the chosen order
    val ordered = remember(lib.playlists, s.playlistOrder) {
        val base = when (s.playlistOrder) {
            PlaylistOrder.MANUAL -> lib.playlists
            PlaylistOrder.NAME -> lib.playlists.sortedBy { it.name.lowercase() }
            PlaylistOrder.SIZE -> lib.playlists.sortedByDescending { it.songIds.size }
        }
        base.sortedByDescending { it.pinned }
    }
    LazyVerticalGrid(
        columns = when (layout) {
            PlaylistLayout.GRID -> GridCells.Adaptive(s.playlistSize.minWidth.dp)
            PlaylistLayout.LIST -> GridCells.Adaptive(360.dp)
            PlaylistLayout.BIG -> GridCells.Adaptive(320.dp)
        },
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "toolbar", span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = onCreate) {
                    Icon(Icons.Rounded.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New playlist")
                }
                Spacer(Modifier.weight(1f))
                for ((l, icon) in listOf(
                    PlaylistLayout.GRID to Icons.Rounded.GridView,
                    PlaylistLayout.LIST to Icons.Rounded.ViewList,
                    PlaylistLayout.BIG to Icons.Rounded.ViewAgenda,
                )) {
                    IconButton(onClick = { onSettings { it.copy(playlistLayout = l) } }, modifier = Modifier.size(40.dp)) {
                        Icon(icon, l.label, tint = if (layout == l) cs.primary else cs.onSurfaceVariant)
                    }
                }
                var sortOpen by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { sortOpen = true }, modifier = Modifier.size(40.dp)) {
                        Icon(Icons.Rounded.SwapVert, "Sort", tint = if (s.playlistOrder != PlaylistOrder.MANUAL) cs.primary else cs.onSurfaceVariant)
                    }
                    AuroraMenu(expanded = sortOpen, onDismiss = { sortOpen = false }) {
                        PlaylistOrder.entries.forEach { o ->
                            AuroraMenuItem(o.label, if (s.playlistOrder == o) Icons.Rounded.Check else Icons.Rounded.SwapVert, {
                                sortOpen = false
                                onSettings { it.copy(playlistOrder = o) }
                            })
                        }
                    }
                }
            }
        }
        if (s.playlistSmartRow) {
            item(key = "smart-title", span = { GridItemSpan(maxLineSpan) }) {
                Text("Smart playlists", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            }
            items(smartPlaylists, key = { it.first.id }, contentType = { "smart" }) { (pl, key, title) ->
                val ref = DetailRef(DetailKind.SMART, key, title)
                val list = remember(songs, lib, key) { songsFor(ref, songs, lib) }
                var menuOpen by remember { mutableStateOf(false) }
                PlaylistCard(
                    pl = pl.copy(songIds = list.map { it.id }),
                    songs = list.take(4),
                    layout = layout,
                    menu = {
                        Box {
                            IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Rounded.MoreVert, "More", tint = cs.onSurfaceVariant)
                            }
                            AuroraMenu(expanded = menuOpen, onDismiss = { menuOpen = false }) {
                                AuroraMenuItem("Play", Icons.Rounded.PlayArrow, { menuOpen = false; onPlay(list) })
                                AuroraMenuItem("Shuffle", Icons.Rounded.Shuffle, { menuOpen = false; onShuffle(list) })
                            }
                        }
                    },
                ) { onOpen(ref) }
            }
        }
        item(key = "yours-title", span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "${lib.playlists.size} yours",
                style = MaterialTheme.typography.labelLarge,
                color = cs.onSurfaceVariant,
            )
        }
        if (lib.playlists.isEmpty()) {
            item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Rounded.QueueMusic, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(40.dp))
                    Text("No playlists yet", style = MaterialTheme.typography.titleMedium)
                    Text("Make one and give it its own look.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
        items(ordered, key = { it.id }, contentType = { "playlist" }) { pl ->
            val list = remember(pl.songIds, byId) { pl.songIds.take(4).mapNotNull { byId[it] } }
            var menuOpen by remember { mutableStateOf(false) }
            PlaylistCard(
                pl = pl,
                songs = list,
                layout = layout,
                menu = {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Rounded.MoreVert, "More", tint = cs.onSurfaceVariant)
                        }
                        AuroraMenu(expanded = menuOpen, onDismiss = { menuOpen = false }) {
                            AuroraMenuItem("Play", Icons.Rounded.PlayArrow, {
                                menuOpen = false
                                onPlay(pl.songIds.mapNotNull { byId[it] })
                            })
                            AuroraMenuItem("Shuffle", Icons.Rounded.Shuffle, {
                                menuOpen = false
                                onShuffle(pl.songIds.mapNotNull { byId[it] })
                            })
                            AuroraMenuItem(if (pl.pinned) "Unpin" else "Pin to top", Icons.Rounded.PushPin, { menuOpen = false; onPin(pl.id) })
                            AuroraMenuItem("Duplicate", Icons.Rounded.ContentCopy, { menuOpen = false; onDuplicate(pl.id) })
                            AuroraMenuItem("Customize", Icons.Rounded.Edit, { menuOpen = false; onEdit(pl.id) })
                            AuroraMenuItem("Delete", Icons.Rounded.Delete, { menuOpen = false; onDelete(pl.id) })
                        }
                    }
                },
            ) { onOpen(DetailRef(DetailKind.PLAYLIST, pl.id, pl.name)) }
        }
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape((LocalAppSettings.current.corner * 1.2f).coerceAtLeast(20f).dp),
        containerColor = cs.surfaceContainerHigh,
        title = { Text(title) },
        text = {
            TextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Playlist name") },
                colors = TextFieldDefaults.colors(),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ------------------------------------------------------------------ editor

/** Change how a playlist looks and how it reacts when you touch it. Changes save as you go. */
@Composable
fun PlaylistEditor(
    pl: Playlist,
    songs: List<Song>,
    current: Song?,
    onUpdate: ((Playlist) -> Playlist) -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var name by remember(pl.id) { mutableStateOf(pl.name) }
    var note by remember(pl.id) { mutableStateOf(pl.note) }
    var emoji by remember(pl.id) { mutableStateOf(pl.emoji) }
    OverlayPage(title = "Customize playlist", song = current, onBack = onBack) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = padding.calculateTopPadding(),
                    bottom = padding.calculateBottomPadding(),
                    start = 16.dp,
                    end = 16.dp,
                ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PlaylistCard(pl.copy(name = name, note = note, emoji = emoji), songs.take(4), Modifier.width(190.dp)) {}
            }
            Text(
                "Press and hold the card to try how it feels.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )

            SettingCard("Name") {
                TextField(
                    value = name,
                    onValueChange = { name = it; onUpdate { p -> p.copy(name = it.ifBlank { "Playlist" }) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Note", style = MaterialTheme.typography.labelLarge)
                TextField(
                    value = note,
                    onValueChange = { v -> note = v.take(80); onUpdate { p -> p.copy(note = v.take(80)) } },
                    placeholder = { Text("A short description") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            SettingCard("Look") {
                Text("Cover", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CoverStyle.entries.forEach { c ->
                        FilterChip(
                            selected = pl.cover == c,
                            onClick = { onUpdate { p -> p.copy(cover = c) } },
                            label = { Text(c.label) },
                        )
                    }
                }
                if (pl.cover == CoverStyle.EMOJI) {
                    Text("Emoji", style = MaterialTheme.typography.labelLarge)
                    TextField(
                        value = emoji,
                        onValueChange = { v -> emoji = v.take(4); onUpdate { p -> p.copy(emoji = v.take(4)) } },
                        singleLine = true,
                        placeholder = { Text("Type or pick one") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        emojiChoices.forEach { e ->
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (emoji == e) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.5f))
                                    .clickable { emoji = e; onUpdate { p -> p.copy(emoji = e) } },
                                contentAlignment = Alignment.Center,
                            ) { Text(verbatim(e), fontSize = 22.sp) }
                        }
                    }
                }
                Text("Accent colour", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in playlistAccents.indices) {
                        val color = if (i == 0) cs.primary else Color(playlistAccents[i])
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(if (pl.accent == i) 3.dp else 0.dp, cs.onSurface, CircleShape)
                                .clickable { onUpdate { p -> p.copy(accent = i) } }
                        )
                    }
                }
                if (pl.cover == CoverStyle.GRADIENT || pl.cover == CoverStyle.EMOJI) {
                    Text("Second colour", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = pl.accent2 < 0,
                            onClick = { onUpdate { p -> p.copy(accent2 = -1) } },
                            label = { Text("Auto") },
                        )
                        for (i in playlistAccents.indices) {
                            val color = if (i == 0) cs.primary else Color(playlistAccents[i])
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(if (pl.accent2 == i) 3.dp else 0.dp, cs.onSurface, CircleShape)
                                    .clickable { onUpdate { p -> p.copy(accent2 = i) } }
                            )
                        }
                    }
                }
                Text("Icon", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in 0 until PLAYLIST_ICON_COUNT) {
                        val selected = pl.icon == i
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (selected) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.5f))
                                .clickable { onUpdate { p -> p.copy(icon = i) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                playlistIcon(i), null,
                                tint = if (selected) cs.onPrimaryContainer else cs.onSecondaryContainer,
                            )
                        }
                    }
                }
                Text("Corners", style = MaterialTheme.typography.labelLarge)
                Segmented(
                    options = PlaylistShape.entries.map { it.label to it },
                    selected = pl.shape,
                    onSelect = { v -> onUpdate { p -> p.copy(shape = v) } },
                )
            }

            SettingCard("Behaviour") {
                ToggleRow("Pin to top", "Pinned playlists stay first in the list", pl.pinned, true) { v -> onUpdate { p -> p.copy(pinned = v) } }
                Text("Song order", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistSort.entries.forEach { o ->
                        FilterChip(
                            selected = pl.sort == o,
                            onClick = { onUpdate { p -> p.copy(sort = o) } },
                            label = { Text(o.label) },
                        )
                    }
                }
            }

            SettingCard("Feel") {
                Text("How the card responds when you touch it", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistFeel.entries.forEach { f ->
                        FilterChip(
                            selected = pl.feel == f,
                            onClick = { onUpdate { p -> p.copy(feel = f) } },
                            label = { Text(f.label) },
                        )
                    }
                }
                Text(pl.feel.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                SliderRow("Response strength", pl.response, 0f..1f, "${(pl.response * 100).toInt()}%") { v ->
                    onUpdate { p -> p.copy(response = v) }
                }
            }

            FilledTonalButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Delete playlist")
            }
        }
    }
}
