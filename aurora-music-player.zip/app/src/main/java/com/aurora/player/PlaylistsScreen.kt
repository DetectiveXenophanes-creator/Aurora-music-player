package com.aurora.player

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private val playlistIcons: List<ImageVector>
    get() = listOf(
        Icons.Rounded.QueueMusic, Icons.Rounded.Favorite, Icons.Rounded.Star, Icons.Rounded.Headphones,
        Icons.Rounded.Bedtime, Icons.Rounded.LocalFireDepartment, Icons.Rounded.Celebration, Icons.Rounded.FitnessCenter,
    )

fun playlistIcon(index: Int): ImageVector = playlistIcons[index.coerceIn(0, PLAYLIST_ICON_COUNT - 1)]

@Composable
private fun accentOf(index: Int): Color =
    if (index <= 0) MaterialTheme.colorScheme.primary
    else Color(playlistAccents[index.coerceIn(0, playlistAccents.size - 1)])

// ------------------------------------------------------------------ feel

class FeelValues(val scale: Float, val rotation: Float, val glow: Float)

/** How a playlist card reacts under your finger. Each playlist picks its own feel and strength. */
@Composable
fun rememberFeel(source: InteractionSource, feel: PlaylistFeel, response: Float): FeelValues {
    val pressed by source.collectIsPressedAsState()
    val r = response.coerceIn(0f, 1f)
    val spec: AnimationSpec<Float> =
        if (feel == PlaylistFeel.BOUNCE) spring(dampingRatio = 0.3f, stiffness = 380f)
        else spring(dampingRatio = 0.75f, stiffness = 500f)
    val pressedScale = when (feel) {
        PlaylistFeel.SQUISH -> 1f - 0.14f * r
        PlaylistFeel.BOUNCE -> 1f - 0.20f * r
        PlaylistFeel.TILT -> 1f - 0.05f * r
        PlaylistFeel.GLOW -> 1f - 0.02f * r
        PlaylistFeel.NONE -> 1f
    }
    val scale by animateFloatAsState(if (pressed) pressedScale else 1f, animationSpec = spec, label = "feelScale")
    val rotation by animateFloatAsState(
        if (pressed && feel == PlaylistFeel.TILT) 6f * r else 0f,
        animationSpec = spec,
        label = "feelRotation",
    )
    val glow by animateFloatAsState(
        if (pressed && feel == PlaylistFeel.GLOW) 1f else 0f,
        animationSpec = spring(dampingRatio = 1f, stiffness = 300f),
        label = "feelGlow",
    )
    return FeelValues(scale, rotation, glow)
}

// ------------------------------------------------------------------ cover and card

@Composable
fun PlaylistCover(pl: Playlist, songs: List<Song>, modifier: Modifier, shape: RoundedCornerShape) {
    val cs = MaterialTheme.colorScheme
    val accent = accentOf(pl.accent)
    val icon = playlistIcon(pl.icon)
    when {
        pl.cover == CoverStyle.MOSAIC && songs.isNotEmpty() -> {
            Column(modifier.clip(shape)) {
                for (row in 0 until 2) {
                    Row(Modifier.weight(1f)) {
                        for (col in 0 until 2) {
                            val song = songs.getOrNull(row * 2 + col)
                            Box(Modifier.weight(1f).fillMaxSize()) {
                                if (song != null) {
                                    Art(song.artUri, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                                } else {
                                    Box(Modifier.fillMaxSize().background(accent.copy(alpha = 0.25f)))
                                }
                            }
                        }
                    }
                }
            }
        }
        pl.cover == CoverStyle.GRADIENT -> {
            Box(
                modifier.clip(shape).background(
                    Brush.linearGradient(listOf(accent, cs.tertiary.copy(alpha = 0.85f)))
                ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = Color.White.copy(alpha = 0.92f), modifier = Modifier.fillMaxSize(0.42f))
            }
        }
        else -> {
            Box(
                modifier.clip(shape).background(accent.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.fillMaxSize(0.42f))
            }
        }
    }
}

@Composable
fun PlaylistCard(
    pl: Playlist,
    songs: List<Song>,
    modifier: Modifier = Modifier,
    menu: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val s = LocalAppSettings.current
    val source = remember { MutableInteractionSource() }
    val feel = rememberFeel(source, pl.feel, pl.response)
    val accent = accentOf(pl.accent)
    val corner = pl.shape.corner
    val shape = RoundedCornerShape(corner.dp)
    val coverShape = RoundedCornerShape((corner * 0.7f).dp)
    Column(
        modifier
            .graphicsLayer {
                scaleX = feel.scale
                scaleY = feel.scale
                rotationZ = feel.rotation
            }
            .clip(shape)
            .background(
                if (s.style == SurfaceStyle.GLASS) cs.surfaceContainerHighest.copy(alpha = 0.45f)
                else cs.surfaceContainerHigh
            )
            .border(2.dp, accent.copy(alpha = 0.9f * feel.glow), shape)
            .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick)
            .padding(10.dp),
    ) {
        PlaylistCover(pl, songs, Modifier.fillMaxWidth().aspectRatio(1f), coverShape)
        Row(Modifier.padding(top = 8.dp, start = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(pl.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${pl.songIds.size} songs",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            menu?.invoke()
        }
    }
}

// ------------------------------------------------------------------ playlists tab

private val smartPlaylists = listOf(
    Triple(Playlist("smart:fav", "Favorites", accent = 6, icon = 1, cover = CoverStyle.GRADIENT), "fav", "Favorites"),
    Triple(Playlist("smart:top", "Most played", accent = 5, icon = 2, cover = CoverStyle.GRADIENT), "top", "Most played"),
    Triple(Playlist("smart:recent", "Recently played", accent = 2, icon = 3, cover = CoverStyle.GRADIENT), "recent", "Recently played"),
)

@Composable
fun PlaylistsScreen(
    songs: List<Song>,
    lib: LibraryData,
    padding: PaddingValues,
    onOpen: (DetailRef) -> Unit,
    onCreate: () -> Unit,
    onEdit: (String) -> Unit,
    onDelete: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val byId = remember(songs) { songs.associateBy { it.id } }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = onCreate) {
                    Icon(Icons.Rounded.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New playlist")
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "${lib.playlists.size} yours",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
            }
        }
        items(smartPlaylists, key = { it.first.id }) { (pl, key, title) ->
            val ref = DetailRef(DetailKind.SMART, key, title)
            val list = songsFor(ref, songs, lib)
            PlaylistCard(pl.copy(songIds = list.map { it.id }), list.take(4)) { onOpen(ref) }
        }
        items(lib.playlists, key = { it.id }) { pl ->
            val list = pl.songIds.mapNotNull { byId[it] }
            var menuOpen by remember { mutableStateOf(false) }
            PlaylistCard(
                pl = pl,
                songs = list.take(4),
                menu = {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Rounded.MoreVert, "More", tint = cs.onSurfaceVariant)
                        }
                        AuroraMenu(expanded = menuOpen, onDismiss = { menuOpen = false }) {
                            AuroraMenuItem("Customize", Icons.Rounded.Edit, { menuOpen = false; onEdit(pl.id) })
                            AuroraMenuItem("Delete", Icons.Rounded.Delete, { menuOpen = false; onDelete(pl.id) })
                        }
                    }
                },
            ) { onOpen(DetailRef(DetailKind.PLAYLIST, pl.id, pl.name)) }
        }
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape((LocalAppSettings.current.corner * 1.2f).coerceAtLeast(20f).dp),
        containerColor = cs.surfaceContainerHigh,
        title = { Text(title) },
        text = {
            TextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Playlist name") },
                colors = TextFieldDefaults.colors(),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ------------------------------------------------------------------ editor

/** Change how a playlist looks and how it reacts when you touch it. Changes save as you go. */
@Composable
fun PlaylistEditor(
    pl: Playlist,
    songs: List<Song>,
    current: Song?,
    onUpdate: ((Playlist) -> Playlist) -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var name by remember(pl.id) { mutableStateOf(pl.name) }
    OverlayPage(title = "Customize playlist", song = current, onBack = onBack) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    top = padding.calculateTopPadding(),
                    bottom = padding.calculateBottomPadding(),
                    start = 16.dp,
                    end = 16.dp,
                ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PlaylistCard(pl.copy(name = name), songs.take(4), Modifier.width(190.dp)) {}
            }
            Text(
                "Press and hold the card to try how it feels.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )

            SettingCard("Name") {
                TextField(
                    value = name,
                    onValueChange = { name = it; onUpdate { p -> p.copy(name = it.ifBlank { "Playlist" }) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            SettingCard("Look") {
                Text("Accent colour", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in playlistAccents.indices) {
                        val color = if (i == 0) cs.primary else Color(playlistAccents[i])
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(if (pl.accent == i) 3.dp else 0.dp, cs.onSurface, CircleShape)
                                .clickable { onUpdate { p -> p.copy(accent = i) } }
                        )
                    }
                }
                Text("Icon", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in 0 until PLAYLIST_ICON_COUNT) {
                        val selected = pl.icon == i
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (selected) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.5f))
                                .clickable { onUpdate { p -> p.copy(icon = i) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                playlistIcon(i), null,
                                tint = if (selected) cs.onPrimaryContainer else cs.onSecondaryContainer,
                            )
                        }
                    }
                }
                Text("Cover", style = MaterialTheme.typography.labelLarge)
                Segmented(
                    options = CoverStyle.entries.map { it.label to it },
                    selected = pl.cover,
                    onSelect = { v -> onUpdate { p -> p.copy(cover = v) } },
                )
                Text("Corners", style = MaterialTheme.typography.labelLarge)
                Segmented(
                    options = PlaylistShape.entries.map { it.label to it },
                    selected = pl.shape,
                    onSelect = { v -> onUpdate { p -> p.copy(shape = v) } },
                )
            }

            SettingCard("Feel") {
                Text("How the card responds when you touch it", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistFeel.entries.forEach { f ->
                        FilterChip(
                            selected = pl.feel == f,
                            onClick = { onUpdate { p -> p.copy(feel = f) } },
                            label = { Text(f.label) },
                        )
                    }
                }
                Text(pl.feel.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                SliderRow("Response strength", pl.response, 0f..1f, "${(pl.response * 100).toInt()}%") { v ->
                    onUpdate { p -> p.copy(response = v) }
                }
            }

            FilledTonalButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Delete playlist")
            }
        }
    }
}
