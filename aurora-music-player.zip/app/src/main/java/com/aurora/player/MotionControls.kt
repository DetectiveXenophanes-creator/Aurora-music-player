package com.aurora.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/**
 * Listens to the accelerometer for two gestures: a shake, and the phone being put face down / turned face up again.
 * It only listens while [configure] says it is needed (music playing and a gesture turned on), so it costs nothing otherwise.
 */
class MotionControls(
    context: Context,
    private val onShake: () -> Unit,
    private val onFlip: (faceDown: Boolean) -> Unit,
) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var running = false
    private var wantShake = false
    private var wantFlip = false
    private var shakeG = 2.9f
    private var lastShake = 0L
    private var state = 0          // 0 face up (or anything else), 1 face down
    private var pendingTarget = -1
    private var pendingSince = 0L

    fun configure(active: Boolean, shake: Boolean, strength: Int, flip: Boolean) {
        shakeG = when (strength) { 0 -> 2.2f; 2 -> 3.6f; else -> 2.9f }
        wantShake = shake
        wantFlip = flip
        val need = active && (shake || flip) && accelerometer != null
        if (need && !running) {
            manager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
            running = true
        } else if (!need && running) {
            manager.unregisterListener(this)
            running = false
            state = 0
            pendingTarget = -1
        }
    }

    fun stop() = configure(false, false, 1, false)

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val now = SystemClock.elapsedRealtime()
        if (wantShake) {
            val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            if (g > shakeG && now - lastShake > 1200L) {
                lastShake = now
                onShake()
            }
        }
        if (wantFlip) {
            // The phone must stay face down (or face up) for over half a second, so a quick wobble does nothing
            val target = when {
                z < -8.0f -> 1
                z > 8.0f -> 0
                else -> -1
            }
            if (target >= 0 && target != state) {
                if (pendingTarget != target) {
                    pendingTarget = target
                    pendingSince = now
                } else if (now - pendingSince > 600L) {
                    state = target
                    pendingTarget = -1
                    onFlip(target == 1)
                }
            } else {
                pendingTarget = -1
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
