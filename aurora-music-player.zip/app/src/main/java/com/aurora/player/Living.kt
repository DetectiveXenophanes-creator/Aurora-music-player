package com.aurora.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/** Mixes two colour schemes. [t] 0 gives [a], 1 gives [b]. */
internal fun lerpScheme(a: ColorScheme, b: ColorScheme, t: Float): ColorScheme {
    if (t <= 0f) return a
    if (t >= 1f) return b
    fun m(x: Color, y: Color): Color = lerp(x, y, t)
    return a.copy(
        primary = m(a.primary, b.primary),
        onPrimary = m(a.onPrimary, b.onPrimary),
        primaryContainer = m(a.primaryContainer, b.primaryContainer),
        onPrimaryContainer = m(a.onPrimaryContainer, b.onPrimaryContainer),
        inversePrimary = m(a.inversePrimary, b.inversePrimary),
        secondary = m(a.secondary, b.secondary),
        onSecondary = m(a.onSecondary, b.onSecondary),
        secondaryContainer = m(a.secondaryContainer, b.secondaryContainer),
        onSecondaryContainer = m(a.onSecondaryContainer, b.onSecondaryContainer),
        tertiary = m(a.tertiary, b.tertiary),
        onTertiary = m(a.onTertiary, b.onTertiary),
        tertiaryContainer = m(a.tertiaryContainer, b.tertiaryContainer),
        onTertiaryContainer = m(a.onTertiaryContainer, b.onTertiaryContainer),
        background = m(a.background, b.background),
        onBackground = m(a.onBackground, b.onBackground),
        surface = m(a.surface, b.surface),
        onSurface = m(a.onSurface, b.onSurface),
        surfaceVariant = m(a.surfaceVariant, b.surfaceVariant),
        onSurfaceVariant = m(a.onSurfaceVariant, b.onSurfaceVariant),
        surfaceTint = m(a.surfaceTint, b.surfaceTint),
        inverseSurface = m(a.inverseSurface, b.inverseSurface),
        inverseOnSurface = m(a.inverseOnSurface, b.inverseOnSurface),
        outline = m(a.outline, b.outline),
        outlineVariant = m(a.outlineVariant, b.outlineVariant),
        surfaceBright = m(a.surfaceBright, b.surfaceBright),
        surfaceDim = m(a.surfaceDim, b.surfaceDim),
        surfaceContainer = m(a.surfaceContainer, b.surfaceContainer),
        surfaceContainerHigh = m(a.surfaceContainerHigh, b.surfaceContainerHigh),
        surfaceContainerHighest = m(a.surfaceContainerHighest, b.surfaceContainerHighest),
        surfaceContainerLow = m(a.surfaceContainerLow, b.surfaceContainerLow),
        surfaceContainerLowest = m(a.surfaceContainerLowest, b.surfaceContainerLowest),
    )
}

/** The theme with the cover's colours worked in. [strength] 1 is the full colour scheme of the cover, lower keeps more of your theme. */
internal fun livingScheme(base: ColorScheme, seed: Color, spread: Float, strength: Float): ColorScheme =
    lerpScheme(base, coverScheme(base, seed, spread), strength.coerceIn(0f, 1f))

/** The glide between two covers is drawn in this many steps. Each step recomposes the colours once, so fewer is lighter. */
private const val LIVING_STEPS = 8

/**
 * Living colours: the colours of the whole app follow the cover of the song that is playing, and glide to the new ones
 * (about two thirds of a second) when the song changes. With the setting off this only passes the theme through, and the
 * content stays in the same place in the tree, so switching it on or off never restarts the screens.
 */
@Composable
fun LivingColors(vm: PlayerViewModel, content: @Composable () -> Unit) {
    val s = LocalAppSettings.current
    val lite = LocalLite.current
    val ui by vm.ui.collectAsState()
    val base = MaterialTheme.colorScheme
    val seed = if (s.livingColors) rememberCoverSeed(ui.current) else null
    val target = remember(seed, base, s.spread, s.livingStrength) {
        if (seed == null) base else livingScheme(base, seed, s.spread, s.livingStrength)
    }
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    val progress = remember { Animatable(1f) }
    LaunchedEffect(target) {
        if (to === target) return@LaunchedEffect
        if (s.livingColors && !lite) {
            from = lerpScheme(from, to, progress.value)
            to = target
            progress.snapTo(0f)
            progress.animateTo(1f, tween(650))
        } else {
            // the feature is off (or Lite is on): follow the theme straight away, no glide
            from = target
            to = target
            progress.snapTo(1f)
        }
    }
    // Read through derivedStateOf: this screen recomposes only when the step changes (8 times), not on every frame
    val step by remember { derivedStateOf { (progress.value * LIVING_STEPS).toInt() } }
    MaterialTheme(
        colorScheme = if (from === to) to else lerpScheme(from, to, step / LIVING_STEPS.toFloat()),
        shapes = MaterialTheme.shapes,
        typography = MaterialTheme.typography,
        content = content,
    )
}
