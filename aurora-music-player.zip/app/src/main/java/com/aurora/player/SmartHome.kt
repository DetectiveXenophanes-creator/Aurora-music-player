package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.abs

private val fitMinutes = listOf(10, 15, 20, 30, 45, 60, 90)

/** "Fit my time": a mix whose songs add up to the time you have, down to a few seconds. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FitTimeCard(songs: List<Song>, lib: LibraryData, shape: RoundedCornerShape, onPlayAll: (List<Song>) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var minutes by rememberSaveable { mutableStateOf(25) }
    var sourceIdx by rememberSaveable { mutableStateOf(0) }
    var round by rememberSaveable { mutableStateOf(0) }
    val source = FitSource.entries[sourceIdx]
    val mix = remember(songs, minutes, sourceIdx, round, lib.favorites.size) {
        fitToTime(fitPool(songs, lib, source), minutes * 60_000L, minutes * 1000L + round)
    }
    val total = mix.sumOf { it.durationMs }
    val diff = total - minutes * 60_000L
    Column(
        Modifier.fillMaxWidth().cardGlow(shape).cardFinish(shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Timer, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.padding(start = 12.dp)) {
                Text("Fit my time", style = MaterialTheme.typography.titleMedium)
                Text(
                    "A mix that ends exactly when your trip does",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            fitMinutes.forEach { m ->
                AuroraChip(verbatim("$m min"), minutes == m) { minutes = m }
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FitSource.entries.forEach { f -> AuroraChip(f.label, source == f) { sourceIdx = f.ordinal } }
        }
        if (mix.isEmpty()) {
            Text(
                "Not enough songs for that. Try another source.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
        } else {
            val gap = abs(diff) / 1000
            val gapText = if (gap >= 90) "${gap / 60} min" else "${gap}s"
            Text(
                "${mix.size} songs  •  ${fmt(total)}" + when {
                    gap < 2 -> "  •  right on time"
                    diff < 0 -> "  •  $gapText short"
                    else -> "  •  $gapText over"
                },
                style = MaterialTheme.typography.labelLarge,
                color = cs.primary,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(onClick = { onPlayAll(mix) }) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                TextButton(onClick = { round++ }) {
                    Icon(Icons.Rounded.Refresh, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Another mix")
                }
            }
        }
    }
}

/** "Right now": songs you usually play around this hour. Shows a short note while Aurora is still learning. */
@Composable
fun RightNowCard(
    songs: List<Song>,
    lib: LibraryData,
    shape: RoundedCornerShape,
    onPlayAll: (List<Song>) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onOpen: (DetailRef) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val hour = remember { java.time.LocalTime.now().hour }
    val mix = remember(songs, lib.songHours, lib.skips) { rightNowMix(songs, lib) }
    val ready = mix.size >= 5
    Row(
        Modifier.fillMaxWidth().cardGlow(shape).cardFinish(shape)
            .clickable(enabled = ready) { onOpen(DetailRef(DetailKind.SMART, "rightnow", "Right now")) }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(cs.secondaryContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Schedule, null, tint = cs.onSecondaryContainer, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text("Right now", style = MaterialTheme.typography.titleMedium)
            Text(
                if (ready) "Songs you usually play around ${hourLabelOf(hour)}"
                else "Aurora is learning which songs you play at which hour. Your first mix shows up after a few days of listening.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        if (ready) {
            FilledTonalButton(onClick = { onShuffle(mix) }) {
                Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Shuffle")
            }
        }
    }
}

/** "Song duel": two songs, you pick the better one. The wins build a ranking of your own. */
@Composable
fun DuelCard(
    songs: List<Song>,
    lib: LibraryData,
    shape: RoundedCornerShape,
    onPlay: (Song, List<Song>) -> Unit,
    onOpen: (DetailRef) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var round by rememberSaveable { mutableStateOf(0) }
    val pair = remember(songs, round) { pickDuel(songs, lib, 100L + round) }
    val duels = lib.duel.values.sumOf { it.second } / 2
    Column(
        Modifier.fillMaxWidth().cardGlow(shape).cardFinish(shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(cs.tertiaryContainer), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.EmojiEvents, null, tint = cs.onTertiaryContainer, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.padding(start = 12.dp)) {
                Text("Song duel", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Which one is better? Your picks build a ranking.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
        }
        if (pair == null) {
            Text(
                "You need at least two songs for a duel.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(pair.first to pair.second, pair.second to pair.first).forEach { (mine, other) ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(cs.onSurface.copy(alpha = 0.06f))
                            .clickable {
                                scope.launch { LibraryStore(context).recordDuel(mine.id, other.id) }
                                round++
                            }
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            Art(mine.artUri, Modifier.size(104.dp), RoundedCornerShape(14.dp))
                            IconButton(onClick = { onPlay(mine, listOf(mine)) }, modifier = Modifier.size(36.dp)) {
                                Box(Modifier.size(28.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.PlayArrow, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        Text(
                            mine.title,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            mine.artist,
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { round++ }) { Text("Skip this pair") }
                Spacer(Modifier.weight(1f))
                Text(
                    "$duels duels",
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(end = 4.dp),
                )
                if (duels >= 2) {
                    TextButton(onClick = { onOpen(DetailRef(DetailKind.SMART, "duel", "Duel champions")) }) {
                        Text("Champions")
                    }
                }
            }
        }
    }
}
