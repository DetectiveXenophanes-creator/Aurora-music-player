package com.aurora.player

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.delay

// App-wide design effects that sit in one layer above the whole app (but under the tour): film grain, a vignette, a warm
// evening tint and an edge light that breathes while music plays. The layer draws only; it never takes a touch.

private val WARM = Color(0xFFFF8A2B)
private const val NIGHT_START = 20 * 60
private const val NIGHT_END = 6 * 60
private const val NIGHT_RAMP = 60

/** The minute of the day right now, 0 to 1439. */
internal fun minuteOfDayNow(): Int {
    val c = java.util.Calendar.getInstance()
    return c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
}

/**
 * How warm the screen should be at this minute of the day, 0 to 1: it fades in over the hour before 20:00, stays all night
 * and fades out between 06:00 and 07:00. Same maths as tools/atmosphere_check.py.
 */
internal fun eveningFactor(m: Int): Float = when {
    m >= NIGHT_START -> 1f
    m >= NIGHT_START - NIGHT_RAMP -> (m - (NIGHT_START - NIGHT_RAMP)) / NIGHT_RAMP.toFloat()
    m < NIGHT_END -> 1f
    m < NIGHT_END + NIGHT_RAMP -> 1f - (m - NIGHT_END) / NIGHT_RAMP.toFloat()
    else -> 0f
}

/** A tile of fine two pixel specks, half white and half black, each with its own strength. It repeats without any seam. */
private fun makeGrainBrush(): ShaderBrush {
    val n = 160
    val cells = n / 2
    val rnd = kotlin.random.Random(11)
    val noise = IntArray(cells * cells) {
        val a = (rnd.nextFloat() * 255f).toInt()
        val c = if (rnd.nextBoolean()) 0xFFFFFF else 0x000000
        (a shl 24) or c
    }
    val px = IntArray(n * n)
    for (y in 0 until n) {
        for (x in 0 until n) px[y * n + x] = noise[(y / 2) * cells + (x / 2)]
    }
    val bitmap = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    return ShaderBrush(ImageShader(bitmap.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
}

private fun shiftHue(c: Color, degrees: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[0] = (hsv[0] + degrees + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Put this last in the screen's top level box. It draws nothing at all when every effect is off. */
@Composable
fun AtmosphereLayer(s: AppSettings, song: Song?, playing: Boolean) {
    if (s.grain > 0f || s.vignette > 0f || s.warmth > 0f) StillAtmosphere(s)
    if (s.edgeLight > 0f) EdgeLight(s, song, playing)
}

/** The effects that never move: warm tint, vignette and grain. Drawn once and kept, so they cost almost nothing. */
@Composable
private fun StillAtmosphere(s: AppSettings) {
    val grain = remember(s.grain > 0f) { if (s.grain > 0f) makeGrainBrush() else null }
    val timed = s.warmth > 0f && s.warmAuto
    val minute by produceState(initialValue = minuteOfDayNow(), timed) {
        if (timed) {
            while (true) {
                delay(60_000)
                value = minuteOfDayNow()
            }
        }
    }
    val warm = when {
        s.warmth <= 0f -> 0f
        s.warmAuto -> eveningFactor(minute) * s.warmth
        else -> s.warmth
    }
    // Its own layer: drawn once and then only replayed, so it never makes the screen behind it redraw
    Canvas(Modifier.fillMaxSize().graphicsLayer { }) {
        if (warm > 0.002f) {
            drawRect(WARM.copy(alpha = (warm * 0.20f).coerceIn(0f, 0.3f)))
        }
        if (s.vignette > 0f) {
            val r = hypot(size.width, size.height) / 2f
            drawRect(
                Brush.radialGradient(
                    0.50f to Color.Transparent,
                    1f to Color.Black.copy(alpha = (s.vignette * 0.6f).coerceIn(0f, 0.7f)),
                    center = center,
                    radius = r,
                ),
            )
        }
        if (grain != null) {
            drawRect(grain, alpha = (s.grain * 0.24f).coerceIn(0f, 0.32f))
        }
    }
}

/**
 * A soft coloured light along the four edges of the screen. It breathes slowly while music plays (12 steps a second, and it
 * stands still in battery saver or when nothing plays). The colours come from the theme, or from the cover of the song.
 */
@Composable
private fun EdgeLight(s: AppSettings, song: Song?, playing: Boolean) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val seed = if (s.edgeCover) rememberCoverSeed(song) else null
    val cover = remember(seed, dark) { seed?.let { readableAccent(it, dark) } }
    val top = cover ?: cs.primary
    val side = if (cover != null) shiftHue(cover, 25f) else cs.secondary
    val bottom = if (cover != null) shiftHue(cover, -35f) else cs.tertiary
    val moving = playing && !s.batterySaver
    val clock = rememberThrottledClock(moving, 12)
    // Its own layer: the breathing redraws only this layer, not the whole screen behind it
    Canvas(Modifier.fillMaxSize().graphicsLayer { }) {
        val breathe = if (moving) 0.78f + 0.22f * sin(clock.value * 1.2f) else 0.78f
        val a = (s.edgeLight * 0.6f * breathe).coerceIn(0f, 0.85f)
        val w = size.width
        val h = size.height
        val thick = minOf(w, h) * 0.14f
        drawRect(
            Brush.verticalGradient(listOf(top.copy(alpha = a), Color.Transparent), startY = 0f, endY = thick),
            size = Size(w, thick),
        )
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, bottom.copy(alpha = a)), startY = h - thick, endY = h),
            topLeft = Offset(0f, h - thick),
            size = Size(w, thick),
        )
        drawRect(
            Brush.horizontalGradient(listOf(side.copy(alpha = a), Color.Transparent), startX = 0f, endX = thick),
            size = Size(thick, h),
        )
        drawRect(
            Brush.horizontalGradient(listOf(Color.Transparent, side.copy(alpha = a)), startX = w - thick, endX = w),
            topLeft = Offset(w - thick, 0f),
            size = Size(thick, h),
        )
    }
}
