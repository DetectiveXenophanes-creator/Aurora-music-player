package com.aurora.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.rounded.Check
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

/** Everything the song menu can do. Provided once at the top of the app. */
class SongActions(
    val favorites: Set<Long>,
    val playlists: List<Playlist>,
    val toggleFavorite: (Song) -> Unit,
    val playNext: (Song) -> Unit,
    val addToQueue: (Song) -> Unit,
    val addToPlaylist: (Playlist, Song) -> Unit,
    val newPlaylistWith: (Song) -> Unit,
)

val LocalSongActions = compositionLocalOf<SongActions?> { null }

@Composable
fun SongsScreen(
    songs: List<Song>,
    lib: LibraryData,
    onUpdate: SettingsUpdate,
    currentId: Long?,
    playing: Boolean,
    granted: Boolean,
    onRequest: () -> Unit,
    padding: PaddingValues,
    selected: Set<Long>,
    onToggleSelect: (Song) -> Unit,
    onVisible: (List<Song>) -> Unit,
    onPlay: (Song, List<Song>) -> Unit,
    onShuffleAll: (List<Song>) -> Unit,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val compact = s.density == ListDensity.COMPACT
    val shape = RoundedCornerShape(s.corner.dp)
    var query by rememberSaveable { mutableStateOf("") }
    var showSort by rememberSaveable { mutableStateOf(false) }
    val playsKey = if (s.sortKey == SortKey.PLAYS) lib.plays else null
    val favKey = if (s.filterFav) lib.favorites else null
    val filtered = remember(songs, query, s.sortKey, s.sortAsc, s.filterFav, s.filterLen, playsKey, favKey) {
        applySortFilter(songs, query, s, lib)
    }
    val (lowLabel, highLabel) = sortDirectionLabels(s.sortKey)
    val summary = buildString {
        append("${filtered.size} songs  •  ${s.sortKey.label}, ${if (s.sortAsc) lowLabel else highLabel}")
        if (s.filterFav) append("  •  Favorites")
        if (s.filterLen != LenFilter.ANY) append("  •  ${s.filterLen.label}")
    }
    val selecting = selected.isNotEmpty()
    LaunchedEffect(filtered) { onVisible(filtered) }
    // Rows that have already played their entrance animation do not play it again.
    val seen = remember { HashSet<Long>() }
    if (showSort) {
        SortFilterSheet(s = s, shown = filtered.size, onUpdate = onUpdate, onDismiss = { showSort = false })
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 8.dp),
    ) {
        if (!granted) {
            item {
                InfoCard(
                    title = "Allow music access",
                    body = "Aurora needs permission to read the audio files on your phone.",
                    action = "Allow",
                    onAction = onRequest,
                )
            }
        } else {
            item {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search songs, artists, albums") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth().cardFinish(shape),
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = { onShuffleAll(filtered) },
                        enabled = filtered.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Shuffle all", maxLines = 1)
                    }
                    FilledTonalButton(onClick = { showSort = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.FilterList, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Sort and filter", maxLines = 1)
                    }
                }
            }
            item {
                Text(
                    summary,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (songs.isEmpty()) {
                item { InfoCard("No music found", "Copy some audio files onto this phone, or check Settings > Library.", null) {} }
            } else if (filtered.isEmpty()) {
                item { InfoCard("No songs match", "Try a different search, or relax the filters in Sort and filter.", null) {} }
            }
            itemsIndexed(filtered, key = { _, song -> song.id }) { index, song ->
                val animate = remember { seen.add(song.id) } && s.listEntrance
                SongRow(
                    song = song,
                    current = song.id == currentId,
                    playing = playing,
                    modifier = Modifier
                        .animateItem(
                            fadeInSpec = if (motion.enabled) motion.effects<Float>() else null,
                            placementSpec = if (motion.enabled) motion.spatial<IntOffset>() else null,
                            fadeOutSpec = if (motion.enabled) motion.effects<Float>() else null,
                        )
                        .enterAnim(animate, index),
                    selecting = selecting,
                    selected = song.id in selected,
                    onLongClick = { onToggleSelect(song) },
                ) {
                    if (selecting) onToggleSelect(song) else onPlay(song, filtered)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SortFilterSheet(s: AppSettings, shown: Int, onUpdate: SettingsUpdate, onDismiss: () -> Unit) {
    val (lowLabel, highLabel) = sortDirectionLabels(s.sortKey)
    AuroraSheet(onDismiss = onDismiss, title = "Sort and filter") {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SheetLabel("Sort by")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SortKey.entries.forEach { k ->
                    AuroraChip(k.label, s.sortKey == k) {
                        if (s.sortKey != k) {
                            val asc = k != SortKey.PLAYS && k != SortKey.ADDED
                            onUpdate { it.copy(sortKey = k, sortAsc = asc) }
                        }
                    }
                }
            }
            SheetLabel("Order")
            Segmented(
                options = listOf(lowLabel to true, highLabel to false),
                selected = s.sortAsc,
                onSelect = { v -> onUpdate { it.copy(sortAsc = v) } },
            )
            SheetLabel("Filter")
            ToggleRow("Favorites only", "Hide songs you have not hearted", s.filterFav, true) { v ->
                onUpdate { it.copy(filterFav = v) }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LenFilter.entries.forEach { f ->
                    AuroraChip(f.label, s.filterLen == f) { onUpdate { it.copy(filterLen = f) } }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    onClick = {
                        onUpdate {
                            it.copy(sortKey = SortKey.TITLE, sortAsc = true, filterFav = false, filterLen = LenFilter.ANY)
                        }
                    },
                ) { Text("Reset") }
                Spacer(Modifier.weight(1f))
                Button(onClick = onDismiss) { Text("Show $shown songs") }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(
    song: Song,
    current: Boolean,
    playing: Boolean,
    modifier: Modifier = Modifier,
    onRemove: (() -> Unit)? = null,
    selecting: Boolean = false,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val compact = s.density == ListDensity.COMPACT
    val shape = RoundedCornerShape(s.corner.dp)
    val artSize = if (compact) 40.dp else 52.dp
    val pad = if (compact) 6.dp else 10.dp
    val borderColor by animateColorAsState(
        targetValue = if (selected) cs.primary else if (current) cs.primary.copy(alpha = 0.7f) else Color.Transparent,
        animationSpec = motion.effects(),
        label = "rowBorder",
    )
    val titleColor by animateColorAsState(
        targetValue = if (current) cs.primary else cs.onSurface,
        animationSpec = motion.effects(),
        label = "rowTitle",
    )
    Row(
        modifier
            .fillMaxWidth()
            .cardFinish(shape)
            .background(if (selected) cs.primaryContainer.copy(alpha = 0.35f) else Color.Transparent, shape)
            .border(1.5.dp, borderColor, shape)
            .clip(shape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick?.let { action ->
                    {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        action()
                    }
                },
            )
            .padding(start = pad, top = pad, bottom = pad, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.listArt) {
            Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((s.corner * 0.5f).dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = if (s.listArt) 12.dp else 8.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.titleMedium,
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${song.artist} • ${fmt(song.durationMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (selecting) {
            SelectDot(selected)
            Spacer(Modifier.width(12.dp))
        } else {
            if (current) {
                EqualizerBars(active = playing, color = cs.primary)
                Spacer(Modifier.width(4.dp))
            }
            SongMenu(song, onRemove)
        }
    }
}

@Composable
private fun SelectDot(selected: Boolean) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(26.dp)
            .clip(CircleShape)
            .background(if (selected) cs.primary else Color.Transparent)
            .border(2.dp, if (selected) cs.primary else cs.outline, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun SongMenu(
    song: Song,
    onRemove: (() -> Unit)?,
    anchor: @Composable (open: () -> Unit) -> Unit = { open ->
        IconButton(onClick = open, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Rounded.MoreVert, "More", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    },
) {
    val actions = LocalSongActions.current
    var open by remember { mutableStateOf(false) }
    Box {
        anchor { open = true }
        AuroraMenu(expanded = open, onDismiss = { open = false }) {
            if (actions != null) {
                val fav = song.id in actions.favorites
                AuroraMenuItem(
                    text = if (fav) "Remove from favorites" else "Add to favorites",
                    icon = if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    highlighted = fav,
                    onClick = { actions.toggleFavorite(song); open = false },
                )
                AuroraMenuItem("Play next", Icons.Rounded.SkipNext, { actions.playNext(song); open = false })
                AuroraMenuItem("Add to queue", Icons.Rounded.QueueMusic, { actions.addToQueue(song); open = false })
                AuroraMenuDivider()
                AuroraMenuLabel("Add to playlist")
                actions.playlists.forEach { pl ->
                    AuroraMenuItem(pl.name, playlistIcon(pl.icon), { actions.addToPlaylist(pl, song); open = false })
                }
                AuroraMenuItem("New playlist…", Icons.Rounded.Add, { actions.newPlaylistWith(song); open = false })
            }
            if (onRemove != null) {
                AuroraMenuDivider()
                AuroraMenuItem("Remove from this playlist", Icons.Rounded.Delete, { onRemove(); open = false })
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String, action: String?, onAction: () -> Unit) {
    val corner = LocalAppSettings.current.corner
    Column(
        Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) FilledTonalButton(onClick = onAction) { Text(action) }
    }
}
