package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

private val auroraColors = listOf(
    Color(0xFF2EE6A6), // green
    Color(0xFF2ED9FF), // cyan
    Color(0xFF8A5CFF), // violet
    Color(0xFFFF6FD8), // pink
)
private val ink = Color(0xFF10163A)

/**
 * Lumi, the cat made of northern lights. The colours slowly flow through her body, she blinks, her tail wags and she
 * bounces when [bounce] is on. When [asleep] her eyes close and she breathes slowly. With [animate] off she is a still
 * picture, which is what Lite mode and Battery saver use.
 */
@Composable
fun AuroraCat(
    modifier: Modifier = Modifier,
    asleep: Boolean = false,
    bounce: Boolean = true,
    animate: Boolean = true,
) {
    val settings = LocalAppSettings.current
    val paused = LocalBackgroundPaused.current
    val running = animate && !settings.batterySaver && !paused
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        var start = 0L
        while (true) {
            withFrameNanos { now ->
                if (start == 0L) start = now
                clock.floatValue = (now - start) / 1_000_000_000f
            }
            delay(24) // about 30 frames a second is plenty for a mascot
        }
    }

    Canvas(modifier) {
        val t = clock.floatValue
        val u = minOf(size.width, size.height) / 100f
        val ox = (size.width - 100f * u) / 2f
        val oy = (size.height - 100f * u) / 2f
        val bob = when {
            !running -> 0f
            asleep -> sin(t * 1.6f) * 0.9f
            bounce -> sin(t * 4.2f) * 1.8f
            else -> 0f
        }
        fun p(x: Float, y: Float) = Offset(ox + x * u, oy + (y + bob) * u)

        val shift = (t * 0.18f % 1f) * 100f * u
        val brush = Brush.linearGradient(
            colors = auroraColors,
            start = Offset(ox + shift - 100f * u, oy),
            end = Offset(ox + shift + 40f * u, oy + 100f * u),
            tileMode = TileMode.Mirror,
        )
        val round = Stroke(width = 5f * u, join = StrokeJoin.Round)

        // soft glow behind everything
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF8A5CFF).copy(alpha = 0.28f), Color.Transparent),
                center = p(50f, 56f),
                radius = 56f * u,
            ),
            radius = 56f * u,
            center = p(50f, 56f),
        )

        // tail
        val wag = if (running && !asleep) sin(t * 2.6f) * 6f else 0f
        val tail = Path().apply {
            moveTo(p(70f, 86f).x, p(70f, 86f).y)
            cubicTo(
                p(90f, 90f).x, p(90f, 90f).y,
                p(96f + wag, 68f).x, p(96f + wag, 68f).y,
                p(86f + wag, 50f).x, p(86f + wag, 50f).y,
            )
        }
        drawPath(tail, brush, style = Stroke(width = 9f * u, cap = StrokeCap.Round))

        // body
        drawOval(brush, p(23f, 61f), Size(54f * u, 38f * u))

        // ears
        val leftEar = Path().apply {
            moveTo(p(27f, 41f).x, p(27f, 41f).y)
            lineTo(p(29f, 13f).x, p(29f, 13f).y)
            lineTo(p(48f, 28f).x, p(48f, 28f).y)
            close()
        }
        val rightEar = Path().apply {
            moveTo(p(73f, 41f).x, p(73f, 41f).y)
            lineTo(p(71f, 13f).x, p(71f, 13f).y)
            lineTo(p(52f, 28f).x, p(52f, 28f).y)
            close()
        }
        drawPath(leftEar, brush)
        drawPath(leftEar, brush, style = round)
        drawPath(rightEar, brush)
        drawPath(rightEar, brush, style = round)
        val innerL = Path().apply {
            moveTo(p(31f, 35f).x, p(31f, 35f).y)
            lineTo(p(32f, 21f).x, p(32f, 21f).y)
            lineTo(p(42f, 29f).x, p(42f, 29f).y)
            close()
        }
        val innerR = Path().apply {
            moveTo(p(69f, 35f).x, p(69f, 35f).y)
            lineTo(p(68f, 21f).x, p(68f, 21f).y)
            lineTo(p(58f, 29f).x, p(58f, 29f).y)
            close()
        }
        drawPath(innerL, Color.White.copy(alpha = 0.45f))
        drawPath(innerR, Color.White.copy(alpha = 0.45f))

        // head
        drawOval(brush, p(22f, 24f), Size(56f * u, 48f * u))

        // face
        val open = if (!running) 1f else {
            val ph = t % 3.4f
            if (ph < 3.2f) 1f else abs((ph - 3.3f) / 0.1f).coerceIn(0f, 1f)
        }
        for (cx in listOf(39f, 61f)) {
            if (asleep) {
                val eye = Path().apply {
                    moveTo(p(cx - 5f, 48f).x, p(cx - 5f, 48f).y)
                    quadraticTo(p(cx, 53f).x, p(cx, 53f).y, p(cx + 5f, 48f).x, p(cx + 5f, 48f).y)
                }
                drawPath(eye, ink, style = Stroke(width = 1.8f * u, cap = StrokeCap.Round))
            } else {
                val ry = 5.6f * open.coerceAtLeast(0.12f)
                drawOval(ink, p(cx - 4.2f, 48f - ry), Size(8.4f * u, 2f * ry * u))
                if (open > 0.5f) drawCircle(Color.White, 1.4f * u, p(cx + 1.4f, 46.2f))
            }
        }
        // cheeks
        drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(32f, 58f))
        drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(68f, 58f))
        // nose and mouth
        val nose = Path().apply {
            moveTo(p(47.5f, 54.5f).x, p(47.5f, 54.5f).y)
            lineTo(p(52.5f, 54.5f).x, p(52.5f, 54.5f).y)
            lineTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            close()
        }
        drawPath(nose, Color(0xFFFFB3D9))
        val mouth = Path().apply {
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(45.5f, 60.5f).x, p(45.5f, 60.5f).y)
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(54.5f, 60.5f).x, p(54.5f, 60.5f).y)
        }
        drawPath(mouth, ink.copy(alpha = 0.8f), style = Stroke(width = 1.4f * u, cap = StrokeCap.Round))
        // whiskers
        val whisker = Color.White.copy(alpha = 0.6f)
        for ((a, b) in listOf(
            Offset(33f, 55f) to Offset(17f, 52f), Offset(33f, 58f) to Offset(17f, 60f),
            Offset(67f, 55f) to Offset(83f, 52f), Offset(67f, 58f) to Offset(83f, 60f),
        )) {
            drawLine(whisker, p(a.x, a.y), p(b.x, b.y), 1.1f * u, StrokeCap.Round)
        }

        // sparkles, or a little "z z" when she sleeps
        if (asleep) {
            val z = Path().apply {
                moveTo(p(74f, 14f).x, p(74f, 14f).y)
                lineTo(p(82f, 14f).x, p(82f, 14f).y)
                lineTo(p(74f, 24f).x, p(74f, 24f).y)
                lineTo(p(82f, 24f).x, p(82f, 24f).y)
            }
            drawPath(z, Color.White.copy(alpha = 0.8f), style = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else {
            val spots = listOf(Offset(10f, 22f), Offset(91f, 26f), Offset(7f, 66f), Offset(93f, 90f))
            spots.forEachIndexed { i, o ->
                val twinkle = if (running) 0.35f + 0.65f * abs(sin(t * 1.7f + i * 1.3f)) else 0.8f
                val r = (2.4f + i % 2) * u
                val c = p(o.x, o.y)
                val star = Path().apply {
                    moveTo(c.x, c.y - r)
                    lineTo(c.x + r * 0.3f, c.y - r * 0.3f)
                    lineTo(c.x + r, c.y)
                    lineTo(c.x + r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x, c.y + r)
                    lineTo(c.x - r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x - r, c.y)
                    lineTo(c.x - r * 0.3f, c.y - r * 0.3f)
                    close()
                }
                drawPath(star, Color.White.copy(alpha = twinkle))
            }
        }
    }
}
