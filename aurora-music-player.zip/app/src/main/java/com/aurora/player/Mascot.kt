package com.aurora.player

import androidx.compose.foundation.Canvas
import kotlin.math.PI
import kotlinx.coroutines.launch
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

private val ink = Color(0xFF10163A)

/** Everything about how the mascot looks. Comes from settings, but the Lumi page can also preview other looks. */
data class MascotLook(
    val palette: MascotPalette = MascotPalette.AURORA,
    val hat: MascotHat = MascotHat.NONE,
    val eyewear: MascotEyewear = MascotEyewear.NONE,
    val headphones: Boolean = false,
    val scarf: Boolean = false,
    val blush: Boolean = true,
    val ears: MascotEars = MascotEars.POINTY,
    val eyes: MascotEyes = MascotEyes.CLASSIC,
    val tail: MascotTail = MascotTail.CURLY,
    val neck: MascotNeck = MascotNeck.NONE,
    val mark: MascotMark = MascotMark.NONE,
    val wings: Boolean = false,
    val sparkles: Boolean = true,
    /** 0 to 360 picks her own colour. Below 0 uses the palette. */
    val hue: Float = -1f,
    val glow: Float = 1f,
    val flow: Boolean = true,
) {
    fun colors(): List<Color> =
        if (hue >= 0f) {
            listOf(
                Color.hsv(hue % 360f, 0.45f, 1f),
                Color.hsv((hue + 35f) % 360f, 0.55f, 1f),
                Color.hsv((hue + 75f) % 360f, 0.60f, 0.98f),
                Color.hsv((hue + 120f) % 360f, 0.50f, 1f),
            )
        } else palette.colors.map { Color(it) }
}

fun AppSettings.mascotLook() = MascotLook(
    palette = mascotPalette, hat = mascotHat, eyewear = mascotEyewear, headphones = mascotHeadphones,
    scarf = mascotScarf, blush = mascotBlush, ears = mascotEars, eyes = mascotEyes, tail = mascotTail,
    neck = mascotNeck, mark = mascotMark, wings = mascotWings, sparkles = mascotSparkles, hue = mascotHue,
    glow = mascotGlow, flow = mascotFlow,
)

private fun starPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    for (i in 0 until 10) {
        val ang = -PI / 2 + i * PI / 5
        val rad = if (i % 2 == 0) r else r * 0.45f
        val x = cx + (cos(ang) * rad).toFloat()
        val y = cy + (sin(ang) * rad).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/**
 * Draws Lumi on any canvas. [wake] is 0 asleep, about 0.45 drowsy and 1 awake. [dance] is 0 to 1 and makes her bounce
 * and float music notes. [pk] is the progress of the touch reaction (0 when she is not being touched).
 * With [running] off she is a still picture; [staticNotes] keeps the music notes visible in that case.
 */
fun DrawScope.drawLumi(
    look: MascotLook,
    t: Float,
    running: Boolean,
    wake: Float,
    dance: Float,
    pk: Float,
    notes: Boolean = true,
    staticNotes: Boolean = false,
) {
    val colors = look.colors()
    val reacting = pk > 0.001f && pk < 0.999f
    val pi = PI.toFloat()
    val happy = if (reacting) sin(pk * pi).coerceIn(0f, 1f) else 0f
    val hop = if (reacting) -sin(pk * pi * 2.5f).coerceAtLeast(0f) * (1f - pk) * 9f else 0f
    val u = minOf(size.width, size.height) / 100f
    val ox = (size.width - 100f * u) / 2f
    val oy = (size.height - 100f * u) / 2f
    val bob = hop + if (!running) 0f else sin(t * 1.6f) * 0.9f * (1f - wake) + sin(t * 4.2f) * 1.8f * dance
    fun p(x: Float, y: Float) = Offset(ox + x * u, oy + (y + bob) * u)
    val squish = if (reacting) sin(pk * pi * 5f) * (1f - pk) * 0.06f else 0f
    val wiggle = if (reacting) sin(pk * pi * 6f) * (1f - pk) * 5f else 0f
    withTransform({
        scale(1f + squish, 1f - squish, pivot = Offset(ox + 50f * u, oy + 100f * u))
        rotate(wiggle, pivot = Offset(ox + 50f * u, oy + 85f * u))
    }) {
        val shift = if (look.flow) (t * 0.18f % 1f) * 100f * u else 0f
        val brush = Brush.linearGradient(
            colors = colors,
            start = Offset(ox + shift - 100f * u, oy),
            end = Offset(ox + shift + 40f * u, oy + 100f * u),
            tileMode = TileMode.Mirror,
        )
        val round = Stroke(width = 5f * u, join = StrokeJoin.Round)

        // soft glow behind everything
        val glowAlpha = (0.28f * look.glow).coerceIn(0f, 0.9f)
        if (glowAlpha > 0.01f) {
            drawCircle(
                Brush.radialGradient(
                    listOf(colors[2].copy(alpha = glowAlpha), Color.Transparent),
                    center = p(50f, 56f),
                    radius = 56f * u,
                ),
                radius = 56f * u,
                center = p(50f, 56f),
            )
        }

        // wings flap gently behind her
        if (look.wings) {
            val flap = if (running) sin(t * 3f) * 9f * (0.3f + 0.7f * wake) else 0f
            withTransform({ rotate(-20f + flap, pivot = p(33f, 74f)) }) {
                drawOval(colors[1].copy(alpha = 0.55f), p(2f, 62f), Size(34f * u, 16f * u))
                drawOval(Color.White.copy(alpha = 0.25f), p(6f, 65f), Size(22f * u, 6f * u))
            }
            withTransform({ rotate(20f - flap, pivot = p(67f, 74f)) }) {
                drawOval(colors[1].copy(alpha = 0.55f), p(64f, 62f), Size(34f * u, 16f * u))
                drawOval(Color.White.copy(alpha = 0.25f), p(72f, 65f), Size(22f * u, 6f * u))
            }
        }

        // tail
        val wag = if (running) sin(t * 2.6f) * 6f * (0.25f + 0.75f * wake) else 0f
        if (look.tail != MascotTail.NONE) {
            val tail = Path().apply {
                moveTo(p(70f, 86f).x, p(70f, 86f).y)
                if (look.tail == MascotTail.LONG) {
                    cubicTo(
                        p(92f, 92f).x, p(92f, 92f).y,
                        p(99f + wag, 56f).x, p(99f + wag, 56f).y,
                        p(90f + wag, 28f).x, p(90f + wag, 28f).y,
                    )
                } else {
                    cubicTo(
                        p(90f, 90f).x, p(90f, 90f).y,
                        p(96f + wag, 68f).x, p(96f + wag, 68f).y,
                        p(86f + wag, 50f).x, p(86f + wag, 50f).y,
                    )
                }
            }
            val tailW = when (look.tail) {
                MascotTail.FLUFFY -> 15f
                MascotTail.LONG -> 7f
                else -> 9f
            }
            drawPath(tail, brush, style = Stroke(width = tailW * u, cap = StrokeCap.Round))
        }

        // body
        drawOval(brush, p(23f, 61f), Size(54f * u, 38f * u))

        // ears
        when (look.ears) {
            MascotEars.ROUND -> {
                drawCircle(brush, 11f * u, p(33f, 25f))
                drawCircle(brush, 11f * u, p(67f, 25f))
                drawCircle(Color.White.copy(alpha = 0.45f), 6f * u, p(33f, 26f))
                drawCircle(Color.White.copy(alpha = 0.45f), 6f * u, p(67f, 26f))
            }
            else -> {
                val tall = look.ears == MascotEars.TALL
                val tip = if (tall) 3f else 13f
                val innerTip = if (tall) 12f else 21f
                val leftEar = Path().apply {
                    moveTo(p(27f, 41f).x, p(27f, 41f).y)
                    lineTo(p(if (tall) 25f else 29f, tip).x, p(if (tall) 25f else 29f, tip).y)
                    lineTo(p(48f, 28f).x, p(48f, 28f).y)
                    close()
                }
                val rightEar = Path().apply {
                    moveTo(p(73f, 41f).x, p(73f, 41f).y)
                    lineTo(p(if (tall) 75f else 71f, tip).x, p(if (tall) 75f else 71f, tip).y)
                    lineTo(p(52f, 28f).x, p(52f, 28f).y)
                    close()
                }
                drawPath(leftEar, brush)
                drawPath(leftEar, brush, style = round)
                drawPath(rightEar, brush)
                drawPath(rightEar, brush, style = round)
                val innerL = Path().apply {
                    moveTo(p(31f, 35f).x, p(31f, 35f).y)
                    lineTo(p(if (tall) 29f else 32f, innerTip).x, p(if (tall) 29f else 32f, innerTip).y)
                    lineTo(p(42f, 29f).x, p(42f, 29f).y)
                    close()
                }
                val innerR = Path().apply {
                    moveTo(p(69f, 35f).x, p(69f, 35f).y)
                    lineTo(p(if (tall) 71f else 68f, innerTip).x, p(if (tall) 71f else 68f, innerTip).y)
                    lineTo(p(58f, 29f).x, p(58f, 29f).y)
                    close()
                }
                drawPath(innerL, Color.White.copy(alpha = 0.45f))
                drawPath(innerR, Color.White.copy(alpha = 0.45f))
            }
        }

        // head
        drawOval(brush, p(22f, 24f), Size(56f * u, 48f * u))

        // markings
        when (look.mark) {
            MascotMark.NONE -> {}
            MascotMark.STRIPES -> {
                val stripe = ink.copy(alpha = 0.32f)
                drawLine(stripe, p(45f, 29f), p(46f, 36f), 1.9f * u, StrokeCap.Round)
                drawLine(stripe, p(50f, 27f), p(50f, 36f), 1.9f * u, StrokeCap.Round)
                drawLine(stripe, p(55f, 29f), p(54f, 36f), 1.9f * u, StrokeCap.Round)
            }
            MascotMark.SPOTS -> {
                val spot = Color.White.copy(alpha = 0.38f)
                drawCircle(spot, 2.6f * u, p(36f, 34f))
                drawCircle(spot, 1.9f * u, p(64f, 36f))
                drawCircle(spot, 1.6f * u, p(53f, 31f))
                drawCircle(spot, 3.2f * u, p(34f, 84f))
                drawCircle(spot, 2.4f * u, p(61f, 88f))
            }
            MascotMark.STAR -> drawPath(starPath(p(50f, 33f).x, p(50f, 33f).y, 4.6f * u), Color.White.copy(alpha = 0.8f))
        }

        // face
        val open = if (!running) 1f else {
            val ph = t % 3.4f
            if (ph < 3.2f) 1f else abs((ph - 3.3f) / 0.1f).coerceIn(0f, 1f)
        }
        val eyeOpen = open * wake
        val ew = when (look.eyes) {
            MascotEyes.BIG -> 10.4f
            MascotEyes.SPARKLE -> 8.8f
            MascotEyes.CLASSIC -> 8.4f
        }
        val eh = when (look.eyes) {
            MascotEyes.BIG -> 7f
            MascotEyes.SPARKLE -> 6f
            MascotEyes.CLASSIC -> 5.6f
        }
        for (cx in listOf(39f, 61f)) {
            if (happy > 0.5f) {
                // happy "^ ^" eyes while she is being petted
                val eye = Path().apply {
                    moveTo(p(cx - 4.5f, 49f).x, p(cx - 4.5f, 49f).y)
                    quadraticTo(p(cx, 42.5f).x, p(cx, 42.5f).y, p(cx + 4.5f, 49f).x, p(cx + 4.5f, 49f).y)
                }
                drawPath(eye, ink, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round))
            } else if (eyeOpen < 0.16f) {
                val eye = Path().apply {
                    moveTo(p(cx - 5f, 48f).x, p(cx - 5f, 48f).y)
                    quadraticTo(p(cx, 53f).x, p(cx, 53f).y, p(cx + 5f, 48f).x, p(cx + 5f, 48f).y)
                }
                drawPath(eye, ink, style = Stroke(width = 1.8f * u, cap = StrokeCap.Round))
            } else {
                val ry = eh * eyeOpen.coerceAtLeast(0.12f)
                drawOval(ink, p(cx - ew / 2f, 48f - ry), Size(ew * u, 2f * ry * u))
                if (eyeOpen > 0.5f) {
                    drawCircle(Color.White, 1.4f * u, p(cx + 1.4f, 46.2f))
                    if (look.eyes == MascotEyes.SPARKLE) drawCircle(Color.White.copy(alpha = 0.85f), 0.9f * u, p(cx - 1.8f, 50.4f))
                }
            }
        }
        // cheeks
        if (look.blush) {
            drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(32f, 58f))
            drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(68f, 58f))
        }
        // nose and mouth
        val nose = Path().apply {
            moveTo(p(47.5f, 54.5f).x, p(47.5f, 54.5f).y)
            lineTo(p(52.5f, 54.5f).x, p(52.5f, 54.5f).y)
            lineTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            close()
        }
        drawPath(nose, Color(0xFFFFB3D9))
        val mouth = Path().apply {
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(45.5f, 60.5f).x, p(45.5f, 60.5f).y)
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(54.5f, 60.5f).x, p(54.5f, 60.5f).y)
        }
        drawPath(mouth, ink.copy(alpha = 0.8f), style = Stroke(width = 1.4f * u, cap = StrokeCap.Round))
        // whiskers
        val whisker = Color.White.copy(alpha = 0.6f)
        for ((a, b) in listOf(
            Offset(33f, 55f) to Offset(17f, 52f), Offset(33f, 58f) to Offset(17f, 60f),
            Offset(67f, 55f) to Offset(83f, 52f), Offset(67f, 58f) to Offset(83f, 60f),
        )) {
            drawLine(whisker, p(a.x, a.y), p(b.x, b.y), 1.1f * u, StrokeCap.Round)
        }

        // ---- accessories
        fun poly(vararg pts: Pair<Float, Float>): Path = Path().apply {
            pts.forEachIndexed { i, pt ->
                val o = p(pt.first, pt.second)
                if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y)
            }
            close()
        }
        val gold = Color(0xFFFFD54F)
        val hatPink = Color(0xFFFF5FA2)
        val soft = Stroke(width = 2.6f * u, join = StrokeJoin.Round)

        if (look.scarf) {
            val scarf = Color(0xFFFF5F7E)
            drawRoundRect(scarf, p(31f, 69f), Size(38f * u, 9f * u), CornerRadius(4.5f * u))
            drawRoundRect(Color(0xFFE04565), p(59f, 73f), Size(7f * u, 16f * u), CornerRadius(3.5f * u))
        }
        when (look.neck) {
            MascotNeck.NONE -> {}
            MascotNeck.BELL -> {
                drawRoundRect(hatPink, p(33f, 67f), Size(34f * u, 4.2f * u), CornerRadius(2.1f * u))
                drawCircle(gold, 3.8f * u, p(50f, 73.5f))
                drawLine(Color(0xFFB8860B), p(47.8f, 74f), p(52.2f, 74f), 0.9f * u, StrokeCap.Round)
            }
            MascotNeck.BOWTIE -> {
                val l = poly(50f to 70f, 39f to 63f, 39f to 77f)
                val r = poly(50f to 70f, 61f to 63f, 61f to 77f)
                drawPath(l, hatPink)
                drawPath(l, hatPink, style = soft)
                drawPath(r, hatPink)
                drawPath(r, hatPink, style = soft)
                drawCircle(Color(0xFFFF2E88), 3.2f * u, p(50f, 70f))
            }
            MascotNeck.STAR -> {
                drawLine(gold.copy(alpha = 0.9f), p(35f, 66f), p(50f, 75f), 1.1f * u, StrokeCap.Round)
                drawLine(gold.copy(alpha = 0.9f), p(65f, 66f), p(50f, 75f), 1.1f * u, StrokeCap.Round)
                drawPath(starPath(p(50f, 79f).x, p(50f, 79f).y, 5.6f * u), gold)
            }
        }
        if (look.headphones) {
            val band = Path().apply {
                moveTo(p(19f, 46f).x, p(19f, 46f).y)
                cubicTo(p(19f, -4f).x, p(19f, -4f).y, p(81f, -4f).x, p(81f, -4f).y, p(81f, 46f).x, p(81f, 46f).y)
            }
            drawPath(band, Color(0xFF2B2F55), style = Stroke(width = 4.4f * u, cap = StrokeCap.Round))
            drawRoundRect(colors[2], p(12f, 38f), Size(11f * u, 21f * u), CornerRadius(5f * u))
            drawRoundRect(colors[2], p(77f, 38f), Size(11f * u, 21f * u), CornerRadius(5f * u))
            drawRoundRect(Color.White.copy(alpha = 0.35f), p(14.5f, 41f), Size(2.2f * u, 15f * u), CornerRadius(1.1f * u))
            drawRoundRect(Color.White.copy(alpha = 0.35f), p(79.5f, 41f), Size(2.2f * u, 15f * u), CornerRadius(1.1f * u))
        }
        when (look.eyewear) {
            MascotEyewear.NONE -> {}
            MascotEyewear.GLASSES -> {
                for (cx in listOf(39f, 61f)) drawCircle(ink, 8.6f * u, p(cx, 48f), style = Stroke(width = 1.6f * u))
                drawLine(ink, p(47.6f, 47f), p(52.4f, 47f), 1.6f * u, StrokeCap.Round)
                drawLine(ink, p(30.4f, 47f), p(26f, 45f), 1.4f * u, StrokeCap.Round)
                drawLine(ink, p(69.6f, 47f), p(74f, 45f), 1.4f * u, StrokeCap.Round)
            }
            MascotEyewear.SHADES -> {
                val lens = Color(0xF2111530)
                drawRoundRect(lens, p(29.5f, 42.5f), Size(19f * u, 12f * u), CornerRadius(4.5f * u))
                drawRoundRect(lens, p(51.5f, 42.5f), Size(19f * u, 12f * u), CornerRadius(4.5f * u))
                drawLine(lens, p(48f, 45f), p(52f, 45f), 1.8f * u, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.5f), p(32f, 45.5f), p(36f, 45.5f), 1.2f * u, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.5f), p(54f, 45.5f), p(58f, 45.5f), 1.2f * u, StrokeCap.Round)
            }
        }
        when (look.hat) {
            MascotHat.NONE -> {}
            MascotHat.PARTY -> {
                val cone = poly(44f to 25f, 66f to 25f, 56f to 4f)
                drawPath(cone, hatPink)
                drawPath(cone, hatPink, style = soft)
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(53f, 17f))
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(58f, 12f))
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(57f, 20f))
                drawCircle(gold, 3f * u, p(56f, 4f))
            }
            MascotHat.CROWN -> {
                val crown = poly(36f to 25f, 36f to 11f, 43f to 18f, 50f to 7f, 57f to 18f, 64f to 11f, 64f to 25f)
                drawPath(crown, gold)
                drawPath(crown, gold, style = soft)
                drawCircle(hatPink, 1.7f * u, p(50f, 18f))
                drawCircle(Color(0xFF2ED9FF), 1.3f * u, p(41f, 21f))
                drawCircle(Color(0xFF2ED9FF), 1.3f * u, p(59f, 21f))
            }
            MascotHat.BOW -> {
                val left = poly(66f to 20f, 54f to 12f, 54f to 28f)
                val right = poly(66f to 20f, 78f to 12f, 78f to 28f)
                drawPath(left, hatPink)
                drawPath(left, hatPink, style = soft)
                drawPath(right, hatPink)
                drawPath(right, hatPink, style = soft)
                drawCircle(Color(0xFFFF2E88), 3.4f * u, p(66f, 20f))
            }
            MascotHat.HALO -> {
                drawOval(gold.copy(alpha = 0.30f), p(36f, 0.5f), Size(28f * u, 8f * u), style = Stroke(width = 5f * u))
                drawOval(gold, p(36f, 0.5f), Size(28f * u, 8f * u), style = Stroke(width = 2.2f * u))
            }
        }

        // sparkles, or a little "z z" when she sleeps
        if (wake < 0.98f) {
            val z = Path().apply {
                moveTo(p(74f, 14f).x, p(74f, 14f).y)
                lineTo(p(82f, 14f).x, p(82f, 14f).y)
                lineTo(p(74f, 24f).x, p(74f, 24f).y)
                lineTo(p(82f, 24f).x, p(82f, 24f).y)
            }
            drawPath(z, Color.White.copy(alpha = 0.8f * (1f - wake)), style = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (wake > 0.02f && look.sparkles) {
            val spots = listOf(Offset(10f, 22f), Offset(91f, 26f), Offset(7f, 66f), Offset(93f, 90f))
            spots.forEachIndexed { i, o ->
                val twinkle = if (running) 0.35f + 0.65f * abs(sin(t * 1.7f + i * 1.3f)) else 0.8f
                val r = (2.4f + i % 2) * u
                val c = p(o.x, o.y)
                val star = Path().apply {
                    moveTo(c.x, c.y - r)
                    lineTo(c.x + r * 0.3f, c.y - r * 0.3f)
                    lineTo(c.x + r, c.y)
                    lineTo(c.x + r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x, c.y + r)
                    lineTo(c.x - r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x - r, c.y)
                    lineTo(c.x - r * 0.3f, c.y - r * 0.3f)
                    close()
                }
                drawPath(star, Color.White.copy(alpha = twinkle * wake))
            }
        }

        // little music notes float up while she listens
        if (notes && dance > 0.02f && (running || staticNotes)) {
            for (i in 0..2) {
                val ph = (t * 0.55f + i / 3f) % 1f
                val nx = 78f + i * 6f + sin((t + i) * 2f) * 3f
                val ny = 34f - ph * 30f
                val a = ((1f - ph) * dance).coerceIn(0f, 1f).let { if (running) it else maxOf(it, 0.7f) }
                val c = p(nx, ny)
                drawCircle(Color.White.copy(alpha = a), 2.1f * u, c)
                drawLine(Color.White.copy(alpha = a), Offset(c.x + 1.9f * u, c.y), Offset(c.x + 1.9f * u, c.y - 7f * u), 1.3f * u, StrokeCap.Round)
            }
        }
        // hearts when she is petted
        if (reacting) {
            for (i in 0..2) {
                val a = (1f - pk).coerceIn(0f, 1f)
                val c = p(36f + i * 14f, 34f - pk * 26f - (i % 2) * 5f)
                val r = 3.2f * u
                val heart = Path().apply {
                    moveTo(c.x, c.y + r)
                    cubicTo(c.x - 2f * r, c.y - 0.2f * r, c.x - 1.2f * r, c.y - 1.8f * r, c.x, c.y - 0.6f * r)
                    cubicTo(c.x + 1.2f * r, c.y - 1.8f * r, c.x + 2f * r, c.y - 0.2f * r, c.x, c.y + r)
                    close()
                }
                drawPath(heart, Color(0xFFFF6FA8).copy(alpha = a))
            }
        }
    }
}

/** Lumi as a picture, for the home screen widget. [mood]: 0 asleep, 1 drowsy (paused), 2 awake (playing). */
fun renderLumiBitmap(px: Int, look: MascotLook, mood: Int, notes: Boolean): android.graphics.Bitmap {
    val image = ImageBitmap(px, px)
    val canvas = GfxCanvas(image)
    CanvasDrawScope().draw(Density(1f), LayoutDirection.Ltr, canvas, androidx.compose.ui.geometry.Size(px.toFloat(), px.toFloat())) {
        drawLumi(
            look = look,
            t = 1.2f,
            running = false,
            wake = when (mood) { 0 -> 0f; 1 -> 0.45f; else -> 1f },
            dance = if (mood >= 2) 1f else 0f,
            pk = 0f,
            notes = notes,
            staticNotes = true,
        )
    }
    return image.asAndroidBitmap()
}

/**
 * Lumi, the cat made of northern lights. The colours slowly flow through her body, she blinks, her tail wags and she
 * bounces when [bounce] is on. When [asleep] her eyes close and she breathes slowly. With [animate] off she is a still
 * picture, which is what Lite mode and Battery saver use.
 */
@Composable
fun AuroraCat(
    modifier: Modifier = Modifier,
    asleep: Boolean = false,
    bounce: Boolean = true,
    animate: Boolean = true,
    drowsy: Boolean = false,
    look: MascotLook = LocalAppSettings.current.mascotLook(),
) {
    val settings = LocalAppSettings.current
    // Moods fade into each other: asleep, drowsy (paused) and awake (music playing).
    val awake by animateFloatAsState(
        targetValue = when {
            asleep -> 0f
            drowsy -> 0.45f
            else -> 1f
        },
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "mascotAwake",
    )
    val dance by animateFloatAsState(
        targetValue = if (bounce && !asleep && !drowsy) 1f else 0f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "mascotDance",
    )
    // Touching her sets off a short happy reaction.
    val poke = remember { Animatable(0f) }
    val pokeScope = rememberCoroutineScope()
    val haptic = rememberHaptic()
    val paused = LocalBackgroundPaused.current
    // A sleeping or dozing Lumi stays still (saves battery); she moves while she is awake.
    val idle = asleep || drowsy
    val running = animate && !settings.batterySaver && !paused && (!idle || settings.ambientWhenPaused)
    val frameMs = if (idle) 110L else settings.mascotFrameMs()
    val clock = remember { mutableFloatStateOf(0f) }
    val speed = settings.mascotSpeed.coerceIn(0.3f, 2.5f)
    LaunchedEffect(running, speed, frameMs) {
        if (!running) return@LaunchedEffect
        var start = 0L
        while (true) {
            withFrameNanos { now ->
                if (start == 0L) start = now
                clock.floatValue = (now - start) / 1_000_000_000f * speed
            }
            delay(frameMs)
        }
    }
    val touchModifier = if (settings.mascotTouch) {
        Modifier.pointerInput(Unit) {
            detectTapGestures(
                onTap = {
                    haptic()
                    pokeScope.launch {
                        poke.snapTo(0f)
                        poke.animateTo(1f, tween(1200, easing = LinearEasing))
                    }
                },
            )
        }
    } else Modifier

    Canvas(modifier.then(touchModifier)) {
        val pk = if (settings.mascotTouch) poke.value else 0f
        val pi = PI.toFloat()
        val reacting = pk > 0.001f && pk < 0.999f
        // Poking wakes her up for a moment, even when she is asleep.
        val wake = maxOf(awake, if (reacting) (sin(pk * pi) * 1.5f).coerceIn(0f, 1f) else 0f)
        drawLumi(
            look = look,
            t = clock.floatValue,
            running = running,
            wake = wake,
            dance = dance,
            pk = pk,
            notes = settings.mascotNotes,
        )
    }
}
