package com.aurora.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One colour of a traced icon: every outline (and hole) of that colour, as x0,y0,x1,y1,... on the tracing lattice. */
class IconLayer(val color: Int, val loops: List<IntArray>)

/** An icon made from a picture: a background colour plus a few flat colour layers made of straight-edged outlines. */
class VectorIcon(
    val id: String,
    val name: String,
    val size: Int,
    val background: Int,
    val layers: List<IconLayer>,
) {
    fun copy(name: String = this.name, background: Int = this.background, layers: List<IconLayer> = this.layers) =
        VectorIcon(id, name, size, background, layers)
}

fun VectorIcon.toJson(): JSONObject {
    val ls = JSONArray()
    for (l in layers) {
        val loops = JSONArray()
        for (loop in l.loops) {
            val a = JSONArray()
            for (v in loop) a.put(v)
            loops.put(a)
        }
        ls.put(JSONObject().put("c", l.color).put("p", loops))
    }
    return JSONObject().put("id", id).put("name", name).put("n", size).put("bg", background).put("l", ls)
}

fun vectorIconFromJson(o: JSONObject): VectorIcon? = runCatching {
    val layers = ArrayList<IconLayer>()
    val ls = o.getJSONArray("l")
    for (i in 0 until ls.length()) {
        val lo = ls.getJSONObject(i)
        val ps = lo.getJSONArray("p")
        val loops = ArrayList<IntArray>()
        for (j in 0 until ps.length()) {
            val a = ps.getJSONArray(j)
            loops.add(IntArray(a.length()) { a.getInt(it) })
        }
        layers.add(IconLayer(lo.getInt("c"), loops))
    }
    VectorIcon(o.getString("id"), o.optString("name", "My icon"), o.optInt("n", IconTracer.GRID), o.getInt("bg"), layers)
}.getOrNull()

// ------------------------------------------------------------------ drawing

/** The outlines of each layer as ready-to-draw paths (even-odd fill, so holes stay holes). */
fun VectorIcon.toPaths(): List<Pair<Int, Path>> = layers.map { layer ->
    val path = Path()
    path.fillType = Path.FillType.EVEN_ODD
    for (loop in layer.loops) {
        if (loop.size < 6) continue
        path.moveTo(loop[0].toFloat(), loop[1].toFloat())
        var i = 2
        while (i + 1 < loop.size) {
            path.lineTo(loop[i].toFloat(), loop[i + 1].toFloat())
            i += 2
        }
        path.close()
    }
    layer.color to path
}

/** Draws the background square (rounded by [cornerFrac] of its size) and the art, [art] of the way across, centred. */
fun drawIconPaths(
    canvas: Canvas,
    paths: List<Pair<Int, Path>>,
    background: Int,
    srcSize: Int,
    size: Float,
    art: Float,
    cornerFrac: Float,
) {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.style = Paint.Style.FILL
    paint.color = background
    if (cornerFrac <= 0f) {
        canvas.drawRect(0f, 0f, size, size, paint)
    } else {
        val r = size * cornerFrac
        canvas.drawRoundRect(0f, 0f, size, size, r, r, paint)
    }
    val artSize = size * art
    val off = (size - artSize) / 2f
    canvas.save()
    canvas.translate(off, off)
    val sc = artSize / srcSize
    canvas.scale(sc, sc)
    for ((color, path) in paths) {
        paint.color = color
        canvas.drawPath(path, paint)
    }
    canvas.restore()
}

/** A full-bleed square picture of the icon, the way Android wants an adaptive icon (art kept inside the safe zone). */
fun VectorIcon.toBitmap(px: Int = 432): Bitmap {
    val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    drawIconPaths(Canvas(bmp), toPaths(), background, size, px.toFloat(), 0.58f, 0f)
    return bmp
}

@Composable
fun VectorIconView(icon: VectorIcon, modifier: Modifier = Modifier, cornerFrac: Float = 0.22f) {
    val paths = remember(icon) { icon.toPaths() }
    ComposeCanvas(modifier) {
        drawIntoCanvas { c ->
            drawIconPaths(c.nativeCanvas, paths, icon.background, icon.size, this.size.minDimension, 0.62f, cornerFrac)
        }
    }
}

// ------------------------------------------------------------------ picture to vector

/**
 * Turns a picture into flat colour shapes, all on the device:
 *  1. shrink to a GRID x GRID square,
 *  2. pick a few colours (k-means) and give every pixel to its nearest colour,
 *  3. optionally clear the background (the colour touching the edges),
 *  4. walk the edge of every colour region, join the edges into closed outlines and
 *  5. straighten each outline (Douglas-Peucker) so only the real corners are left.
 */
object IconTracer {
    const val GRID = 96
    private const val EPS = 0.9

    /** Reads a picture (shrunk while loading). Null when the file is not a picture Android can read. */
    fun decode(context: Context, uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }.getOrNull()

    /** The middle square of the picture, shrunk to GRID x GRID pixels. */
    fun toGrid(src: Bitmap): IntArray {
        val side = min(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(square, GRID, GRID, true)
        val px = IntArray(GRID * GRID)
        small.getPixels(px, 0, GRID, 0, 0, GRID, GRID)
        return px
    }

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF

    private fun dist2(c: Int, ce: IntArray): Int {
        val dr = red(c) - ce[0]
        val dg = green(c) - ce[1]
        val db = blue(c) - ce[2]
        return dr * dr + dg * dg + db * db
    }

    private fun nearest(c: Int, cent: List<IntArray>): Int {
        var best = 0
        var bd = Int.MAX_VALUE
        for (j in cent.indices) {
            val d = dist2(c, cent[j])
            if (d < bd) {
                bd = d
                best = j
            }
        }
        return best
    }

    fun trace(px: IntArray, colors: Int, removeBackground: Boolean): List<IconLayer> {
        val n = GRID
        val total = n * n
        val k = colors.coerceIn(2, 8)
        val solid = BooleanArray(total) { (px[it] ushr 24) >= 128 }

        // colours: a spread-out start, then a few rounds of k-means on a sample of the opaque pixels
        val sample = ArrayList<Int>()
        val step = max(1, total / 3000)
        var s = 0
        while (s < total) {
            if (solid[s]) sample.add(s)
            s += step
        }
        if (sample.isEmpty()) return emptyList()
        val cent = ArrayList<IntArray>()
        val first = px[sample[0]]
        cent.add(intArrayOf(red(first), green(first), blue(first)))
        while (cent.size < k) {
            var best = -1
            var bestD = -1
            for (p in sample) {
                var d = Int.MAX_VALUE
                for (ce in cent) d = min(d, dist2(px[p], ce))
                if (d > bestD) {
                    bestD = d
                    best = p
                }
            }
            if (bestD <= 0) break
            val c = px[best]
            cent.add(intArrayOf(red(c), green(c), blue(c)))
        }
        val kk = cent.size
        repeat(8) {
            val sum = Array(kk) { LongArray(4) }
            for (p in sample) {
                val c = px[p]
                val j = nearest(c, cent)
                sum[j][0] += red(c).toLong()
                sum[j][1] += green(c).toLong()
                sum[j][2] += blue(c).toLong()
                sum[j][3]++
            }
            for (j in 0 until kk) {
                if (sum[j][3] > 0) {
                    cent[j][0] = (sum[j][0] / sum[j][3]).toInt()
                    cent[j][1] = (sum[j][1] / sum[j][3]).toInt()
                    cent[j][2] = (sum[j][2] / sum[j][3]).toInt()
                }
            }
        }

        val label = IntArray(total) { if (solid[it]) nearest(px[it], cent) else -1 }

        if (removeBackground) clearBackground(label, kk)

        // one round of majority smoothing takes the speckles out
        val clean = IntArray(total)
        val tally = IntArray(kk + 1)
        for (y in 0 until n) {
            for (x in 0 until n) {
                java.util.Arrays.fill(tally, 0)
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val xx = x + dx
                        val yy = y + dy
                        if (xx < 0 || yy < 0 || xx >= n || yy >= n) continue
                        tally[label[yy * n + xx] + 1]++
                    }
                }
                var bestC = label[y * n + x] + 1
                for (t in 0..kk) if (tally[t] > tally[bestC]) bestC = t
                clean[y * n + x] = bestC - 1
            }
        }

        val layers = ArrayList<IconLayer>()
        for (c in 0 until kk) {
            val loops = loopsFor(clean, c)
            if (loops.isEmpty()) continue
            val col = (0xFF shl 24) or (cent[c][0] shl 16) or (cent[c][1] shl 8) or cent[c][2]
            layers.add(IconLayer(col, loops))
        }
        return layers
    }

    /** Clears the colour that fills the edges of the picture (only the part joined to the edge). */
    private fun clearBackground(label: IntArray, kk: Int) {
        val n = GRID
        val counts = IntArray(kk)
        var edgePixels = 0
        fun count(x: Int, y: Int) {
            val l = label[y * n + x]
            if (l >= 0) counts[l]++
            edgePixels++
        }
        for (t in 0 until n) {
            count(t, 0)
            count(t, n - 1)
            count(0, t)
            count(n - 1, t)
        }
        var top = -1
        var topCount = 0
        for (j in 0 until kk) {
            if (counts[j] > topCount) {
                topCount = counts[j]
                top = j
            }
        }
        if (top < 0 || topCount * 100 < edgePixels * 35) return
        val queue = IntArray(n * n)
        val seen = BooleanArray(n * n)
        var head = 0
        var tail = 0
        fun push(p: Int) {
            if (!seen[p] && label[p] == top) {
                seen[p] = true
                queue[tail++] = p
            }
        }
        for (t in 0 until n) {
            push(t)
            push((n - 1) * n + t)
            push(t * n)
            push(t * n + n - 1)
        }
        while (head < tail) {
            val p = queue[head++]
            val x = p % n
            val y = p / n
            if (x > 0) push(p - 1)
            if (x < n - 1) push(p + 1)
            if (y > 0) push(p - n)
            if (y < n - 1) push(p + n)
        }
        for (p in 0 until n * n) if (seen[p]) label[p] = -1
    }

    /** Every closed outline around the pixels of colour [c]: the outer edges and the holes. */
    private fun loopsFor(label: IntArray, c: Int): List<IntArray> {
        val n = GRID
        val w = n + 1
        val out = HashMap<Int, ArrayList<Int>>()
        fun edge(x0: Int, y0: Int, x1: Int, y1: Int) {
            out.getOrPut(y0 * w + x0) { ArrayList(2) }.add(y1 * w + x1)
        }
        for (y in 0 until n) {
            for (x in 0 until n) {
                if (label[y * n + x] != c) continue
                if (y == 0 || label[(y - 1) * n + x] != c) edge(x, y, x + 1, y)
                if (x == n - 1 || label[y * n + x + 1] != c) edge(x + 1, y, x + 1, y + 1)
                if (y == n - 1 || label[(y + 1) * n + x] != c) edge(x + 1, y + 1, x, y + 1)
                if (x == 0 || label[y * n + x - 1] != c) edge(x, y + 1, x, y)
            }
        }
        val result = ArrayList<IntArray>()
        while (out.isNotEmpty()) {
            val start = out.keys.first()
            val keys = ArrayList<Int>()
            var cur = start
            do {
                keys.add(cur)
                val list = out[cur] ?: break
                val next = list.removeAt(list.size - 1)
                if (list.isEmpty()) out.remove(cur)
                cur = next
            } while (cur != start)
            val loop = shape(keys, w)
            if (loop != null) result.add(loop)
        }
        return result
    }

    /** Keeps only the corners that matter. Null for specks too small to see. */
    private fun shape(keys: List<Int>, w: Int): IntArray? {
        val m = keys.size
        if (m < 4) return null
        val xs = IntArray(m) { keys[it] % w }
        val ys = IntArray(m) { keys[it] / w }
        val cx = ArrayList<Int>()
        val cy = ArrayList<Int>()
        for (i in 0 until m) {
            val p = (i + m - 1) % m
            val q = (i + 1) % m
            val cross = (xs[i] - xs[p]) * (ys[q] - ys[i]) - (ys[i] - ys[p]) * (xs[q] - xs[i])
            if (cross != 0) {
                cx.add(xs[i])
                cy.add(ys[i])
            }
        }
        val n = cx.size
        if (n < 3) return null
        val px = IntArray(n) { cx[it] }
        val py = IntArray(n) { cy[it] }
        var far = 0
        var farD = -1L
        for (i in 1 until n) {
            val dx = (px[i] - px[0]).toLong()
            val dy = (py[i] - py[0]).toLong()
            val d = dx * dx + dy * dy
            if (d > farD) {
                farD = d
                far = i
            }
        }
        val keep = BooleanArray(n)
        keep[0] = true
        keep[far] = true
        simplify(px, py, 0, far, n, keep)
        simplify(px, py, far, n, n, keep)
        val outX = ArrayList<Int>()
        val outY = ArrayList<Int>()
        for (i in 0 until n) {
            if (keep[i]) {
                outX.add(px[i])
                outY.add(py[i])
            }
        }
        val cnt = outX.size
        if (cnt < 3) return null
        var area = 0L
        for (i in 0 until cnt) {
            val j = (i + 1) % cnt
            area += outX[i].toLong() * outY[j] - outX[j].toLong() * outY[i]
        }
        if (abs(area) / 2.0 < 2.0) return null
        val flat = IntArray(cnt * 2)
        for (i in 0 until cnt) {
            flat[i * 2] = outX[i]
            flat[i * 2 + 1] = outY[i]
        }
        return flat
    }

    /** Douglas-Peucker on a closed outline. Indices run a..b, and index n means point 0 again. */
    private fun simplify(px: IntArray, py: IntArray, a: Int, b: Int, n: Int, keep: BooleanArray) {
        if (b - a < 2) return
        val ax = px[a % n].toDouble()
        val ay = py[a % n].toDouble()
        val bx = px[b % n].toDouble()
        val by = py[b % n].toDouble()
        val dx = bx - ax
        val dy = by - ay
        val len = sqrt(dx * dx + dy * dy)
        var maxD = -1.0
        var at = -1
        for (i in a + 1 until b) {
            val x = px[i % n].toDouble()
            val y = py[i % n].toDouble()
            val d = if (len == 0.0) hypot(x - ax, y - ay) else abs(dx * (ay - y) - (ax - x) * dy) / len
            if (d > maxD) {
                maxD = d
                at = i
            }
        }
        if (at >= 0 && maxD > EPS) {
            keep[at % n] = true
            simplify(px, py, a, at, n, keep)
            simplify(px, py, at, b, n, keep)
        }
    }
}
