package com.aurora.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/** How one home screen widget looks. Every widget you add has its own copy. */
data class WidgetOpts(
    val layout: Int = 0, // 0 classic, 1 compact, 2 cover
    val bg: Int = 0, // 0 app theme, 1 accent, 2 dark, 3 light, 4 custom
    val hue: Float = 260f,
    val shade: Float = 0.35f,
    val opacity: Float = 0.92f,
    val radius: Int = 2, // index into WidgetRender.RADII
    val showArt: Boolean = true,
    val artShape: Int = 1, // 0 square, 1 rounded, 2 circle
    val showButtons: Boolean = true,
    val showArtist: Boolean = true,
    val plate: Boolean = true,
    val textSize: Int = 1, // 0 small, 1 medium, 2 large
)

object WidgetStore {
    private fun prefs(c: Context) = c.getSharedPreferences("aurora_widget_opts", Context.MODE_PRIVATE)

    fun load(c: Context, id: Int): WidgetOpts {
        val p = prefs(c)
        val d = WidgetOpts()
        fun k(n: String) = "${id}_$n"
        return WidgetOpts(
            layout = p.getInt(k("layout"), d.layout),
            bg = p.getInt(k("bg"), d.bg),
            hue = p.getFloat(k("hue"), d.hue),
            shade = p.getFloat(k("shade"), d.shade),
            opacity = p.getFloat(k("opacity"), d.opacity),
            radius = p.getInt(k("radius"), d.radius),
            showArt = p.getBoolean(k("showArt"), d.showArt),
            artShape = p.getInt(k("artShape"), d.artShape),
            showButtons = p.getBoolean(k("showButtons"), d.showButtons),
            showArtist = p.getBoolean(k("showArtist"), d.showArtist),
            plate = p.getBoolean(k("plate"), d.plate),
            textSize = p.getInt(k("textSize"), d.textSize),
        )
    }

    fun save(c: Context, id: Int, o: WidgetOpts) {
        fun k(n: String) = "${id}_$n"
        prefs(c).edit()
            .putInt(k("layout"), o.layout)
            .putInt(k("bg"), o.bg)
            .putFloat(k("hue"), o.hue)
            .putFloat(k("shade"), o.shade)
            .putFloat(k("opacity"), o.opacity)
            .putInt(k("radius"), o.radius)
            .putBoolean(k("showArt"), o.showArt)
            .putInt(k("artShape"), o.artShape)
            .putBoolean(k("showButtons"), o.showButtons)
            .putBoolean(k("showArtist"), o.showArtist)
            .putBoolean(k("plate"), o.plate)
            .putInt(k("textSize"), o.textSize)
            .apply()
    }

    fun delete(c: Context, id: Int) {
        val p = prefs(c)
        val e = p.edit()
        p.all.keys.filter { it.startsWith("${id}_") }.forEach { e.remove(it) }
        e.apply()
    }
}

/** What the widgets show: the current song and the app's colours. Written by the player service and the app. */
object WidgetState {
    class Song(val title: String, val artist: String, val artUri: String, val playing: Boolean, val has: Boolean)
    class Theme(val primary: Int, val surface: Int, val onSurface: Int)

    private fun prefs(c: Context) = c.getSharedPreferences("aurora_widget_state", Context.MODE_PRIVATE)

    fun saveSong(c: Context, title: String, artist: String, artUri: String, playing: Boolean, has: Boolean) {
        prefs(c).edit()
            .putString("title", title)
            .putString("artist", artist)
            .putString("art", artUri)
            .putBoolean("playing", playing)
            .putBoolean("has", has)
            .apply()
    }

    fun song(c: Context): Song {
        val p = prefs(c)
        return Song(
            p.getString("title", "") ?: "",
            p.getString("artist", "") ?: "",
            p.getString("art", "") ?: "",
            p.getBoolean("playing", false),
            p.getBoolean("has", false),
        )
    }

    fun saveTheme(c: Context, primary: Int, surface: Int, onSurface: Int) {
        val p = prefs(c)
        if (p.getInt("t_primary", 0) == primary && p.getInt("t_surface", 0) == surface && p.getInt("t_on", 0) == onSurface) return
        p.edit().putInt("t_primary", primary).putInt("t_surface", surface).putInt("t_on", onSurface).apply()
        AuroraWidget.refreshAll(c)
    }

    fun theme(c: Context): Theme {
        val p = prefs(c)
        return Theme(
            p.getInt("t_primary", 0xFF6750A4.toInt()),
            p.getInt("t_surface", 0xFF2B2930.toInt()),
            p.getInt("t_on", 0xFFE6E0E9.toInt()),
        )
    }
}

object WidgetRender {
    val RADII = intArrayOf(0, 14, 26, 40)
    private val DARK = 0xFF14141B.toInt()
    private val LIGHT = 0xFFF4F1F8.toInt()

    private var cachedUri: String? = null
    private var cachedBmp: Bitmap? = null

    fun backgroundColor(o: WidgetOpts, t: WidgetState.Theme): Int = when (o.bg) {
        0 -> t.surface
        1 -> t.primary
        2 -> DARK
        3 -> LIGHT
        else -> Color.HSVToColor(floatArrayOf(o.hue.coerceIn(0f, 359f), 0.5f, o.shade.coerceIn(0.15f, 0.95f)))
    }

    fun readableOn(bg: Int): Int = if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1B1B1F.toInt() else 0xFFF2F0F7.toInt()

    private fun loadArt(c: Context, uri: String, target: Int): Bitmap? {
        if (uri.isEmpty()) return null
        if (uri == cachedUri) cachedBmp?.let { return it }
        val bmp = runCatching {
            val u = Uri.parse(uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }.getOrNull()
        if (bmp != null) {
            cachedUri = uri
            cachedBmp = bmp
        }
        return bmp
    }

    /** Centre-crops [src] into a [w] x [h] bitmap with rounded corners. */
    private fun cropRounded(src: Bitmap, w: Int, h: Int, radius: Float, scrim: Boolean): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val scale = max(w / src.width.toFloat(), h / src.height.toFloat())
        val m = Matrix()
        m.setScale(scale, scale)
        m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        shader.setLocalMatrix(m)
        paint.shader = shader
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        canvas.drawRoundRect(rect, radius, radius, paint)
        if (scrim) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.shader = LinearGradient(
                0f, h * 0.35f, 0f, h.toFloat(),
                Color.argb(0, 0, 0, 0), Color.argb(200, 0, 0, 0), Shader.TileMode.CLAMP,
            )
            canvas.drawRoundRect(rect, radius, radius, sp)
        }
        return out
    }

    private fun servicePi(c: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            c,
            code,
            Intent(c, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun openPi(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(c, 10, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun build(c: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val o = WidgetStore.load(c, id)
        val song = WidgetState.song(c)
        val theme = WidgetState.theme(c)
        val d = c.resources.displayMetrics.density
        val layoutRes = when (o.layout) {
            1 -> R.layout.widget_compact
            2 -> R.layout.widget_cover
            else -> R.layout.widget_classic
        }
        val v = RemoteViews(c.packageName, layoutRes)
        val cover = o.layout == 2
        val bg = backgroundColor(o, theme)
        val radiusIndex = o.radius.coerceIn(0, RADII.size - 1)
        val radiusDp = RADII[radiusIndex]

        v.setImageViewResource(
            R.id.w_bg,
            when (radiusIndex) {
                0 -> R.drawable.widget_bg_0
                1 -> R.drawable.widget_bg_14
                2 -> R.drawable.widget_bg_26
                else -> R.drawable.widget_bg_40
            },
        )
        v.setInt(R.id.w_bg, "setColorFilter", bg)
        v.setInt(R.id.w_bg, "setImageAlpha", (o.opacity.coerceIn(0.1f, 1f) * 255).toInt())

        // Art
        val artSizeDp = if (o.layout == 1) 44 else 64
        var textColor = readableOn(bg)
        if (cover) {
            val sizeInfo = mgr.getAppWidgetOptions(id)
            val wDp = sizeInfo.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
            val hDp = sizeInfo.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 150)
            val scale = min(1f, 600f / max(wDp * d, hDp * d))
            val wPx = (wDp * d * scale).toInt().coerceAtLeast(64)
            val hPx = (hDp * d * scale).toInt().coerceAtLeast(64)
            val art = if (song.has) loadArt(c, song.artUri, max(wPx, hPx)) else null
            if (art != null) {
                v.setImageViewBitmap(R.id.w_art, cropRounded(art, wPx, hPx, radiusDp * d * scale, true))
                v.setViewVisibility(R.id.w_art, View.VISIBLE)
                textColor = Color.WHITE
            } else {
                v.setViewVisibility(R.id.w_art, View.GONE)
            }
        } else if (o.showArt) {
            val px = (artSizeDp * d).toInt()
            val art = if (song.has) loadArt(c, song.artUri, px) else null
            if (art != null) {
                val r = when (o.artShape) {
                    0 -> 0f
                    1 -> px * 0.18f
                    else -> px / 2f
                }
                v.setImageViewBitmap(R.id.w_art, cropRounded(art, px, px, r, false))
            } else {
                v.setImageViewResource(R.id.w_art, R.drawable.ic_w_note)
                v.setInt(R.id.w_art, "setColorFilter", textColor)
            }
            v.setViewVisibility(R.id.w_art, View.VISIBLE)
        } else {
            v.setViewVisibility(R.id.w_art, View.GONE)
        }

        // Text
        val titleSp = floatArrayOf(13f, 15f, 17f)[o.textSize.coerceIn(0, 2)] - if (o.layout == 1) 1f else 0f
        v.setTextViewText(R.id.w_title, if (song.has) song.title else "Aurora")
        v.setTextViewText(R.id.w_artist, if (song.has) song.artist else "Tap to open")
        v.setTextColor(R.id.w_title, textColor)
        v.setTextColor(R.id.w_artist, (textColor and 0x00FFFFFF) or 0xB3000000.toInt())
        v.setTextViewTextSize(R.id.w_title, TypedValue.COMPLEX_UNIT_SP, titleSp)
        v.setTextViewTextSize(R.id.w_artist, TypedValue.COMPLEX_UNIT_SP, titleSp - 3f)
        v.setViewVisibility(R.id.w_artist, if (o.showArtist) View.VISIBLE else View.GONE)

        // Buttons
        v.setViewVisibility(R.id.w_prev, if (o.showButtons) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_next, if (o.showButtons) View.VISIBLE else View.GONE)
        v.setImageViewResource(R.id.w_play, if (song.playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        v.setInt(R.id.w_prev, "setColorFilter", textColor)
        v.setInt(R.id.w_next, "setColorFilter", textColor)
        if (o.plate) {
            val plate = if (ColorUtils.calculateContrast(theme.primary, bg) < 1.6 && !(cover && textColor == Color.WHITE)) textColor else theme.primary
            v.setViewVisibility(R.id.w_plate, View.VISIBLE)
            v.setInt(R.id.w_plate, "setColorFilter", plate)
            v.setInt(R.id.w_play, "setColorFilter", readableOn(plate))
        } else {
            v.setViewVisibility(R.id.w_plate, View.GONE)
            v.setInt(R.id.w_play, "setColorFilter", textColor)
        }

        v.setOnClickPendingIntent(R.id.w_play, servicePi(c, AuroraWidget.ACTION_TOGGLE, 1))
        v.setOnClickPendingIntent(R.id.w_prev, servicePi(c, AuroraWidget.ACTION_PREV, 2))
        v.setOnClickPendingIntent(R.id.w_next, servicePi(c, AuroraWidget.ACTION_NEXT, 3))
        v.setOnClickPendingIntent(R.id.w_root, openPi(c))
        return v
    }
}

class AuroraWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        exec.execute {
            try {
                renderAll(context, appWidgetManager, appWidgetIds)
            } finally {
                pending.finish()
            }
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle,
    ) {
        refresh(context, appWidgetManager, intArrayOf(appWidgetId))
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { WidgetStore.delete(context, it) }
    }

    companion object {
        const val ACTION_TOGGLE = "com.aurora.player.widget.TOGGLE"
        const val ACTION_NEXT = "com.aurora.player.widget.NEXT"
        const val ACTION_PREV = "com.aurora.player.widget.PREV"
        private val exec = Executors.newSingleThreadExecutor()

        private fun renderAll(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                runCatching { mgr.updateAppWidget(id, WidgetRender.build(c, mgr, id)) }
            }
        }

        fun refresh(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val app = c.applicationContext
            exec.execute { renderAll(app, mgr, ids) }
        }

        /** Redraws every widget on the home screen. Cheap when there are none. */
        fun refreshAll(c: Context) {
            val app = c.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, AuroraWidget::class.java))
            if (ids.isNotEmpty()) refresh(app, mgr, ids)
        }
    }
}
