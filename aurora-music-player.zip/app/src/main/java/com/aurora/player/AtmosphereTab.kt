package com.aurora.player

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** One tap sets the colours, the effects and the cover frame together. */
private enum class Mood(val label: String) {
    CLEAN("Clean"), CINEMA("Cinema"), NEON("Neon night"), COZY("Cozy evening"), DREAMY("Dreamy"), CUSTOM("Custom"),
}

private fun Mood.applyTo(s: AppSettings): AppSettings = when (this) {
    Mood.CLEAN -> s.copy(
        livingColors = false, grain = 0f, vignette = 0f, edgeLight = 0f, warmth = 0f, coverFrame = CoverFrame.NONE,
    )
    Mood.CINEMA -> s.copy(
        livingColors = false, grain = 0.35f, vignette = 0.55f, edgeLight = 0f,
        warmth = 0.25f, warmAuto = false, coverFrame = CoverFrame.GALLERY,
    )
    Mood.NEON -> s.copy(
        livingColors = true, livingStrength = 0.6f, grain = 0f, vignette = 0.35f,
        edgeLight = 0.8f, edgeCover = true, warmth = 0f, coverFrame = CoverFrame.NEON,
    )
    Mood.COZY -> s.copy(
        livingColors = false, grain = 0.2f, vignette = 0.25f, edgeLight = 0f,
        warmth = 0.5f, warmAuto = true, coverFrame = CoverFrame.POLAROID,
    )
    Mood.DREAMY -> s.copy(
        livingColors = true, livingStrength = 0.9f, grain = 0.1f, vignette = 0f,
        edgeLight = 0.45f, edgeCover = true, warmth = 0f, coverFrame = CoverFrame.LIFTED,
    )
    Mood.CUSTOM -> s
}

/** The mood that matches the current settings, or Custom when you have mixed your own. */
private fun detectMood(s: AppSettings): Mood =
    Mood.entries.firstOrNull { it != Mood.CUSTOM && it.applyTo(s) == s } ?: Mood.CUSTOM

private fun amount(v: Float): String = if (v <= 0f) "Off" else "${(v * 100).roundToInt()}%"

private fun step(v: Float): Float = (v * 20).roundToInt() / 20f

/**
 * Settings > Atmosphere: design effects for the whole app. The effects are drawn over everything, this page included,
 * so you see every change live right where you are.
 */
@Composable
internal fun AtmosphereTab(s: AppSettings, song: Song?, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme

    SettingCard("Moods") {
        Text(
            "One tap sets the colours, the effects and the cover frame together. Everything below stays yours to change.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        ChipPicker(Mood.entries.map { it.label to it }, detectMood(s)) { m ->
            if (m != Mood.CUSTOM) onUpdate { m.applyTo(it) }
        }
    }

    SettingCard("Living colours") {
        ToggleRow(
            "Follow the cover",
            "The colours of the whole app glide to the colours of the album cover that is playing",
            s.livingColors,
            true,
        ) { v -> onUpdate { it.copy(livingColors = v) } }
        if (s.livingColors) {
            SliderRow("Colour strength", s.livingStrength, 0.2f..1f, "${(s.livingStrength * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(livingStrength = step(v)) }
            }
        }
        Text(
            "It works on top of your theme and mixes the cover colours in. Without a cover the app keeps your theme.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Film grain") {
        Text(
            "A fine speckle over the whole screen, like film. It never moves, so it costs almost no battery.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        SliderRow("Grain amount", s.grain, 0f..1f, amount(s.grain)) { v -> onUpdate { it.copy(grain = step(v)) } }
    }

    SettingCard("Vignette") {
        Text(
            "The corners of the screen fade to dark, which pulls the eye to the middle.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        SliderRow("Vignette amount", s.vignette, 0f..1f, amount(s.vignette)) { v -> onUpdate { it.copy(vignette = step(v)) } }
    }

    SettingCard("Edge light") {
        Text(
            "A soft coloured light along the edges of the screen. It breathes slowly while music plays and stands still in battery saver.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        SliderRow("Edge light amount", s.edgeLight, 0f..1f, amount(s.edgeLight)) { v -> onUpdate { it.copy(edgeLight = step(v)) } }
        ToggleRow(
            "Colour from the cover",
            "Use the colour of the album cover instead of the theme colours",
            s.edgeCover,
            s.edgeLight > 0f,
        ) { v -> onUpdate { it.copy(edgeCover = v) } }
    }

    SettingCard("Evening warmth") {
        Text(
            "A warm amber tint, like a night light, that is easier on the eyes in the dark.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        SliderRow("Warmth amount", s.warmth, 0f..1f, amount(s.warmth)) { v -> onUpdate { it.copy(warmth = step(v)) } }
        ToggleRow(
            "Only in the evening",
            "Fades in from 19:00, stays until 06:00 and is gone by 07:00. Off means all day.",
            s.warmAuto,
            s.warmth > 0f,
        ) { v -> onUpdate { it.copy(warmAuto = v) } }
        if (s.warmth > 0f && s.warmAuto) {
            val now = minuteOfDayNow()
            val clock = "%02d:%02d".format(now / 60, now % 60)
            Text(
                if (eveningFactor(now) > 0f) {
                    "It is $clock, so the warmth is on right now."
                } else {
                    "It is $clock, so the warmth is off right now. Turn off Only in the evening to see it."
                },
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
    }

    SettingCard("Cover frames") {
        val frame = effectiveFrame(s.coverFrame, s.artShape)
        Box(Modifier.fillMaxWidth().padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
            CoverFrameBox(
                frame = frame,
                shape = npArtShape(s.artShape, s.corner),
                accent = cs.primary,
                caption = song?.title ?: "Northern lights",
                modifier = Modifier.size(170.dp),
            ) { inner -> MiniArt(song?.artUri, Modifier.fillMaxSize(), inner) }
        }
        ChipPicker(CoverFrame.entries.map { it.label to it }, s.coverFrame) { v -> onUpdate { it.copy(coverFrame = v) } }
        Text(s.coverFrame.blurb, style = MaterialTheme.typography.bodyMedium)
        if (s.coverFrame.needsRect && frame == CoverFrame.NONE) {
            Text(
                "Your cover shape is ${s.artShape.label}. Polaroid, Stamp, Film and Gallery need Rounded or Squircle, so no frame is drawn. Neon and Lifted work with every shape.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Text(
            "The frame is drawn around the big cover on the Now Playing screen.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }
}
