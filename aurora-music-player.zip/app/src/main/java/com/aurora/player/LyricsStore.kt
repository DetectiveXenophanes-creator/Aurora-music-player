package com.aurora.player

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream

data class LrcLine(val timeMs: Long, val text: String)

/** [synced] lyrics carry a time for every line; plain lyrics are just shown as text. */
data class Lyrics(val lines: List<LrcLine>, val synced: Boolean)

/**
 * Finds lyrics for a song, in this order: a file the user added in Aurora, an .lrc file next to the song
 * (only where Android lets apps read it), and lyrics saved inside an MP3 (ID3 "USLT").
 */
object LyricsStore {
    private val stamp = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val inlineTag = Regex("""<\d{1,3}:\d{2}(?:[.:]\d{1,3})?>""")

    private fun file(c: Context, id: Long) = File(File(c.filesDir, "lyrics").also { it.mkdirs() }, "$id.lrc")

    fun hasImported(c: Context, id: Long) = file(c, id).exists()

    fun remove(c: Context, id: Long) { file(c, id).delete() }

    suspend fun import(c: Context, id: Long, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val text = c.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: return@runCatching false
            if (text.isBlank() || text.length > 500_000) return@runCatching false
            file(c, id).writeText(text)
            true
        }.getOrDefault(false)
    }

    suspend fun load(c: Context, song: Song): Lyrics? = withContext(Dispatchers.IO) {
        runCatching {
            val own = file(c, song.id)
            val text = if (own.exists()) own.readText() else (sidecar(c, song) ?: embedded(c, song))
            text?.let { parse(it) }
        }.getOrNull()
    }

    @Suppress("DEPRECATION")
    private fun sidecar(c: Context, song: Song): String? {
        val path = c.contentResolver.query(song.uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        val f = File(path.substringBeforeLast('.') + ".lrc")
        return if (f.canRead()) f.readText() else null
    }

    private fun readFully(i: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = i.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun syncsafe(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0x7F) shl 21) or ((b[p + 1].toInt() and 0x7F) shl 14) or ((b[p + 2].toInt() and 0x7F) shl 7) or (b[p + 3].toInt() and 0x7F)

    private fun embedded(c: Context, song: Song): String? {
        c.contentResolver.openInputStream(song.uri)?.use { input ->
            val head = ByteArray(10)
            if (readFully(input, head) < 10 || head[0] != 'I'.code.toByte() || head[1] != 'D'.code.toByte() || head[2] != '3'.code.toByte()) return null
            val version = head[3].toInt()
            if (version < 3) return null
            val size = syncsafe(head, 6)
            if (size <= 0 || size > 4_000_000) return null
            val tag = ByteArray(size)
            val got = readFully(input, tag)
            var p = 0
            while (p + 10 <= got) {
                if (tag[p].toInt() == 0) break
                val id = String(tag, p, 4, Charsets.ISO_8859_1)
                val fsize = if (version >= 4) syncsafe(tag, p + 4) else
                    ((tag[p + 4].toInt() and 0xFF) shl 24) or ((tag[p + 5].toInt() and 0xFF) shl 16) or
                        ((tag[p + 6].toInt() and 0xFF) shl 8) or (tag[p + 7].toInt() and 0xFF)
                val start = p + 10
                if (fsize <= 0 || start + fsize > got) break
                if (id == "USLT" && fsize > 5) return decodeUslt(tag, start, fsize)
                p = start + fsize
            }
        }
        return null
    }

    private fun decodeUslt(b: ByteArray, start: Int, len: Int): String? {
        val enc = b[start].toInt()
        val end = start + len
        val wide = enc == 1 || enc == 2
        var i = start + 4 // encoding byte + 3 language bytes
        while (i < end) { // skip the short description that comes before the text
            if (!wide && b[i].toInt() == 0) { i += 1; break }
            if (wide && i + 1 < end && b[i].toInt() == 0 && b[i + 1].toInt() == 0) { i += 2; break }
            i += if (wide) 2 else 1
        }
        if (i >= end) return null
        val cs = when (enc) { 1 -> Charsets.UTF_16; 2 -> Charsets.UTF_16BE; 3 -> Charsets.UTF_8; else -> Charsets.ISO_8859_1 }
        return String(b, i, end - i, cs).trim('\u0000').ifBlank { null }
    }

    /** Reads .lrc text ("[01:23.45] words"). Text without times becomes plain lyrics. */
    fun parse(raw: String): Lyrics? {
        val timed = ArrayList<LrcLine>()
        val plain = ArrayList<String>()
        for (line in raw.replace("\r", "").split('\n')) {
            val matches = stamp.findAll(line).toList()
            if (matches.isEmpty()) {
                val t = line.trim()
                if (!t.startsWith("[")) plain.add(t)
                continue
            }
            val text = inlineTag.replace(stamp.replace(line, ""), "").trim()
            for (m in matches) {
                val frac = m.groupValues[3]
                val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.take(3).toLong() }
                timed.add(LrcLine(m.groupValues[1].toLong() * 60_000 + m.groupValues[2].toLong() * 1000 + ms, text))
            }
        }
        if (timed.isNotEmpty()) return Lyrics(timed.sortedBy { it.timeMs }, true)
        val lines = plain.dropWhile { it.isEmpty() }
        return if (lines.isEmpty()) null else Lyrics(lines.map { LrcLine(-1L, it) }, false)
    }
}
