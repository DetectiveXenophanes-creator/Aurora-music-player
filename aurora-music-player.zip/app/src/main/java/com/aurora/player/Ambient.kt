package com.aurora.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

/**
 * How hard the decorative animations (glow breathing, drifting glow, spinning cover, Lumi) are allowed to work.
 * Efficient keeps everything still unless you touch it, Balanced runs them at a gentle frame rate, Smooth is the
 * old behaviour.
 */
enum class PowerProfile(val label: String) { EFFICIENT("Efficient"), BALANCED("Balanced"), SMOOTH("Smooth") }

/** True while music is playing. Decorative animations rest when it is false, unless "keep animating while paused" is on. */
val LocalIsPlaying = compositionLocalOf { false }

fun AppSettings.ambientFps(): Int = when (powerProfile) {
    PowerProfile.EFFICIENT -> 8
    PowerProfile.BALANCED -> 10
    PowerProfile.SMOOTH -> 30
}

/** Milliseconds between frames for the spinning cover and the seek bar waves. */
fun AppSettings.spinFrameMs(): Long = when (powerProfile) {
    PowerProfile.EFFICIENT -> 66L
    PowerProfile.BALANCED -> 50L
    PowerProfile.SMOOTH -> 16L
}

/** Milliseconds between frames for Lumi while she is awake. */
fun AppSettings.mascotFrameMs(): Long = when (powerProfile) {
    PowerProfile.EFFICIENT -> 66L
    PowerProfile.BALANCED -> 50L
    PowerProfile.SMOOTH -> 24L
}

/** Whether decorative animations should be moving right now. */
fun AppSettings.ambientMoving(playing: Boolean, paused: Boolean): Boolean =
    !batterySaver && !paused && powerProfile != PowerProfile.EFFICIENT && (playing || ambientWhenPaused)

/** The settings the app really runs with: Android's own battery saver switches ours on, Efficient slows the backgrounds. */
fun AppSettings.withPower(systemSaver: Boolean): AppSettings {
    var s = this
    if (autoSaver && systemSaver) s = s.copy(batterySaver = true)
    if (powerProfile == PowerProfile.EFFICIENT) s = s.copy(bgFps = minOf(s.bgFps, 10))
    return s
}

/**
 * A clock in seconds that ticks [fps] times a second instead of at every screen refresh, and does not tick at all
 * while [running] is false. Everything that reads it only redraws that often, which lets the screen and the GPU rest.
 */
@Composable
fun rememberThrottledClock(running: Boolean, fps: Int): State<Float> {
    val t = remember { mutableFloatStateOf(0f) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    // While a list is being scrolled every frame is needed for the scroll itself, so the decorative clocks wait.
    // They carry on from the same moment when the list settles.
    val scrolling = LocalScrolling.current.value
    LaunchedEffect(running, fps, lifecycle, scrolling) {
        if (!running || scrolling) return@LaunchedEffect
        // Stops completely while the app is off screen (screen locked, other app in front): nobody sees the animation,
        // and a timer that keeps ticking would wake the processor several times a second for nothing.
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            val frame = 1000L / fps.coerceAtLeast(1)
            val origin = System.nanoTime() - (t.floatValue * 1_000_000_000f).toLong()
            while (true) {
                t.floatValue = (System.nanoTime() - origin) / 1_000_000_000f
                delay(frame)
            }
        }
    }
    return t
}

/** Whether Android's battery saver is on. */
@Composable
fun rememberPowerSaveMode(): Boolean {
    val ctx = LocalContext.current
    val pm = remember { ctx.getSystemService(Context.POWER_SERVICE) as PowerManager }
    var on by remember { mutableStateOf(pm.isPowerSaveMode) }
    DisposableEffect(ctx) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                on = pm.isPowerSaveMode
            }
        }
        ctx.registerReceiver(receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED))
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return on
}
