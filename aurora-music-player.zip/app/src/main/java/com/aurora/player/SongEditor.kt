package com.aurora.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Custom covers live in the app's own folder, so no storage permission is needed and the music files stay untouched. */
object CoverStore {
    private const val MAX_SIDE = 1200

    fun dir(context: Context): File = File(context.filesDir, "covers").also { it.mkdirs() }

    /** Shrinks the picked image, saves it and returns its file name. Older covers of the same song are removed. */
    suspend fun save(context: Context, songId: Long, source: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= MAX_SIDE && bounds.outHeight / (sample * 2) >= MAX_SIDE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@runCatching null

            val rotation = resolver.openInputStream(source)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
            val longest = max(bmp.width, bmp.height)
            if (rotation != 0f || longest > MAX_SIDE) {
                val m = Matrix()
                if (rotation != 0f) m.postRotate(rotation)
                if (longest > MAX_SIDE) {
                    val k = MAX_SIDE.toFloat() / longest
                    m.postScale(k, k)
                }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            deleteFor(context, songId)
            val name = "${songId}_${System.currentTimeMillis()}.jpg"
            FileOutputStream(File(dir(context), name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            name
        }.getOrNull()
    }

    fun deleteFor(context: Context, songId: Long) {
        dir(context).listFiles()?.forEach { f -> if (f.name.startsWith("${songId}_")) f.delete() }
    }
}

/**
 * Bottom sheet to change a song's title, artist, album and cover. The changes are kept inside Aurora
 * (the audio file is not rewritten), so they work for every song and need no extra permission.
 */
@Composable
fun SongEditSheet(
    song: Song,
    onSave: (title: String, artist: String, album: String, newArt: Uri?, resetArt: Boolean) -> Unit,
    onRestoreAll: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val corner = LocalAppSettings.current.corner
    var title by remember(song.id) { mutableStateOf(song.title) }
    var artist by remember(song.id) { mutableStateOf(song.artist) }
    var album by remember(song.id) { mutableStateOf(song.album) }
    var pendingArt by remember(song.id) { mutableStateOf<Uri?>(null) }
    var resetArt by remember(song.id) { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            pendingArt = uri
            resetArt = false
        }
    }
    val picked: Uri? = pendingArt
    val preview: Uri = if (resetArt) song.albumArtUri else (picked ?: song.artUri)
    val hasCustomCover = picked != null || (song.customArt != null && !resetArt)
    val changedInfo = song.title != song.origTitle || song.artist != song.origArtist ||
        song.album != song.origAlbum || song.customArt != null

    AuroraSheet(onDismiss = onDismiss, title = "Edit song") {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding()
                .padding(start = 24.dp, end = 24.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Art(preview, Modifier.size(104.dp), RoundedCornerShape((corner * 0.7f).coerceAtLeast(12f).dp))
                Column(Modifier.padding(start = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text("Change cover") }
                    TextButton(
                        enabled = hasCustomCover,
                        onClick = {
                            pendingArt = null
                            resetArt = song.customArt != null
                        },
                    ) { Text("Use original cover") }
                }
            }
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(200) },
                singleLine = true,
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = artist,
                onValueChange = { artist = it.take(200) },
                singleLine = true,
                label = { Text("Artist") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = album,
                onValueChange = { album = it.take(200) },
                singleLine = true,
                label = { Text("Album") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Changes are saved inside Aurora. Your audio files are not modified.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(enabled = changedInfo || pendingArt != null, onClick = onRestoreAll) { Text("Restore original") }
                Spacer(Modifier.weight(1f))
                Button(
                    enabled = title.isNotBlank(),
                    onClick = { onSave(title, artist, album, pendingArt, resetArt) },
                ) { Text("Save") }
            }
        }
    }
}
