package com.aurora.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

@Composable
fun AuroraApp(vm: PlayerViewModel) {
    val settings by vm.settings.collectAsState()
    AuroraTheme(settings) {
        CompositionLocalProvider(LocalAppSettings provides settings) {
            Root(vm)
        }
    }
}

@Composable
private fun Root(vm: PlayerViewModel) {
    val context = LocalContext.current
    val settings = LocalAppSettings.current
    val songs by vm.songs.collectAsState()
    val ui by vm.ui.collectAsState()
    val haze = remember { HazeState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showNow by rememberSaveable { mutableStateOf(false) }

    val audioPerm = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val perms = remember {
        buildList {
            add(audioPerm)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs() else launcher.launch(perms)
    }

    BackHandler(enabled = showNow) { showNow = false }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val hasMini = ui.current != null
    val contentPadding = PaddingValues(
        top = topInset + 76.dp,
        bottom = bottomInset + 96.dp + (if (hasMini) 82.dp else 0.dp),
    )
    val barShape = RoundedCornerShape((settings.corner * 1.2f).dp)

    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize()) {
            // Everything that bars and panels blur lives inside the haze source.
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground()
                if (tab == 0) {
                    SongsScreen(
                        songs = songs,
                        currentId = ui.current?.id,
                        granted = granted,
                        onRequest = { launcher.launch(perms) },
                        padding = contentPadding,
                        onPlay = { s, q -> vm.play(s, q) },
                        onShuffleAll = { vm.shuffleAll(it) },
                    )
                } else {
                    SettingsScreen(
                        s = settings,
                        padding = contentPadding,
                        onUpdate = { vm.updateSettings(it) },
                    )
                }
            }

            // Top bar
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp)
                    .fillMaxWidth()
                    .height(56.dp)
                    .finish(barShape),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    if (tab == 0) "Library" else "Customize",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }

            // Mini player + navigation
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(start = 16.dp, end = 16.dp, bottom = bottomInset + 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ui.current?.let { song ->
                    MiniPlayer(song, ui.isPlaying, ui.duration, vm, barShape) { showNow = true }
                }
                Box(Modifier.fillMaxWidth().finish(barShape)) {
                    NavigationBar(containerColor = Color.Transparent, windowInsets = WindowInsets(0)) {
                        NavigationBarItem(
                            selected = tab == 0,
                            onClick = { tab = 0 },
                            icon = { Icon(Icons.Rounded.LibraryMusic, null) },
                            label = { Text("Library") },
                        )
                        NavigationBarItem(
                            selected = tab == 1,
                            onClick = { tab = 1 },
                            icon = { Icon(Icons.Rounded.Palette, null) },
                            label = { Text("Customize") },
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showNow,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
            ) {
                NowPlayingScreen(vm) { showNow = false }
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    onOpen: () -> Unit,
) {
    val pos by vm.position.collectAsState()
    val corner = LocalAppSettings.current.corner
    Column(Modifier.fillMaxWidth().finish(shape).clickable(onClick = onOpen)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(song.artUri, Modifier.size(52.dp), RoundedCornerShape((corner * 0.5f).dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(song.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = { vm.togglePlay() }) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play or pause")
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
        }
        LinearProgressIndicator(
            progress = { if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = MaterialTheme.colorScheme.primary,
            trackColor = Color.Transparent,
        )
    }
}
