package com.aurora.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

class MusicPermission(val granted: Boolean, val request: () -> Unit)

@Composable
fun rememberMusicPermission(): MusicPermission {
    val context = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val perms = remember {
        buildList {
            add(audioPerm)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = ContextCompat.checkSelfPermission(context, audioPerm) == PackageManager.PERMISSION_GRANTED
    }
    return MusicPermission(granted) { launcher.launch(perms) }
}

@Composable
fun AuroraApp(vm: PlayerViewModel) {
    val settings by vm.settings.collectAsState()
    val loaded by vm.settingsLoaded.collectAsState()
    val motion = remember(settings.animSet, settings.animSpeed, settings.animIntensity) {
        Motion(settings.animSet, settings.animSpeed, settings.animIntensity)
    }
    val perm = rememberMusicPermission()
    var introDone by rememberSaveable { mutableStateOf(false) }

    AuroraTheme(settings) {
        CompositionLocalProvider(
            LocalAppSettings provides settings,
            LocalMotion provides motion,
        ) {
            when {
                !loaded -> AuroraBackground(null)
                !introDone && settings.showIntro -> IntroScreen { introDone = true }
                !settings.setupDone -> SetupScreen(
                    s = settings,
                    granted = perm.granted,
                    onRequest = perm.request,
                    onUpdate = { vm.updateSettings(it) },
                )
                else -> Root(vm, perm)
            }
        }
    }
}

private data class Page(val tab: AppTab, val detail: DetailRef?)

@Composable
private fun Root(vm: PlayerViewModel, perm: MusicPermission) {
    val settings = LocalAppSettings.current
    val motion = LocalMotion.current
    val songs by vm.songs.collectAsState()
    val allSongs by vm.allSongs.collectAsState()
    val ui by vm.ui.collectAsState()
    val lib by vm.library.collectAsState()
    val detail by vm.detail.collectAsState()
    val haze = remember { HazeState() }
    var tab by rememberSaveable { mutableIntStateOf(settings.startTab.ordinal) }
    var showNow by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var createSong by remember { mutableStateOf<Song?>(null) }

    LaunchedEffect(perm.granted) {
        if (perm.granted) vm.loadSongs() else perm.request()
    }

    BackHandler(enabled = detail != null) { vm.closeDetail() }
    BackHandler(enabled = showNow) { showNow = false }

    val songActions = remember(lib.favorites, lib.playlists) {
        SongActions(
            favorites = lib.favorites,
            playlists = lib.playlists,
            toggleFavorite = { vm.toggleFavorite(it.id) },
            playNext = { vm.playNext(it) },
            addToQueue = { vm.addToQueue(it) },
            addToPlaylist = { pl, song -> vm.addToPlaylist(pl.id, song.id) },
            newPlaylistWith = { createSong = it; showCreate = true },
        )
    }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val miniExtra by animateDpAsState(
        targetValue = if (ui.current != null) 82.dp else 0.dp,
        animationSpec = motion.spatial(),
        label = "miniExtra",
    )
    val contentPadding = PaddingValues(
        top = topInset + 82.dp,
        bottom = bottomInset + 84.dp + miniExtra.coerceAtLeast(0.dp),
    )
    val barShape = RoundedCornerShape((settings.corner * 1.2f).dp)
    val currentTab = AppTab.entries[tab.coerceIn(0, AppTab.entries.size - 1)]
    val page = Page(currentTab, detail)

    CompositionLocalProvider(
        LocalHazeState provides haze,
        LocalSongActions provides songActions,
    ) {
        Box(Modifier.fillMaxSize()) {
            // Everything that bars and panels blur lives inside the haze source.
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(ui.current)
                AnimatedContent(
                    targetState = page,
                    transitionSpec = {
                        val forward = when {
                            initialState.detail == null && targetState.detail != null -> true
                            initialState.detail != null && targetState.detail == null -> false
                            else -> targetState.tab.ordinal > initialState.tab.ordinal
                        }
                        motion.tab(forward)
                    },
                    label = "pages",
                    modifier = Modifier.fillMaxSize(),
                ) { pg ->
                    val d = pg.detail
                    if (d != null) {
                        val list = remember(d, songs, lib) { songsFor(d, songs, lib) }
                        DetailScreen(
                            subtitle = when (d.kind) {
                                DetailKind.ALBUM -> list.firstOrNull()?.artist ?: ""
                                DetailKind.ARTIST -> "Artist"
                                DetailKind.FOLDER -> d.key
                                DetailKind.PLAYLIST -> "Playlist"
                                DetailKind.SMART -> "Made for you"
                            },
                            songs = list,
                            padding = contentPadding,
                            currentId = ui.current?.id,
                            playing = ui.isPlaying,
                            onPlay = { s, q -> vm.play(s, q) },
                            onPlayAll = { vm.playAll(it) },
                            onShuffle = { vm.shuffleAll(it) },
                            onRemove = if (d.kind == DetailKind.PLAYLIST) {
                                { song -> vm.removeFromPlaylist(d.key, song.id) }
                            } else null,
                        )
                    } else {
                        when (pg.tab) {
                            AppTab.HOME -> HomeScreen(
                                songs = songs,
                                lib = lib,
                                currentId = ui.current?.id,
                                playing = ui.isPlaying,
                                granted = perm.granted,
                                onRequest = perm.request,
                                padding = contentPadding,
                                onPlay = { s, q -> vm.play(s, q) },
                                onPlayAll = { vm.playAll(it) },
                                onOpen = { vm.openDetail(it) },
                            )
                            AppTab.SONGS -> SongsScreen(
                                songs = songs,
                                currentId = ui.current?.id,
                                playing = ui.isPlaying,
                                granted = perm.granted,
                                onRequest = perm.request,
                                padding = contentPadding,
                                onPlay = { s, q -> vm.play(s, q) },
                                onShuffleAll = { vm.shuffleAll(it) },
                            )
                            AppTab.PLAYLISTS -> PlaylistsScreen(
                                songs = songs,
                                lib = lib,
                                padding = contentPadding,
                                onOpen = { vm.openDetail(it) },
                                onCreate = { createSong = null; showCreate = true },
                                onEdit = { editingId = it },
                                onDelete = { vm.deletePlaylist(it) },
                            )
                            AppTab.ALBUMS -> {
                                val groups = remember(songs) { albumsOf(songs) }
                                AlbumsScreen(groups, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.ALBUM, g.key, g.title))
                                }
                            }
                            AppTab.FOLDERS -> {
                                val groups = remember(songs) { foldersOf(songs) }
                                GroupListScreen(groups, true, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.FOLDER, g.key, g.title))
                                }
                            }
                            AppTab.ARTISTS -> {
                                val groups = remember(songs) { artistsOf(songs) }
                                GroupListScreen(groups, false, contentPadding) { g ->
                                    vm.openDetail(DetailRef(DetailKind.ARTIST, g.key, g.title))
                                }
                            }
                        }
                    }
                }
            }

            // Top bar
            AuroraTopBar(
                title = detail?.title ?: currentTab.label,
                onBack = if (detail != null) {
                    { vm.closeDetail() }
                } else null,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp),
            ) {
                val d = detail
                if (d != null && d.kind == DetailKind.PLAYLIST) {
                    RoundIconButton(Icons.Rounded.Edit, "Customize", { editingId = d.key })
                } else if (d == null) {
                    RoundIconButton(Icons.Rounded.Settings, "Settings", { showSettings = true })
                }
            }

            // Mini player + navigation
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, bottom = bottomInset + 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AnimatedVisibility(
                    visible = ui.current != null,
                    enter = motion.miniEnter(),
                    exit = motion.miniExit(),
                ) {
                    ui.current?.let { song ->
                        MiniPlayer(song, ui.isPlaying, ui.duration, vm, barShape) { showNow = true }
                    }
                }
                BottomNav(
                    tab = currentTab,
                    onSelect = {
                        tab = it.ordinal
                        vm.closeDetail()
                    },
                )
            }

            AnimatedVisibility(
                visible = showNow,
                enter = slideInVertically(motion.spatial()) { it },
                exit = slideOutVertically(motion.effects()) { it },
            ) {
                NowPlayingScreen(vm) { showNow = false }
            }

            val editing = lib.playlists.firstOrNull { it.id == editingId }
            AnimatedVisibility(
                visible = editing != null,
                enter = fadeIn(motion.effects()) + slideInVertically(motion.spatial()) { (it * 0.08f).toInt() },
                exit = fadeOut(motion.effects()) + slideOutVertically(motion.effects()) { (it * 0.08f).toInt() },
            ) {
                if (editing != null) {
                    val byId = allSongs.associateBy { it.id }
                    PlaylistEditor(
                        pl = editing,
                        songs = editing.songIds.mapNotNull { byId[it] },
                        current = ui.current,
                        onUpdate = { t -> vm.updatePlaylist(editing.id, t) },
                        onDelete = {
                            vm.deletePlaylist(editing.id)
                            if (detail?.key == editing.id) vm.closeDetail()
                            editingId = null
                        },
                        onBack = { editingId = null },
                    )
                }
            }

            AnimatedVisibility(
                visible = showSettings,
                enter = fadeIn(motion.effects()) + slideInVertically(motion.spatial()) { (it * 0.08f).toInt() },
                exit = fadeOut(motion.effects()) + slideOutVertically(motion.effects()) { (it * 0.08f).toInt() },
            ) {
                SettingsPage(
                    s = settings,
                    allSongs = allSongs,
                    song = ui.current,
                    onUpdate = { vm.updateSettings(it) },
                    onRescan = { vm.loadSongs() },
                    onRunSetup = {
                        showSettings = false
                        vm.updateSettings { it.copy(setupDone = false) }
                    },
                    onBack = { showSettings = false },
                )
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "New playlist",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { name ->
                val id = vm.createPlaylist(name, createSong?.id)
                showCreate = false
                createSong = null
                tab = AppTab.PLAYLISTS.ordinal
                editingId = id
            },
            onDismiss = { showCreate = false; createSong = null },
        )
    }
}

@Composable
private fun MiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    onOpen: () -> Unit,
) {
    val pos by vm.position.collectAsState()
    val corner = LocalAppSettings.current.corner
    Column(Modifier.fillMaxWidth().finish(shape).clickable(onClick = onOpen)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(song.artUri, Modifier.size(48.dp), RoundedCornerShape((corner * 0.5f).dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(song.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            PlayPauseButton(
                playing = playing,
                onClick = { vm.togglePlay() },
                modifier = Modifier.size(46.dp),
                iconSize = 20.dp,
                tonal = true,
            )
            Spacer(Modifier.width(8.dp))
            SkipButton(
                forward = true,
                onClick = { vm.next() },
                modifier = Modifier.size(46.dp),
                iconSize = 24.dp,
            )
        }
        LinearProgressIndicator(
            progress = { if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = MaterialTheme.colorScheme.primary,
            trackColor = Color.Transparent,
        )
    }
}
