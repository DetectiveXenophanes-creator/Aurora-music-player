package com.aurora.player

import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * The mini player designs. CLASSIC is the bar that is joined to the dock (the old behaviour). Every other design floats
 * on its own: just above the dock, or in the dock's own row beside the corner button when the dock is Radial.
 */
enum class FloatMini(val label: String, val blurb: String) {
    CLASSIC("Classic", "The mini player you know, joined to the dock."),
    PILL("Pill", "A slim floating capsule: the cover, the song and a play button inside a progress ring."),
    CARD("Card", "A roomier card with a bigger cover, a progress bar and previous, play and next buttons."),
    DISC("Disc", "A round bubble. The cover spins like a record while music plays and a ring fills with the song."),
    COVER("Cover", "The album cover fills the whole card, with the song, controls and a thin progress line on top."),
    CASSETTE("Cassette", "A little tape. Both reels turn while it plays, and the tape winds from the left reel to the right as the song goes."),
    TICKET("Ticket", "A concert ticket with punched notches and a dashed tear line. The barcode fills in as the song plays."),
    WAVE("Wave", "Every song gets its own waveform, drawn from its name. Tap or drag along it to jump to any spot."),
    DIAL("Dial", "A retro radio dial. The needle sweeps across the scale as the song plays. Drag it to tune to any moment."),
    NEON("Neon", "A neon sign on a dark panel. The glass tube lights up around the edge as the song plays, with the odd flicker."),
}

/** Which side a floating mini player leans to when it is narrower than the room it has (and the Disc, which is small). */
enum class FloatAlign(val label: String) { START("Left"), CENTER("Middle"), END("Right") }

/** Everything a design needs, so the same designs run on the real player and on the preview in Settings. */
class FloatMiniState(
    val title: String,
    val artist: String,
    /** The cover, or null for a plain placeholder (the preview when nothing is playing). */
    val art: Uri?,
    val playing: Boolean,
    /** A colour taken from the cover (already made easy to see), or null to use the theme colour. */
    val accent: Color?,
    /** 0 to 1. Only called while drawing, so the position ticking does not redraw the whole player. */
    val progress: () -> Float,
    val onOpen: () -> Unit,
    val onToggle: () -> Unit,
    val onPrev: () -> Unit,
    val onNext: () -> Unit,
    /** Jump to a spot in the song, 0 to 1 (the Wave and the Dial can be scrubbed). */
    val onSeek: (Float) -> Unit,
)

internal fun miniScale(size: MiniSize): Float = when (size) {
    MiniSize.SLIM -> 0.88f
    MiniSize.NORMAL -> 1f
    MiniSize.LARGE -> 1.12f
}

/** The Size setting, but never so big that a design outgrows the 72 dp row of the Radial dock. */
internal fun effectiveScale(s: AppSettings, dockRow: Boolean): Float {
    val k = miniScale(s.miniSize)
    return if (dockRow) minOf(k, 0.92f) else k
}

/** How tall the design is above the dock, used to keep the lists from hiding behind it. */
fun floatMiniHeight(s: AppSettings): Dp {
    val k = miniScale(s.miniSize)
    return when (s.floatMini) {
        FloatMini.CLASSIC -> 82.dp
        FloatMini.PILL -> 66.dp * k
        FloatMini.CARD -> 102.dp * k
        FloatMini.DISC -> 76.dp * k
        FloatMini.COVER -> 112.dp * k
        FloatMini.CASSETTE -> 74.dp * k
        FloatMini.TICKET -> 74.dp * k
        FloatMini.WAVE -> 64.dp * k
        FloatMini.DIAL -> 68.dp * k
        FloatMini.NEON -> 64.dp * k
    }
}

/** The outline of each design. The player opens and closes by growing out of this shape. */
fun floatMiniShape(s: AppSettings, dockRow: Boolean = false): Shape = when (s.floatMini) {
    FloatMini.DISC -> CircleShape
    FloatMini.PILL, FloatMini.NEON -> RoundedCornerShape(50)
    FloatMini.CARD, FloatMini.CLASSIC, FloatMini.WAVE -> RoundedCornerShape((s.corner * 1.2f).dp)
    FloatMini.COVER -> RoundedCornerShape((s.corner * 1.4f).dp)
    FloatMini.CASSETTE -> RoundedCornerShape((s.corner * 0.9f).dp)
    FloatMini.DIAL -> RoundedCornerShape((s.corner * 1.0f).dp)
    FloatMini.TICKET -> TicketShape(
        corner = (s.corner * 0.9f).dp,
        notch = 7.dp,
        stubX = TICKET_PAD + 50.dp * effectiveScale(s, dockRow) + TICKET_PAD,
    )
}

/** Where a floating mini player sits above the dock. */
fun floatAlignment(align: FloatAlign): Alignment = when (align) {
    FloatAlign.START -> Alignment.BottomStart
    FloatAlign.CENTER -> Alignment.BottomCenter
    FloatAlign.END -> Alignment.BottomEnd
}

/** Where a floating mini player sits inside the Radial dock's row. */
fun floatRowAlignment(align: FloatAlign): Alignment = when (align) {
    FloatAlign.START -> Alignment.CenterStart
    FloatAlign.CENTER -> Alignment.Center
    FloatAlign.END -> Alignment.CenterEnd
}

/**
 * Makes a colour from a cover easy to see on the theme: washed out covers (greys) give null so the theme colour is used,
 * the rest is pushed to a lively, bright (dark theme) or deep (light theme) version of the same hue.
 */
internal fun readableAccent(seed: Color, dark: Boolean): Color? {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    if (hsv[1] < 0.12f) return null
    hsv[1] = maxOf(hsv[1], 0.5f)
    hsv[2] = if (dark) maxOf(hsv[2], 0.82f) else minOf(hsv[2], 0.62f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** The state of the real player, for the real screen. The position is only read while drawing. */
@Composable
fun rememberLiveMiniState(
    vm: PlayerViewModel,
    song: Song,
    playing: Boolean,
    duration: Long,
    onOpen: () -> Unit,
): FloatMiniState {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val position = vm.position.collectAsState()
    val seed = if (s.floatTint) rememberCoverSeed(song) else null
    val dark = cs.background.luminance() < 0.5f
    val accent = remember(seed, dark) { seed?.let { readableAccent(it, dark) } }
    return FloatMiniState(
        title = song.title,
        artist = song.artist,
        art = song.artUri,
        playing = playing,
        accent = accent,
        progress = { if (duration > 0) (position.value.toFloat() / duration).coerceIn(0f, 1f) else 0f },
        onOpen = onOpen,
        onToggle = { vm.togglePlay() },
        onPrev = { vm.previous() },
        onNext = { vm.next() },
        onSeek = { f -> if (duration > 0) vm.seekTo((f.coerceIn(0f, 1f) * duration).toLong()) },
    )
}

/**
 * Draws one of the floating designs. [modifier] comes first (the host puts the shared-element morph on it) and
 * [widthFraction] is how much of the free width the bar may use (the Disc ignores it). [dockRow] is true in the Radial
 * dock's 72 dp row: the tall designs then use a short version. [narrow] is true while the radial fan is open and there is
 * little room: every design then shrinks to the cover and a play button.
 */
@Composable
fun FloatingMini(
    design: FloatMini,
    st: FloatMiniState,
    shape: Shape,
    modifier: Modifier = Modifier,
    widthFraction: Float = 1f,
    dockRow: Boolean = false,
    narrow: Boolean = false,
) {
    val s = LocalAppSettings.current
    val k = effectiveScale(s, dockRow)
    if (narrow) {
        PillMini(st, k, RoundedCornerShape(50), modifier.fillMaxWidth(), narrow = true)
        return
    }
    val wide = modifier.widthIn(max = 640.dp).fillMaxWidth(widthFraction.coerceIn(0.5f, 1f))
    when (design) {
        FloatMini.DISC -> DiscMini(st, k, modifier)
        FloatMini.CARD -> CardMini(st, k, shape, wide, dockRow)
        FloatMini.COVER -> CoverMini(st, k, shape, wide, dockRow)
        FloatMini.CASSETTE -> CassetteMini(st, k, shape, wide)
        FloatMini.TICKET -> TicketMini(st, k, shape, wide)
        FloatMini.WAVE -> WaveMini(st, k, shape, wide)
        FloatMini.DIAL -> DialMini(st, k, shape, wide)
        FloatMini.NEON -> NeonMini(st, k, shape, wide)
        FloatMini.PILL, FloatMini.CLASSIC -> PillMini(st, k, shape, wide, narrow = false)
    }
}

// ---------------------------------------------------------------- the first four designs

/** Pill: the familiar bar, but floating and fully round. Also the short version every design turns into while [narrow]. */
@Composable
private fun PillMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier, narrow: Boolean) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val button = if (narrow) minOf(44.dp * k, 40.dp) else 44.dp * k
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) MiniArt(st.art, Modifier.size(if (narrow) minOf(42.dp * k, 38.dp) else 42.dp * k), CircleShape)
        if (narrow) {
            Spacer(Modifier.weight(1f))
        } else {
            Spacer(Modifier.width(10.dp))
            SongLines(st, Modifier.weight(1f), Color.Unspecified, cs.onSurfaceVariant, false)
        }
        Box(Modifier.size(button + 8.dp), contentAlignment = Alignment.Center) {
            if (s.miniProgress) RingProgress(st.progress, st.playing, st.accent ?: cs.primary, Modifier.fillMaxSize())
            PlayPauseButton(
                playing = st.playing,
                onClick = st.onToggle,
                modifier = Modifier.size(button - 4.dp),
                iconSize = 20.dp,
                tonal = true,
                showGlow = false,
            )
        }
        if (s.miniSkip && !narrow) {
            Spacer(Modifier.width(2.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(button - 4.dp), iconSize = 24.dp)
        }
    }
}

/** Card: bigger cover, a progress bar and previous / play / next in a row under the song. Short version in the dock row. */
@Composable
private fun CardMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier, dockRow: Boolean) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val accent = st.accent ?: cs.primary
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(if (dockRow) 8.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            MiniArt(st.art, Modifier.size((if (dockRow) 50.dp else 64.dp) * k), RoundedCornerShape((s.corner * 0.6f).dp))
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            SongLines(st, Modifier, Color.Unspecified, cs.onSurfaceVariant, false)
            Spacer(Modifier.height(if (dockRow) 4.dp else 6.dp))
            if (dockRow) {
                if (s.miniProgress) BarProgress(st.progress, accent, Modifier.fillMaxWidth().height(4.dp))
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.miniProgress) {
                        BarProgress(st.progress, accent, Modifier.weight(1f).height(4.dp))
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    Spacer(Modifier.width(8.dp))
                    if (s.miniSkip) {
                        SkipButton(forward = false, onClick = st.onPrev, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
                        Spacer(Modifier.width(4.dp))
                    }
                    PlayPauseButton(
                        playing = st.playing,
                        onClick = st.onToggle,
                        modifier = Modifier.size(42.dp * k),
                        iconSize = 22.dp,
                        tonal = true,
                        showGlow = false,
                    )
                    if (s.miniSkip) {
                        Spacer(Modifier.width(4.dp))
                        SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
                    }
                }
            }
        }
        if (dockRow) {
            Spacer(Modifier.width(8.dp))
            PlayPauseButton(
                playing = st.playing,
                onClick = st.onToggle,
                modifier = Modifier.size(44.dp * k),
                iconSize = 22.dp,
                tonal = true,
                showGlow = false,
            )
        }
    }
}

/** Disc: a round bubble. The cover turns like a record, the ring around it is the progress, a small button plays and pauses. */
@Composable
private fun DiscMini(st: FloatMiniState, k: Float, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val accent = st.accent ?: cs.primary
    val disc = 68.dp * k
    var angle by remember { mutableFloatStateOf(0f) }
    // 20 steps a second is plenty for a slow turn and is gentle on the battery
    LaunchedEffect(st.playing, motion.enabled) {
        if (st.playing && motion.enabled) {
            while (true) {
                delay(50)
                angle = (angle + 1.2f) % 360f
            }
        }
    }
    Box(Modifier.size(disc + 8.dp)) {
        Box(
            modifier
                .size(disc)
                .gestures(st)
                .glow(CircleShape, s.glowMini, if (st.playing) 1f else 0.45f)
                .finish(CircleShape)
                .clickable(onClick = st.onOpen),
            contentAlignment = Alignment.Center,
        ) {
            if (s.miniArt) {
                MiniArt(
                    st.art,
                    Modifier.fillMaxSize().padding(6.dp).graphicsLayer { rotationZ = angle },
                    CircleShape,
                )
                // the little hole in the middle of a record
                Box(Modifier.size(10.dp).clip(CircleShape).background(cs.surface))
            } else {
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSurfaceVariant)
            }
            if (s.miniProgress) {
                val track = accent.copy(alpha = 0.18f)
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 3.dp.toPx()
                    val inset = stroke / 2f
                    val arc = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(stroke))
                    val p = st.progress().coerceIn(0f, 1f)
                    if (p > 0.002f) {
                        drawArc(accent, -90f, 360f * p, false, Offset(inset, inset), arc, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .size(28.dp * k)
                .clip(CircleShape)
                .background(accent)
                .clickable(onClick = st.onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (st.playing) "Pause" else "Play",
                tint = if (accent.luminance() > 0.5f) Color.Black.copy(alpha = 0.85f) else Color.White,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** Cover: the album art is the whole card, with a dark fade at the bottom for the text and white controls. */
@Composable
private fun CoverMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier, dockRow: Boolean) {
    val s = LocalAppSettings.current
    val showSkip = s.miniSkip && !dockRow
    Box(
        modifier
            .height(if (dockRow) 66.dp else 112.dp * k)
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .clip(shape)
            .clickable(onClick = st.onOpen),
    ) {
        MiniArt(st.art, Modifier.matchParentSize(), RectangleShape)
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.82f)))),
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 14.dp, end = 10.dp, bottom = if (dockRow) 7.dp else 10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SongLines(st, Modifier.weight(1f), Color.White, Color.White.copy(alpha = 0.72f), !dockRow)
                if (showSkip) {
                    RoundButton(Icons.Rounded.SkipPrevious, "Previous", st.onPrev, 34.dp * k, Color.White.copy(alpha = 0.16f), Color.White)
                    Spacer(Modifier.width(6.dp))
                }
                RoundButton(
                    if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (st.playing) "Pause" else "Play",
                    st.onToggle,
                    (if (dockRow) 36.dp else 42.dp * k),
                    Color.White,
                    Color.Black.copy(alpha = 0.85f),
                )
                if (showSkip) {
                    Spacer(Modifier.width(6.dp))
                    RoundButton(Icons.Rounded.SkipNext, "Next", st.onNext, 34.dp * k, Color.White.copy(alpha = 0.16f), Color.White)
                }
            }
            if (s.miniProgress) {
                Spacer(Modifier.height(if (dockRow) 5.dp else 8.dp))
                BarProgress(st.progress, st.accent ?: Color.White, Modifier.fillMaxWidth().height(3.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- shared pieces (also used by FloatingMiniStyles.kt)

@Composable
internal fun SongLines(st: FloatMiniState, modifier: Modifier, title: Color, artist: Color, big: Boolean) {
    val marquee = LocalAppSettings.current.marqueeTitles
    Column(modifier) {
        Text(
            verbatim(st.title),
            modifier = Modifier.titleMarquee(marquee),
            color = title,
            style = if (big) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
        )
        Text(
            verbatim(st.artist),
            color = artist,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** The cover, or a soft coloured square with a note when there is no song (the preview in Settings). */
@Composable
internal fun MiniArt(uri: Uri?, modifier: Modifier, shape: Shape) {
    if (uri != null) {
        Art(uri, modifier, shape)
    } else {
        val cs = MaterialTheme.colorScheme
        Box(
            modifier
                .clip(shape)
                .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.tertiaryContainer))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onPrimaryContainer)
        }
    }
}

@Composable
internal fun RoundButton(icon: ImageVector, description: String, onClick: () -> Unit, size: Dp, bg: Color, tint: Color) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** A thin rounded progress bar. [progress] is only called while drawing. */
@Composable
internal fun BarProgress(progress: () -> Float, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val round = CornerRadius(size.height / 2f, size.height / 2f)
        drawRoundRect(color.copy(alpha = 0.22f), size = size, cornerRadius = round)
        val p = progress().coerceIn(0f, 1f)
        if (p > 0.002f) {
            drawRoundRect(color, size = Size(maxOf(size.height, size.width * p), size.height), cornerRadius = round)
        }
    }
}

/** The outline of the play button (it follows the play button shape setting) that fills with the song, from the top, clockwise. */
@Composable
private fun RingProgress(progress: () -> Float, playing: Boolean, color: Color, modifier: Modifier) {
    val corners = rememberPlayCorners(playing)
    val measure = remember { PathMeasure() }
    val seg = remember { Path() }
    val track = color.copy(alpha = 0.16f)
    Canvas(modifier) {
        if (size.minDimension < 6.dp.toPx()) return@Canvas
        val stroke = 2.5.dp.toPx()
        val path = shapeOutlinePath(size.width, size.height, stroke / 2f, corners)
        drawPath(path, track, style = Stroke(width = stroke, cap = StrokeCap.Round))
        val p = progress().coerceIn(0f, 1f)
        if (p > 0.002f) {
            measure.setPath(path, false)
            seg.reset()
            measure.getSegment(0f, measure.length * p, seg, true)
            drawPath(seg, color, style = Stroke(width = stroke, cap = StrokeCap.Round))
        }
    }
}

/** The gestures of every design, from the player's own settings: swipe sideways to skip, swipe up to open. */
@Composable
internal fun Modifier.gestures(st: FloatMiniState): Modifier {
    val s = LocalAppSettings.current
    return miniGestures(s.miniSwipe, s.floatSwipeUp, st.title, st.onPrev, st.onNext, st.onOpen)
}

/**
 * Swipe sideways to skip (right goes back, left goes forward) and swipe up to open the full player. The player follows the
 * finger and springs back. It also gives a small bounce when a new song starts.
 */
@Composable
internal fun Modifier.miniGestures(
    skip: Boolean,
    up: Boolean,
    key: Any,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit,
): Modifier {
    val motion = LocalMotion.current
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val follow = spring<Float>(dampingRatio = 0.7f, stiffness = 500f)
    val shownX by animateFloatAsState(targetValue = dragX, animationSpec = follow, label = "floatMiniDragX")
    val shownY by animateFloatAsState(targetValue = dragY, animationSpec = follow, label = "floatMiniDragY")
    val bump = remember { Animatable(1f) }
    val seen = remember { mutableStateOf<Any?>(null) }
    LaunchedEffect(key) {
        if (seen.value != null && seen.value != key && motion.enabled) {
            bump.snapTo(0.93f)
            bump.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 380f))
        }
        seen.value = key
    }
    val prev by rememberUpdatedState(onPrev)
    val next by rememberUpdatedState(onNext)
    val open by rememberUpdatedState(onOpen)
    val gesture = if (skip || up) {
        Modifier.pointerInput(key, skip, up) {
            detectDragGestures(
                onDragStart = {
                    dragX = 0f
                    dragY = 0f
                },
                onDragEnd = {
                    if (abs(dragX) > abs(dragY) * 1.2f) {
                        if (dragX > 140f) prev() else if (dragX < -140f) next()
                    } else if (up && dragY < -80f) {
                        open()
                    }
                    dragX = 0f
                    dragY = 0f
                },
                onDragCancel = {
                    dragX = 0f
                    dragY = 0f
                },
                onDrag = { change, amount ->
                    change.consume()
                    if (skip) dragX = (dragX + amount.x).coerceIn(-320f, 320f)
                    if (up) dragY = (dragY + amount.y).coerceIn(-160f, 0f)
                },
            )
        }
    } else {
        Modifier
    }
    return this
        .graphicsLayer {
            translationX = shownX * 0.5f
            translationY = shownY * 0.6f
            scaleX = bump.value
            scaleY = bump.value
            alpha = 1f - (abs(shownX) / 900f).coerceAtMost(0.3f)
        }
        .then(gesture)
}
