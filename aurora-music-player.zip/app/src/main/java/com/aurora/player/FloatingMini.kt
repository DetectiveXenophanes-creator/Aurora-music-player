package com.aurora.player

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * The mini player designs. CLASSIC is the bar that sits joined to the dock (the old behaviour). Every other design
 * floats on its own: it is not part of the dock, so it can sit anywhere above it or under the header.
 */
enum class FloatMini(val label: String, val blurb: String) {
    CLASSIC("Classic", "The mini player you know, joined to the dock."),
    PILL("Pill", "A slim floating capsule: the cover, the song and a play button inside a progress ring."),
    CARD("Card", "A roomier card with a bigger cover, a progress bar and previous, play and next buttons."),
    DISC("Disc", "A round bubble. The cover spins like a record while music plays and a ring fills with the song."),
    ISLAND("Island", "A small dark capsule with live bars that dance while it plays. The song fills it up like a battery."),
    COVER("Cover", "The album cover fills the whole card, with the song, controls and a thin progress line on top."),
}

/** Where a floating mini player sits. */
enum class FloatPos(val label: String) { ABOVE("Above the dock"), TOP("Under the header") }

/** Which side of the screen a floating mini player leans to (matters when it is narrower than the screen, and for the Disc). */
enum class FloatAlign(val label: String) { START("Left"), CENTER("Middle"), END("Right") }

/** Everything a design needs, so the same designs run on the real player and on the preview in Settings. */
class FloatMiniState(
    val title: String,
    val artist: String,
    /** The cover, or null for a plain placeholder (the preview when nothing is playing). */
    val art: Uri?,
    val playing: Boolean,
    /** 0 to 1. Only called while drawing, so the position ticking does not redraw the whole player. */
    val progress: () -> Float,
    val onOpen: () -> Unit,
    val onToggle: () -> Unit,
    val onPrev: () -> Unit,
    val onNext: () -> Unit,
)

private fun miniScale(size: MiniSize): Float = when (size) {
    MiniSize.SLIM -> 0.88f
    MiniSize.NORMAL -> 1f
    MiniSize.LARGE -> 1.12f
}

/** How tall the design is, used to keep the lists from hiding behind it. */
fun floatMiniHeight(s: AppSettings): Dp {
    val k = miniScale(s.miniSize)
    return when (s.floatMini) {
        FloatMini.CLASSIC -> 82.dp
        FloatMini.PILL -> 66.dp * k
        FloatMini.CARD -> 102.dp * k
        FloatMini.DISC -> 76.dp * k
        FloatMini.ISLAND -> 52.dp * k
        FloatMini.COVER -> 112.dp * k
    }
}

/** The outline of each design. The player opens and closes by growing out of this shape. */
fun floatMiniShape(design: FloatMini, corner: Float): Shape = when (design) {
    FloatMini.DISC -> CircleShape
    FloatMini.PILL, FloatMini.ISLAND -> RoundedCornerShape(50)
    FloatMini.CARD, FloatMini.CLASSIC -> RoundedCornerShape((corner * 1.2f).dp)
    FloatMini.COVER -> RoundedCornerShape((corner * 1.4f).dp)
}

fun floatAlignment(pos: FloatPos, align: FloatAlign): Alignment = when (pos) {
    FloatPos.ABOVE -> when (align) {
        FloatAlign.START -> Alignment.BottomStart
        FloatAlign.CENTER -> Alignment.BottomCenter
        FloatAlign.END -> Alignment.BottomEnd
    }
    FloatPos.TOP -> when (align) {
        FloatAlign.START -> Alignment.TopStart
        FloatAlign.CENTER -> Alignment.TopCenter
        FloatAlign.END -> Alignment.TopEnd
    }
}

/**
 * Draws one of the floating designs. [modifier] comes first (the host puts the shared-element morph on it) and
 * [widthFraction] is how much of the free width the bar may use (the Disc ignores it).
 */
@Composable
fun FloatingMini(
    design: FloatMini,
    st: FloatMiniState,
    shape: Shape,
    modifier: Modifier = Modifier,
    widthFraction: Float = 1f,
) {
    val s = LocalAppSettings.current
    val k = miniScale(s.miniSize)
    val frac = widthFraction.coerceIn(0.5f, 1f)
    when (design) {
        FloatMini.DISC -> DiscMini(st, k, modifier)
        FloatMini.ISLAND -> IslandMini(st, k, shape, modifier.widthIn(max = 300.dp).fillMaxWidth(frac))
        FloatMini.CARD -> CardMini(st, k, shape, modifier.widthIn(max = 640.dp).fillMaxWidth(frac))
        FloatMini.COVER -> CoverMini(st, k, shape, modifier.widthIn(max = 640.dp).fillMaxWidth(frac))
        FloatMini.PILL, FloatMini.CLASSIC -> PillMini(st, k, shape, modifier.widthIn(max = 640.dp).fillMaxWidth(frac))
    }
}

// ---------------------------------------------------------------- the five designs

/** Pill: the familiar bar, but floating and fully round. */
@Composable
private fun PillMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val button = 44.dp * k
    Row(
        modifier
            .swipeToSkip(s.miniSwipe, st.title, st.onPrev, st.onNext)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) MiniArt(st.art, Modifier.size(42.dp * k), CircleShape)
        Spacer(Modifier.width(10.dp))
        SongLines(st, Modifier.weight(1f), Color.Unspecified, cs.onSurfaceVariant, false)
        Box(Modifier.size(button + 8.dp), contentAlignment = Alignment.Center) {
            if (s.miniProgress) RingProgress(st.progress, st.playing, Modifier.fillMaxSize())
            PlayPauseButton(
                playing = st.playing,
                onClick = st.onToggle,
                modifier = Modifier.size(button - 4.dp),
                iconSize = 20.dp,
                tonal = true,
                showGlow = false,
            )
        }
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(button - 4.dp), iconSize = 24.dp)
        }
    }
}

/** Card: bigger cover, a progress bar and previous / play / next in a row under the song. */
@Composable
private fun CardMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    Row(
        modifier
            .swipeToSkip(s.miniSwipe, st.title, st.onPrev, st.onNext)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            MiniArt(st.art, Modifier.size(64.dp * k), RoundedCornerShape((s.corner * 0.6f).dp))
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            SongLines(st, Modifier, Color.Unspecified, cs.onSurfaceVariant, false)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (s.miniProgress) {
                    BarProgress(st.progress, cs.primary, Modifier.weight(1f).height(4.dp))
                } else {
                    Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.width(8.dp))
                if (s.miniSkip) {
                    SkipButton(forward = false, onClick = st.onPrev, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
                    Spacer(Modifier.width(4.dp))
                }
                PlayPauseButton(
                    playing = st.playing,
                    onClick = st.onToggle,
                    modifier = Modifier.size(42.dp * k),
                    iconSize = 22.dp,
                    tonal = true,
                    showGlow = false,
                )
                if (s.miniSkip) {
                    Spacer(Modifier.width(4.dp))
                    SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
                }
            }
        }
    }
}

/** Disc: a round bubble. The cover turns like a record, the ring around it is the progress, a small button plays and pauses. */
@Composable
private fun DiscMini(st: FloatMiniState, k: Float, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val disc = 68.dp * k
    var angle by remember { mutableFloatStateOf(0f) }
    // 20 steps a second is plenty for a slow turn and is gentle on the battery
    LaunchedEffect(st.playing, motion.enabled) {
        if (st.playing && motion.enabled) {
            while (true) {
                delay(50)
                angle = (angle + 1.2f) % 360f
            }
        }
    }
    Box(Modifier.size(disc + 8.dp)) {
        Box(
            modifier
                .size(disc)
                .swipeToSkip(s.miniSwipe, st.title, st.onPrev, st.onNext)
                .glow(CircleShape, s.glowMini, if (st.playing) 1f else 0.45f)
                .finish(CircleShape)
                .clickable(onClick = st.onOpen),
            contentAlignment = Alignment.Center,
        ) {
            if (s.miniArt) {
                MiniArt(
                    st.art,
                    Modifier.fillMaxSize().padding(6.dp).graphicsLayer { rotationZ = angle },
                    CircleShape,
                )
                // the little hole in the middle of a record
                Box(Modifier.size(10.dp).clip(CircleShape).background(cs.surface))
            } else {
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSurfaceVariant)
            }
            if (s.miniProgress) {
                val track = cs.primary.copy(alpha = 0.18f)
                val color = cs.primary
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 3.dp.toPx()
                    val inset = stroke / 2f
                    val arc = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(stroke))
                    val p = st.progress().coerceIn(0f, 1f)
                    if (p > 0.002f) {
                        drawArc(color, -90f, 360f * p, false, Offset(inset, inset), arc, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .size(28.dp * k)
                .clip(CircleShape)
                .background(cs.primary)
                .clickable(onClick = st.onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (st.playing) "Pause" else "Play",
                tint = cs.onPrimary,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** Island: a small dark capsule, always dark whatever the theme. The song fills it up from the left like a battery. */
@Composable
private fun IslandMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val bg = cs.inverseSurface
    val fg = cs.inverseOnSurface
    Row(
        modifier
            .swipeToSkip(s.miniSwipe, st.title, st.onPrev, st.onNext)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .clip(shape)
            .background(bg)
            .then(
                if (s.miniProgress) {
                    Modifier.drawBehind {
                        val p = st.progress().coerceIn(0f, 1f)
                        drawRect(fg.copy(alpha = 0.12f), size = Size(size.width * p, size.height))
                    }
                } else {
                    Modifier
                },
            )
            .border(1.dp, fg.copy(alpha = 0.10f), shape)
            .clickable(onClick = st.onOpen)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            MiniArt(st.art, Modifier.size(38.dp * k), CircleShape)
            Spacer(Modifier.width(8.dp))
        }
        EqBars(st.playing, cs.inversePrimary, Modifier.size(width = 18.dp, height = 16.dp))
        Spacer(Modifier.width(8.dp))
        SongLines(st, Modifier.weight(1f), fg, fg.copy(alpha = 0.65f), false)
        if (s.miniSkip) {
            RoundButton(Icons.Rounded.SkipNext, "Next", st.onNext, 34.dp * k, Color.Transparent, fg)
        }
        RoundButton(
            if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (st.playing) "Pause" else "Play",
            st.onToggle,
            38.dp * k,
            fg,
            bg,
        )
    }
}

/** Cover: the album art is the whole card, with a dark fade at the bottom for the text and white controls. */
@Composable
private fun CoverMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    Box(
        modifier
            .height(112.dp * k)
            .swipeToSkip(s.miniSwipe, st.title, st.onPrev, st.onNext)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .clip(shape)
            .clickable(onClick = st.onOpen),
    ) {
        MiniArt(st.art, Modifier.matchParentSize(), RectangleShape)
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.82f)))),
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 14.dp, end = 10.dp, bottom = 10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SongLines(st, Modifier.weight(1f), Color.White, Color.White.copy(alpha = 0.72f), true)
                if (s.miniSkip) {
                    RoundButton(Icons.Rounded.SkipPrevious, "Previous", st.onPrev, 34.dp * k, Color.White.copy(alpha = 0.16f), Color.White)
                    Spacer(Modifier.width(6.dp))
                }
                RoundButton(
                    if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (st.playing) "Pause" else "Play",
                    st.onToggle,
                    42.dp * k,
                    Color.White,
                    Color.Black.copy(alpha = 0.85f),
                )
                if (s.miniSkip) {
                    Spacer(Modifier.width(6.dp))
                    RoundButton(Icons.Rounded.SkipNext, "Next", st.onNext, 34.dp * k, Color.White.copy(alpha = 0.16f), Color.White)
                }
            }
            if (s.miniProgress) {
                Spacer(Modifier.height(8.dp))
                BarProgress(st.progress, Color.White, Modifier.fillMaxWidth().height(3.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- shared pieces

@Composable
private fun SongLines(st: FloatMiniState, modifier: Modifier, title: Color, artist: Color, big: Boolean) {
    val marquee = LocalAppSettings.current.marqueeTitles
    Column(modifier) {
        Text(
            verbatim(st.title),
            modifier = Modifier.titleMarquee(marquee),
            color = title,
            style = if (big) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
        )
        Text(
            verbatim(st.artist),
            color = artist,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** The cover, or a soft coloured square with a note when there is no song (the preview in Settings). */
@Composable
internal fun MiniArt(uri: Uri?, modifier: Modifier, shape: Shape) {
    if (uri != null) {
        Art(uri, modifier, shape)
    } else {
        val cs = MaterialTheme.colorScheme
        Box(
            modifier
                .clip(shape)
                .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.tertiaryContainer))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onPrimaryContainer)
        }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, description: String, onClick: () -> Unit, size: Dp, bg: Color, tint: Color) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** A thin rounded progress bar. [progress] is only called while drawing. */
@Composable
private fun BarProgress(progress: () -> Float, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val round = CornerRadius(size.height / 2f, size.height / 2f)
        drawRoundRect(color.copy(alpha = 0.22f), size = size, cornerRadius = round)
        val p = progress().coerceIn(0f, 1f)
        if (p > 0.002f) {
            drawRoundRect(color, size = Size(maxOf(size.height, size.width * p), size.height), cornerRadius = round)
        }
    }
}

/** The outline of the play button (it follows the play button shape setting) that fills with the song, from the top, clockwise. */
@Composable
private fun RingProgress(progress: () -> Float, playing: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val corners = rememberPlayCorners(playing)
    val measure = remember { PathMeasure() }
    val seg = remember { Path() }
    val color = cs.primary
    val track = color.copy(alpha = 0.16f)
    Canvas(modifier) {
        if (size.minDimension < 6.dp.toPx()) return@Canvas
        val stroke = 2.5.dp.toPx()
        val path = shapeOutlinePath(size.width, size.height, stroke / 2f, corners)
        drawPath(path, track, style = Stroke(width = stroke, cap = StrokeCap.Round))
        val p = progress().coerceIn(0f, 1f)
        if (p > 0.002f) {
            measure.setPath(path, false)
            seg.reset()
            measure.getSegment(0f, measure.length * p, seg, true)
            drawPath(seg, color, style = Stroke(width = stroke, cap = StrokeCap.Round))
        }
    }
}

/** Four little bars that jump while the music plays and lie low when it is paused. */
@Composable
private fun EqBars(playing: Boolean, color: Color, modifier: Modifier) {
    val motion = LocalMotion.current
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing, motion.enabled) {
        if (playing && motion.enabled) {
            while (true) {
                delay(90)
                phase += 0.6f
            }
        }
    }
    Canvas(modifier) {
        val bars = 4
        val gap = 2.5.dp.toPx()
        val w = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val f = if (playing) 0.3f + 0.7f * abs(sin(phase * (1f + 0.37f * i) + i * 1.3f)) else 0.22f
            val h = size.height * f
            drawRoundRect(
                color,
                topLeft = Offset(i * (w + gap), size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f, w / 2f),
            )
        }
    }
}

/** Swipe sideways to skip: right goes back, left goes forward. It follows the finger and springs back. */
@Composable
private fun Modifier.swipeToSkip(on: Boolean, key: Any, onPrev: () -> Unit, onNext: () -> Unit): Modifier {
    var drag by remember { mutableFloatStateOf(0f) }
    val shown by animateFloatAsState(
        targetValue = drag,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "floatMiniDrag",
    )
    val prev by rememberUpdatedState(onPrev)
    val next by rememberUpdatedState(onNext)
    val gesture = if (on) {
        Modifier.pointerInput(key) {
            detectHorizontalDragGestures(
                onDragStart = { drag = 0f },
                onDragEnd = {
                    if (drag > 140f) prev() else if (drag < -140f) next()
                    drag = 0f
                },
                onDragCancel = { drag = 0f },
                onHorizontalDrag = { change, amount ->
                    change.consume()
                    drag = (drag + amount).coerceIn(-320f, 320f)
                },
            )
        }
    } else {
        Modifier
    }
    return this
        .graphicsLayer {
            translationX = shown * 0.5f
            alpha = 1f - (abs(shown) / 900f).coerceAtMost(0.3f)
        }
        .then(gesture)
}
