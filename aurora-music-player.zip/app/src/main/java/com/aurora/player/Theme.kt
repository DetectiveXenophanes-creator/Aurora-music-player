package com.aurora.player

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.remember
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import dev.chrisbanes.haze.HazeState

val LocalAppSettings = staticCompositionLocalOf { AppSettings() }
val LocalHazeState = staticCompositionLocalOf { HazeState() }

@Composable
fun AuroraTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current

    var scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        seedScheme(Color(settings.accent), dark, settings.spread, settings.vibrancy)
    }
    if (dark && settings.amoled) {
        scheme = scheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerLow = Color(0xFF050505),
            surfaceContainer = Color(0xFF0C0C0C),
            surfaceContainerHigh = Color(0xFF151515),
            surfaceContainerHighest = Color(0xFF1E1E1E),
        )
    }

    val r = settings.corner
    val shapes = Shapes(
        extraSmall = RoundedCornerShape((r * 0.25f).dp),
        small = RoundedCornerShape((r * 0.5f).dp),
        medium = RoundedCornerShape((r * 0.75f).dp),
        large = RoundedCornerShape(r.dp),
        extraLarge = RoundedCornerShape((r * 1.4f).dp),
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    val typography = remember(settings.uiFont) { buildTypography(settings.uiFont) }
    val baseDensity = LocalDensity.current
    val density = remember(baseDensity.density, baseDensity.fontScale, settings.textScale) {
        Density(baseDensity.density, baseDensity.fontScale * settings.textScale)
    }
    CompositionLocalProvider(LocalDensity provides density) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, typography = typography) {
            // Surface provides the content colour (white on dark, black on light). Without it, text defaults to black.
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = scheme.background,
                contentColor = scheme.onBackground,
                content = content,
            )
        }
    }
}

private fun buildTypography(font: UiFont): Typography {
    val family = when (font) {
        UiFont.DEFAULT -> return Typography()
        UiFont.SERIF -> FontFamily.Serif
        UiFont.MONO -> FontFamily.Monospace
    }
    val t = Typography()
    return t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = family),
        displayMedium = t.displayMedium.copy(fontFamily = family),
        displaySmall = t.displaySmall.copy(fontFamily = family),
        headlineLarge = t.headlineLarge.copy(fontFamily = family),
        headlineMedium = t.headlineMedium.copy(fontFamily = family),
        headlineSmall = t.headlineSmall.copy(fontFamily = family),
        titleLarge = t.titleLarge.copy(fontFamily = family),
        titleMedium = t.titleMedium.copy(fontFamily = family),
        titleSmall = t.titleSmall.copy(fontFamily = family),
        bodyLarge = t.bodyLarge.copy(fontFamily = family),
        bodyMedium = t.bodyMedium.copy(fontFamily = family),
        bodySmall = t.bodySmall.copy(fontFamily = family),
        labelLarge = t.labelLarge.copy(fontFamily = family),
        labelMedium = t.labelMedium.copy(fontFamily = family),
        labelSmall = t.labelSmall.copy(fontFamily = family),
    )
}

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, v)))

/** Fallback palette generated from one accent colour (used when Material You wallpaper colours are off). */
internal fun seedScheme(seed: Color, dark: Boolean, spread: Float = 1f, vibrancy: Float = 1f): ColorScheme {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val h = hsv[0]
    fun c(hue: Float, sat: Float, v: Float): Color = hsv(hue, (sat * vibrancy).coerceIn(0f, 1f), v)
    return if (dark) {
        darkColorScheme(
            primary = c(h, .45f, .96f),
            onPrimary = c(h, .85f, .22f),
            primaryContainer = c(h, .70f, .38f),
            onPrimaryContainer = c(h, .15f, .97f),
            secondary = c(h + 20f * spread, .25f, .90f),
            onSecondary = c(h + 20f * spread, .50f, .22f),
            secondaryContainer = c(h + 20f * spread, .40f, .32f),
            onSecondaryContainer = c(h + 20f * spread, .12f, .93f),
            tertiary = c(h + 60f * spread, .35f, .94f),
            onTertiary = c(h + 60f * spread, .60f, .24f),
            tertiaryContainer = c(h + 60f * spread, .50f, .34f),
            onTertiaryContainer = c(h + 60f * spread, .12f, .95f),
            background = c(h, .15f, .10f),
            onBackground = c(h, .05f, .92f),
            surface = c(h, .15f, .10f),
            onSurface = c(h, .05f, .92f),
            surfaceVariant = c(h, .20f, .26f),
            onSurfaceVariant = c(h, .10f, .82f),
            surfaceContainerLow = c(h, .16f, .12f),
            surfaceContainer = c(h, .16f, .15f),
            surfaceContainerHigh = c(h, .16f, .19f),
            surfaceContainerHighest = c(h, .16f, .23f),
            outline = c(h, .10f, .62f),
        )
    } else {
        lightColorScheme(
            primary = c(h, .75f, .55f),
            onPrimary = Color.White,
            primaryContainer = c(h, .22f, .98f),
            onPrimaryContainer = c(h, .90f, .26f),
            secondary = c(h + 20f * spread, .40f, .50f),
            onSecondary = Color.White,
            secondaryContainer = c(h + 20f * spread, .16f, .96f),
            onSecondaryContainer = c(h + 20f * spread, .60f, .22f),
            tertiary = c(h + 60f * spread, .50f, .52f),
            onTertiary = Color.White,
            tertiaryContainer = c(h + 60f * spread, .20f, .97f),
            onTertiaryContainer = c(h + 60f * spread, .80f, .25f),
            background = c(h, .04f, .99f),
            onBackground = c(h, .15f, .12f),
            surface = c(h, .04f, .99f),
            onSurface = c(h, .15f, .12f),
            surfaceVariant = c(h, .10f, .92f),
            onSurfaceVariant = c(h, .20f, .32f),
            surfaceContainerLow = c(h, .05f, .97f),
            surfaceContainer = c(h, .07f, .95f),
            surfaceContainerHigh = c(h, .09f, .93f),
            surfaceContainerHighest = c(h, .11f, .91f),
            outline = c(h, .15f, .48f),
        )
    }
}
