package com.aurora.player

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import dev.chrisbanes.haze.HazeState

val LocalAppSettings = staticCompositionLocalOf { AppSettings() }
val LocalHazeState = staticCompositionLocalOf { HazeState() }

@Composable
fun AuroraTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current

    var scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        seedScheme(Color(settings.accent), dark)
    }
    if (dark && settings.amoled) {
        scheme = scheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerLow = Color(0xFF050505),
            surfaceContainer = Color(0xFF0C0C0C),
            surfaceContainerHigh = Color(0xFF151515),
            surfaceContainerHighest = Color(0xFF1E1E1E),
        )
    }

    val r = settings.corner
    val shapes = Shapes(
        extraSmall = RoundedCornerShape((r * 0.25f).dp),
        small = RoundedCornerShape((r * 0.5f).dp),
        medium = RoundedCornerShape((r * 0.75f).dp),
        large = RoundedCornerShape(r.dp),
        extraLarge = RoundedCornerShape((r * 1.4f).dp),
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(colorScheme = scheme, shapes = shapes, typography = Typography(), content = content)
}

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, v)))

/** Fallback palette generated from one accent colour (used when Material You wallpaper colours are off). */
private fun seedScheme(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val h = hsv[0]
    return if (dark) {
        darkColorScheme(
            primary = hsv(h, .45f, .96f),
            onPrimary = hsv(h, .85f, .22f),
            primaryContainer = hsv(h, .70f, .38f),
            onPrimaryContainer = hsv(h, .15f, .97f),
            secondary = hsv(h + 20, .25f, .90f),
            onSecondary = hsv(h + 20, .50f, .22f),
            secondaryContainer = hsv(h + 20, .40f, .32f),
            onSecondaryContainer = hsv(h + 20, .12f, .93f),
            tertiary = hsv(h + 60, .35f, .94f),
            onTertiary = hsv(h + 60, .60f, .24f),
            tertiaryContainer = hsv(h + 60, .50f, .34f),
            onTertiaryContainer = hsv(h + 60, .12f, .95f),
            background = hsv(h, .15f, .10f),
            onBackground = hsv(h, .05f, .92f),
            surface = hsv(h, .15f, .10f),
            onSurface = hsv(h, .05f, .92f),
            surfaceVariant = hsv(h, .20f, .26f),
            onSurfaceVariant = hsv(h, .10f, .82f),
            surfaceContainerLow = hsv(h, .16f, .12f),
            surfaceContainer = hsv(h, .16f, .15f),
            surfaceContainerHigh = hsv(h, .16f, .19f),
            surfaceContainerHighest = hsv(h, .16f, .23f),
            outline = hsv(h, .10f, .62f),
        )
    } else {
        lightColorScheme(
            primary = hsv(h, .75f, .55f),
            onPrimary = Color.White,
            primaryContainer = hsv(h, .22f, .98f),
            onPrimaryContainer = hsv(h, .90f, .26f),
            secondary = hsv(h + 20, .40f, .50f),
            onSecondary = Color.White,
            secondaryContainer = hsv(h + 20, .16f, .96f),
            onSecondaryContainer = hsv(h + 20, .60f, .22f),
            tertiary = hsv(h + 60, .50f, .52f),
            onTertiary = Color.White,
            tertiaryContainer = hsv(h + 60, .20f, .97f),
            onTertiaryContainer = hsv(h + 60, .80f, .25f),
            background = hsv(h, .04f, .99f),
            onBackground = hsv(h, .15f, .12f),
            surface = hsv(h, .04f, .99f),
            onSurface = hsv(h, .15f, .12f),
            surfaceVariant = hsv(h, .10f, .92f),
            onSurfaceVariant = hsv(h, .20f, .32f),
            surfaceContainerLow = hsv(h, .05f, .97f),
            surfaceContainer = hsv(h, .07f, .95f),
            surfaceContainerHigh = hsv(h, .09f, .93f),
            surfaceContainerHighest = hsv(h, .11f, .91f),
            outline = hsv(h, .15f, .48f),
        )
    }
}
