package com.aurora.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private class TourStep(
    val title: String,
    val text: String,
    val tab: AppTab? = null,
    val pointsDown: Boolean = false,
)

private val tour = listOf(
    TourStep("Hi, I'm Lumi!", "I'm a cat made of northern lights. Want a quick look around Aurora with me?", AppTab.HOME),
    TourStep("Home", "Your top song, a daily mix and your stats live here.", AppTab.HOME),
    TourStep("Songs", "All your music in one list. Search, sort, and press and hold to pick a few.", AppTab.SONGS),
    TourStep("Playlists", "Make a playlist for every mood and give each one its own look.", AppTab.PLAYLISTS),
    TourStep("Albums, Folders, Artists", "Browse your music your way, then tap to play.", AppTab.ALBUMS),
    TourStep("Tabs", "Your tabs are down here. You can change how they look in Settings > Design.", null, true),
    TourStep("Mini player", "Play a song and a small player pops up here. Tap it to open the big one.", null, true),
    TourStep("The player", "Drag the seek bar, tap the heart, shuffle or repeat. Tap the time to see what's left.", null),
    TourStep("Queue and sleep", "The moon sets a sleep timer. The queue shows what's coming up next.", null),
    TourStep("Sound", "Speed, pitch, equalizer, bass and loudness all live in the Sound button.", null),
    TourStep("Make it yours", "Settings > Themes and Design have loads of colours and looks. Try a few!", null),
    TourStep("Seek bar studio", "Pick from eight seek bar styles with your own thumb, colour and waves.", null),
    TourStep("Fun stuff", "Cover shapes, background patterns, cover colours... and me! You can hide me in Settings.", null),
    TourStep("Backup and speed", "Back up playlists in Settings > Backup. On older phones Aurora switches to Lite by itself.", null),
    TourStep("That's it!", "Replay this tour any time in Settings > Startup. Enjoy the music!", AppTab.HOME),
)

/**
 * The tour: Lumi and a short speech bubble float over the real tabs. Some steps switch the tab underneath so you can
 * see what she is talking about. Skip is always one tap away.
 */
@Composable
fun TourOverlay(onTab: (AppTab) -> Unit, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val corner = LocalAppSettings.current.corner
    var step by rememberSaveable { mutableIntStateOf(0) }
    val last = tour.size - 1
    val current = tour[step.coerceIn(0, last)]

    LaunchedEffect(step) { tour[step.coerceIn(0, last)].tab?.let(onTab) }
    BackHandler { if (step > 0) step -= 1 else onDone() }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.34f)).blockTouches()) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 16.dp, end = 16.dp, bottom = 148.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                key(step) { AuroraCat(Modifier.popIn().size(104.dp)) }
                Spacer(Modifier.weight(1f))
                if (step < last) TextButton(onClick = onDone) { Text("Skip", color = Color.White) }
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .cardFinish(RoundedCornerShape((corner * 1.1f).dp))
                    .background(cs.surface.copy(alpha = 0.84f))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AnimatedContent(
                    targetState = step,
                    transitionSpec = { motion.text() },
                    label = "tourText",
                ) { st ->
                    val page = tour[st.coerceIn(0, last)]
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(page.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(page.text, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${step + 1} / ${tour.size}", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    if (step > 0) TextButton(onClick = { step -= 1 }) { Text("Back") }
                    Button(onClick = { if (step < last) step += 1 else onDone() }) {
                        Text(if (step < last) "Next" else "Let's go")
                    }
                }
            }
            if (current.pointsDown) {
                val bounce by rememberInfiniteTransition(label = "arrow").animateFloat(
                    initialValue = 0f,
                    targetValue = 10f,
                    animationSpec = infiniteRepeatable(tween(520), RepeatMode.Reverse),
                    label = "arrowBounce",
                )
                Icon(
                    Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.CenterHorizontally).size(40.dp).offset(y = bounce.dp),
                )
            }
        }
    }
}
