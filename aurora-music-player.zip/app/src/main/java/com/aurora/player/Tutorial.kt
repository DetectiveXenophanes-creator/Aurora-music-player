package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private class TourPage(
    val icon: ImageVector,
    val title: String,
    val body: String,
    val where: String? = null,
)

private val tour = listOf(
    TourPage(
        Icons.Rounded.MusicNote,
        "Hi, and welcome!",
        "This little tour shows you everything Aurora can do, in plain words. It takes about two minutes. " +
            "You can skip it whenever you like and replay it later.",
        "Settings > Startup > Show the tour again",
    ),
    TourPage(
        Icons.Rounded.Home,
        "Home",
        "Home is your cosy starting point. It shows your most played song, a fresh daily mix, quick tiles for " +
            "favorites and recent songs, your listening stats, and what you played last.",
        "Settings > Home lets you hide cards, reorder them and choose how big the daily mix is",
    ),
    TourPage(
        Icons.Rounded.Search,
        "Songs",
        "All the music on your phone in one list. Search to find a song fast. Sort by title, artist, album, length, " +
            "date added or most played, and filter to favorites or short and long songs. Press and hold a song to " +
            "pick several at once, then add them to a playlist or delete them.",
    ),
    TourPage(
        Icons.Rounded.QueueMusic,
        "Playlists and favorites",
        "Make a playlist for every mood. Give each one its own look with Customize in its menu. " +
            "Tap the heart on the player to add a song to your favorites.",
    ),
    TourPage(
        Icons.Rounded.Album,
        "Albums, Folders and Artists",
        "Browse your music the way you think about it: by album, by folder or by artist. " +
            "Tap one to see its songs and play them.",
        "Hide folders you don't want, like voice notes, in Settings > Library",
    ),
    TourPage(
        Icons.Rounded.PlayCircle,
        "The mini player and tabs",
        "When a song is playing, a small player floats above your tabs. Tap it to open the full player. " +
            "Play, pause and skip work right there. The tabs below switch between Home, Songs, Playlists, Albums, Folders and Artists.",
        "Settings > Design > Navigation bar changes how the tabs look",
    ),
    TourPage(
        Icons.Rounded.MusicNote,
        "The player",
        "The big cover sits in the middle, with little arrows beside it to skip. Tap or drag the seek bar to jump " +
            "around a song. Tap the time on the right to switch between the full length and the time left. " +
            "Below you'll find shuffle, repeat and the heart for favorites. The three dots on a song open more actions, " +
            "like Play next and Add to queue.",
    ),
    TourPage(
        Icons.Rounded.Bedtime,
        "Queue and sleep timer",
        "The queue button shows what plays next. The moon button sets a sleep timer, so the music stops by itself " +
            "when you drift off.",
    ),
    TourPage(
        Icons.Rounded.GraphicEq,
        "Sound",
        "The Sound button lets you change the speed and pitch, switch on the five-band equalizer with presets, " +
            "and add extra bass or loudness. There's also Skip silence, which jumps over quiet gaps.",
        "Settings > Audio",
    ),
    TourPage(
        Icons.Rounded.ColorLens,
        "Colours and themes",
        "Pick from 13 ready-made themes, use Material You colours from your wallpaper, or build your own by choosing " +
            "a hue, how vibrant it is and how far the colours spread. Save your themes and share them as a short code.",
        "Settings > Themes",
    ),
    TourPage(
        Icons.Rounded.Palette,
        "Design styles",
        "Aurora isn't stuck in one look. Choose Material You, Soft, Outlined, Neo-brutal or Glossy, and every bar, " +
            "card and panel changes to match. With Material You you can also pick Matte or Frosted glass.",
        "Settings > Design",
    ),
    TourPage(
        Icons.Rounded.Tune,
        "Your seek bar, your way",
        "Eight seek bar styles: Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars and Steps. Choose the thumb shape, " +
            "thickness, colour (even a gradient) and how big the waves are. A live preview shows what you're making.",
        "Settings > Seek bar",
    ),
    TourPage(
        Icons.Rounded.Brush,
        "Buttons and cover",
        "Change the shape of the skip and action buttons (Pill, Soft, Square or Sharp), the play button, and the cover " +
            "(Rounded, Circle or a spinning vinyl). Turn on Cover colours and the player borrows its colours from the album art.",
        "Settings > Design and Settings > Customization",
    ),
    TourPage(
        Icons.Rounded.AutoAwesome,
        "Animations",
        "Pick how Aurora moves: Smooth, Bouncy, Snappy, Fluid or Minimal. Speed and intensity sliders fine-tune it, " +
            "and there's a little track to try your settings.",
        "Settings > Animations",
    ),
    TourPage(
        Icons.Rounded.Waves,
        "Backgrounds",
        "Choose a gradient, the album art or a flat colour behind everything. Add a soft northern-lights glow and " +
            "drifting squiggly shapes, or turn them all off for a calmer look.",
        "Settings > Customization > Background",
    ),
    TourPage(
        Icons.Rounded.Language,
        "Language and text",
        "Aurora speaks English plus ten more languages. You can also change the font and make the text bigger or smaller.",
        "Settings > Startup and Settings > Customization > Text",
    ),
    TourPage(
        Icons.Rounded.FolderOpen,
        "Your library",
        "Aurora finds the music on your phone by itself. You can hide folders, ignore very short clips like " +
            "notification sounds, include audio that isn't music, and rescan any time.",
        "Settings > Library",
    ),
    TourPage(
        Icons.Rounded.Backup,
        "Backup and restore",
        "Save your playlists, favorites and settings to a file, and bring them back on a new phone. " +
            "Playlists keep song names, not the audio files themselves.",
        "Settings > Backup",
    ),
    TourPage(
        Icons.Rounded.Speed,
        "Smooth on any phone",
        "Aurora checks how powerful your phone is. On older or low-memory phones it switches to Lite: no blur, a calmer " +
            "background and fewer effects, so it stays quick. Prefer to choose yourself? Pick Auto, Full or Lite. " +
            "Battery saver and the background frame rate live there too.",
        "Settings > Customization > Performance",
    ),
    TourPage(
        Icons.Rounded.Favorite,
        "Little extras",
        "Small taps can buzz a little (haptics). You can keep the screen on while the player is open, choose which tab " +
            "Aurora opens on, turn the intro animation on or off, and have Home greet you by name.",
        "Settings > Player, Startup and Home",
    ),
    TourPage(
        Icons.Rounded.CheckCircle,
        "That's the tour!",
        "You now know your way around. Everything can be changed later, so play with it and make Aurora yours. Enjoy the music.",
    ),
)

/** Friendly walk-through shown once after setup (and again from Settings > Startup). */
@Composable
fun TutorialScreen(onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val corner = LocalAppSettings.current.corner
    var step by rememberSaveable { mutableIntStateOf(0) }
    val last = tour.size - 1

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(null)
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${step + 1} / ${tour.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                if (step < last) TextButton(onClick = onDone) { Text("Skip tour") }
            }
            LinearProgressIndicator(
                progress = { (step + 1f) / tour.size },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)),
                color = cs.primary,
                trackColor = cs.primary.copy(alpha = 0.18f),
            )
            Spacer(Modifier.height(16.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = { motion.tab(targetState > initialState) },
                label = "tourPage",
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) { st ->
                val page = tour[st]
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Box(
                        Modifier.popIn().size(88.dp).clip(RoundedCornerShape(30.dp)).background(cs.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(page.icon, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(46.dp))
                    }
                    Text(page.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(page.body, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
                    page.where?.let { w ->
                        Column(
                            Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text("Where to find it", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                            Text(w, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) TextButton(onClick = { step -= 1 }) { Text("Back") }
                Spacer(Modifier.weight(1f))
                Button(onClick = { if (step < last) step += 1 else onDone() }) {
                    Text(if (step < last) "Next" else "Let's go")
                }
            }
        }
    }
}
