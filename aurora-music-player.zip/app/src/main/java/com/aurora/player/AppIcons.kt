package com.aurora.player

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import kotlin.math.abs

/** A launcher icon that ships inside the app. [alias] is the manifest entry that shows it on the home screen. */
class IconPreset(
    val id: String,
    val label: String,
    val alias: String,
    val res: Int,
    /** Hue of the icon in degrees, or -1 for the grey one. */
    val hue: Float,
)

/** Colour icons for the home screen, and the shortcut that carries your own icons. */
object AppIcons {
    val presets: List<IconPreset> = listOf(
        IconPreset("aurora", "Aurora", "IconAurora", R.mipmap.ic_launcher, 260f),
        IconPreset("red", "Red", "IconRed", R.mipmap.ic_launcher_red, 0f),
        IconPreset("orange", "Orange", "IconOrange", R.mipmap.ic_launcher_orange, 25f),
        IconPreset("amber", "Amber", "IconAmber", R.mipmap.ic_launcher_amber, 45f),
        IconPreset("green", "Green", "IconGreen", R.mipmap.ic_launcher_green, 130f),
        IconPreset("teal", "Teal", "IconTeal", R.mipmap.ic_launcher_teal, 175f),
        IconPreset("blue", "Blue", "IconBlue", R.mipmap.ic_launcher_blue, 215f),
        IconPreset("pink", "Pink", "IconPink", R.mipmap.ic_launcher_pink, 330f),
        IconPreset("mono", "Mono", "IconMono", R.mipmap.ic_launcher_mono, -1f),
    )

    private fun component(context: Context, p: IconPreset) =
        ComponentName(context.packageName, "com.aurora.player.${p.alias}")

    /** The icon the home screen shows right now. */
    fun current(context: Context): IconPreset {
        val pm = context.packageManager
        for (p in presets) {
            val on = runCatching {
                when (pm.getComponentEnabledSetting(component(context, p))) {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
                    else -> p.id == "aurora" // not set: the manifest decides, and only Aurora starts enabled
                }
            }.getOrDefault(false)
            if (on) return p
        }
        return presets[0]
    }

    /** Shows [target] on the home screen. The new one is switched on before the old ones go off, so there is always one. */
    fun apply(context: Context, target: IconPreset): Boolean {
        if (current(context) == target) return true
        val pm = context.packageManager
        return runCatching {
            pm.setComponentEnabledSetting(
                component(context, target),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP,
            )
            for (p in presets) {
                if (p != target) {
                    pm.setComponentEnabledSetting(
                        component(context, p),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP,
                    )
                }
            }
        }.isSuccess
    }

    /** The colour icon closest to [accent]. Greys and near-blacks get the Mono icon. */
    fun nearest(accent: Int): IconPreset {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(accent, hsv)
        if (hsv[1] < 0.15f || hsv[2] < 0.2f) return presets.last()
        var best = presets[0]
        var bestD = 999f
        for (p in presets) {
            if (p.hue < 0f) continue
            var d = abs(hsv[0] - p.hue)
            if (d > 180f) d = 360f - d
            if (d < bestD) {
                bestD = d
                best = p
            }
        }
        return best
    }

    /**
     * Android only lets a launcher icon come from inside the app, so your own icons go on the home screen as a
     * shortcut that opens Aurora. Asks the launcher to add it; false when this launcher cannot.
     */
    fun pinCustom(context: Context, icon: VectorIcon): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return false
        return runCatching {
            val intent = Intent(context, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
            val info = ShortcutInfoCompat.Builder(context, "icon_${icon.id}")
                .setShortLabel(icon.name.ifBlank { "Aurora" })
                .setIcon(IconCompat.createWithAdaptiveBitmap(icon.toBitmap()))
                .setIntent(intent)
                .build()
            ShortcutManagerCompat.requestPinShortcut(context, info, null)
        }.getOrDefault(false)
    }
}

// ------------------------------------------------------------------ your own icons

data class IconPrefs(val icons: List<VectorIcon>, val auto: Boolean)

private val Context.iconStore by preferencesDataStore(name = "aurora_icons")

/** Your own icons (kept as vector outlines) and the "follow my accent colour" switch. */
class IconStore(context: Context) {
    private val context = context.applicationContext

    private object K {
        val custom = stringPreferencesKey("custom_icons")
        val auto = booleanPreferencesKey("follow_accent")
    }

    val flow: Flow<IconPrefs> = this.context.iconStore.data.map { p ->
        IconPrefs(readIcons(p), p[K.auto] ?: false)
    }

    val autoFlow: Flow<Boolean> = flow.map { it.auto }.distinctUntilChanged()

    suspend fun snapshot(): List<VectorIcon> = flow.first().icons

    suspend fun upsert(icon: VectorIcon) = change { list -> (list.filter { it.id != icon.id } + icon).takeLast(MAX_ICONS) }

    suspend fun remove(id: String) = change { list -> list.filter { it.id != id } }

    suspend fun rename(id: String, name: String) =
        change { list -> list.map { if (it.id == id) it.copy(name = name) else it } }

    /** Adds the icons from a backup that are not here yet. */
    suspend fun merge(extra: List<VectorIcon>) = change { list ->
        val have = list.map { it.id }.toSet()
        (list + extra.filter { it.id !in have }).takeLast(MAX_ICONS)
    }

    suspend fun setAuto(on: Boolean) {
        context.iconStore.edit { it[K.auto] = on }
    }

    private suspend fun change(block: (List<VectorIcon>) -> List<VectorIcon>) {
        context.iconStore.edit { p ->
            val next = block(readIcons(p))
            val arr = JSONArray()
            next.forEach { arr.put(it.toJson()) }
            p[K.custom] = arr.toString()
        }
    }

    private fun readIcons(p: Preferences): List<VectorIcon> {
        val s = p[K.custom] ?: return emptyList()
        return runCatching {
            val arr = JSONArray(s)
            (0 until arr.length()).mapNotNull { vectorIconFromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    companion object {
        const val MAX_ICONS = 30
    }
}

/** When "follow my accent colour" is on, keeps the home screen icon matched to the theme colour. */
@Composable
fun IconAutoEffect(accent: Int) {
    val context = LocalContext.current
    val store = remember { IconStore(context) }
    val auto by store.autoFlow.collectAsState(initial = false)
    LaunchedEffect(auto, accent) {
        if (auto) {
            delay(1500) // wait for the colour slider to settle
            AppIcons.apply(context, AppIcons.nearest(accent))
        }
    }
}
