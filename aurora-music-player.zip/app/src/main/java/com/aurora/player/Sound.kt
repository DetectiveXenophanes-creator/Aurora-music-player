package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.roundToInt

const val EQ_RANGE_DB = 12f

private val eqBandNames = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")

private val eqPresets: List<Pair<String, List<Float>>> = listOf(
    "Flat" to listOf(0f, 0f, 0f, 0f, 0f),
    "Bass" to listOf(6f, 4f, 1f, 0f, 0f),
    "Treble" to listOf(0f, 0f, 0f, 4f, 6f),
    "Vocal" to listOf(-2f, 0f, 4f, 3f, -1f),
    "Rock" to listOf(5f, 2f, -2f, 3f, 5f),
    "Pop" to listOf(-1f, 3f, 5f, 2f, -1f),
    "Jazz" to listOf(3f, 1f, -2f, 2f, 4f),
    "Dance" to listOf(6f, 3f, 0f, 2f, 4f),
)

/** On/off switch, presets and five vertical band sliders. Changes apply to the music live. */
@Composable
fun EqualizerPanel(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    ToggleRow("Equalizer", "Shape the sound with five bands", s.eqEnabled, true) { v ->
        onUpdate { it.copy(eqEnabled = v) }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        eqPresets.forEach { (name, gains) ->
            AuroraChip(name, s.eqGains == gains) {
                onUpdate { it.copy(eqGains = gains, eqEnabled = true) }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        eqBandNames.forEachIndexed { i, name ->
            val g = s.eqGains.getOrElse(i) { 0f }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
                Text(
                    "%+d".format(g.roundToInt()),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (s.eqEnabled) cs.primary else cs.onSurfaceVariant,
                )
                BandSlider(
                    value = g,
                    enabled = s.eqEnabled,
                    onChange = { v ->
                        onUpdate { cur ->
                            val list = cur.eqGains.toMutableList()
                            while (list.size < 5) list.add(0f)
                            list[i] = v
                            cur.copy(eqGains = list, eqEnabled = true)
                        }
                    },
                    modifier = Modifier.width(48.dp).height(170.dp),
                )
                Text(name, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
    }
    Text(
        "Equalizer, bass and loudness depend on your phone's audio hardware. Values are in decibels.",
        style = MaterialTheme.typography.bodySmall,
        color = cs.onSurfaceVariant,
    )
}

private fun bandValueAt(y: Float, height: Float, pad: Float): Float {
    val usable = (height - 2 * pad).coerceAtLeast(1f)
    val f = ((height - pad - y) / usable).coerceIn(0f, 1f)
    val v = -EQ_RANGE_DB + f * 2f * EQ_RANGE_DB
    return v.roundToInt().toFloat().coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB)
}

/** One vertical equalizer band: drag or tap anywhere on the track. */
@Composable
private fun BandSlider(value: Float, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val currentOnChange by rememberUpdatedState(onChange)
    val track = cs.primary.copy(alpha = 0.20f)
    val fill = if (enabled) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.55f)
    val tick = cs.onSurfaceVariant.copy(alpha = 0.5f)
    Canvas(
        modifier
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectTapGestures { o -> currentOnChange(bandValueAt(o.y, size.height.toFloat(), pad)) }
            }
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    currentOnChange(bandValueAt(change.position.y, size.height.toFloat(), pad))
                }
            },
    ) {
        val pad = 14.dp.toPx()
        val cx = size.width / 2f
        val trackW = 8.dp.toPx()
        val top = pad
        val bottom = size.height - pad
        val mid = (top + bottom) / 2f
        val f = ((value + EQ_RANGE_DB) / (2f * EQ_RANGE_DB)).coerceIn(0f, 1f)
        val ty = bottom - (bottom - top) * f

        drawRoundRect(
            track,
            topLeft = Offset(cx - trackW / 2f, top),
            size = Size(trackW, bottom - top),
            cornerRadius = CornerRadius(trackW / 2f),
        )
        // zero line
        drawRoundRect(
            tick,
            topLeft = Offset(cx - 13.dp.toPx(), mid - 1.dp.toPx()),
            size = Size(26.dp.toPx(), 2.dp.toPx()),
            cornerRadius = CornerRadius(1.dp.toPx()),
        )
        // filled part, from the zero line to the thumb
        val fillTop = minOf(ty, mid)
        val fillH = abs(ty - mid)
        if (fillH > 0.5f) {
            drawRoundRect(
                fill,
                topLeft = Offset(cx - trackW / 2f, fillTop),
                size = Size(trackW, fillH),
                cornerRadius = CornerRadius(trackW / 2f),
            )
        }
        drawCircle(fill, radius = 11.dp.toPx(), center = Offset(cx, ty))
        drawCircle(cs.surface, radius = 4.dp.toPx(), center = Offset(cx, ty))
    }
}

private val speedPresets = listOf(0.75f, 1f, 1.25f, 1.5f)

/** Speed, pitch and equalizer in one sheet, opened from the Tune button on Now Playing. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SoundSheet(s: AppSettings, onUpdate: SettingsUpdate, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AuroraSheet(onDismiss = onDismiss, title = "Sound") {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SheetLabel("Speed")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                speedPresets.forEach { v ->
                    AuroraChip("%s×".format(if (v == 1f) "1" else v.toString()), abs(s.playbackSpeed - v) < 0.01f) {
                        onUpdate { it.copy(playbackSpeed = v) }
                    }
                }
            }
            SliderRow("Song speed", s.playbackSpeed, 0.5f..2f, "%.2f×".format(s.playbackSpeed)) { v ->
                onUpdate { it.copy(playbackSpeed = (v * 20).roundToInt() / 20f) }
            }
            SliderRow("Pitch", s.playbackPitch, 0.5f..1.5f, "%.2f×".format(s.playbackPitch)) { v ->
                onUpdate { it.copy(playbackPitch = (v * 20).roundToInt() / 20f) }
            }
            FilledTonalButton(onClick = { onUpdate { it.copy(playbackSpeed = 1f, playbackPitch = 1f) } }) {
                Icon(Icons.Rounded.RestartAlt, null, Modifier.padding(end = 0.dp))
                Text("  Reset speed and pitch")
            }

            SheetLabel("Equalizer")
            EqualizerPanel(s, onUpdate)
            Text(
                "These settings stay on for every song until you change them.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
    }
}
