package com.aurora.player

import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Still up?"
        h < 12 -> "Good morning"
        h < 18 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun HomeScreen(
    songs: List<Song>,
    lib: LibraryData,
    currentId: Long?,
    playing: Boolean,
    granted: Boolean,
    onRequest: () -> Unit,
    padding: PaddingValues,
    onPlay: (Song, List<Song>) -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onOpen: (DetailRef) -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(s.corner.dp)
    val ranked = remember(songs, lib.plays) { mostPlayed(songs, lib) }
    val daily = remember(songs, lib.plays, s.mixSize) { dailyMix(songs, lib, s.mixSize) }
    val recent = remember(songs, lib.recent) {
        val byId = songs.associateBy { it.id }
        lib.recent.mapNotNull { byId[it] }.take(5)
    }
    val totalPlays = lib.plays.values.sum()
    val stats = remember(songs, lib.plays) { listeningStats(songs, lib) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp)) {
                if (s.greeting) {
                    val hello = tr(greeting()) + if (s.userName.isNotBlank()) ", " + s.userName.trim() else ""
                    Text(verbatim(hello), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
                Text(
                    "${songs.size} songs  •  $totalPlays plays",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
        }
        if (!granted) {
            item {
                InfoCard(
                    "Allow music access",
                    "Aurora needs permission to read the audio files on your phone.",
                    "Allow",
                    onRequest,
                )
            }
        } else if (songs.isEmpty()) {
            item { InfoCard("No music found", "Copy some audio files onto this phone, or check Settings > Library.", null) {} }
        } else {
            for (section in s.homeOrder) {
                if (section in s.homeHidden) continue
                when (section) {
                    HomeSection.MOST -> {
                        item(key = "sec_most") {
                            val top = ranked.firstOrNull()
                            MostPlayedCard(top, top?.let { lib.plays[it.id] } ?: 0, shape) { song -> onPlay(song, ranked) }
                        }
                    }
                    HomeSection.MIX -> {
                        item(key = "sec_mix_head") {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Daily mix", style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        "Fresh every day, built from what you play most",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = cs.onSurfaceVariant,
                                    )
                                }
                                FilledTonalButton(onClick = { onPlayAll(daily) }) {
                                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Play")
                                }
                            }
                        }
                        item(key = "sec_mix_row") {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(daily, key = { it.id }) { song ->
                                    DailyCard(song, song.id == currentId) { onPlay(song, daily) }
                                }
                            }
                        }
                    }
                    HomeSection.TILES -> {
                        item(key = "sec_tiles") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                SmartTile(
                                    Icons.Rounded.Favorite, "Favorites", "${lib.favorites.size}", shape,
                                    Modifier.weight(1f),
                                ) { onOpen(DetailRef(DetailKind.SMART, "fav", "Favorites")) }
                                SmartTile(
                                    Icons.Rounded.Star, "Most played", "${ranked.size.coerceAtMost(25)}", shape,
                                    Modifier.weight(1f),
                                ) { onOpen(DetailRef(DetailKind.SMART, "top", "Most played")) }
                                SmartTile(
                                    Icons.Rounded.History, "Recent", "${lib.recent.size}", shape,
                                    Modifier.weight(1f),
                                ) { onOpen(DetailRef(DetailKind.SMART, "recent", "Recently played")) }
                            }
                        }
                    }
                    HomeSection.STATS -> {
                        if (stats.totalPlays > 0) {
                            item(key = "sec_stats") { StatsCard(stats, shape) }
                        }
                    }
                    HomeSection.RECENT -> {
                        if (recent.isNotEmpty()) {
                            item(key = "sec_recent_head") {
                                Text(
                                    "Recently played",
                                    style = MaterialTheme.typography.titleLarge,
                                    modifier = Modifier.padding(horizontal = 4.dp),
                                )
                            }
                            items(recent, key = { "r" + it.id }) { song ->
                                SongRow(song, song.id == currentId, playing) { onPlay(song, recent) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsCard(stats: ListeningStats, shape: RoundedCornerShape) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    Column(
        Modifier.fillMaxWidth().cardFinish(shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("YOUR LISTENING", style = MaterialTheme.typography.labelMedium, color = cs.primary)
        Text(
            fmtLong(stats.totalMs),
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            color = cs.primary,
        )
        Text(
            "about this long, from ${stats.totalPlays} plays of ${stats.distinctSongs} songs",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        if (stats.topArtists.isNotEmpty()) {
            Spacer(Modifier.height(2.dp))
            Text("Top artists", style = MaterialTheme.typography.titleSmall)
            val max = stats.topArtists.first().second.coerceAtLeast(1)
            stats.topArtists.forEach { (name, count) ->
                val frac by animateFloatAsState(
                    targetValue = count.toFloat() / max,
                    animationSpec = motion.spatial(),
                    label = "artistBar",
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            verbatim(name),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(end = 8.dp),
                        )
                        Text("$count", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(cs.primary.copy(alpha = 0.15f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac.coerceIn(0.02f, 1f))
                                .height(8.dp)
                                .clip(CircleShape)
                                .background(cs.primary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MostPlayedCard(top: Song?, count: Int, shape: RoundedCornerShape, onPlay: (Song) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    Row(
        Modifier
            .fillMaxWidth()
            .pressScale(source)
            .cardFinish(shape)
            .clickable(interactionSource = source, indication = LocalIndication.current, enabled = top != null) {
                top?.let(onPlay)
            }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text("MOST PLAYED", style = MaterialTheme.typography.labelMedium, color = cs.primary)
            if (top == null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Listen to a few songs and your favourite will show up here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            } else {
                Spacer(Modifier.height(4.dp))
                Text(verbatim(top.title), style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(verbatim(top.artist), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$count", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = cs.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (count == 1) "time played" else "times played",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 6.dp),
                    )
                }
            }
        }
        if (top != null) {
            Art(top.artUri, Modifier.size(104.dp), RoundedCornerShape(24.dp))
        }
    }
}

@Composable
private fun DailyCard(song: Song, current: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    Column(
        Modifier
            .width(132.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(20.dp))
            .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick),
    ) {
        Art(song.artUri, Modifier.size(132.dp), RoundedCornerShape(20.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            verbatim(song.title),
            style = MaterialTheme.typography.labelLarge,
            color = if (current) cs.primary else cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Text(
            verbatim(song.artist),
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
private fun SmartTile(
    icon: ImageVector,
    title: String,
    count: String,
    shape: RoundedCornerShape,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    Column(
        modifier
            .pressScale(source)
            .cardFinish(shape)
            .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(cs.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(22.dp))
        }
        Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        Text(count, style = MaterialTheme.typography.titleLarge, color = cs.primary)
    }
}
