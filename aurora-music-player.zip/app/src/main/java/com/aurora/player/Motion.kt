package com.aurora.player

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import kotlin.math.max
import kotlin.math.roundToInt

enum class AnimSet(val label: String, val blurb: String) {
    SMOOTH("Smooth", "Gentle, eased motion. The balanced default."),
    BOUNCY("Bouncy", "Springy and playful, with a bit of overshoot."),
    SNAPPY("Snappy", "Fast and crisp. Responds instantly."),
    FLUID("Fluid", "Slow, floaty and soft, like liquid."),
    MINIMAL("Minimal", "Almost no motion. Quick fades only."),
}

/**
 * One animation set. [speed] makes everything faster or slower, [intensity] scales how far and how hard
 * things move (slide distance, squish depth, overshoot, wave height).
 */
@Immutable
class Motion(val set: AnimSet, speed: Float, intensity: Float) {
    private val k = speed.coerceIn(0.3f, 2f)

    /** 0 = barely moves, 1 = full strength, up to 1.5 = extra strong. */
    val amount: Float = intensity.coerceIn(0f, 1.5f)
    val enabled: Boolean = set != AnimSet.MINIMAL

    private fun from(v: Float) = (1f - (1f - v) * amount).coerceIn(0.2f, 1.2f)

    private val damping: Float = run {
        val base = when (set) {
            AnimSet.SMOOTH -> 0.9f
            AnimSet.BOUNCY -> 0.55f
            AnimSet.SNAPPY -> 0.85f
            AnimSet.FLUID -> 0.75f
            AnimSet.MINIMAL -> 1f
        }
        (base + (1f - base) * (1f - amount).coerceIn(0f, 1f)).coerceIn(0.3f, 1f)
    }
    private val stiffness: Float = when (set) {
        AnimSet.SMOOTH -> 260f
        AnimSet.BOUNCY -> 220f
        AnimSet.SNAPPY -> 600f
        AnimSet.FLUID -> 90f
        AnimSet.MINIMAL -> 1200f
    } * k * k
    private val fadeMs = when (set) {
        AnimSet.SMOOTH -> 320
        AnimSet.BOUNCY -> 280
        AnimSet.SNAPPY -> 160
        AnimSet.FLUID -> 560
        AnimSet.MINIMAL -> 100
    }

    val staggerMs: Int = when (set) {
        AnimSet.SMOOTH -> 30
        AnimSet.BOUNCY -> 40
        AnimSet.SNAPPY -> 16
        AnimSet.FLUID -> 55
        AnimSet.MINIMAL -> 0
    }
    val pressScale: Float = run {
        val base = when (set) {
            AnimSet.SMOOTH -> 0.94f
            AnimSet.BOUNCY -> 0.86f
            AnimSet.SNAPPY -> 0.96f
            AnimSet.FLUID -> 0.92f
            AnimSet.MINIMAL -> 1f
        }
        1f - (1f - base) * amount
    }
    val waveSpeed: Float = when (set) {
        AnimSet.SMOOTH -> 0.7f
        AnimSet.BOUNCY -> 1f
        AnimSet.SNAPPY -> 1.3f
        AnimSet.FLUID -> 0.45f
        AnimSet.MINIMAL -> 0f
    } * k
    val waveAmp: Float = (0.35f + 0.65f * amount).coerceIn(0.2f, 1.3f)
    /** Slide distance multiplier for list rows and icons. */
    val travel: Float = amount.coerceIn(0f, 1.3f)

    /** Spring used for size, position, shape and scale. */
    fun <T> spatial(): FiniteAnimationSpec<T> =
        spring<T>(dampingRatio = damping, stiffness = stiffness.coerceAtLeast(30f))

    /** Tween used for fades and colour changes. */
    fun <T> effects(): FiniteAnimationSpec<T> =
        tween<T>(durationMillis = max(1, (fadeMs / k).roundToInt()), easing = FastOutSlowInEasing)

    fun tab(forward: Boolean): ContentTransform {
        val dir = if (forward) 1 else -1
        val d = travel
        return when (set) {
            AnimSet.MINIMAL -> fadeIn(effects()) togetherWith fadeOut(effects())
            AnimSet.SNAPPY ->
                (slideInHorizontally(spatial()) { (it * dir * 0.3f * d).toInt() } + fadeIn(effects())) togetherWith
                    (slideOutHorizontally(spatial()) { (-it * dir * 0.3f * d).toInt() } + fadeOut(effects()))
            AnimSet.BOUNCY ->
                (slideInHorizontally(spatial()) { (it * dir * 0.2f * d).toInt() } + fadeIn(effects()) + scaleIn(spatial(), from(0.9f))) togetherWith
                    (fadeOut(effects()) + scaleOut(effects(), from(0.95f)))
            AnimSet.FLUID ->
                (slideInVertically(spatial()) { (it * 0.06f * d).toInt() } + fadeIn(effects()) + scaleIn(spatial(), from(0.96f))) togetherWith
                    (slideOutVertically(effects()) { (-it * 0.04f * d).toInt() } + fadeOut(effects()))
            AnimSet.SMOOTH ->
                (slideInHorizontally(spatial()) { (it * dir * 0.18f * d).toInt() } + fadeIn(effects())) togetherWith
                    (slideOutHorizontally(spatial()) { (-it * dir * 0.18f * d).toInt() } + fadeOut(effects()))
        }
    }

    fun songChange(): ContentTransform =
        if (!enabled) {
            fadeIn(effects()) togetherWith fadeOut(effects())
        } else {
            (fadeIn(effects()) + scaleIn(spatial(), from(0.88f))) togetherWith
                (fadeOut(effects()) + scaleOut(effects(), 1f + (1f - from(0.92f))))
        }

    fun text(): ContentTransform =
        if (!enabled) {
            fadeIn(effects()) togetherWith fadeOut(effects())
        } else {
            (slideInVertically(spatial()) { (it * 0.35f * travel).toInt() } + fadeIn(effects())) togetherWith
                (slideOutVertically(effects()) { (-it * 0.35f * travel).toInt() } + fadeOut(effects()))
        }

    fun miniEnter(): EnterTransition = slideInVertically(spatial()) { it } + fadeIn(effects())
    fun miniExit(): ExitTransition = slideOutVertically(effects()) { it } + fadeOut(effects())
}

val LocalMotion = staticCompositionLocalOf { Motion(AnimSet.SMOOTH, 0.8f, 0.5f) }
