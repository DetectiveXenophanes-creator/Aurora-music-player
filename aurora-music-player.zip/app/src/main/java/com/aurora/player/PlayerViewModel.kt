package com.aurora.player

import android.app.Application
import android.content.ComponentName
import android.content.IntentSender
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

data class PlayerUi(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val duration: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val audioInfo: String = "",
)

private data class LibraryFilter(val minSec: Int, val excluded: Set<String>)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val libStore = LibraryStore(app)

    private val _loaded = MutableStateFlow(false)
    val settingsLoaded: StateFlow<Boolean> = _loaded.asStateFlow()
    val settings: StateFlow<AppSettings> = store.flow
        .onEach { _loaded.value = true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val library: StateFlow<LibraryData> =
        libStore.flow.stateIn(viewModelScope, SharingStarted.Eagerly, LibraryData())

    private val allSongsFlow = MutableStateFlow<List<Song>>(emptyList())
    /** Everything MediaStore found, before folder and length filters. */
    val allSongs: StateFlow<List<Song>> = allSongsFlow.asStateFlow()

    val songs: StateFlow<List<Song>> = combine(
        allSongsFlow,
        settings.map { LibraryFilter(it.minDurationSec, it.excludedFolders) }.distinctUntilChanged(),
    ) { all, f ->
        all.filter { it.durationMs >= f.minSec * 1000L && it.folder !in f.excluded }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _ui = MutableStateFlow(PlayerUi())
    val ui = _ui.asStateFlow()
    private val _position = MutableStateFlow(0L)
    val position = _position.asStateFlow()
    private val _detail = MutableStateFlow<DetailRef?>(null)
    val detail = _detail.asStateFlow()
    private val _sleepLeft = MutableStateFlow<Long?>(null)
    val sleepLeft = _sleepLeft.asStateFlow()

    private var controller: MediaController? = null
    private var songMap: Map<Long, Song> = emptyMap()
    private var countedId: Long? = null
    private var sleepJob: Job? = null
    private var loadedOnce = false

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                sync(c)
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(400)
                val c = controller
                if (c != null && c.isPlaying) {
                    val p = c.currentPosition
                    _position.value = p
                    countPlay(c, p)
                }
            }
        }

        viewModelScope.launch {
            settings.map { it.includeNonMusic }.distinctUntilChanged().drop(1).collect {
                if (loadedOnce) loadSongs()
            }
        }
    }

    /** A play counts once 30 seconds (or half the song, if shorter) have been listened to. */
    private fun countPlay(c: Player, pos: Long) {
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        if (pos < 2000 && countedId == id) countedId = null
        if (countedId == id) return
        val d = c.duration
        val threshold = if (d > 0) minOf(30_000L, d / 2) else 30_000L
        if (pos >= threshold) {
            countedId = id
            viewModelScope.launch { libStore.recordPlay(id) }
        }
    }

    private fun formatName(mime: String?): String = when (mime) {
        null -> ""
        "audio/mpeg" -> "MP3"
        "audio/flac" -> "FLAC"
        "audio/mp4a-latm" -> "AAC"
        "audio/vorbis" -> "OGG"
        "audio/opus" -> "OPUS"
        "audio/raw" -> "WAV"
        else -> mime.substringAfter('/').uppercase()
    }

    private fun audioInfo(p: Player, song: Song?): String {
        var rate = 0
        var kbps = 0
        var mime: String? = null
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (g.isTrackSelected(i)) {
                    val f = g.getTrackFormat(i)
                    if (f.sampleRate > 0) rate = f.sampleRate
                    val br = maxOf(f.bitrate, f.averageBitrate)
                    if (br > 0) kbps = br / 1000
                    mime = f.sampleMimeType ?: f.containerMimeType
                }
            }
        }
        if (kbps == 0) kbps = song?.bitrateKbps ?: 0
        val parts = mutableListOf<String>()
        if (rate > 0) parts += "%.1f kHz".format(rate / 1000f)
        if (kbps > 0) parts += "$kbps kbps"
        val name = formatName(mime)
        if (name.isNotEmpty()) parts += name
        return parts.joinToString(" • ")
    }

    private fun sync(p: Player) {
        val id = p.currentMediaItem?.mediaId?.toLongOrNull()
        val song = id?.let { songMap[it] }
        _ui.value = PlayerUi(
            current = song,
            isPlaying = p.isPlaying,
            duration = p.duration.coerceAtLeast(0L),
            shuffle = p.shuffleModeEnabled,
            repeat = p.repeatMode,
            audioInfo = audioInfo(p, song),
        )
        _position.value = p.currentPosition
    }

    fun loadSongs() {
        viewModelScope.launch {
            try {
                val list = MusicRepository.load(getApplication(), settings.value.includeNonMusic)
                songMap = list.associateBy { it.id }
                allSongsFlow.value = list
                loadedOnce = true
                controller?.let { sync(it) }
            } catch (_: SecurityException) {
            }
        }
    }

    // ------------------------------------------------------------ playback

    fun play(song: Song, queue: List<Song>) {
        val c = controller ?: return
        val index = queue.indexOf(song).coerceAtLeast(0)
        c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playAll(list: List<Song>) {
        if (list.isNotEmpty()) play(list.first(), list)
    }

    fun shuffleAll(list: List<Song>) {
        if (list.isEmpty()) return
        val q = list.shuffled()
        play(q.first(), q)
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(song, listOf(song))
        else c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(song, listOf(song)) else c.addMediaItem(song.toMediaItem())
    }

    fun queueSnapshot(): List<Song> {
        val c = controller ?: return emptyList()
        return (0 until c.mediaItemCount).mapNotNull { i ->
            c.getMediaItemAt(i).mediaId.toLongOrNull()?.let { songMap[it] }
        }
    }

    fun currentIndex(): Int = controller?.currentMediaItemIndex ?: 0

    fun jumpTo(index: Int) {
        val c = controller ?: return
        c.seekToDefaultPosition(index)
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms); _position.value = ms }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) {
            _sleepLeft.value = null
            return
        }
        sleepJob = viewModelScope.launch {
            var left = minutes * 60_000L
            while (left > 0) {
                _sleepLeft.value = left
                delay(1000)
                left -= 1000
            }
            controller?.pause()
            _sleepLeft.value = null
        }
    }

    // ------------------------------------------------------------ navigation and settings

    fun openDetail(ref: DetailRef) { _detail.value = ref }
    fun closeDetail() { _detail.value = null }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { store.update(transform) }
    }

    // ------------------------------------------------------------ library

    fun toggleFavorite(id: Long) {
        viewModelScope.launch { libStore.toggleFavorite(id) }
    }

    fun createPlaylist(name: String, withSongs: List<Long> = emptyList()): String {
        val id = newPlaylistId()
        viewModelScope.launch {
            libStore.editPlaylists { it + Playlist(id, name.trim().ifBlank { "New playlist" }, withSongs.distinct()) }
        }
        return id
    }

    fun addSongsToPlaylist(id: String, songIds: List<Long>) {
        updatePlaylist(id) { pl -> pl.copy(songIds = pl.songIds + songIds.filter { it !in pl.songIds }.distinct()) }
    }

    // ------------------------------------------------------------ deleting songs from the phone

    /** Android 11+: a system confirmation dialog that deletes the files. Null on older versions. */
    fun deleteIntent(songs: List<Song>): IntentSender? {
        if (Build.VERSION.SDK_INT < 30 || songs.isEmpty()) return null
        return runCatching {
            MediaStore.createDeleteRequest(getApplication<Application>().contentResolver, songs.map { it.uri }).intentSender
        }.getOrNull()
    }

    /** Android 10 and older: delete directly. Returns the ids that were really deleted. */
    suspend fun deleteLegacy(songs: List<Song>): Set<Long> = withContext(Dispatchers.IO) {
        val resolver = getApplication<Application>().contentResolver
        songs.filter { s -> runCatching { resolver.delete(s.uri, null, null) > 0 }.getOrDefault(false) }
            .map { it.id }
            .toSet()
    }

    /** Call after the files are gone: drop them from the queue, playlists and favorites, then rescan. */
    fun songsDeleted(ids: Set<Long>) {
        controller?.let { c ->
            for (i in c.mediaItemCount - 1 downTo 0) {
                val id = c.getMediaItemAt(i).mediaId.toLongOrNull()
                if (id != null && id in ids) c.removeMediaItem(i)
            }
        }
        viewModelScope.launch { libStore.removeSongs(ids) }
        loadSongs()
    }

    fun updatePlaylist(id: String, transform: (Playlist) -> Playlist) {
        viewModelScope.launch {
            libStore.editPlaylists { list -> list.map { if (it.id == id) transform(it) else it } }
        }
    }

    fun deletePlaylist(id: String) {
        viewModelScope.launch { libStore.editPlaylists { list -> list.filter { it.id != id } } }
    }

    fun addToPlaylist(id: String, songId: Long) {
        updatePlaylist(id) { if (songId in it.songIds) it else it.copy(songIds = it.songIds + songId) }
    }

    fun removeFromPlaylist(id: String, songId: Long) {
        updatePlaylist(id) { it.copy(songIds = it.songIds - songId) }
    }

    // ------------------------------------------------------------ backup and restore

    /** Playlists (with their songs listed by name, not the audio files), favorites and every setting, as JSON. */
    suspend fun createBackup(): String {
        val lib = library.value
        val byId = allSongsFlow.value.associateBy { it.id }
        fun ref(id: Long): JSONObject {
            val song = byId[id]
            return JSONObject()
                .put("id", id)
                .put("title", song?.title ?: "")
                .put("artist", song?.artist ?: "")
                .put("dur", song?.durationMs ?: 0L)
        }
        val playlists = JSONArray()
        lib.playlists.forEach { p ->
            val songs = JSONArray()
            p.songIds.forEach { songs.put(ref(it)) }
            playlists.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("accent", p.accent)
                    .put("icon", p.icon)
                    .put("cover", p.cover.name)
                    .put("shape", p.shape.name)
                    .put("feel", p.feel.name)
                    .put("response", p.response.toDouble())
                    .put("songs", songs)
            )
        }
        val favorites = JSONArray()
        lib.favorites.forEach { favorites.put(ref(it)) }
        return JSONObject()
            .put("app", "Aurora")
            .put("version", 1)
            .put("created", System.currentTimeMillis())
            .put("settings", store.exportJson())
            .put("playlists", playlists)
            .put("favorites", favorites)
            .toString(2)
    }

    /** Merges the playlists in a backup into this phone's library and restores its settings. */
    suspend fun restoreBackup(text: String): String {
        val root = try {
            JSONObject(text)
        } catch (e: Exception) {
            return "That file is not an Aurora backup."
        }
        if (root.optString("app") != "Aurora") return "That file is not an Aurora backup."

        val songs = allSongsFlow.value
        val byId = songs.associateBy { it.id }
        var matched = 0
        var missing = 0

        fun resolve(o: JSONObject): Long? {
            val id = o.optLong("id", -1L)
            val title = o.optString("title")
            val artist = o.optString("artist")
            val dur = o.optLong("dur", 0L)
            val same = byId[id]
            if (same != null && (title.isEmpty() || same.title.equals(title, true))) return same.id
            if (title.isEmpty()) return null
            return songs.firstOrNull {
                it.title.equals(title, true) && it.artist.equals(artist, true) && abs(it.durationMs - dur) < 3000
            }?.id ?: songs.firstOrNull {
                it.title.equals(title, true) && abs(it.durationMs - dur) < 3000
            }?.id
        }

        val incoming = mutableListOf<Playlist>()
        val arr = root.optJSONArray("playlists")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ids = mutableListOf<Long>()
                val sa = o.optJSONArray("songs")
                if (sa != null) {
                    for (j in 0 until sa.length()) {
                        val r = resolve(sa.getJSONObject(j))
                        if (r != null) { ids += r; matched++ } else missing++
                    }
                }
                incoming += Playlist(
                    id = o.getString("id"),
                    name = o.optString("name", "Playlist"),
                    songIds = ids,
                    accent = o.optInt("accent", 0),
                    icon = o.optInt("icon", 0),
                    cover = CoverStyle.entries.firstOrNull { it.name == o.optString("cover") } ?: CoverStyle.MOSAIC,
                    shape = PlaylistShape.entries.firstOrNull { it.name == o.optString("shape") } ?: PlaylistShape.SOFT,
                    feel = PlaylistFeel.entries.firstOrNull { it.name == o.optString("feel") } ?: PlaylistFeel.SQUISH,
                    response = o.optDouble("response", 0.6).toFloat(),
                )
            }
        }
        val incomingIds = incoming.map { it.id }.toSet()
        libStore.editPlaylists { cur -> cur.filter { it.id !in incomingIds } + incoming }

        val favs = mutableSetOf<Long>()
        val fa = root.optJSONArray("favorites")
        if (fa != null) {
            for (i in 0 until fa.length()) resolve(fa.getJSONObject(i))?.let { favs += it }
        }
        if (favs.isNotEmpty()) libStore.addFavorites(favs)

        val settingsRestored = root.optJSONObject("settings")?.let { store.importJson(it); true } ?: false

        val note = if (songs.isEmpty()) " Your music library was not loaded, so songs could not be matched." else ""
        return "Restored ${incoming.size} playlists ($matched songs matched, $missing not found on this phone)" +
            (if (settingsRestored) " and your settings." else ".") + note
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
