package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin
import kotlin.random.Random

private const val FLY_COUNT = 28
private const val RAIN_COUNT = 46
private const val DROP_COUNT = 6

/**
 * A scene behind the player (Settings > Player look). Spotlight, Fireflies and Rain are drawn on one canvas in their own
 * graphics layer, from a clock that ticks 20 times a second, stops while the app is off screen or a list scrolls, and
 * does not run at all while [running] is false. Brushes are built once and moved while drawing, and the particles'
 * starting values are made once, so a tick allocates nothing. Colour wash draws no clock at all.
 */
@Composable
fun StageBackground(stage: NpStage, song: Song?, running: Boolean, modifier: Modifier = Modifier.fillMaxSize()) {
    if (stage == NpStage.NONE) return
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val paused = LocalBackgroundPaused.current
    val live = running && !paused && !s.batterySaver && LocalMotion.current.enabled && stage != NpStage.WASH
    val clock = rememberThrottledClock(live, 20)
    val primary = cs.primary
    val tertiary = cs.tertiary
    val blend = if (dark) BlendMode.Plus else BlendMode.SrcOver
    val k = if (dark) 1f else 0.7f
    when (stage) {
        NpStage.NONE -> Unit
        NpStage.SPOTLIGHT -> {
            val beam = remember { Path().apply { moveTo(0f, 0f); lineTo(-0.5f, 1f); lineTo(0.5f, 1f); close() } }
            val brushes = remember(primary, tertiary) { listOf(unitBeam(primary), unitBeam(tertiary)) }
            Canvas(modifier.graphicsLayer { }) {
                val t = clock.value
                val w = size.width
                val h = size.height
                for (i in 0 until 2) {
                    val x = w * (if (i == 0) 0.28f else 0.72f) + w * 0.06f * sin(t * 0.35f + i * 2.4f)
                    val angle = (if (i == 0) 14f else -14f) + 9f * sin(t * 0.5f + i * 1.9f)
                    withTransform({
                        translate(x, -h * 0.05f)
                        rotate(angle, Offset.Zero)
                        scale(w * 0.75f, h * 1.1f, Offset.Zero)
                    }) {
                        drawPath(beam, brushes[i], alpha = 0.26f * k, blendMode = blend)
                    }
                }
            }
        }
        NpStage.FIREFLIES -> {
            val seeds = remember { seedArray(FLY_COUNT * 5, 11) }
            val glows = remember(primary, tertiary) { listOf(unitGlowBrush(primary), unitGlowBrush(tertiary)) }
            Canvas(modifier.graphicsLayer { }) {
                val t = clock.value
                val w = size.width
                val h = size.height
                for (i in 0 until FLY_COUNT) {
                    val b = i * 5
                    val x = seeds[b] * w + sin(t * (0.15f + seeds[b + 2] * 0.25f) + seeds[b + 3] * STAGE_TWO_PI) * w * 0.04f
                    var yy = seeds[b + 1] - t * (0.012f + seeds[b + 2] * 0.02f)
                    yy -= floor(yy)
                    val twinkle = 0.5f + 0.5f * sin(t * (0.8f + seeds[b + 2]) + seeds[b + 3] * 9f)
                    val r = (5f + seeds[b + 4] * 8f).dp.toPx()
                    withTransform({
                        translate(x, yy * h)
                        scale(r, r, Offset.Zero)
                    }) {
                        drawCircle(
                            glows[i % 2],
                            radius = 1f,
                            center = Offset.Zero,
                            alpha = (0.22f + 0.6f * twinkle) * k,
                            blendMode = blend,
                        )
                    }
                }
            }
        }
        NpStage.RAIN -> {
            val streaks = remember { seedArray(RAIN_COUNT * 4, 23) }
            val drops = remember { seedArray(DROP_COUNT * 4, 37) }
            val streak = remember(primary, dark) { if (dark) lerp(primary, Color.White, 0.65f) else primary }
            Canvas(modifier.graphicsLayer { }) {
                val t = clock.value
                val w = size.width
                val h = size.height
                val slant = 0.22f
                val width = 1.4f.dp.toPx()
                for (i in 0 until RAIN_COUNT) {
                    val b = i * 4
                    val speed = 0.35f + streaks[b + 2] * 0.45f
                    var yy = streaks[b + 1] + t * speed
                    yy -= floor(yy)
                    val len = (14f + streaks[b + 3] * 22f).dp.toPx()
                    val y = yy * (h + len) - len
                    val x = streaks[b] * (w + h * slant) - h * slant * yy
                    drawLine(
                        streak,
                        Offset(x, y),
                        Offset(x - len * slant, y + len),
                        strokeWidth = width,
                        cap = StrokeCap.Round,
                        alpha = (0.12f + 0.2f * streaks[b + 3]) * k,
                    )
                }
                drawDrops(drops, t, w, h, streak, k)
            }
        }
        NpStage.WASH -> {
            val bg = cs.background
            val uri = song?.artUri
            Box(modifier) {
                if (uri != null) {
                    Art(
                        uri,
                        Modifier.fillMaxSize().graphicsLayer {
                            scaleX = 1.9f
                            scaleY = 1.9f
                            alpha = 0.3f
                        },
                        RectangleShape,
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(primary.copy(alpha = 0.18f), Color.Transparent))))
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg.copy(alpha = 0.15f), bg.copy(alpha = 0.85f)))))
            }
        }
    }
}

private const val STAGE_TWO_PI = 2f * PI.toFloat()

/** Plain random numbers between 0 and 1, the same every run, made once so the particles keep their places. */
private fun seedArray(n: Int, seed: Int): FloatArray {
    val r = Random(seed)
    return FloatArray(n) { r.nextFloat() }
}

/** A beam of light one unit long, strongest at the top and gone at the bottom. */
private fun unitBeam(c: Color): Brush =
    Brush.verticalGradient(listOf(c.copy(alpha = 1f), Color.Transparent), startY = 0f, endY = 1f)

/** A soft ball one unit big, fading to nothing at the edge. */
private fun unitGlowBrush(c: Color): Brush =
    Brush.radialGradient(listOf(c.copy(alpha = 1f), Color.Transparent), center = Offset.Zero, radius = 1f)

/** A few big slow drops sliding down the glass, each with a small highlight. */
private fun DrawScope.drawDrops(drops: FloatArray, t: Float, w: Float, h: Float, color: Color, k: Float) {
    for (i in 0 until DROP_COUNT) {
        val b = i * 4
        var yy = drops[b + 1] + t * (0.012f + drops[b + 2] * 0.014f)
        yy -= floor(yy)
        val r = (4f + drops[b + 3] * 4f).dp.toPx()
        val c = Offset(drops[b] * w, yy * h)
        drawCircle(color, radius = r, center = c, alpha = 0.12f * k)
        drawCircle(Color.White, radius = r * 0.3f, center = Offset(c.x - r * 0.3f, c.y - r * 0.3f), alpha = 0.3f * k)
    }
}
