package com.aurora.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.FrameMetrics
import android.view.Window
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView

private val NotScrolling: State<Boolean> = mutableStateOf(false)

/**
 * True while a page is being scrolled (and for a moment after). Decorative clocks (the moving backdrop, glows, the edge
 * light) wait while it is true, so every frame goes to the scroll itself. It holds the State itself, not its value, so
 * the screen that provides it never recomposes when it flips; only the small animated pieces that read it do.
 */
val LocalScrolling = compositionLocalOf<State<Boolean>> { NotScrolling }

/** What Auto smooth has found out in this session. */
object SmoothState {
    /** True once the screen kept dropping frames; Auto then runs in Lite until you open the app again or pick Full. */
    var struggling by mutableStateOf(false)
}

// A frame that takes longer than this missed at least one refresh on a 60 Hz screen (and is clearly late on faster ones).
private const val JANK_NS = 24_000_000L
// A window is two seconds of drawing. It counts as bad when at least this share of its frames were late.
private const val WINDOW_NS = 2_000_000_000L
private const val MIN_FRAMES = 40
private const val JANK_PERCENT = 18
// Three bad windows in a row (six seconds of real stutter) before anything is switched off, so one heavy moment
// (opening the app, a big list loading) never counts.
private const val BAD_WINDOWS = 3

/**
 * Listens to Android's own frame timings. It is passive: it only receives the frames that are drawn anyway and never
 * asks for extra ones, so it costs nothing while the screen is still.
 */
private class FrameWatch(private val onStruggle: () -> Unit) : Window.OnFrameMetricsAvailableListener {
    private var windowStart = 0L
    private var frames = 0
    private var janky = 0
    private var bad = 0

    override fun onFrameMetricsAvailable(window: Window, frameMetrics: FrameMetrics, dropCountSinceLastInvocation: Int) {
        // the very first frame of a window always takes long (everything is set up), it says nothing about smoothness
        if (frameMetrics.getMetric(FrameMetrics.FIRST_DRAW_FRAME) == 1L) return
        val now = System.nanoTime()
        if (windowStart == 0L) windowStart = now
        frames++
        if (frameMetrics.getMetric(FrameMetrics.TOTAL_DURATION) > JANK_NS) janky++
        if (now - windowStart >= WINDOW_NS) {
            bad = if (frames >= MIN_FRAMES && janky * 100 >= frames * JANK_PERCENT) bad + 1 else 0
            frames = 0
            janky = 0
            windowStart = now
            if (bad >= BAD_WINDOWS) {
                bad = 0
                onStruggle()
            }
        }
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** While [enabled], watches the frame rate and sets [SmoothState.struggling] when the screen keeps stuttering. */
@Composable
fun rememberFrameWatch(enabled: Boolean) {
    val view = LocalView.current
    DisposableEffect(enabled, view) {
        val window = view.context.findActivity()?.window
        if (!enabled || window == null) return@DisposableEffect onDispose { }
        val thread = HandlerThread("aurora-frames").apply { start() }
        val main = Handler(Looper.getMainLooper())
        val watch = FrameWatch { main.post { SmoothState.struggling = true } }
        window.addOnFrameMetricsAvailableListener(watch, Handler(thread.looper))
        onDispose {
            window.removeOnFrameMetricsAvailableListener(watch)
            thread.quitSafely()
        }
    }
}
