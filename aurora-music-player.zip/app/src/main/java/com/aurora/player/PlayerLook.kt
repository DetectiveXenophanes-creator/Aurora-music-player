package com.aurora.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// =====================================================================================================================
// Player look (3.10.0): how the Now Playing screen looks. Everything is Standard or off until you pick something.
// =====================================================================================================================

/** The look of the previous, play and next buttons. The pill row (shuffle, repeat, favourite) is not changed. */
enum class ControlSkin(val label: String, val blurb: String) {
    STANDARD("Standard", "The buttons Aurora already has."),
    KEYS("Piano keys", "Previous and next are white keys, play is a black key that glows while music plays."),
    TAPE("Tape deck", "Chunky beveled buttons that press in, and Play stays pressed down while music plays."),
    GLASS("Glass", "Frosted see-through pills with a bright edge."),
    KNOB("Dial knob", "A big dial with tick marks for play, small round knobs for previous and next."),
}

/** The look of the song title. */
enum class TitleStyle(val label: String, val blurb: String) {
    STANDARD("Standard", "The normal title."),
    POSTER("Poster", "Big, heavy capitals with the words stacked on two lines."),
    HANDWRITTEN("Handwritten", "A flowing handwriting font."),
    OUTLINE("Outline", "Hollow letters drawn only as an outline in the theme colour."),
    SPACED("Spaced", "Small capitals with wide space between the letters."),
}

/** Where the title and the artist sit. Auto keeps what the player design does by itself. */
enum class TitleAlign(val label: String) {
    AUTO("Auto"), LEFT("Left"), CENTER("Centre"), RIGHT("Right"),
}

/** The three blocks under the cover that the layout composer can put in any order. */
enum class NpSection(val label: String) {
    TITLE("Title"), SEEK("Seek bar"), CONTROLS("Buttons"),
}

/** How much of its space the cover takes. Large also trims the gaps around the cover so it gets every spare pixel. */
enum class CoverSize(val label: String, val scale: Float, val tight: Boolean) {
    SMALL("Small", 0.78f, false),
    MEDIUM("Medium", 1f, false),
    LARGE("Large", 1f, true),
}

/** How much air there is between the blocks. Normal is exactly what the player had before. */
enum class NpDensity(val label: String, val factor: Float) {
    COMPACT("Compact", 0.5f),
    NORMAL("Normal", 1f),
    ROOMY("Roomy", 1.6f),
}

/** A moving scene drawn behind the player. */
enum class NpStage(val label: String, val blurb: String) {
    NONE("None", "Just your normal background."),
    SPOTLIGHT("Spotlight", "Two soft beams of light sway down from the top."),
    FIREFLIES("Fireflies", "Small glowing lights drift slowly upwards."),
    RAIN("Rain", "Thin streaks of rain and a few slow drops on the glass."),
    WASH("Colour wash", "The cover, huge and faint, fills the screen behind the player."),
}

const val DEFAULT_NP_ORDER = "TITLE,SEEK,CONTROLS"

// ---------------------------------------------------------------- layout order

/** Turns the stored text into a valid order: unknown or repeated names are dropped, missing blocks are added at the end. */
fun parseOrder(raw: String): List<NpSection> {
    val out = ArrayList<NpSection>(3)
    for (part in raw.split(',')) {
        val sec = NpSection.entries.firstOrNull { it.name == part.trim() }
        if (sec != null && sec !in out) out.add(sec)
    }
    for (sec in NpSection.entries) {
        if (sec !in out) out.add(sec)
    }
    return out
}

fun encodeOrder(list: List<NpSection>): String = list.joinToString(",") { it.name }

/** Always returns a text that parseOrder reads back as the same valid order. */
fun repairOrder(raw: String): String = encodeOrder(parseOrder(raw))

/** Moves one block up (delta -1) or down (delta 1). Returns the text unchanged when it cannot move. */
fun moveNpSection(raw: String, sec: NpSection, delta: Int): String {
    val list = parseOrder(raw).toMutableList()
    val from = list.indexOf(sec)
    val to = from + delta
    if (from < 0 || to < 0 || to >= list.size) return encodeOrder(list)
    val other = list[to]
    list[to] = sec
    list[from] = other
    return encodeOrder(list)
}

// ---------------------------------------------------------------- title

internal fun TitleAlign.textAlign(defaultCenter: Boolean): TextAlign = when (this) {
    TitleAlign.AUTO -> if (defaultCenter) TextAlign.Center else TextAlign.Start
    TitleAlign.LEFT -> TextAlign.Start
    TitleAlign.CENTER -> TextAlign.Center
    TitleAlign.RIGHT -> TextAlign.End
}

internal fun TitleAlign.horizontal(defaultCenter: Boolean): Alignment.Horizontal = when (this) {
    TitleAlign.AUTO -> if (defaultCenter) Alignment.CenterHorizontally else Alignment.Start
    TitleAlign.LEFT -> Alignment.Start
    TitleAlign.CENTER -> Alignment.CenterHorizontally
    TitleAlign.RIGHT -> Alignment.End
}

/** Puts the words on two lines, about half each: "Dancing in the Dark" becomes "Dancing in" and "the Dark". */
internal fun stackWords(text: String): String {
    val words = text.trim().split(' ').filter { it.isNotEmpty() }
    if (words.size < 2) return text
    val cut = (words.size + 1) / 2
    return words.subList(0, cut).joinToString(" ") + "\n" + words.subList(cut, words.size).joinToString(" ")
}

/**
 * The song title in the chosen style. [base] is the size the player design uses; with Standard the result is exactly
 * what the players drew before. A null [title] means nothing is playing.
 */
@Composable
internal fun StyledTitle(
    title: String?,
    base: TextStyle,
    style: TitleStyle,
    align: TextAlign,
    weight: FontWeight,
    marquee: Boolean,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    if (title == null) {
        Text(
            "Nothing playing",
            style = base,
            fontWeight = weight,
            textAlign = align,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier,
        )
        return
    }
    val px = with(LocalDensity.current) { 1.6f.dp.toPx() }
    when (style) {
        TitleStyle.STANDARD -> Text(
            verbatim(title),
            style = base,
            fontWeight = weight,
            textAlign = align,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            modifier = modifier.titleMarquee(marquee),
        )
        TitleStyle.POSTER -> Text(
            verbatim(stackWords(title.uppercase())),
            style = base,
            fontSize = base.fontSize * 1.25f,
            lineHeight = base.fontSize * 1.2f,
            fontWeight = FontWeight.Black,
            letterSpacing = (-0.5f).sp,
            textAlign = align,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier,
        )
        TitleStyle.HANDWRITTEN -> Text(
            verbatim(title),
            style = base,
            fontSize = base.fontSize * 1.3f,
            fontFamily = FontFamily.Cursive,
            fontWeight = FontWeight.SemiBold,
            textAlign = align,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            modifier = modifier.titleMarquee(marquee),
        )
        TitleStyle.OUTLINE -> Text(
            verbatim(title),
            style = base.merge(TextStyle(drawStyle = Stroke(width = px, join = StrokeJoin.Round))),
            color = cs.primary,
            fontWeight = FontWeight.Black,
            textAlign = align,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            modifier = modifier.titleMarquee(marquee),
        )
        TitleStyle.SPACED -> Text(
            verbatim(title.uppercase()),
            style = base,
            fontSize = base.fontSize * 0.8f,
            letterSpacing = 3.5f.sp,
            fontWeight = FontWeight.Medium,
            textAlign = align,
            maxLines = 1,
            overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            modifier = modifier.titleMarquee(marquee),
        )
    }
}

/** The artist line, either plain text or inside a small rounded chip. */
@Composable
internal fun StyledArtist(
    artist: String,
    base: TextStyle,
    color: Color,
    align: TextAlign,
    chip: Boolean,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    if (chip && artist.isNotEmpty()) {
        Text(
            verbatim(artist),
            style = base,
            color = cs.onPrimaryContainer,
            textAlign = align,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier
                .clip(RoundedCornerShape(percent = 50))
                .background(cs.primaryContainer.copy(alpha = 0.75f))
                .padding(horizontal = 14.dp, vertical = 4.dp),
        )
    } else {
        Text(
            if (artist.isEmpty()) "" else verbatim(artist),
            style = base,
            color = color,
            textAlign = align,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier,
        )
    }
}

// ---------------------------------------------------------------- control skins

private val KeyDark = Color(0xFF222226)

/**
 * The play button in the chosen skin. Size comes from [modifier]. With Standard it is the normal [PlayPauseButton].
 * The settings preview uses this same composable.
 */
@Composable
internal fun SkinPlay(skin: ControlSkin, playing: Boolean, onClick: () -> Unit, modifier: Modifier, iconSize: Dp) {
    val cs = MaterialTheme.colorScheme
    when (skin) {
        ControlSkin.STANDARD -> PlayPauseButton(playing = playing, onClick = onClick, modifier = modifier, iconSize = iconSize)
        ControlSkin.KEYS -> PianoKey(black = true, lit = playing, modifier = modifier, onClick = onClick) {
            PlayPauseIcon(playing, Color.White, iconSize)
        }
        ControlSkin.TAPE -> TapeButton(latched = playing, modifier = modifier, onClick = onClick) {
            PlayPauseIcon(playing, if (playing) cs.onPrimary else KeyDark, iconSize)
        }
        ControlSkin.GLASS -> GlassButton(tinted = playing, modifier = modifier, onClick = onClick) {
            PlayPauseIcon(playing, cs.onSurface, iconSize)
        }
        ControlSkin.KNOB -> KnobPlay(playing = playing, modifier = modifier, onClick = onClick, iconSize = iconSize)
    }
}

/** The previous or next button in the chosen skin. Size comes from [modifier]. */
@Composable
internal fun SkinSkip(skin: ControlSkin, forward: Boolean, onClick: () -> Unit, modifier: Modifier, iconSize: Dp) {
    val cs = MaterialTheme.colorScheme
    val icon = if (forward) Icons.Rounded.SkipNext else Icons.Rounded.SkipPrevious
    val description = if (forward) "Next" else "Previous"
    when (skin) {
        ControlSkin.STANDARD -> SkipButton(forward = forward, onClick = onClick, modifier = modifier, iconSize = iconSize)
        ControlSkin.KEYS -> PianoKey(black = false, lit = false, modifier = modifier, onClick = onClick) {
            Icon(icon, description, tint = KeyDark, modifier = Modifier.size(iconSize))
        }
        ControlSkin.TAPE -> TapeButton(latched = false, modifier = modifier, onClick = onClick) {
            Icon(icon, description, tint = KeyDark, modifier = Modifier.size(iconSize))
        }
        ControlSkin.GLASS -> GlassButton(tinted = false, modifier = modifier, onClick = onClick) {
            Icon(icon, description, tint = cs.onSurface, modifier = Modifier.size(iconSize))
        }
        ControlSkin.KNOB -> KnobSkip(modifier = modifier, onClick = onClick) {
            Icon(icon, description, tint = KeyDark, modifier = Modifier.size(iconSize * 0.8f))
        }
    }
}

/** A piano key. White for the skip buttons, black for play. A lit key shows a bar of the theme colour at its foot. */
@Composable
private fun PianoKey(black: Boolean, lit: Boolean, modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val shape = RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 14.dp, bottomEnd = 14.dp)
    val top = if (black) Color(0xFF3C3C45) else Color(0xFFFFFFFF)
    val bottom = if (black) Color(0xFF0D0D11) else Color(0xFFE2DDD0)
    val foot = when {
        lit -> cs.primary
        black -> Color(0xFF000000)
        else -> Color(0xFFC9C3B3)
    }
    Box(
        modifier
            .graphicsLayer { translationY = if (pressed) 3.dp.toPx() else 0f }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .drawBehind {
                val edge = 5.dp.toPx()
                drawRect(foot, topLeft = Offset(0f, size.height - edge), size = Size(size.width, edge))
            }
            .border(1.dp, Color.Black.copy(alpha = 0.35f), shape)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** A chunky tape deck button. It sinks in while pressed, and Play stays sunk (and tinted) while music plays. */
@Composable
private fun TapeButton(latched: Boolean, modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val down = pressed || latched
    val shape = RoundedCornerShape(8.dp)
    val faceTop = if (down) Color(0xFF8D8D96) else Color(0xFFD9D9DF)
    val faceBottom = if (down) Color(0xFFB5B5BD) else Color(0xFF8C8C95)
    val top = if (latched) lerp(faceTop, cs.primary, 0.6f) else faceTop
    val bottom = if (latched) lerp(faceBottom, cs.primary, 0.6f) else faceBottom
    Box(
        modifier
            .graphicsLayer { translationY = if (down) 2.dp.toPx() else 0f }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(
                2.dp,
                Brush.verticalGradient(
                    if (down) listOf(Color.Black.copy(alpha = 0.45f), Color.White.copy(alpha = 0.6f))
                    else listOf(Color.White.copy(alpha = 0.75f), Color.Black.copy(alpha = 0.45f)),
                ),
                shape,
            )
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** A frosted pill: a see-through fill with a bright edge. Tinted with the theme colour for the play button. */
@Composable
private fun GlassButton(tinted: Boolean, modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val light = cs.background.luminance() > 0.5f
    val shape = RoundedCornerShape(percent = 50)
    val fillTop = if (light) Color.White.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.28f)
    val fillBottom = if (light) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.08f)
    val edgeTop = if (light) Color.White else Color.White.copy(alpha = 0.65f)
    val edgeBottom = if (light) Color.Black.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.12f)
    Box(
        modifier
            .pressScale(source)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(fillTop, fillBottom)))
            .background(if (tinted) cs.primary.copy(alpha = 0.28f) else Color.Transparent)
            .border(1.dp, Brush.verticalGradient(listOf(edgeTop, edgeBottom)), shape)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

private val KnobFace = Brush.linearGradient(listOf(Color(0xFFF0F0F5), Color(0xFF6A6A73)))

/** A big dial for play. 21 tick marks run round three quarters of it and light up while music plays, the pointer turns. */
@Composable
private fun KnobPlay(playing: Boolean, modifier: Modifier, onClick: () -> Unit, iconSize: Dp) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val turn by animateFloatAsState(if (playing) 40f else -40f, tween(300), label = "knobTurn")
    val on = cs.primary
    val off = cs.onSurface.copy(alpha = 0.3f)
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxHeight()
                .aspectRatio(1f)
                .drawBehind {
                    val c = center
                    val r = size.minDimension / 2f
                    val len = 5.dp.toPx()
                    val w = 2.dp.toPx()
                    val color = if (playing) on else off
                    for (i in 0..20) {
                        val a = (-225f + i * 13.5f) * (PI.toFloat() / 180f)
                        val ca = cos(a)
                        val sa = sin(a)
                        drawLine(
                            color,
                            Offset(c.x + ca * (r - len), c.y + sa * (r - len)),
                            Offset(c.x + ca * r, c.y + sa * r),
                            strokeWidth = w,
                            cap = StrokeCap.Round,
                        )
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .fillMaxSize(0.78f)
                    .pressScale(source)
                    .clip(CircleShape)
                    .background(KnobFace)
                    .border(1.5.dp, Color.Black.copy(alpha = 0.3f), CircleShape)
                    .clickable(interactionSource = source, indication = LocalIndication.current) {
                        haptic()
                        onClick()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = turn }) {
                    Box(
                        Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 5.dp)
                            .size(width = 4.dp, height = 10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(cs.primary),
                    )
                }
                PlayPauseIcon(playing, KeyDark, iconSize * 0.85f)
            }
        }
    }
}

/** A small round knob for previous and next. */
@Composable
private fun KnobSkip(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxHeight(0.82f)
                .aspectRatio(1f)
                .pressScale(source)
                .clip(CircleShape)
                .background(KnobFace)
                .border(1.dp, Color.Black.copy(alpha = 0.3f), CircleShape)
                .clickable(interactionSource = source, indication = LocalIndication.current) {
                    haptic()
                    onClick()
                },
            contentAlignment = Alignment.Center,
        ) { content() }
    }
}
