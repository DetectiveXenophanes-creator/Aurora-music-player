package com.aurora.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private const val NOT_CURRENT = "Floating mini players are for the Current interface. Switch to Current in Interface and they are ready."

/** What the little preview pretends the dock looks like. */
private enum class PreviewDock { BAR, RADIAL, RADIAL_OPEN }

/** Settings > Mini player: pick one of the floating designs, place it, and watch a live preview while you do. */
@Composable
internal fun MiniPlayerTab(s: AppSettings, song: Song?, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    val current = s.uiVersion == UiVersion.CURRENT
    val classic = s.floatMini == FloatMini.CLASSIC
    val radial = s.dockStyle == DockStyle.RADIAL
    var previewDock by remember { mutableStateOf(if (radial) PreviewDock.RADIAL else PreviewDock.BAR) }

    SettingCard("Preview") {
        MiniPreview(s, song, previewDock)
        ChipPicker(
            listOf(
                "Above a bar dock" to PreviewDock.BAR,
                "Radial dock" to PreviewDock.RADIAL,
                "Radial, menu open" to PreviewDock.RADIAL_OPEN,
            ),
            previewDock,
        ) { v -> previewDock = v }
        Text(
            "This is a small copy of your screen with the real design on it. Tap play, swipe the player, drag along a wave or a dial, or change anything below and it follows right away.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Design", if (current) null else NOT_CURRENT) {
        Text(
            "Every design except Classic floats on its own. With a bar dock it sits just above the dock. With the Radial dock it sits in the dock's own row, beside the corner button.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        ChipPicker(FloatMini.entries.map { it.label to it }, s.floatMini) { v -> onUpdate { it.copy(floatMini = v) } }
        Text(s.floatMini.blurb, style = MaterialTheme.typography.bodyMedium)
    }

    SettingCard(
        "Position",
        if (!current) NOT_CURRENT else if (classic) "Pick one of the floating designs above to place it." else null,
    ) {
        Text(
            if (radial) {
                "Your dock is Radial, so the mini player sits in the dock's row, beside the corner button. Gap, margin and hiding are for bar docks."
            } else {
                "It floats just above your dock."
            },
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        Text("Side", style = MaterialTheme.typography.labelLarge)
        ChipPicker(FloatAlign.entries.map { it.label to it }, s.floatAlign) { v -> onUpdate { it.copy(floatAlign = v) } }
        if (s.floatMini != FloatMini.DISC) {
            SliderRow("Width", s.floatWidth, 0.55f..1f, "${(s.floatWidth * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(floatWidth = (v * 20).roundToInt() / 20f) }
            }
        }
        if (!radial) {
            SliderRow("Gap above the dock", s.floatGap, 0f..60f, "${s.floatGap.roundToInt()} dp") { v ->
                onUpdate { it.copy(floatGap = v.roundToInt().toFloat()) }
            }
            SliderRow("Side margin", s.floatMargin, 6f..40f, "${s.floatMargin.roundToInt()} dp") { v ->
                onUpdate { it.copy(floatMargin = v.roundToInt().toFloat()) }
            }
            ToggleRow(
                "Hide with the dock",
                "Slides away together with the dock while you scroll (turn on Hide bars while scrolling in Interface)",
                s.floatHide,
                true,
            ) { v -> onUpdate { it.copy(floatHide = v) } }
        }
    }

    SettingCard("Extras", if (current) null else NOT_CURRENT) {
        ToggleRow(
            "Colour from the cover",
            "The progress, reels, needle, barcode and neon take the main colour of the album cover",
            s.floatTint,
            true,
        ) { v -> onUpdate { it.copy(floatTint = v) } }
        ToggleRow(
            "Swipe up to open",
            "Swipe the mini player upwards to open the full player (it also bounces a little when a new song starts)",
            s.floatSwipeUp,
            true,
        ) { v -> onUpdate { it.copy(floatSwipeUp = v) } }
    }

    SettingCard("What it shows") {
        Text("Size", style = MaterialTheme.typography.labelLarge)
        ChipPicker(MiniSize.entries.map { it.label to it }, s.miniSize) { v -> onUpdate { it.copy(miniSize = v) } }
        ToggleRow("Cover", "Show the album cover", s.miniArt, true) { v -> onUpdate { it.copy(miniArt = v) } }
        ToggleRow("Progress", "Show how far the song is: a ring, a bar, tape, barcode, waves, needle or neon, depending on the design", s.miniProgress, true) { v ->
            onUpdate { it.copy(miniProgress = v) }
        }
        ToggleRow("Skip buttons", "Show previous and next where the design has room", s.miniSkip, true) { v ->
            onUpdate { it.copy(miniSkip = v) }
        }
        ToggleRow("Swipe to skip", "Swipe the player right for the previous song and left for the next", s.miniSwipe, true) { v ->
            onUpdate { it.copy(miniSwipe = v) }
        }
        Text(
            "These also apply to the Classic mini player and the Layout settings.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Start over") {
        OutlinedButton(onClick = {
            val d = AppSettings()
            onUpdate {
                it.copy(
                    floatMini = d.floatMini, floatAlign = d.floatAlign,
                    floatGap = d.floatGap, floatMargin = d.floatMargin, floatWidth = d.floatWidth, floatHide = d.floatHide,
                    floatTint = d.floatTint, floatSwipeUp = d.floatSwipeUp,
                )
            }
        }) { Text("Back to the Classic mini player") }
    }
}

/**
 * A little copy of the screen (header, a few song rows and a dock) with the chosen design on it, in the place it will have.
 * It uses the real design code, so what you see here is what you get. Play, pause and the progress are local to the preview.
 */
@Composable
private fun MiniPreview(s: AppSettings, song: Song?, dock: PreviewDock) {
    val cs = MaterialTheme.colorScheme
    val floatingOn = s.uiVersion == UiVersion.CURRENT && s.floatMini != FloatMini.CLASSIC
    val design = if (floatingOn) s.floatMini else FloatMini.PILL
    val align = if (floatingOn) s.floatAlign else FloatAlign.CENTER
    val gap = if (floatingOn) s.floatGap else 6f
    val margin = if (floatingOn) s.floatMargin else 12f
    val widthFraction = if (floatingOn) s.floatWidth else 1f
    val radial = dock != PreviewDock.BAR
    val shapeSettings = if (floatingOn) s else s.copy(floatMini = FloatMini.PILL)

    var playing by remember { mutableStateOf(true) }
    var frozen by remember { mutableFloatStateOf(0.35f) }
    val ticker = rememberInfiniteTransition(label = "previewTicker")
    val running = ticker.animateFloat(
        initialValue = 0.02f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing)),
        label = "previewProgress",
    )
    val st = FloatMiniState(
        title = song?.title ?: "Northern lights",
        artist = song?.artist ?: "Aurora Sound",
        art = song?.artUri,
        playing = playing,
        accent = null,
        progress = { if (playing) running.value else frozen },
        onOpen = {},
        onToggle = {
            if (playing) frozen = running.value
            playing = !playing
        },
        onPrev = {},
        onNext = {},
        onSeek = { f -> frozen = f },
    )

    val screen = RoundedCornerShape((s.corner * 1.2f).dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(330.dp)
            .clip(screen)
            .background(Brush.verticalGradient(listOf(cs.primaryContainer.copy(alpha = 0.55f), cs.surface))),
    ) {
        // a stand-in header
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 12.dp)
                .width(120.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(50))
                .background(cs.onSurface.copy(alpha = 0.12f)),
        )
        // stand-in song rows
        Column(
            Modifier.padding(start = 12.dp, end = 12.dp, top = 52.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            repeat(5) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.onSurface.copy(alpha = 0.10f)))
                    Spacer(Modifier.width(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.width(130.dp).height(8.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.14f)))
                        Box(Modifier.width(80.dp).height(6.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.08f)))
                    }
                }
            }
        }
        if (radial) {
            // the Radial dock: a corner button and the mini player in the same 72 dp row
            val left = s.radialSide == RadialSide.LEFT
            val open = dock == PreviewDock.RADIAL_OPEN
            val button: @Composable () -> Unit = {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(percent = if (open) 50 else 32)).background(cs.primary.copy(alpha = if (open) 0.9f else 0.55f)),
                )
            }
            val mini: @Composable RowScope.() -> Unit = {
                Box(Modifier.weight(1f), contentAlignment = floatRowAlignment(align)) {
                    FloatingMini(
                        design,
                        st,
                        floatMiniShape(shapeSettings, dockRow = true),
                        Modifier,
                        widthFraction,
                        dockRow = true,
                        narrow = open,
                    )
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 8.dp)
                    .height(72.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (left) {
                    button()
                    Spacer(Modifier.width(if (open) 96.dp else 10.dp))
                    mini()
                } else {
                    mini()
                    Spacer(Modifier.width(if (open) 96.dp else 10.dp))
                    button()
                }
            }
        } else {
            // a stand-in bar dock, with the mini player floating above it
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .width(230.dp)
                    .height(52.dp)
                    .clip(RoundedCornerShape(50))
                    .background(cs.surfaceContainerHigh),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                repeat(4) { i ->
                    Box(
                        Modifier
                            .size(if (i == 0) 30.dp else 22.dp)
                            .clip(CircleShape)
                            .background(if (i == 0) cs.primary.copy(alpha = 0.55f) else cs.onSurface.copy(alpha = 0.16f)),
                    )
                }
            }
            Box(
                Modifier
                    .align(floatAlignment(align))
                    .padding(start = margin.dp, end = margin.dp, bottom = 64.dp + gap.dp),
            ) {
                FloatingMini(design, st, floatMiniShape(shapeSettings), Modifier, widthFraction)
            }
        }
    }
}
