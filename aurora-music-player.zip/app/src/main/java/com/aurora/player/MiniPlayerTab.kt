package com.aurora.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private const val NOT_CURRENT = "Floating mini players are for the Current interface. Switch to Current in Interface and they are ready."

/** Settings > Mini player: pick one of the floating designs, place it, and watch a live preview while you do. */
@Composable
internal fun MiniPlayerTab(s: AppSettings, song: Song?, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    val current = s.uiVersion == UiVersion.CURRENT
    val classic = s.floatMini == FloatMini.CLASSIC

    SettingCard("Preview") {
        MiniPreview(s, song)
        Text(
            "This is a small copy of your screen. Tap play, swipe the player sideways or change anything below and it follows right away.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Design", if (current) null else NOT_CURRENT) {
        Text(
            "Every design except Classic floats on its own, free from the dock.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        ChipPicker(FloatMini.entries.map { it.label to it }, s.floatMini) { v -> onUpdate { it.copy(floatMini = v) } }
        Text(s.floatMini.blurb, style = MaterialTheme.typography.bodyMedium)
    }

    SettingCard(
        "Position",
        if (!current) NOT_CURRENT else if (classic) "Pick one of the floating designs above to move it around." else null,
    ) {
        Text("Where it floats", style = MaterialTheme.typography.labelLarge)
        ChipPicker(FloatPos.entries.map { it.label to it }, s.floatPos) { v -> onUpdate { it.copy(floatPos = v) } }
        Text("Side", style = MaterialTheme.typography.labelLarge)
        ChipPicker(FloatAlign.entries.map { it.label to it }, s.floatAlign) { v -> onUpdate { it.copy(floatAlign = v) } }
        SliderRow("Gap from the dock or header", s.floatGap, 0f..60f, "${s.floatGap.roundToInt()} dp") { v ->
            onUpdate { it.copy(floatGap = v.roundToInt().toFloat()) }
        }
        SliderRow("Side margin", s.floatMargin, 6f..40f, "${s.floatMargin.roundToInt()} dp") { v ->
            onUpdate { it.copy(floatMargin = v.roundToInt().toFloat()) }
        }
        if (s.floatMini != FloatMini.DISC) {
            SliderRow("Width", s.floatWidth, 0.55f..1f, "${(s.floatWidth * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(floatWidth = (v * 20).roundToInt() / 20f) }
            }
        }
        ToggleRow(
            "Hide with the dock",
            "Slides away together with the dock while you scroll (turn on Hide bars while scrolling in Interface)",
            s.floatHide,
            true,
        ) { v -> onUpdate { it.copy(floatHide = v) } }
    }

    SettingCard("What it shows") {
        Text("Size", style = MaterialTheme.typography.labelLarge)
        ChipPicker(MiniSize.entries.map { it.label to it }, s.miniSize) { v -> onUpdate { it.copy(miniSize = v) } }
        ToggleRow("Cover", "Show the album cover", s.miniArt, true) { v -> onUpdate { it.copy(miniArt = v) } }
        ToggleRow("Progress", "Show how far the song is, as a ring, a bar or a fill depending on the design", s.miniProgress, true) { v ->
            onUpdate { it.copy(miniProgress = v) }
        }
        ToggleRow("Skip buttons", "Show previous and next where the design has room", s.miniSkip, true) { v ->
            onUpdate { it.copy(miniSkip = v) }
        }
        ToggleRow("Swipe to skip", "Swipe the player right for the previous song and left for the next", s.miniSwipe, true) { v ->
            onUpdate { it.copy(miniSwipe = v) }
        }
        Text(
            "These also apply to the Classic mini player and the Layout settings.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Start over") {
        OutlinedButton(onClick = {
            val d = AppSettings()
            onUpdate {
                it.copy(
                    floatMini = d.floatMini, floatPos = d.floatPos, floatAlign = d.floatAlign,
                    floatGap = d.floatGap, floatMargin = d.floatMargin, floatWidth = d.floatWidth, floatHide = d.floatHide,
                )
            }
        }) { Text("Back to the Classic mini player") }
    }
}

/**
 * A little copy of the screen (header, a few song rows, a dock) with the chosen design on it, in the chosen place.
 * It uses the real design code, so what you see here is what you get. Play, pause and the progress are local to the preview.
 */
@Composable
private fun MiniPreview(s: AppSettings, song: Song?) {
    val cs = MaterialTheme.colorScheme
    val floatingOn = s.uiVersion == UiVersion.CURRENT && s.floatMini != FloatMini.CLASSIC
    val design = if (floatingOn) s.floatMini else FloatMini.PILL
    val pos = if (floatingOn) s.floatPos else FloatPos.ABOVE
    val align = if (floatingOn) s.floatAlign else FloatAlign.CENTER
    val gap = if (floatingOn) s.floatGap else 6f
    val margin = if (floatingOn) s.floatMargin else 12f
    val widthFraction = if (floatingOn) s.floatWidth else 1f
    val onTop = pos == FloatPos.TOP

    var playing by remember { mutableStateOf(true) }
    var frozen by remember { mutableFloatStateOf(0.35f) }
    val ticker = rememberInfiniteTransition(label = "previewTicker")
    val running = ticker.animateFloat(
        initialValue = 0.02f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing)),
        label = "previewProgress",
    )
    val st = FloatMiniState(
        title = song?.title ?: "Northern lights",
        artist = song?.artist ?: "Aurora Sound",
        art = song?.artUri,
        playing = playing,
        progress = { if (playing) running.value else frozen },
        onOpen = {},
        onToggle = {
            if (playing) frozen = running.value
            playing = !playing
        },
        onPrev = {},
        onNext = {},
    )

    val screen = RoundedCornerShape((s.corner * 1.2f).dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(330.dp)
            .clip(screen)
            .background(Brush.verticalGradient(listOf(cs.primaryContainer.copy(alpha = 0.55f), cs.surface))),
    ) {
        // a stand-in header
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 12.dp)
                .width(120.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(50))
                .background(cs.onSurface.copy(alpha = 0.12f)),
        )
        // stand-in song rows
        Column(
            Modifier.padding(start = 12.dp, end = 12.dp, top = 52.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            repeat(5) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.onSurface.copy(alpha = 0.10f)))
                    Spacer(Modifier.width(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.width(130.dp).height(8.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.14f)))
                        Box(Modifier.width(80.dp).height(6.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.08f)))
                    }
                }
            }
        }
        // a stand-in dock
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
                .width(230.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(50))
                .background(cs.surfaceContainerHigh),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            repeat(4) { i ->
                Box(
                    Modifier
                        .size(if (i == 0) 30.dp else 22.dp)
                        .clip(CircleShape)
                        .background(if (i == 0) cs.primary.copy(alpha = 0.55f) else cs.onSurface.copy(alpha = 0.16f)),
                )
            }
        }
        // the mini player, placed the way the real one is
        Box(
            Modifier
                .align(floatAlignment(pos, align))
                .padding(
                    start = margin.dp,
                    end = margin.dp,
                    top = if (onTop) 44.dp + gap.dp else 0.dp,
                    bottom = if (onTop) 0.dp else 64.dp + gap.dp,
                ),
        ) {
            FloatingMini(design, st, floatMiniShape(design, s.corner), Modifier, widthFraction)
        }
    }
}
