package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

// The five designs with a character of their own. Each one has a way of showing progress that the others do not:
// the tape winds from reel to reel, the barcode fills in, the waveform lights up, the needle sweeps the dial and the
// neon tube glows around the edge. Together with the shared pieces in FloatingMini.kt.

private val DEG = (PI / 180.0).toFloat()
private val TAPE = Color(0xFF241C18)
private val HUB = Color(0xFFEDE7DF)
private val NEON_PANEL = Color(0xFF0B0B13)

/** The padding around the cover on a Ticket. The notches sit exactly on the tear line: padding + cover + padding. */
internal val TICKET_PAD = 9.dp

/** A ticket outline: a rounded rectangle with a half circle punched out of the top and the bottom at [stubX]. */
class TicketShape(private val corner: Dp, private val notch: Dp, private val stubX: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { corner.toPx() }
        val r = with(density) { notch.toPx() }
        val x = with(density) { stubX.toPx() }.coerceIn(r * 2f, maxOf(r * 2f, size.width - r * 2f))
        val body = Path()
        body.addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(c, c)))
        val holes = Path()
        holes.addOval(Rect(Offset(x, 0f), r))
        holes.addOval(Rect(Offset(x, size.height), r))
        return Outline.Generic(Path.combine(PathOperation.Difference, body, holes))
    }
}

// ---------------------------------------------------------------- Cassette

/** Cassette: two reels that turn while it plays. The tape winds from the left reel to the right one as the song goes. */
@Composable
internal fun CassetteMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val accent = st.accent ?: cs.primary
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(st.playing, motion.enabled) {
        if (st.playing && motion.enabled) {
            while (true) {
                delay(50)
                angle = (angle + 3f) % 360f
            }
        }
    }
    val bodyH = 56.dp * k
    val reelDp = bodyH * 0.40f
    val shell = cs.surfaceContainerHighest
    val edge = cs.outline.copy(alpha = 0.35f)
    val label = cs.tertiaryContainer
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f).height(bodyH)) {
            Canvas(Modifier.fillMaxSize()) {
                val u = 1.dp.toPx()
                val w = size.width
                val h = size.height
                val round = CornerRadius(10f * u, 10f * u)
                drawRoundRect(shell, size = size, cornerRadius = round)
                drawRoundRect(edge, size = size, cornerRadius = round, style = Stroke(1.2f * u))
                val reelMax = h * 0.40f
                val hub = reelMax * 0.36f
                val cy = h / 2f
                val cxL = 6f * u + reelMax
                val cxR = w - 6f * u - reelMax
                // the paper label sits between the two reels
                drawRoundRect(
                    label,
                    topLeft = Offset(cxL, 8f * u),
                    size = Size(maxOf(0f, cxR - cxL), h - 16f * u),
                    cornerRadius = CornerRadius(6f * u, 6f * u),
                )
                val p = st.progress().coerceIn(0f, 1f)
                val empty = hub + 3f * u
                val rL = reelMax + (empty - reelMax) * p
                val rR = empty + (reelMax - empty) * p
                // the strip of tape that runs between the bottoms of the two reels
                drawLine(TAPE, Offset(cxL, cy + rL), Offset(cxR, cy + rR), strokeWidth = 1.6f * u)
                for (side in 0..1) {
                    val cx = if (side == 0) cxL else cxR
                    val r = if (side == 0) rL else rR
                    val c = Offset(cx, cy)
                    drawCircle(TAPE, r, c)
                    drawCircle(Color.White.copy(alpha = 0.07f), r, c, style = Stroke(1.2f * u))
                    drawCircle(HUB, hub, c)
                    for (j in 0 until 6) {
                        val a = (angle + j * 60f) * DEG
                        drawLine(TAPE, c, Offset(cx + cos(a) * hub, cy + sin(a) * hub), strokeWidth = 1.5f * u)
                    }
                    drawCircle(accent, hub * 0.3f, c)
                }
            }
            SongLines(
                st,
                Modifier.align(Alignment.Center).padding(horizontal = 6.dp + reelDp * 2f + 4.dp),
                cs.onTertiaryContainer,
                cs.onTertiaryContainer.copy(alpha = 0.7f),
                false,
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayPauseButton(
            playing = st.playing,
            onClick = st.onToggle,
            modifier = Modifier.size(44.dp * k),
            iconSize = 22.dp,
            tonal = true,
            showGlow = false,
        )
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
        }
    }
}

// ---------------------------------------------------------------- Ticket

/** Ticket: a cover stub, a dashed tear line with punched notches, the artist in spaced capitals and a barcode that fills in. */
@Composable
internal fun TicketMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val accent = st.accent ?: cs.primary
    val art = 50.dp * k
    val marquee = s.marqueeTitles
    val ink = cs.onSurface
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .drawBehind {
                // the tear line, exactly under the notches of the outline
                val x = (TICKET_PAD * 2 + art).toPx()
                drawLine(
                    ink.copy(alpha = 0.30f),
                    Offset(x, 11.dp.toPx()),
                    Offset(x, size.height - 11.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx())),
                )
            }
            .clickable(onClick = st.onOpen)
            .padding(TICKET_PAD),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MiniArt(if (s.miniArt) st.art else null, Modifier.size(art), RoundedCornerShape((s.corner * 0.5f).dp))
        Spacer(Modifier.width(TICKET_PAD * 2))
        Column(Modifier.weight(1f)) {
            Text(
                verbatim(st.artist.uppercase()),
                color = accent,
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.6.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                verbatim(st.title),
                modifier = Modifier.titleMarquee(marquee),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            )
            if (s.miniProgress) {
                Spacer(Modifier.height(3.dp))
                Barcode(st.title.hashCode(), st.progress, accent, ink.copy(alpha = 0.28f), Modifier.fillMaxWidth().height(13.dp))
            }
        }
        Spacer(Modifier.width(8.dp))
        PlayPauseButton(
            playing = st.playing,
            onClick = st.onToggle,
            modifier = Modifier.size(44.dp * k),
            iconSize = 22.dp,
            tonal = true,
            showGlow = false,
        )
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
        }
    }
}

/** A barcode made from the song's name, so every song has its own. The part you have played is lit. */
@Composable
private fun Barcode(seed: Int, progress: () -> Float, lit: Color, dim: Color, modifier: Modifier) {
    Canvas(modifier) {
        val u = 1.dp.toPx()
        val p = progress().coerceIn(0f, 1f)
        var x = 0f
        var i = 0
        while (x < size.width) {
            val h = (seed * 31 + i * 17) and 0x7fffffff
            val bar = (1.2f + (h % 4) * 0.8f) * u
            val gap = (1.0f + ((h / 7) % 3) * 0.7f) * u
            if (x + bar > size.width) break
            drawRect(if (x < p * size.width) lit else dim, topLeft = Offset(x, 0f), size = Size(bar, size.height))
            x += bar + gap
            i++
        }
    }
}

// ---------------------------------------------------------------- Wave

/** Wave: the song's own waveform under its name. Tap or drag along it to jump to any spot. */
@Composable
internal fun WaveMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val accent = st.accent ?: cs.primary
    val marquee = s.marqueeTitles
    var scrub by remember { mutableStateOf<Float?>(null) }
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            MiniArt(st.art, Modifier.size(46.dp * k), RoundedCornerShape((s.corner * 0.6f).dp))
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    verbatim(st.title),
                    modifier = Modifier.weight(1f, fill = false).titleMarquee(marquee),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
                )
                Text(
                    verbatim("  ·  " + st.artist),
                    modifier = Modifier.widthIn(max = 96.dp),
                    color = cs.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(2.dp))
            WaveStrip(
                seed = st.title.hashCode(),
                progress = st.progress,
                scrub = scrub,
                playing = st.playing,
                lit = accent,
                dim = cs.onSurface.copy(alpha = 0.22f),
                onScrub = { scrub = it },
                onSeek = st.onSeek,
                modifier = Modifier.fillMaxWidth().height(24.dp * k),
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayPauseButton(
            playing = st.playing,
            onClick = st.onToggle,
            modifier = Modifier.size(44.dp * k),
            iconSize = 22.dp,
            tonal = true,
            showGlow = false,
        )
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(34.dp * k), iconSize = 22.dp)
        }
    }
}

/** Bars shaped from the song's name (so each song looks different). The bars at the playhead bounce while it plays. */
@Composable
private fun WaveStrip(
    seed: Int,
    progress: () -> Float,
    scrub: Float?,
    playing: Boolean,
    lit: Color,
    dim: Color,
    onScrub: (Float?) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier,
) {
    val motion = LocalMotion.current
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing, motion.enabled) {
        if (playing && motion.enabled) {
            while (true) {
                delay(90)
                phase += 0.7f
            }
        }
    }
    val a = (seed and 0xff) / 25f
    val b = ((seed shr 8) and 0xff) / 31f
    Canvas(modifier.scrubbable(onScrub, onSeek)) {
        val u = 1.dp.toPx()
        val barW = 3f * u
        val gap = 2f * u
        val n = maxOf(8, ((size.width + gap) / (barW + gap)).toInt())
        val head = (scrub ?: progress()).coerceIn(0f, 1f) * n
        for (i in 0 until n) {
            val base = 0.30f + 0.70f * abs(sin(i * 0.37f + a) * 0.6f + sin(i * 0.91f + b) * 0.4f)
            val near = abs(i - head)
            val bounce = if (playing && near < 3f) 1f + 0.22f * (1f - near / 3f) * sin(phase + i) else 1f
            val h = (size.height * base * bounce).coerceIn(2f * u, size.height)
            drawRoundRect(
                if (i < head) lit else dim,
                topLeft = Offset(i * (barW + gap), (size.height - h) / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}

// ---------------------------------------------------------------- Dial

/** Dial: a retro radio. The play button is the knob, the song is the station and the needle sweeps the scale. Drag it to tune. */
@Composable
internal fun DialMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val accent = st.accent ?: cs.primary
    val marquee = s.marqueeTitles
    val glass = RoundedCornerShape(10.dp)
    var scrub by remember { mutableStateOf<Float?>(null) }
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .finish(shape)
            .clickable(onClick = st.onOpen)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlayPauseButton(
            playing = st.playing,
            onClick = st.onToggle,
            modifier = Modifier.size(46.dp * k),
            iconSize = 22.dp,
            tonal = true,
            showGlow = false,
        )
        Spacer(Modifier.width(10.dp))
        Column(
            Modifier
                .weight(1f)
                .clip(glass)
                .background(cs.onSurface.copy(alpha = 0.07f))
                .border(1.dp, cs.onSurface.copy(alpha = 0.12f), glass)
                .padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (s.miniArt) {
                    MiniArt(st.art, Modifier.size(22.dp * k), CircleShape)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    verbatim(st.title),
                    modifier = Modifier.weight(1f, fill = false).titleMarquee(marquee),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
                )
                Text(
                    verbatim("  " + st.artist),
                    modifier = Modifier.widthIn(max = 84.dp),
                    color = cs.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(3.dp))
            DialScale(st.progress, scrub, accent, cs.onSurface, { scrub = it }, st.onSeek, Modifier.fillMaxWidth().height(18.dp))
        }
        if (s.miniSkip) {
            Spacer(Modifier.width(8.dp))
            SkipButton(forward = true, onClick = st.onNext, modifier = Modifier.size(36.dp * k), iconSize = 22.dp)
        }
    }
}

/** A tuning scale: ticks that light up behind a glowing needle. */
@Composable
private fun DialScale(
    progress: () -> Float,
    scrub: Float?,
    lit: Color,
    ink: Color,
    onScrub: (Float?) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier,
) {
    Canvas(modifier.scrubbable(onScrub, onSeek)) {
        val u = 1.dp.toPx()
        val n = maxOf(10, (size.width / (5f * u)).toInt())
        val nx = (scrub ?: progress()).coerceIn(0f, 1f) * size.width
        for (i in 0..n) {
            val x = i * size.width / n
            val long = i % 5 == 0
            val h = size.height * (if (long) 0.85f else 0.5f)
            val c = if (x <= nx) lit.copy(alpha = 0.95f) else ink.copy(alpha = 0.35f)
            drawLine(c, Offset(x, size.height - h), Offset(x, size.height), strokeWidth = (if (long) 1.6f else 1f) * u)
        }
        drawLine(lit.copy(alpha = 0.25f), Offset(nx, 0f), Offset(nx, size.height), strokeWidth = 7f * u, cap = StrokeCap.Round)
        drawLine(lit, Offset(nx, 0f), Offset(nx, size.height), strokeWidth = 2f * u, cap = StrokeCap.Round)
    }
}

// ---------------------------------------------------------------- Neon

/** Neon: a dark panel with a glass tube around the edge. The tube lights up as the song plays, with the odd flicker. */
@Composable
internal fun NeonMini(st: FloatMiniState, k: Float, shape: Shape, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val tube = lerp(st.accent ?: cs.primary, Color.White, 0.25f)
    val text = lerp(tube, Color.White, 0.6f)
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(st.playing, motion.enabled) {
        if (st.playing && motion.enabled) {
            while (true) {
                delay(110)
                phase += 1f
            }
        }
    }
    val corners = remember { PlayCorners(50f, 50f, 50f, 50f) }
    val measure = remember { PathMeasure() }
    val seg = remember { Path() }
    val marquee = s.marqueeTitles
    Row(
        modifier
            .gestures(st)
            .glow(shape, s.glowMini, if (st.playing) 1f else 0.45f)
            .clip(shape)
            .background(NEON_PANEL)
            .drawBehind {
                val stroke = 2.dp.toPx()
                val path = shapeOutlinePath(size.width, size.height, stroke * 2f, corners)
                // the unlit tube first, then the lit part with a soft glow around it
                drawPath(path, tube.copy(alpha = 0.18f), style = Stroke(width = stroke))
                val p = if (s.miniProgress) st.progress().coerceIn(0f, 1f) else 1f
                if (p > 0.002f) {
                    measure.setPath(path, false)
                    seg.reset()
                    measure.getSegment(0f, measure.length * p, seg, true)
                    val flick = if (st.playing && motion.enabled && phase.toInt() % 29 == 0) 0.6f else 1f
                    drawPath(seg, tube.copy(alpha = 0.10f * flick), style = Stroke(width = stroke * 5f, cap = StrokeCap.Round))
                    drawPath(seg, tube.copy(alpha = 0.22f * flick), style = Stroke(width = stroke * 3f, cap = StrokeCap.Round))
                    drawPath(seg, tube.copy(alpha = flick), style = Stroke(width = stroke, cap = StrokeCap.Round))
                }
            }
            .clickable(onClick = st.onOpen)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            MiniArt(st.art, Modifier.size(40.dp * k).border(1.5.dp, tube, CircleShape), CircleShape)
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                verbatim(st.title),
                modifier = Modifier.titleMarquee(marquee),
                color = text,
                style = MaterialTheme.typography.titleSmall.copy(shadow = Shadow(tube, Offset.Zero, 14f)),
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = if (marquee) TextOverflow.Clip else TextOverflow.Ellipsis,
            )
            Text(
                verbatim(st.artist),
                color = tube.copy(alpha = 0.75f),
                style = MaterialTheme.typography.bodySmall.copy(shadow = Shadow(tube, Offset.Zero, 8f)),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (s.miniSkip) {
            RoundButton(Icons.Rounded.SkipNext, "Next", st.onNext, 34.dp * k, Color.Transparent, tube)
        }
        Box(
            Modifier
                .size(42.dp * k)
                .drawBehind { drawCircle(tube.copy(alpha = 0.12f), radius = size.minDimension / 2f * 1.25f) }
                .clip(CircleShape)
                .border(1.5.dp, tube, CircleShape)
                .clickable(onClick = st.onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (st.playing) "Pause" else "Play",
                tint = tube,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- scrubbing

/**
 * Lets a strip be tapped or dragged to pick a spot in the song (0 to 1 across its width). [onScrub] follows the finger
 * (null when it lets go) and [onSeek] is called once with the final spot.
 */
@Composable
internal fun Modifier.scrubbable(onScrub: (Float?) -> Unit, onSeek: (Float) -> Unit): Modifier {
    val scrubbing by rememberUpdatedState(onScrub)
    val seeking by rememberUpdatedState(onSeek)
    return this
        .pointerInput(Unit) {
            detectTapGestures { offset -> seeking((offset.x / size.width).coerceIn(0f, 1f)) }
        }
        .pointerInput(Unit) {
            var last = 0f
            detectHorizontalDragGestures(
                onDragStart = { offset ->
                    last = (offset.x / size.width).coerceIn(0f, 1f)
                    scrubbing(last)
                },
                onDragEnd = {
                    seeking(last)
                    scrubbing(null)
                },
                onDragCancel = { scrubbing(null) },
                onHorizontalDrag = { change, _ ->
                    change.consume()
                    last = (change.position.x / size.width).coerceIn(0f, 1f)
                    scrubbing(last)
                },
            )
        }
}
