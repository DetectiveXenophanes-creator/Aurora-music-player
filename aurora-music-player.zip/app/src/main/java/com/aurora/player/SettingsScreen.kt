package com.aurora.player

import android.os.Build
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private val swatches = listOf(0xFF6750A4, 0xFF0B6BCB, 0xFF1B8A5A, 0xFFD9480F, 0xFFC2185B, 0xFF00897B).map { it.toInt() }

@Composable
fun SettingsScreen(
    s: AppSettings,
    padding: PaddingValues,
    onUpdate: ((AppSettings) -> AppSettings) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    var blur by remember { mutableFloatStateOf(s.blur) }
    var corner by remember { mutableFloatStateOf(s.corner) }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(
                top = padding.calculateTopPadding(),
                bottom = padding.calculateBottomPadding(),
                start = 16.dp,
                end = 16.dp,
            ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SettingCard("Component finish") {
            Segmented(
                options = listOf("Matte" to SurfaceStyle.MATTE, "Frosted glass" to SurfaceStyle.GLASS),
                selected = s.style,
                onSelect = { v -> onUpdate { it.copy(style = v) } },
            )
            Text(
                if (s.style == SurfaceStyle.GLASS)
                    "Bars and panels blur what is behind them. Full blur needs Android 12 or newer; older phones get a frosted tint."
                else
                    "Solid, opaque surfaces with no transparency.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
            if (s.style == SurfaceStyle.GLASS) {
                Text("Blur strength: ${blur.roundToInt()}", style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = blur,
                    onValueChange = { blur = it; onUpdate { c -> c.copy(blur = it) } },
                    valueRange = 4f..48f,
                )
            }
        }

        SettingCard("Shape") {
            Text("Corner roundness: ${corner.roundToInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = corner,
                onValueChange = { corner = it; onUpdate { c -> c.copy(corner = it) } },
                valueRange = 6f..40f,
            )
        }

        SettingCard("Colour") {
            Segmented(
                options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
                selected = s.themeMode,
                onSelect = { v -> onUpdate { it.copy(themeMode = v) } },
            )
            ToggleRow(
                title = "Material You colours",
                subtitle = if (canDynamic) "Use colours from your wallpaper" else "Needs Android 12 or newer",
                checked = s.dynamicColor && canDynamic,
                enabled = canDynamic,
                onChange = { v -> onUpdate { it.copy(dynamicColor = v) } },
            )
            Text("Accent colour", style = MaterialTheme.typography.labelLarge)
            val dynamicActive = s.dynamicColor && canDynamic
            Row(Modifier.alpha(if (dynamicActive) 0.4f else 1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                swatches.forEach { c ->
                    val selected = !dynamicActive && s.accent == c
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(if (selected) 3.dp else 0.dp, cs.onSurface, CircleShape)
                            .clickable { onUpdate { it.copy(accent = c, dynamicColor = false) } }
                    )
                }
            }
            ToggleRow(
                title = "True black (AMOLED)",
                subtitle = "Pure black backgrounds in dark mode",
                checked = s.amoled,
                enabled = true,
                onChange = { v -> onUpdate { it.copy(amoled = v) } },
            )
        }
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable () -> Unit) {
    val corner = LocalAppSettings.current.corner
    Column(
        Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (label, value) ->
            SegmentedButton(
                selected = value == selected,
                onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
                label = { Text(label) },
            )
        }
    }
}
