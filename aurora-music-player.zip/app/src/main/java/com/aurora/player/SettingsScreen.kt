package com.aurora.player

import android.os.Build
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val swatches = listOf(
    0xFF6750A4, 0xFF0B6BCB, 0xFF00897B, 0xFF1B8A5A,
    0xFFD9480F, 0xFFC2185B, 0xFFB00020, 0xFF5D4037,
).map { it.toInt() }

private enum class SettingsTab(val label: String, val icon: ImageVector) {
    THEMES("Themes", Icons.Rounded.ColorLens),
    CUSTOMIZATION("Customization", Icons.Rounded.Palette),
    ANIMATIONS("Animations", Icons.Rounded.AutoAwesome),
    AUDIO("Audio", Icons.Rounded.GraphicEq),
    LIBRARY("Library", Icons.Rounded.FolderOpen),
    HOME("Home", Icons.Rounded.Home),
    STARTUP("Startup", Icons.Rounded.Tune),
    PLAYER("Player", Icons.Rounded.PlayCircle),
    BACKUP("Backup", Icons.Rounded.Backup),
    ABOUT("About", Icons.Rounded.Info),
}

typealias SettingsUpdate = ((AppSettings) -> AppSettings) -> Unit

@Composable
fun SettingsPage(
    s: AppSettings,
    allSongs: List<Song>,
    lib: LibraryData,
    song: Song?,
    onUpdate: SettingsUpdate,
    onRescan: () -> Unit,
    onRunSetup: () -> Unit,
    onBackup: suspend () -> String,
    onRestore: suspend (String) -> String,
    onBack: () -> Unit,
) {
    val motion = LocalMotion.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    OverlayPage(title = "Settings", song = song, onBack = onBack) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(top = padding.calculateTopPadding())
        ) {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SettingsTab.entries.forEach { t ->
                    FilterChip(
                        selected = tab == t.ordinal,
                        onClick = { tab = t.ordinal },
                        label = { Text(t.label) },
                        leadingIcon = { Icon(t.icon, null, Modifier.size(18.dp)) },
                    )
                }
            }

            AnimatedContent(
                targetState = tab,
                transitionSpec = { motion.tab(targetState > initialState) },
                label = "settingsTab",
                modifier = Modifier.fillMaxSize(),
            ) { t ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(
                            start = 16.dp,
                            end = 16.dp,
                            top = 12.dp,
                            bottom = padding.calculateBottomPadding(),
                        ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    when (SettingsTab.entries[t]) {
                        SettingsTab.CUSTOMIZATION -> CustomizationTab(s, onUpdate)
                        SettingsTab.ANIMATIONS -> AnimationsTab(s, onUpdate)
                        SettingsTab.AUDIO -> AudioTab(s, onUpdate)
                        SettingsTab.LIBRARY -> LibraryTab(s, allSongs, onUpdate, onRescan)
                        SettingsTab.STARTUP -> StartupTab(s, onUpdate, onRunSetup)
                        SettingsTab.PLAYER -> PlayerTab(s, onUpdate)
                        SettingsTab.HOME -> HomeTab(s, onUpdate)
                        SettingsTab.THEMES -> ThemesTab(s, onUpdate)
                        SettingsTab.BACKUP -> BackupTab(lib, onBackup, onRestore)
                        SettingsTab.ABOUT -> AboutTab(onUpdate)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ tabs

@Composable
private fun CustomizationTab(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme

    SettingCard("Component finish") {
        Segmented(
            options = listOf("Matte" to SurfaceStyle.MATTE, "Frosted glass" to SurfaceStyle.GLASS),
            selected = s.style,
            onSelect = { v -> onUpdate { it.copy(style = v) } },
        )
        Text(
            if (s.style == SurfaceStyle.GLASS)
                "Bars and panels blur what is behind them. Full blur needs Android 12 or newer; older phones get a frosted tint."
            else
                "Solid, opaque surfaces with no transparency.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        if (s.style == SurfaceStyle.GLASS) {
            SliderRow("Blur strength", s.blur, 4f..48f, "${s.blur.roundToInt()}") { v -> onUpdate { it.copy(blur = v) } }
            SliderRow("Frost tint", s.glassTint, 0.1f..0.9f, "${(s.glassTint * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(glassTint = v) }
            }
            ToggleRow("Glass edge highlight", "A light rim around glass panels", s.edgeHighlight, true) { v ->
                onUpdate { it.copy(edgeHighlight = v) }
            }
        }
    }

    SettingCard("Shape and layout") {
        SliderRow("Corner roundness", s.corner, 6f..40f, "${s.corner.roundToInt()}") { v -> onUpdate { it.copy(corner = v) } }
        Text("Play button shape", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Morph" to PlayShape.MORPH, "Circle" to PlayShape.CIRCLE, "Squircle" to PlayShape.SQUIRCLE),
            selected = s.playShape,
            onSelect = { v -> onUpdate { it.copy(playShape = v) } },
        )
        Text("Song list density", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Comfortable" to ListDensity.COMFORTABLE, "Compact" to ListDensity.COMPACT),
            selected = s.density,
            onSelect = { v -> onUpdate { it.copy(density = v) } },
        )
        ToggleRow("Album art in song list", "Show cover thumbnails", s.listArt, true) { v ->
            onUpdate { it.copy(listArt = v) }
        }
        ToggleRow("Tab names", "Show the name of the selected bottom tab", s.navLabels, true) { v ->
            onUpdate { it.copy(navLabels = v) }
        }
    }

    SettingCard("Background") {
        Segmented(
            options = listOf(
                "Gradient" to BackgroundStyle.GRADIENT,
                "Album art" to BackgroundStyle.ALBUM,
                "Flat" to BackgroundStyle.FLAT,
            ),
            selected = s.background,
            onSelect = { v -> onUpdate { it.copy(background = v) } },
        )
        SliderRow(
            "Aurora glow",
            s.auroraGlow,
            0f..1f,
            if (s.auroraGlow < 0.03f) "Off" else "${(s.auroraGlow * 100).roundToInt()}%",
        ) { v -> onUpdate { it.copy(auroraGlow = (v * 20).roundToInt() / 20f) } }
        Text(
            "Soft northern lights in your theme colours behind everything.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        Text("Squiggly shapes", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Off" to SquiggleMode.OFF, "Still" to SquiggleMode.STATIC, "Drifting" to SquiggleMode.ANIMATED),
            selected = s.squiggles,
            onSelect = { v -> onUpdate { it.copy(squiggles = v) } },
        )
        Text(
            "Wavy lines and squiggly circles. Drifting updates about 20 times a second and pauses while other pages are open. Still or Off saves the most battery.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }

    SettingCard("Now playing") {
        Text("Cover shape", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = ArtShape.entries.map { it.label to it },
            selected = s.artShape,
            onSelect = { v -> onUpdate { it.copy(artShape = v) } },
        )
        Text("Seek bar style", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Line" to SeekStyle.LINE, "Wavy" to SeekStyle.WAVY),
            selected = s.seekStyle,
            onSelect = { v -> onUpdate { it.copy(seekStyle = v) } },
        )
        SliderRow(
            "Artwork edge softness",
            s.artEdge,
            0f..1f,
            if (s.artEdge < 0.02f) "Sharp" else "${(s.artEdge * 100).roundToInt()}%",
        ) { v -> onUpdate { it.copy(artEdge = (v * 20).roundToInt() / 20f) } }
        Text(
            "Feathers the cover's edges so it melts into the background. Set to Sharp for a crisp edge.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    SettingCard("Text") {
        Text("Font", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = UiFont.entries.map { it.label to it },
            selected = s.uiFont,
            onSelect = { v -> onUpdate { it.copy(uiFont = v) } },
        )
        SliderRow("Text size", s.textScale, 0.85f..1.3f, "${(s.textScale * 100).roundToInt()}%") { v ->
            onUpdate { it.copy(textScale = (v * 20).roundToInt() / 20f) }
        }
    }

    SettingCard("Performance") {
        ToggleRow(
            "Battery saver",
            "Stops decorative motion: drifting shapes, aurora glow, wavy seek bar and the spinning vinyl",
            s.batterySaver,
            true,
        ) { v -> onUpdate { it.copy(batterySaver = v) } }
        Text("Background frame rate", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Battery" to 12, "Balanced" to 20, "Smooth" to 30),
            selected = s.bgFps,
            onSelect = { v -> onUpdate { it.copy(bgFps = v) } },
        )
        Text(
            "Lower frame rates make the moving background use less power. The rest of the app is not affected.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun AnimationsTab(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    SettingCard("Animation set") {
        AnimSet.entries.forEach { set ->
            val selected = s.animSet == set
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onUpdate { it.copy(animSet = set) } }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = selected, onClick = { onUpdate { it.copy(animSet = set) } })
                Column(Modifier.weight(1f)) {
                    Text(set.label, style = MaterialTheme.typography.bodyLarge)
                    Text(set.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }

    SettingCard("Intensity") {
        Text(
            "How far and how hard things move. Lower is calmer.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        Segmented(
            options = listOf("Subtle" to 0.25f, "Balanced" to 0.5f, "Lively" to 1f),
            selected = listOf(0.25f, 0.5f, 1f).firstOrNull { kotlin.math.abs(it - s.animIntensity) < 0.03f } ?: -1f,
            onSelect = { v -> onUpdate { it.copy(animIntensity = v) } },
        )
        SliderRow("Fine tune", s.animIntensity, 0f..1.5f, "${(s.animIntensity * 100).roundToInt()}%") { v ->
            onUpdate { it.copy(animIntensity = v) }
        }
        SliderRow("Speed", s.animSpeed, 0.3f..1.5f, "%.1f×".format(s.animSpeed)) { v ->
            onUpdate { it.copy(animSpeed = v) }
        }
    }

    SettingCard("Try it") {
        Text("Tap the track to feel your settings.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        MotionPreview()
    }

    SettingCard("Effects") {
        ToggleRow("List entrance", "Rows rise in one after another", s.listEntrance, true) { v ->
            onUpdate { it.copy(listEntrance = v) }
        }
        ToggleRow("Artwork breathing", "Cover shrinks slightly while paused", s.artBreathing, true) { v ->
            onUpdate { it.copy(artBreathing = v) }
        }
    }
}

@Composable
private fun AudioTab(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    SettingCard("Playback") {
        SliderRow("Speed", s.playbackSpeed, 0.5f..2f, "%.2f×".format(s.playbackSpeed)) { v ->
            onUpdate { it.copy(playbackSpeed = (v * 20).roundToInt() / 20f) }
        }
        SliderRow("Pitch", s.playbackPitch, 0.5f..1.5f, "%.2f×".format(s.playbackPitch)) { v ->
            onUpdate { it.copy(playbackPitch = (v * 20).roundToInt() / 20f) }
        }
        ToggleRow("Skip silence", "Jump over quiet gaps in tracks", s.skipSilence, true) { v ->
            onUpdate { it.copy(skipSilence = v) }
        }
        TextButton(onClick = { onUpdate { it.copy(playbackSpeed = 1f, playbackPitch = 1f) } }) {
            Text("Reset speed and pitch")
        }
    }
    SettingCard("Equalizer") {
        EqualizerPanel(s, onUpdate)
    }
    SettingCard("Sound") {
        SliderRow("Bass boost", s.bassBoost, 0f..1f, "${(s.bassBoost * 100).roundToInt()}%") { v ->
            onUpdate { it.copy(bassBoost = v) }
        }
        SliderRow("Loudness boost", s.loudness, 0f..1f, "${(s.loudness * 100).roundToInt()}%") { v ->
            onUpdate { it.copy(loudness = v) }
        }
        Text(
            "Bass and loudness effects depend on your phone. Very high loudness can distort quiet tracks.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }
}

@Composable
private fun LibraryTab(s: AppSettings, allSongs: List<Song>, onUpdate: SettingsUpdate, onRescan: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val folders = remember(allSongs) { foldersOf(allSongs) }

    SettingCard("Scan") {
        Text(
            "${allSongs.size} songs found in ${folders.size} folders",
            style = MaterialTheme.typography.bodyLarge,
        )
        FilledTonalButton(onClick = onRescan) { Text("Rescan library") }
        ToggleRow(
            "Include non-music audio",
            "Voice recordings, ringtones and other sounds",
            s.includeNonMusic,
            true,
        ) { v -> onUpdate { it.copy(includeNonMusic = v) } }
        Text("Hide short tracks", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Show all" to 0, "Under 30s" to 30, "Under 60s" to 60),
            selected = s.minDurationSec,
            onSelect = { v -> onUpdate { it.copy(minDurationSec = v) } },
        )
    }

    SettingCard("Folders") {
        Text(
            "Turn off a folder to hide everything in it from Aurora.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        Row {
            TextButton(onClick = { onUpdate { it.copy(excludedFolders = emptySet()) } }) { Text("Include all") }
            TextButton(onClick = { onUpdate { it.copy(excludedFolders = folders.map { g -> g.key }.toSet()) } }) {
                Text("Exclude all")
            }
        }
        if (folders.isEmpty()) {
            Text("No folders yet. Allow music access and rescan.", style = MaterialTheme.typography.bodyMedium)
        }
        folders.forEach { g ->
            val included = g.key !in s.excludedFolders
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(verbatim(g.title), style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${g.songs.size} songs  •  ${g.subtitle}",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Switch(
                    checked = included,
                    onCheckedChange = { on ->
                        onUpdate {
                            it.copy(excludedFolders = if (on) it.excludedFolders - g.key else it.excludedFolders + g.key)
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun StartupTab(s: AppSettings, onUpdate: SettingsUpdate, onRunSetup: () -> Unit) {
    var showLanguages by remember { mutableStateOf(false) }
    if (showLanguages) {
        LanguageSheet(
            current = s.language,
            onPick = { l -> onUpdate { it.copy(language = l) }; showLanguages = false },
            onDismiss = { showLanguages = false },
        )
    }
    SettingCard("Language") {
        LanguageButton(s.language, { showLanguages = true })
        Text(
            "Changes the language of the whole app straight away.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    SettingCard("Open on") {
        StartTabPicker(s.startTab) { v -> onUpdate { it.copy(startTab = v) } }
    }
    SettingCard("Intro") {
        ToggleRow("Play intro animation", "The northern lights animation when Aurora opens", s.showIntro, true) { v ->
            onUpdate { it.copy(showIntro = v) }
        }
    }
    SettingCard("Setup") {
        FilledTonalButton(onClick = onRunSetup) { Text("Run setup again") }
    }
}

@Composable
private fun PlayerTab(s: AppSettings, onUpdate: SettingsUpdate) {
    SettingCard("Feedback") {
        ToggleRow("Haptic feedback", "Small vibration when you tap player buttons", s.haptics, true) { v ->
            onUpdate { it.copy(haptics = v) }
        }
        ToggleRow("Keep screen on", "While the Now Playing screen is open", s.keepScreenOn, true) { v ->
            onUpdate { it.copy(keepScreenOn = v) }
        }
    }
}

@Composable
private fun AboutTab(onUpdate: SettingsUpdate) {
    SettingCard("Aurora") {
        Text("Version 2.3.0", style = MaterialTheme.typography.bodyLarge)
        Text(
            "A native Android music player with Material You colours, matte or frosted glass finishes, playlists you can customize and swappable animation sets.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    SettingCard("Reset") {
        FilledTonalButton(onClick = { onUpdate { AppSettings(setupDone = it.setupDone) } }) { Text("Reset all settings") }
    }
}

@Composable
private fun HomeTab(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    SettingCard("Home screen") {
        Text(
            "Choose what shows on Home and in which order.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        s.homeOrder.forEachIndexed { i, section ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 4.dp)) {
                    Text(section.label, style = MaterialTheme.typography.bodyLarge)
                    Text(section.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                IconButton(
                    onClick = { onUpdate { it.copy(homeOrder = moveSection(it.homeOrder, section, -1)) } },
                    enabled = i > 0,
                    modifier = Modifier.size(38.dp),
                ) { Icon(Icons.Rounded.ArrowUpward, "Move up", Modifier.size(20.dp)) }
                IconButton(
                    onClick = { onUpdate { it.copy(homeOrder = moveSection(it.homeOrder, section, 1)) } },
                    enabled = i < s.homeOrder.size - 1,
                    modifier = Modifier.size(38.dp),
                ) { Icon(Icons.Rounded.ArrowDownward, "Move down", Modifier.size(20.dp)) }
                Switch(
                    checked = section !in s.homeHidden,
                    onCheckedChange = { on ->
                        onUpdate { it.copy(homeHidden = if (on) it.homeHidden - section else it.homeHidden + section) }
                    },
                )
            }
        }
        FilledTonalButton(onClick = { onUpdate { it.copy(homeOrder = HomeSection.entries.toList(), homeHidden = emptySet()) } }) {
            Text("Reset layout")
        }
    }
    SettingCard("Daily mix") {
        SliderRow("Songs in the mix", s.mixSize.toFloat(), 6f..30f, "${s.mixSize}") { v ->
            onUpdate { it.copy(mixSize = v.roundToInt()) }
        }
    }
}

private fun moveSection(list: List<HomeSection>, section: HomeSection, delta: Int): List<HomeSection> {
    val from = list.indexOf(section)
    val to = from + delta
    if (from < 0 || to < 0 || to >= list.size) return list
    val out = list.toMutableList()
    out.removeAt(from)
    out.add(to, section)
    return out
}

@Composable
private fun BackupTab(lib: LibraryData, onBackup: suspend () -> String, onRestore: suspend (String) -> String) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = try {
                    val text = onBackup()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    }
                    "Backup saved."
                } catch (e: Exception) {
                    "Could not save the backup: ${e.message ?: "unknown error"}"
                }
                busy = false
            }
        }
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = try {
                    val text = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    }
                    onRestore(text)
                } catch (e: Exception) {
                    "Could not read that file: ${e.message ?: "unknown error"}"
                }
                busy = false
            }
        }
    }

    val songsInPlaylists = lib.playlists.sumOf { it.songIds.size }
    SettingCard("Back up") {
        Text(
            "Saves a small file with your playlists (the song names inside them, not the audio files), your favorites and all your settings.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        Text(
            "${lib.playlists.size} playlists  •  $songsInPlaylists songs in playlists  •  ${lib.favorites.size} favorites",
            style = MaterialTheme.typography.labelLarge,
        )
        FilledTonalButton(
            enabled = !busy,
            onClick = {
                val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                saveLauncher.launch("aurora-backup-$day.json")
            },
        ) {
            Icon(Icons.Rounded.Backup, null, Modifier.size(18.dp))
            Text("  Save backup")
        }
    }
    SettingCard("Restore") {
        Text(
            "Adds the playlists from a backup and restores your settings. Songs are matched by title, artist and length, so it also works on a new phone.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        FilledTonalButton(enabled = !busy, onClick = { openLauncher.launch(arrayOf("*/*")) }) {
            Icon(Icons.Rounded.Restore, null, Modifier.size(18.dp))
            Text("  Restore from file")
        }
        Text(
            "Play counts and listening history are not included in backups.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
    }
    status?.let {
        SettingCard("Status") { Text(it, style = MaterialTheme.typography.bodyMedium, color = cs.primary) }
    }
}

// ------------------------------------------------------------------ shared pieces

@Composable
fun StartTabPicker(selected: AppTab, onSelect: (AppTab) -> Unit) {
    val cs = MaterialTheme.colorScheme
    AppTab.entries.forEach { t ->
        val on = t == selected
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (on) cs.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
                .clickable { onSelect(t) }
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(t.icon(), null, tint = if (on) cs.onPrimaryContainer else cs.onSurfaceVariant)
            Text(t.label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f).padding(start = 12.dp))
            RadioButton(selected = on, onClick = { onSelect(t) })
        }
    }
}

@Composable
private fun MotionPreview() {
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    var right by remember { mutableStateOf(false) }
    val x by animateFloatAsState(
        targetValue = if (right) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "preview",
    )
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(cs.surfaceContainerHighest.copy(alpha = 0.5f))
            .clickable { right = !right },
    ) {
        Box(
            Modifier
                .padding(8.dp)
                .offset(x = (maxWidth - 64.dp) * x)
                .size(48.dp)
                .clip(CircleShape)
                .background(cs.primary)
        )
    }
}

@Composable
fun SettingCard(title: String, content: @Composable () -> Unit) {
    val corner = LocalAppSettings.current.corner
    Column(
        Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val dragging by source.collectIsDraggedAsState()
    var local by remember { mutableFloatStateOf(value) }
    if (!dragging) local = value
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Text(display, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = local.coerceIn(range.start, range.endInclusive),
            onValueChange = { local = it; onChange(it) },
            valueRange = range,
            interactionSource = source,
        )
    }
}

@Composable
fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    val cs = MaterialTheme.colorScheme
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (label, value) ->
            SegmentedButton(
                selected = value == selected,
                onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
                colors = SegmentedButtonDefaults.colors(
                    activeContainerColor = cs.primaryContainer,
                    activeContentColor = cs.onPrimaryContainer,
                    activeBorderColor = cs.primary.copy(alpha = 0.5f),
                    inactiveContainerColor = cs.secondaryContainer.copy(alpha = 0.4f),
                    inactiveContentColor = cs.onSecondaryContainer,
                    inactiveBorderColor = cs.outline.copy(alpha = 0.35f),
                ),
                label = { Text(label, maxLines = 1) },
            )
        }
    }
}
