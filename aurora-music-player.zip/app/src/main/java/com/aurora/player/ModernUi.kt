package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Height of the Current header below the status bar. */
val ModernHeaderHeight: Dp = 64.dp

/** Height of the Current dock (without the system navigation inset). */
val ModernDockHeight: Dp = 64.dp

/**
 * The Current UI's top bar: full width, frosted, with a big bold title that follows the page.
 * With the Clean header style it is just a fade, so the title floats over the content.
 */
@Composable
fun ModernHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val base = modifier.fillMaxWidth().height(topInset + ModernHeaderHeight)
    val surface = if (s.headerStyle == HeaderStyle.FROSTED) {
        base.finish(RectangleShape)
    } else {
        base.background(Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.92f), Color.Transparent)))
    }
    Row(
        surface.padding(top = topInset, start = 12.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(8.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        AnimatedContent(
            targetState = title,
            transitionSpec = { motion.text() },
            label = "modernTitle",
            modifier = Modifier.weight(1f),
        ) { t ->
            Text(
                t,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        actions()
    }
}

/**
 * The Current UI's navigation: one slim dock with every tab as an icon. The selected tab grows a little, takes the
 * accent colour and shows its name (or a small bar when labels are off). Floating or attached to the screen edge.
 */
@Composable
fun ModernDock(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    val s = LocalAppSettings.current
    val attached = s.dockStyle == DockStyle.ATTACHED
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    if (attached) {
        Row(
            modifier
                .fillMaxWidth()
                .height(ModernDockHeight + bottomInset)
                .finish(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .padding(start = 8.dp, end = 8.dp, bottom = bottomInset),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppTab.entries.forEach { t -> DockItem(t, t == tab, Modifier.weight(1f)) { onSelect(t) } }
        }
    } else {
        Row(
            modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .height(ModernDockHeight)
                .finish(RoundedCornerShape(percent = 50))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppTab.entries.forEach { t -> DockItem(t, t == tab, Modifier.weight(1f)) { onSelect(t) } }
        }
    }
}

@Composable
private fun DockItem(tab: AppTab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val accent = s.navColor.tonal(cs)
    val tint by animateColorAsState(
        targetValue = if (selected) cs.primary else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "dockTint",
    )
    val glow by animateColorAsState(
        targetValue = if (selected) accent.first.copy(alpha = 0.85f) else Color.Transparent,
        animationSpec = motion.effects(),
        label = "dockGlow",
    )
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.14f else 1f,
        animationSpec = motion.spatial(),
        label = "dockScale",
    )
    val barWidth by animateDpAsState(
        targetValue = if (selected) 16.dp else 0.dp,
        animationSpec = motion.spatial(),
        label = "dockBar",
    )
    Column(
        modifier
            .fillMaxHeight()
            .padding(vertical = 6.dp, horizontal = 1.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(22.dp))
            .background(glow)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            tab.icon(),
            contentDescription = tab.label,
            tint = tint,
            modifier = Modifier.size(24.dp).graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
        )
        Box(Modifier.height(13.dp), contentAlignment = Alignment.Center) {
            if (s.navLabels) {
                Text(tab.label, color = tint, fontSize = 10.sp, maxLines = 1, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
            } else {
                Box(Modifier.size(width = barWidth, height = 3.dp).clip(CircleShape).background(tint))
            }
        }
    }
}

/**
 * The Current UI's mini player: a capsule with the cover, the song and a play button wrapped in a progress ring.
 * Follows the same Layout settings as before (size, cover, skip button, progress).
 */
@Composable
fun ModernMiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
) {
    val s = LocalAppSettings.current
    val artSize = when (s.miniSize) {
        MiniSize.SLIM -> 38.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 56.dp
    }
    val pad = if (s.miniSize == MiniSize.SLIM) 6.dp else 8.dp
    val button = when (s.miniSize) {
        MiniSize.SLIM -> 40.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 52.dp
    }
    Row(
        modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .finish(shape)
            .clickable(onClick = onOpen)
            .padding(pad),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((s.corner * 0.55f).dp))
            Spacer(Modifier.width(12.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                verbatim(song.title),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                verbatim(song.artist),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(Modifier.size(button + 8.dp), contentAlignment = Alignment.Center) {
            if (s.miniProgress) ProgressRing(vm, duration, Modifier.fillMaxSize())
            PlayPauseButton(
                playing = playing,
                onClick = { vm.togglePlay() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 20.dp,
                tonal = true,
            )
        }
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(
                forward = true,
                onClick = { vm.next() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 24.dp,
            )
        }
    }
}

/** Follows the playback position on its own, so the rest of the mini player is not redrawn every few milliseconds. */
@Composable
private fun ProgressRing(vm: PlayerViewModel, duration: Long, modifier: Modifier) {
    val pos by vm.position.collectAsState()
    CircularProgressIndicator(
        progress = { if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f },
        modifier = modifier,
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
        strokeWidth = 2.5.dp,
    )
}

/** The Current Home screen's opening card: greeting, library numbers, a Play all button and Lumi. */
@Composable
fun ModernHomeHero(
    greeting: String?,
    subtitle: String,
    showMascot: Boolean,
    asleep: Boolean,
    drowsy: Boolean,
    playing: Boolean,
    canPlay: Boolean,
    onPlayAll: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape((s.corner * 1.1f).dp)
    Box(
        Modifier
            .fillMaxWidth()
            .cardFinish(shape)
            .background(
                Brush.linearGradient(
                    listOf(cs.primaryContainer.copy(alpha = 0.65f), cs.tertiaryContainer.copy(alpha = 0.45f)),
                ),
            ),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, top = 18.dp, bottom = 18.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (greeting != null) {
                    Text(
                        greeting,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer,
                    )
                }
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                if (canPlay) {
                    Spacer(Modifier.height(4.dp))
                    FilledTonalButton(onClick = onPlayAll) {
                        Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Play all")
                    }
                }
            }
            if (showMascot) {
                AuroraCat(
                    Modifier.size((s.mascotSize * 1.5f).dp),
                    asleep = asleep,
                    drowsy = drowsy,
                    bounce = playing,
                )
            }
        }
    }
}
