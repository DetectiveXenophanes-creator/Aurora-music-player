package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Height of the Current header below the status bar. The large title needs more room. */
fun modernHeaderHeight(s: AppSettings): Dp = if (s.headerStyle == HeaderStyle.LARGE) 92.dp else 64.dp

/** Height of the Current dock (without the system navigation inset). */
val ModernDockHeight: Dp = 64.dp

/**
 * The Current UI's top bar. Large title: a big bold title with a glowing accent bar that fades into the page. Frosted
 * bar: full width and blurred. Clean: just a fade.
 */
@Composable
fun ModernHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val g = LocalGlow.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val large = s.headerStyle == HeaderStyle.LARGE
    val base = modifier.fillMaxWidth().height(topInset + modernHeaderHeight(s))
    val surface = when (s.headerStyle) {
        HeaderStyle.FROSTED -> base.finish(RectangleShape)
        HeaderStyle.CLEAN -> base.background(Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.92f), Color.Transparent)))
        HeaderStyle.LARGE -> base.background(
            Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.96f), cs.background.copy(alpha = 0.80f), Color.Transparent)),
        )
    }
    Row(
        surface.padding(top = topInset + if (large) 8.dp else 0.dp, start = 12.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(8.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        AnimatedContent(
            targetState = title,
            transitionSpec = { motion.text() },
            label = "modernTitle",
            modifier = Modifier.weight(1f),
        ) { t ->
            Column {
                Text(
                    t,
                    style = if (large) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.headlineSmall,
                    fontWeight = if (large) FontWeight.ExtraBold else FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (large) {
                    Spacer(Modifier.height(3.dp))
                    Box(
                        Modifier
                            .size(width = 34.dp, height = 4.dp)
                            .drawBehind {
                                val c = g?.color?.invoke() ?: cs.primary
                                val r = 26.dp.toPx()
                                drawCircle(
                                    Brush.radialGradient(listOf(c.copy(alpha = 0.55f * s.glowStrength.coerceAtMost(1f)), Color.Transparent), center = center, radius = r),
                                    radius = r,
                                    center = center,
                                )
                            }
                            .clip(CircleShape)
                            .background(cs.primary),
                    )
                }
            }
        }
        actions()
    }
}

/**
 * The Current UI's navigation: one slim dock with every tab as an icon. A glowing marker slides to the selected tab
 * with a springy overshoot and the icon lifts. Floating or attached to the screen edge.
 */
@Composable
fun ModernDock(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    val s = LocalAppSettings.current
    val attached = s.dockStyle == DockStyle.ATTACHED
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    if (attached) {
        val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        Box(
            modifier
                .fillMaxWidth()
                .height(ModernDockHeight + bottomInset)
                .glow(shape, s.glowDock)
                .finish(shape),
        ) {
            DockBody(tab, onSelect, Modifier.fillMaxWidth().height(ModernDockHeight).padding(horizontal = 8.dp))
        }
    } else {
        val shape = RoundedCornerShape(percent = 50)
        Box(
            modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .height(ModernDockHeight)
                .glow(shape, s.glowDock)
                .finish(shape),
        ) {
            DockBody(tab, onSelect, Modifier.fillMaxSize().padding(horizontal = 8.dp))
        }
    }
}

@Composable
private fun DockBody(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val g = LocalGlow.current
    val accent = s.navColor.tonal(cs)
    val tabs = AppTab.entries
    BoxWithConstraints(modifier) {
        val itemW = maxWidth / tabs.size
        val x by animateDpAsState(
            targetValue = itemW * tab.ordinal,
            animationSpec = spring(dampingRatio = 0.62f, stiffness = 380f),
            label = "dockX",
        )
        when (s.dockIndicator) {
            DockIndicator.PILL -> Box(
                Modifier
                    .offset(x = x)
                    .width(itemW)
                    .fillMaxHeight()
                    .padding(horizontal = 2.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(accent.first.copy(alpha = 0.9f)),
            )
            DockIndicator.LINE -> Box(
                Modifier
                    .offset(x = x + (itemW - 30.dp) / 2, y = 1.dp)
                    .size(width = 30.dp, height = 4.dp)
                    .drawBehind {
                        val c = g?.color?.invoke() ?: cs.primary
                        val r = 28.dp.toPx()
                        drawCircle(
                            Brush.radialGradient(listOf(c.copy(alpha = 0.6f * s.glowStrength.coerceAtMost(1f)), Color.Transparent), center = center, radius = r),
                            radius = r,
                            center = center,
                        )
                    }
                    .clip(CircleShape)
                    .background(cs.primary),
            )
        }
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { t -> DockItem(t, t == tab, Modifier.weight(1f)) { onSelect(t) } }
        }
    }
}

@Composable
private fun DockItem(tab: AppTab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val accent = s.navColor.tonal(cs)
    val selectedTint = if (s.dockIndicator == DockIndicator.PILL) accent.second else cs.primary
    val tint by animateColorAsState(
        targetValue = if (selected) selectedTint else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "dockTint",
    )
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.16f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 420f),
        label = "dockScale",
    )
    val lift by animateFloatAsState(
        targetValue = if (selected) -3f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "dockLift",
    )
    Column(
        modifier
            .fillMaxHeight()
            .padding(vertical = 4.dp, horizontal = 1.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(22.dp))
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            tab.icon(),
            contentDescription = tab.label,
            tint = tint,
            modifier = Modifier.size(24.dp).graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationY = lift * density
            },
        )
        if (s.navLabels) {
            Text(
                tab.label,
                color = tint,
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.graphicsLayer { translationY = lift * density * 0.6f },
            )
        }
    }
}

/**
 * The Current UI's mini player: a capsule with the cover, the song and a play button wrapped in a progress ring.
 * Follows the same Layout settings as before (size, cover, skip button, progress).
 */
@Composable
fun ModernMiniPlayer(
    song: Song,
    playing: Boolean,
    duration: Long,
    vm: PlayerViewModel,
    shape: Shape,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
) {
    val s = LocalAppSettings.current
    val artSize = when (s.miniSize) {
        MiniSize.SLIM -> 38.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 56.dp
    }
    val pad = if (s.miniSize == MiniSize.SLIM) 6.dp else 8.dp
    val button = when (s.miniSize) {
        MiniSize.SLIM -> 40.dp
        MiniSize.NORMAL -> 46.dp
        MiniSize.LARGE -> 52.dp
    }
    // Swipe the mini player sideways to skip: right goes back, left goes forward. It follows the finger and springs back.
    var drag by remember { mutableFloatStateOf(0f) }
    val shownDrag by animateFloatAsState(
        targetValue = drag,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "miniDrag",
    )
    val swipe = if (s.miniSwipe) {
        Modifier.pointerInput(song.id) {
            detectHorizontalDragGestures(
                onDragStart = { drag = 0f },
                onDragEnd = {
                    if (drag > 140f) vm.previous() else if (drag < -140f) vm.next()
                    drag = 0f
                },
                onDragCancel = { drag = 0f },
                onHorizontalDrag = { change, amount ->
                    change.consume()
                    drag = (drag + amount).coerceIn(-320f, 320f)
                },
            )
        }
    } else Modifier
    Row(
        modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .graphicsLayer {
                translationX = shownDrag * 0.5f
                alpha = 1f - (abs(shownDrag) / 900f).coerceAtMost(0.3f)
            }
            .glow(shape, s.glowMini, if (playing) 1f else 0.45f)
            .finish(shape)
            .then(swipe)
            .clickable(onClick = onOpen)
            .padding(pad),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.miniArt) {
            Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((s.corner * 0.55f).dp))
            Spacer(Modifier.width(12.dp))
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                verbatim(song.title),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                verbatim(song.artist),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(Modifier.size(button + 8.dp), contentAlignment = Alignment.Center) {
            if (s.miniProgress) ProgressRing(vm, duration, Modifier.fillMaxSize())
            PlayPauseButton(
                playing = playing,
                onClick = { vm.togglePlay() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 20.dp,
                tonal = true,
            )
        }
        if (s.miniSkip) {
            Spacer(Modifier.width(2.dp))
            SkipButton(
                forward = true,
                onClick = { vm.next() },
                modifier = Modifier.size(button - 4.dp),
                iconSize = 24.dp,
            )
        }
    }
}

/** Follows the playback position on its own, so the rest of the mini player is not redrawn every few milliseconds. */
@Composable
private fun ProgressRing(vm: PlayerViewModel, duration: Long, modifier: Modifier) {
    val pos by vm.position.collectAsState()
    CircularProgressIndicator(
        progress = { if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f },
        modifier = modifier,
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
        strokeWidth = 2.5.dp,
    )
}

/** The Current Home screen's opening card: greeting, library numbers, a Play all button and Lumi. */
@Composable
fun ModernHomeHero(
    greeting: String?,
    subtitle: String,
    showMascot: Boolean,
    asleep: Boolean,
    drowsy: Boolean,
    playing: Boolean,
    canPlay: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape((s.corner * 1.1f).dp)
    Box(
        Modifier
            .fillMaxWidth()
            .cardGlow(shape)
            .cardFinish(shape)
            .background(
                Brush.linearGradient(
                    listOf(cs.primaryContainer.copy(alpha = 0.65f), cs.tertiaryContainer.copy(alpha = 0.45f)),
                ),
            ),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, top = 18.dp, bottom = 18.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (greeting != null) {
                    Text(
                        greeting,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer,
                    )
                }
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                if (canPlay) {
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = onPlayAll) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Play all")
                        }
                        OutlinedButton(onClick = onShuffle) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Shuffle")
                        }
                    }
                }
            }
            if (showMascot) {
                AuroraCat(
                    Modifier.size((s.mascotSize * 1.5f).dp),
                    asleep = asleep,
                    drowsy = drowsy,
                    bounce = playing,
                )
            }
        }
    }
}
