package com.aurora.player

import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

// ------------------------------------------------------------------ skip memory

/** A song you have skipped at least 3 times, and more often than you have played it. */
fun isOftenSkipped(id: Long, lib: LibraryData): Boolean {
    val sk = lib.skips[id] ?: 0
    return sk >= 3 && sk > (lib.plays[id] ?: 0)
}

/**
 * Takes the songs you keep skipping out of a shuffle or a mix. Only when Skip memory is on, and only when the list is big
 * enough (12 songs or more) that it still has plenty left; a small playlist is shuffled exactly as it is.
 */
fun skipFiltered(songs: List<Song>, lib: LibraryData): List<Song> {
    if (!lib.skipAware || lib.skips.isEmpty() || songs.size < 12) return songs
    val kept = songs.filter { !isOftenSkipped(it.id, lib) }
    return if (kept.size >= 8) kept else songs
}

/** Every song you skipped twice or more, the ones you skip but never finish first. */
fun oftenSkipped(songs: List<Song>, lib: LibraryData): List<Song> =
    songs.filter { (lib.skips[it.id] ?: 0) >= 2 }
        .sortedWith(
            compareByDescending<Song> { (lib.skips[it.id] ?: 0) - (lib.plays[it.id] ?: 0) }.thenBy { it.title.lowercase() }
        )

// ------------------------------------------------------------------ right now

fun hourLabelOf(hour: Int): String {
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    return "$h12 " + if (hour < 12) "AM" else "PM"
}

/**
 * Songs you usually play around this time of day. Each play is remembered with its hour, a song scores for the hour you
 * are in and half as much for the hours next to it, and the top ones are shuffled with a seed that changes every hour.
 */
fun rightNowMix(songs: List<Song>, lib: LibraryData, size: Int = 25): List<Song> {
    if (lib.songHours.isEmpty()) return emptyList()
    val now = java.time.LocalDateTime.now()
    val h = now.hour
    val scored = ArrayList<Pair<Song, Float>>()
    for (s in skipFiltered(songs, lib)) {
        val hrs = lib.songHours[s.id] ?: continue
        val score = hrs.getOrElse(h) { 0 } + 0.5f * (hrs.getOrElse((h + 23) % 24) { 0 } + hrs.getOrElse((h + 1) % 24) { 0 })
        if (score >= 1f) scored.add(s to score)
    }
    if (scored.isEmpty()) return emptyList()
    scored.sortByDescending { it.second }
    val rnd = Random(now.toLocalDate().toEpochDay() * 24 + h)
    return scored.take(size * 2).map { it.first }.shuffled(rnd).take(size)
}

// ------------------------------------------------------------------ fit my time

enum class FitSource(val label: String) {
    ANY("Anything"), FAVORITES("Favorites"), FRESH("Not heard much")
}

fun fitPool(songs: List<Song>, lib: LibraryData, source: FitSource): List<Song> {
    val base = skipFiltered(songs, lib)
    return when (source) {
        FitSource.ANY -> base
        FitSource.FAVORITES -> base.filter { it.id in lib.favorites }
        FitSource.FRESH -> base.filter { (lib.plays[it.id] ?: 0) <= 1 }
    }
}

/**
 * Picks songs whose lengths add up as close as possible to [targetMs]: a first pick that fits, then a few hundred tries
 * of adding, swapping or dropping one song, keeping every change that lands closer. Same [seed], same mix.
 */
fun fitToTime(pool: List<Song>, targetMs: Long, seed: Long): List<Song> {
    val usable = pool.filter { it.durationMs in 30_000L..900_000L }
    if (usable.isEmpty()) return emptyList()
    val rnd = Random(seed)
    val order = usable.shuffled(rnd)
    val chosen = ArrayList<Song>()
    var total = 0L
    for (s in order) {
        if (total + s.durationMs <= targetMs) {
            chosen.add(s)
            total += s.durationMs
        }
    }
    val unused = ArrayList<Song>(order.filter { it !in chosen })
    var best = abs(targetMs - total)
    var tries = 0
    while (tries < 600 && best > 2_000L) {
        tries++
        when (rnd.nextInt(3)) {
            0 -> if (unused.isNotEmpty()) {
                val j = unused[rnd.nextInt(unused.size)]
                val nt = total + j.durationMs
                if (abs(targetMs - nt) < best) {
                    chosen.add(j)
                    unused.remove(j)
                    total = nt
                    best = abs(targetMs - nt)
                }
            }
            1 -> if (chosen.isNotEmpty() && unused.isNotEmpty()) {
                val i = rnd.nextInt(chosen.size)
                val k = rnd.nextInt(unused.size)
                val nt = total - chosen[i].durationMs + unused[k].durationMs
                if (abs(targetMs - nt) < best) {
                    val old = chosen[i]
                    chosen[i] = unused[k]
                    unused[k] = old
                    total = nt
                    best = abs(targetMs - nt)
                }
            }
            else -> if (chosen.size > 1) {
                val i = rnd.nextInt(chosen.size)
                val nt = total - chosen[i].durationMs
                if (abs(targetMs - nt) < best) {
                    unused.add(chosen.removeAt(i))
                    total = nt
                    best = abs(targetMs - nt)
                }
            }
        }
    }
    return chosen.shuffled(rnd)
}

// ------------------------------------------------------------------ song duel

/** Two songs to put against each other: one that has had few duels, and one close to it in rating. */
fun pickDuel(songs: List<Song>, lib: LibraryData, seed: Long): Pair<Song, Song>? {
    val favs = songs.filter { it.id in lib.favorites }
    val pool = if (favs.size >= 8) favs else songs
    if (pool.size < 2) return null
    val rnd = Random(seed)
    val byGames = pool.sortedBy { lib.duel[it.id]?.second ?: 0 }
    val a = byGames.take(max(4, pool.size / 5)).random(rnd)
    val ra = lib.duel[a.id]?.first ?: 1000
    val close = pool.filter { it.id != a.id }.sortedBy { abs((lib.duel[it.id]?.first ?: 1000) - ra) }.take(6)
    return a to close.random(rnd)
}

/** The songs that keep winning: the best ratings among songs with at least two duels. */
fun duelChampions(songs: List<Song>, lib: LibraryData, size: Int = 25): List<Song> =
    songs.filter { (lib.duel[it.id]?.second ?: 0) >= 2 }
        .sortedByDescending { lib.duel[it.id]?.first ?: 1000 }
        .take(size)
