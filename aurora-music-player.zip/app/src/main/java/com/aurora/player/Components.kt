package com.aurora.player

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

private fun Modifier.edge(on: Boolean, shape: Shape, strength: Float): Modifier =
    if (on) {
        this.border(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.40f * strength), Color.White.copy(alpha = 0.05f * strength))
            ),
            shape,
        )
    } else this

/**
 * Finish for floating bars and panels.
 * GLASS: real backdrop blur of whatever sits behind it (Android 12+; older versions fall back to a tint).
 * MATTE: solid tonal surface, no transparency.
 */
@Composable
fun Modifier.finish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .hazeEffect(
                state = LocalHazeState.current,
                style = HazeStyle(
                    backgroundColor = cs.surface,
                    tint = HazeTint(cs.surfaceContainerHighest.copy(alpha = s.glassTint.coerceIn(0.05f, 0.95f))),
                    blurRadius = s.blur.dp,
                    noiseFactor = 0.05f,
                ),
            )
            .edge(s.edgeHighlight, shape, 1f)
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

/** Finish for cards inside the scrolling content (frosted tint with a light edge, or solid matte). */
@Composable
fun Modifier.cardFinish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .background(cs.surfaceContainerHighest.copy(alpha = (s.glassTint * 0.8f).coerceIn(0.08f, 0.9f)))
            .edge(s.edgeHighlight, shape, 0.75f)
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

// ---------------------------------------------------------------- background

private class Squig(
    val y: Float,
    val amp: Float,
    val wavelength: Float,
    val stroke: Float,
    val speed: Float,
    val alpha: Float,
    val color: Int,
)

private val squigs = listOf(
    Squig(0.07f, 14f, 150f, 4f, 1f, 0.22f, 0),
    Squig(0.19f, 22f, 210f, 7f, -1f, 0.16f, 1),
    Squig(0.31f, 12f, 110f, 3f, 2f, 0.20f, 2),
    Squig(0.45f, 28f, 250f, 10f, -1f, 0.12f, 0),
    Squig(0.58f, 16f, 160f, 5f, 1f, 0.20f, 1),
    Squig(0.71f, 24f, 190f, 8f, -2f, 0.14f, 2),
    Squig(0.84f, 13f, 125f, 4f, 1f, 0.22f, 0),
    Squig(0.95f, 20f, 170f, 6f, -1f, 0.16f, 1),
)

/** The wavy "squiggle" lines from Material Design, drifting slowly behind everything. */
@Composable
fun SquiggleLayer() {
    val mode = LocalAppSettings.current.squiggles
    if (mode == SquiggleMode.OFF) return
    val cs = MaterialTheme.colorScheme
    val animated = mode == SquiggleMode.ANIMATED
    val t = rememberInfiniteTransition(label = "squiggles")
    val phase by t.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(30000, easing = LinearEasing)),
        label = "squigPhase",
    )
    val colors = listOf(cs.primary, cs.secondary, cs.tertiary)
    Canvas(Modifier.fillMaxSize()) {
        val p = if (animated) phase else 0f
        squigs.forEachIndexed { index, sq ->
            val path = Path()
            val wl = sq.wavelength.dp.toPx()
            val amp = sq.amp.dp.toPx()
            val baseY = size.height * sq.y
            var x = -10f
            path.moveTo(x, baseY + amp * sin(x / wl * 2f * PI.toFloat() + sq.speed * p + index))
            while (x < size.width + 10f) {
                x += 6f
                path.lineTo(x, baseY + amp * sin(x / wl * 2f * PI.toFloat() + sq.speed * p + index))
            }
            drawPath(
                path,
                colors[sq.color].copy(alpha = sq.alpha),
                style = Stroke(width = sq.stroke.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

@Composable
fun AuroraBackground(song: Song?, overlayArt: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val style = LocalAppSettings.current.background
    Box(Modifier.fillMaxSize().background(cs.background)) {
        if (style == BackgroundStyle.GRADIENT || overlayArt) {
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.primaryContainer.copy(alpha = 0.85f), Color.Transparent),
                            center = Offset(size.width * 0.10f, size.height * 0.12f),
                            radius = size.width * 1.2f,
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.tertiaryContainer.copy(alpha = 0.75f), Color.Transparent),
                            center = Offset(size.width * 0.95f, size.height * 0.50f),
                            radius = size.width * 1.2f,
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.secondaryContainer.copy(alpha = 0.70f), Color.Transparent),
                            center = Offset(size.width * 0.20f, size.height * 0.95f),
                            radius = size.width * 1.3f,
                        )
                    )
                }
            )
        }
        if (style == BackgroundStyle.ALBUM || overlayArt) {
            Crossfade(targetState = song?.artUri, animationSpec = motion.effects(), label = "bgArt") { uri ->
                if (uri != null) {
                    AsyncImage(
                        model = uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        alpha = 0.55f,
                        modifier = Modifier.fillMaxSize().blur(40.dp, BlurredEdgeTreatment.Unbounded),
                    )
                }
            }
            if (!overlayArt) {
                Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 0.35f)))
            }
        }
        SquiggleLayer()
    }
}

@Composable
fun Art(uri: Uri, modifier: Modifier, shape: Shape = RoundedCornerShape(12.dp)) {
    val cs = MaterialTheme.colorScheme
    Box(modifier.clip(shape).background(cs.secondaryContainer), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSecondaryContainer)
        AsyncImage(
            model = uri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
        )
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------------------------------------------------------------- top bar and overlay pages

@Composable
fun AuroraTopBar(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val shape = RoundedCornerShape((s.corner * 1.2f).dp)
    Row(
        modifier.fillMaxWidth().height(60.dp).finish(shape).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(10.dp))
        } else {
            Spacer(Modifier.width(12.dp))
        }
        AnimatedContent(
            targetState = title,
            transitionSpec = { motion.text() },
            label = "topTitle",
            modifier = Modifier.weight(1f),
        ) { t ->
            Text(
                t,
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        actions()
    }
}

/** Full-screen page with its own background, blurred top bar and back handling. */
@Composable
fun OverlayPage(
    title: String,
    song: Song?,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    val haze = remember { HazeState() }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    BackHandler(onBack = onBack)
    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(song)
                content(PaddingValues(top = topInset + 80.dp, bottom = bottomInset + 24.dp))
            }
            AuroraTopBar(
                title = title,
                onBack = onBack,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp),
                actions = actions,
            )
        }
    }
}
