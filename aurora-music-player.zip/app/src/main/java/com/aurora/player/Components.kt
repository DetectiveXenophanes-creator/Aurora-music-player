package com.aurora.player

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect

/**
 * Finish for floating bars and panels.
 * GLASS: real backdrop blur of whatever sits behind it (Android 12+; older versions fall back to a tint).
 * MATTE: solid tonal surface, no transparency.
 */
@Composable
fun Modifier.finish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .hazeEffect(
                state = LocalHazeState.current,
                style = HazeStyle(
                    backgroundColor = cs.surface,
                    tint = HazeTint(cs.surfaceContainerHighest.copy(alpha = 0.50f)),
                    blurRadius = s.blur.dp,
                    noiseFactor = 0.05f,
                ),
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.40f), Color.White.copy(alpha = 0.05f))),
                shape,
            )
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

/** Finish for cards inside the scrolling content (frosted tint with a light edge, or solid matte). */
@Composable
fun Modifier.cardFinish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .background(cs.surfaceContainerHighest.copy(alpha = 0.40f))
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.04f))),
                shape,
            )
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

@Composable
fun AuroraBackground() {
    val cs = MaterialTheme.colorScheme
    val glass = LocalAppSettings.current.style == SurfaceStyle.GLASS
    val base = Modifier.fillMaxSize().background(cs.background)
    Box(
        if (glass) {
            base.drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(cs.primaryContainer.copy(alpha = 0.85f), Color.Transparent),
                        center = Offset(size.width * 0.10f, size.height * 0.12f),
                        radius = size.width * 1.2f,
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(cs.tertiaryContainer.copy(alpha = 0.75f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.50f),
                        radius = size.width * 1.2f,
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(cs.secondaryContainer.copy(alpha = 0.70f), Color.Transparent),
                        center = Offset(size.width * 0.20f, size.height * 0.95f),
                        radius = size.width * 1.3f,
                    )
                )
            }
        } else base
    )
}

@Composable
fun Art(uri: Uri, modifier: Modifier, shape: Shape = RoundedCornerShape(12.dp)) {
    val cs = MaterialTheme.colorScheme
    Box(modifier.clip(shape).background(cs.secondaryContainer), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSecondaryContainer)
        AsyncImage(
            model = uri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
        )
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
