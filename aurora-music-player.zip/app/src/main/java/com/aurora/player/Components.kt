package com.aurora.player

import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private fun Modifier.edge(on: Boolean, shape: Shape, strength: Float): Modifier =
    if (on) {
        this.border(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.40f * strength), Color.White.copy(alpha = 0.05f * strength))
            ),
            shape,
        )
    } else this

/** Draws [shape] filled with [color], moved by ([dx], [dy]) dp. Used for hard and soft drop shadows. */
private fun DrawScope.shadowOf(shape: Shape, color: Color, dx: Float, dy: Float) {
    val o = shape.createOutline(size, layoutDirection, this)
    translate(dx.dp.toPx(), dy.dp.toPx()) {
        when (o) {
            is Outline.Rectangle -> drawRect(color, Offset(o.rect.left, o.rect.top), Size(o.rect.width, o.rect.height))
            is Outline.Rounded -> drawRoundRect(
                color,
                Offset(o.roundRect.left, o.roundRect.top),
                Size(o.roundRect.width, o.roundRect.height),
                o.roundRect.topLeftCornerRadius,
            )
            is Outline.Generic -> drawPath(o.path, color)
        }
    }
}

/** Surfaces for every design style except Material You (which has its own matte and glass finishes below). */
@Composable
private fun Modifier.designFinish(shape: Shape, bar: Boolean): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val bw = s.borderWidth.coerceIn(0.5f, 5f)
    return when (s.design) {
        DesignStyle.SOFT -> this
            .clip(shape)
            .background(Brush.verticalGradient(listOf(cs.surfaceContainerHighest, cs.surfaceContainerLow)))
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Black.copy(alpha = 0.14f))),
                shape,
            )
        DesignStyle.OUTLINE -> this
            .clip(shape)
            .background(cs.surface.copy(alpha = if (bar) 0.97f else 0.5f))
            .border((bw * 0.75f).dp, cs.outline, shape)
        DesignStyle.BRUTAL -> this
            .drawBehind { shadowOf(shape, cs.onSurface, 3f, 3f) }
            .clip(shape)
            .background(if (bar) cs.surface else cs.surfaceContainerHigh)
            .border(bw.dp, cs.onSurface, shape)
        DesignStyle.GLOSSY -> this
            .clip(shape)
            .background(Brush.verticalGradient(listOf(cs.surfaceContainerHighest, cs.surfaceContainer)))
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0f)),
                        startY = 0f,
                        endY = size.height * 0.55f,
                    )
                )
            }
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))),
                shape,
            )
        DesignStyle.NEON -> this
            .clip(shape)
            .background(cs.surface.copy(alpha = if (bar) 0.94f else 0.6f))
            .border((bw * 3f).dp, cs.primary.copy(alpha = 0.10f), shape)
            .border((bw * 1.8f).dp, cs.primary.copy(alpha = 0.20f), shape)
            .border((bw * 0.7f).dp, cs.primary, shape)
        DesignStyle.CANDY -> this
            .drawBehind { shadowOf(shape, cs.primary.copy(alpha = 0.45f), 0f, 3f) }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(cs.primaryContainer, cs.tertiaryContainer)))
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0f)),
                        startY = 0f,
                        endY = size.height * 0.5f,
                    )
                )
            }
            .border((bw * 1.5f).dp, Color.White.copy(alpha = 0.65f), shape)
        DesignStyle.PAPER -> this
            .drawBehind {
                shadowOf(shape, Color.Black.copy(alpha = 0.06f), 0f, 5f)
                shadowOf(shape, Color.Black.copy(alpha = 0.10f), 0f, 2f)
            }
            .clip(shape)
            .background(if (bar) cs.surfaceContainerLow else cs.surfaceContainerLowest)
            .border(0.8.dp, cs.outlineVariant.copy(alpha = 0.6f), shape)
        DesignStyle.TERMINAL -> this
            .clip(shape)
            .background(cs.surface.copy(alpha = if (bar) 0.97f else 0.7f))
            .border((bw * 0.6f).dp, cs.primary.copy(alpha = 0.85f), shape)
        DesignStyle.MATERIAL -> this
    }
}

/**
 * Finish for floating bars and panels.
 * GLASS: real backdrop blur of whatever sits behind it (Android 12+; older versions fall back to a tint).
 * MATTE: solid tonal surface, no transparency.
 */
@Composable
fun Modifier.finish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    if (s.design != DesignStyle.MATERIAL) return designFinish(shape, true)
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .hazeEffect(
                state = LocalHazeState.current,
                style = HazeStyle(
                    backgroundColor = cs.surface,
                    tint = HazeTint(cs.surfaceContainerHighest.copy(alpha = s.glassTint.coerceIn(0.05f, 0.95f))),
                    blurRadius = s.blur.dp,
                    noiseFactor = 0.05f,
                ),
            )
            .edge(s.edgeHighlight, shape, 1f)
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

/** Finish for cards inside the scrolling content (frosted tint with a light edge, or solid matte). */
@Composable
fun Modifier.cardFinish(shape: Shape): Modifier {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    if (s.design != DesignStyle.MATERIAL) return designFinish(shape, false)
    return if (s.style == SurfaceStyle.GLASS) {
        this
            .clip(shape)
            .background(cs.surfaceContainerHighest.copy(alpha = (s.glassTint * 0.8f).coerceIn(0.08f, 0.9f)))
            .edge(s.edgeHighlight, shape, 0.75f)
    } else {
        this.clip(shape).background(cs.surfaceContainerHigh)
    }
}

/** A quiet repeating pattern behind everything. Drawn once and cached, so it costs nothing while scrolling. */
@Composable
fun PatternLayer(pattern: BgPattern) {
    if (pattern == BgPattern.NONE) return
    val cs = MaterialTheme.colorScheme
    val ink = cs.onSurface.copy(alpha = 0.07f)
    val c1 = cs.primary.copy(alpha = 0.24f)
    val c2 = cs.tertiary.copy(alpha = 0.24f)
    val c3 = cs.secondary.copy(alpha = 0.24f)
    Canvas(Modifier.fillMaxSize()) {
        val step = 28.dp.toPx()
        when (pattern) {
            BgPattern.DOTS -> {
                var y = step / 2f
                while (y < size.height) {
                    var x = step / 2f
                    while (x < size.width) {
                        drawCircle(ink, 1.6.dp.toPx(), Offset(x, y))
                        x += step
                    }
                    y += step
                }
            }
            BgPattern.GRID -> {
                var x = 0f
                while (x < size.width) {
                    drawLine(ink, Offset(x, 0f), Offset(x, size.height), 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(ink, Offset(0f, y), Offset(size.width, y), 1f)
                    y += step
                }
            }
            BgPattern.STARS -> {
                val r = kotlin.random.Random(7)
                repeat(70) {
                    val rad = (0.7f + r.nextFloat() * 1.5f).dp.toPx()
                    drawCircle(
                        cs.onSurface.copy(alpha = 0.10f + r.nextFloat() * 0.18f),
                        rad,
                        Offset(r.nextFloat() * size.width, r.nextFloat() * size.height),
                    )
                }
            }
            BgPattern.CONFETTI -> {
                val r = kotlin.random.Random(11)
                val colors = listOf(c1, c2, c3)
                repeat(46) {
                    val c = colors[r.nextInt(3)]
                    val at = Offset(r.nextFloat() * size.width, r.nextFloat() * size.height)
                    val sz = (5f + r.nextFloat() * 8f).dp.toPx()
                    if (r.nextBoolean()) {
                        drawCircle(c, sz / 2f, at)
                    } else {
                        rotate(r.nextFloat() * 180f, at) {
                            drawRoundRect(c, Offset(at.x - sz / 2f, at.y - sz / 4f), Size(sz, sz / 2f), CornerRadius(sz / 4f))
                        }
                    }
                }
            }
            BgPattern.STRIPES -> {
                var x = -size.height
                while (x < size.width) {
                    drawLine(ink, Offset(x, size.height), Offset(x + size.height, 0f), 2.dp.toPx())
                    x += step * 1.4f
                }
            }
            BgPattern.NONE -> {}
        }
    }
}

// ---------------------------------------------------------------- background

/** True while another full-screen page covers the main screen, so its background can stop animating. */
val LocalBackgroundPaused = compositionLocalOf { false }

private class Squig(
    val y: Float,
    val amp: Float,
    val wavelength: Float,
    val stroke: Float,
    val speed: Float,
    val alpha: Float,
    val color: Int,
)

private val squigs = listOf(
    Squig(0.07f, 14f, 150f, 4f, 1f, 0.22f, 0),
    Squig(0.19f, 22f, 210f, 7f, -1f, 0.16f, 1),
    Squig(0.31f, 12f, 110f, 3f, 2f, 0.20f, 2),
    Squig(0.45f, 28f, 250f, 10f, -1f, 0.12f, 0),
    Squig(0.58f, 16f, 160f, 5f, 1f, 0.20f, 1),
    Squig(0.71f, 24f, 190f, 8f, -2f, 0.14f, 2),
    Squig(0.84f, 13f, 125f, 4f, 1f, 0.22f, 0),
    Squig(0.95f, 20f, 170f, 6f, -1f, 0.16f, 1),
)

/** A scalloped, flower-like circle (the Material 3 badge shape). Some are filled, some are outlines. */
private class Ring(
    val x: Float,        // centre, as a fraction of the width
    val y: Float,        // centre, as a fraction of the height
    val radius: Float,   // dp
    val lobes: Int,
    val depth: Float,    // how deep the scallops are, as a fraction of the radius
    val spin: Int,       // whole lobe steps per loop (sign = direction), so the loop is seamless
    val filled: Boolean,
    val stroke: Float,   // dp, for outlines
    val alpha: Float,
    val color: Int,
)

private val rings = listOf(
    Ring(0.86f, 0.10f, 74f, 10, 0.07f, 1, true, 0f, 0.13f, 0),
    Ring(0.10f, 0.27f, 46f, 12, 0.08f, -1, false, 4f, 0.20f, 1),
    Ring(0.80f, 0.40f, 110f, 9, 0.05f, -1, false, 5f, 0.14f, 2),
    Ring(0.18f, 0.55f, 84f, 8, 0.09f, 1, true, 0f, 0.12f, 2),
    Ring(0.88f, 0.68f, 52f, 14, 0.07f, 2, false, 3f, 0.20f, 0),
    Ring(0.30f, 0.80f, 120f, 11, 0.05f, 1, false, 6f, 0.12f, 1),
    Ring(0.75f, 0.92f, 66f, 9, 0.08f, -1, true, 0f, 0.14f, 1),
)

private const val SQUIGGLE_LOOP_NS = 30_000_000_000L
private const val TWO_PI = 2f * PI.toFloat()

private fun DrawScope.drawRing(path: Path, r: Ring, cx: Float, cy: Float, radiusPx: Float, phase: Float, color: Color, strokePx: Float) {
    path.rewind()
    val steps = 144
    for (i in 0..steps) {
        val th = i.toFloat() / steps * TWO_PI
        val rr = radiusPx * (1f + r.depth * sin(r.lobes * th + r.spin * phase))
        val x = cx + rr * cos(th)
        val y = cy + rr * sin(th)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    if (r.filled) {
        drawPath(path, color)
    } else {
        drawPath(path, color, style = Stroke(width = strokePx, join = StrokeJoin.Round))
    }
}

/**
 * Wavy lines and squiggly circles from Material Design, drifting slowly behind everything.
 * Cheap on purpose: it redraws about 20 times a second, not at all in Still mode, and stops while another
 * full-screen page (Now Playing, Settings, playlist editor) covers it.
 */
@Composable
fun SquiggleLayer() {
    val settings = LocalAppSettings.current
    val mode = settings.squiggles
    if (mode == SquiggleMode.OFF) return
    val paused = LocalBackgroundPaused.current
    val cs = MaterialTheme.colorScheme
    val running = mode == SquiggleMode.ANIMATED && !paused && !settings.batterySaver
    val frameMs = 1000L / settings.bgFps.coerceIn(8, 30)
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running, frameMs) {
        if (!running) return@LaunchedEffect
        while (true) {
            delay(frameMs)
            withFrameNanos { now ->
                phase.floatValue = (now % SQUIGGLE_LOOP_NS).toFloat() / SQUIGGLE_LOOP_NS.toFloat() * TWO_PI
            }
        }
    }
    val colors = listOf(cs.primary, cs.secondary, cs.tertiary)
    val path = remember { Path() }
    Canvas(Modifier.fillMaxSize()) {
        val p = phase.floatValue
        val step = 7.dp.toPx()

        // squiggly circles first, so the lines draw over them
        rings.forEachIndexed { index, r ->
            val bobX = 8.dp.toPx() * sin(p + index)
            val bobY = 6.dp.toPx() * sin(p + index * 2f)
            drawRing(
                path = path,
                r = r,
                cx = size.width * r.x + bobX,
                cy = size.height * r.y + bobY,
                radiusPx = r.radius.dp.toPx(),
                phase = p,
                color = colors[r.color].copy(alpha = r.alpha),
                strokePx = r.stroke.dp.toPx(),
            )
        }

        squigs.forEachIndexed { index, sq ->
            path.rewind()
            val wl = sq.wavelength.dp.toPx()
            val amp = sq.amp.dp.toPx()
            val baseY = size.height * sq.y
            var x = -10f
            path.moveTo(x, baseY + amp * sin(x / wl * TWO_PI + sq.speed * p + index))
            while (x < size.width + 10f) {
                x += step
                path.lineTo(x, baseY + amp * sin(x / wl * TWO_PI + sq.speed * p + index))
            }
            drawPath(
                path,
                colors[sq.color].copy(alpha = sq.alpha),
                style = Stroke(width = sq.stroke.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

/**
 * Feathers the edges of whatever it wraps so the picture melts into the background.
 * [amount] is 0 (sharp) to 1 (very soft).
 */
fun Modifier.softEdges(amount: Float, circular: Boolean = false): Modifier {
    if (amount <= 0.02f) return this
    val f = (amount.coerceIn(0f, 1f) * 0.25f).coerceAtLeast(0.01f)
    if (circular) {
        val g = (f * 1.6f).coerceAtMost(0.5f)
        return this
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.radialGradient(0f to Color.Black, (1f - g) to Color.Black, 1f to Color.Transparent),
                    blendMode = BlendMode.DstIn,
                )
            }
    }
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(
                Brush.horizontalGradient(0f to Color.Transparent, f to Color.Black, (1f - f) to Color.Black, 1f to Color.Transparent),
                blendMode = BlendMode.DstIn,
            )
            drawRect(
                Brush.verticalGradient(0f to Color.Transparent, f to Color.Black, (1f - f) to Color.Black, 1f to Color.Transparent),
                blendMode = BlendMode.DstIn,
            )
        }
}

/**
 * Full-screen pages sit on top of other pages. Without this, touches that miss a button fall through
 * to whatever is underneath (for example a song row) and trigger it.
 */
fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) { detectTapGestures { } }

/** Keeps wide screens readable: content is centred and never wider than [max]. */
@Composable
fun ContentWidth(max: Dp, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(Modifier.widthIn(max = max).fillMaxSize()) { content() }
    }
}

@Composable
fun AuroraBackground(song: Song?, overlayArt: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val style = LocalAppSettings.current.background
    val lite = LocalLite.current
    Box(Modifier.fillMaxSize().background(cs.background)) {
        if (style == BackgroundStyle.GRADIENT || overlayArt) {
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.primaryContainer.copy(alpha = 0.85f), Color.Transparent),
                            center = Offset(size.width * 0.10f, size.height * 0.12f),
                            radius = size.width * 1.2f,
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.tertiaryContainer.copy(alpha = 0.75f), Color.Transparent),
                            center = Offset(size.width * 0.95f, size.height * 0.50f),
                            radius = size.width * 1.2f,
                        )
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(cs.secondaryContainer.copy(alpha = 0.70f), Color.Transparent),
                            center = Offset(size.width * 0.20f, size.height * 0.95f),
                            radius = size.width * 1.3f,
                        )
                    )
                }
            )
        }
        if (style == BackgroundStyle.ALBUM || overlayArt) {
            Crossfade(targetState = song?.artUri, animationSpec = motion.effects(), label = "bgArt") { uri ->
                if (uri != null) {
                    AsyncImage(
                        model = uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        alpha = 0.55f,
                        modifier = Modifier.fillMaxSize().then(
                            if (lite) Modifier else Modifier.blur(40.dp, BlurredEdgeTreatment.Unbounded)
                        ),
                    )
                }
            }
            if (!overlayArt) {
                Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 0.35f)))
            }
        }
        AuroraGlowLayer(LocalAppSettings.current.auroraGlow)
        PatternLayer(LocalAppSettings.current.bgPattern)
        SquiggleLayer()
    }
}

@Composable
fun Art(uri: Uri, modifier: Modifier, shape: Shape = RoundedCornerShape(12.dp)) {
    val cs = MaterialTheme.colorScheme
    Box(modifier.clip(shape).background(cs.secondaryContainer), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSecondaryContainer)
        AsyncImage(
            model = uri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
        )
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** "3 h 20 min", "45 min" or "2 d 4 h" for longer spans. */
fun fmtLong(ms: Long): String {
    val totalMin = (ms / 60_000).coerceAtLeast(0)
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h >= 24 -> "${h / 24} d ${h % 24} h"
        h > 0 -> "$h h $m min"
        else -> "$m min"
    }
}

// ---------------------------------------------------------------- top bar and overlay pages

@Composable
fun AuroraTopBar(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val shape = RoundedCornerShape((s.corner * 1.2f).dp)
    Row(
        modifier.fillMaxWidth().height(60.dp).finish(shape).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(10.dp))
        } else {
            Spacer(Modifier.width(12.dp))
        }
        AnimatedContent(
            targetState = title,
            transitionSpec = { motion.text() },
            label = "topTitle",
            modifier = Modifier.weight(1f),
        ) { t ->
            Text(
                t,
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        actions()
    }
}

/** Full-screen page with its own background, blurred top bar and back handling. */
@Composable
fun OverlayPage(
    title: String,
    song: Song?,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    maxWidth: Dp = 760.dp,
    content: @Composable (PaddingValues) -> Unit,
) {
    val haze = remember { HazeState() }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    BackHandler(onBack = onBack)
    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize().blockTouches()) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(song)
                ContentWidth(maxWidth) {
                    content(PaddingValues(top = topInset + 80.dp, bottom = bottomInset + 24.dp))
                }
            }
            AuroraTopBar(
                title = title,
                onBack = onBack,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp)
                    .widthIn(max = maxWidth - 32.dp),
                actions = actions,
            )
        }
    }
}
