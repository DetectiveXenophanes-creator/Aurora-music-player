package com.aurora.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Settings > Smart extras: what Aurora learns from how you listen, and a way to wipe it. */
@Composable
internal fun LabTab() {
    val context = LocalContext.current
    val store = remember { LibraryStore(context) }
    val lib by store.flow.collectAsState(initial = LibraryData())
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var note by remember { mutableStateOf<String?>(null) }
    val keptOut = lib.skips.keys.count { isOftenSkipped(it, lib) }
    val duels = lib.duel.values.sumOf { it.second } / 2

    note?.let { msg ->
        SettingCard("Status") { Text(msg, style = MaterialTheme.typography.bodyMedium, color = cs.primary) }
    }

    SettingCard("Skip memory") {
        Text(
            "Aurora notices when you skip a song within its first seconds. Songs you skip at least 3 times, and skip more often than you play, are kept out of Shuffle, the Daily mix and the smart mixes. A playlist with fewer than 12 songs is never filtered, and you can still play any song yourself.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        ToggleRow(
            "Keep often-skipped songs out of shuffles",
            if (keptOut == 0) "Nothing is being kept out right now" else "$keptOut songs are being kept out right now",
            lib.skipAware,
            true,
        ) { on -> scope.launch { store.setSkipAware(on) } }
        Text(
            "See every song you skip in Playlists, under Often skipped.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        OutlinedButton(onClick = {
            scope.launch { store.clearSkips() }
            note = "Skip memory is clear. Aurora starts counting again."
        }) { Text("Forget all skips") }
    }

    SettingCard("Right now") {
        Text(
            "Aurora remembers the hour of each play, starting with this version, and builds a mix of the songs you usually play at the hour you are in. It needs a few days of listening before the first mix shows up on Home.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        Text(
            "${lib.songHours.size} songs have hour data so far.",
            style = MaterialTheme.typography.labelLarge,
        )
        OutlinedButton(onClick = {
            scope.launch { store.clearSongHours() }
            note = "Your hour habits are forgotten."
        }) { Text("Forget my hours") }
    }

    SettingCard("Song duel") {
        Text(
            "Pick the better of two songs on Home. Every pick moves the winner up and the loser down (the Elo system chess uses). The Duel champions list in Playlists shows the songs that keep winning.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$duels duels played", style = MaterialTheme.typography.labelLarge)
        }
        OutlinedButton(onClick = {
            scope.launch { store.clearDuels() }
            note = "Duel rankings are reset."
        }) { Text("Reset duel rankings") }
    }
}
