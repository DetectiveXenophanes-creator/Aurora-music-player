package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import kotlin.random.Random

// ------------------------------------------------------------------ playlist model

enum class CoverStyle(val label: String) {
    MOSAIC("Mosaic"), ICON("Icon"), GRADIENT("Gradient"), EMOJI("Emoji"), ART("Single cover"), STACK("Stack"),
}
enum class PlaylistSort(val label: String) { MANUAL("As added"), TITLE("Title"), ARTIST("Artist"), LENGTH("Longest first") }
enum class PlaylistShape(val label: String, val corner: Int) {
    SOFT("Soft", 24), ROUND("Round", 40), SQUARE("Sharp", 8), PILL("Pill", 56)
}
enum class PlaylistFeel(val label: String, val blurb: String) {
    SQUISH("Squish", "Shrinks under your finger"),
    BOUNCE("Bounce", "Springs back with a wobble"),
    TILT("Tilt", "Leans like a physical card"),
    GLOW("Glow", "Lights up its edge"),
    LIFT("Lift", "Rises toward you"),
    NONE("Still", "No reaction"),
}

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long> = emptyList(),
    val accent: Int = 0,          // index into playlistAccents, 0 = follow theme
    val icon: Int = 0,            // index into playlistIconCount
    val cover: CoverStyle = CoverStyle.MOSAIC,
    val shape: PlaylistShape = PlaylistShape.SOFT,
    val feel: PlaylistFeel = PlaylistFeel.SQUISH,
    val response: Float = 0.6f,
    val emoji: String = "",       // shown as the cover with the Emoji cover style
    val accent2: Int = -1,        // second colour of the gradient, -1 = automatic
    val note: String = "",        // a short description under the name
    val pinned: Boolean = false,  // pinned playlists stay at the top
    val sort: PlaylistSort = PlaylistSort.MANUAL,
)

val playlistAccents: List<Int> = listOf(
    0x00000000, 0xFF6750A4, 0xFF0B6BCB, 0xFF00897B, 0xFF1B8A5A, 0xFFD9480F, 0xFFC2185B, 0xFFB00020,
).map { it.toInt() }
const val PLAYLIST_ICON_COUNT = 8

/** Changes the user made to one song. A null field means "keep what the file says". The audio file itself is never touched. */
data class SongEdit(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val art: String? = null, // file name of the custom cover inside the app's covers folder
) {
    val isEmpty: Boolean get() = title == null && artist == null && album == null && art == null
}

data class LibraryData(
    val playlists: List<Playlist> = emptyList(),
    val favorites: Set<Long> = emptySet(),
    val plays: Map<Long, Int> = emptyMap(),
    val recent: List<Long> = emptyList(),
    /** (song id, epoch day) for every counted play, newest last. Powers "On this day". */
    val playLog: List<Pair<Long, Long>> = emptyList(),
    /** Emoji "mood stickers" the user gave to songs. */
    val stickers: Map<Long, String> = emptyMap(),
    val edits: Map<Long, SongEdit> = emptyMap(),
    /** Plays per hour of the day, for each epoch day (24 counts per day). Powers streaks, badges and the listening clock. */
    val listenLog: Map<Long, List<Int>> = emptyMap(),
    /** Days with plays that came from a restored backup (day -> plays), for streaks and the calendar. */
    val extraDays: Map<Long, Int> = emptyMap(),
    /** How often you skipped a song within its first seconds (song id -> skips). */
    val skips: Map<Long, Int> = emptyMap(),
    /** Plays of each song per hour of the day (song id -> 24 counts), for the Right now mix. */
    val songHours: Map<Long, List<Int>> = emptyMap(),
    /** Song duel scores (song id -> rating and number of duels). */
    val duel: Map<Long, Pair<Int, Int>> = emptyMap(),
    /** Keep often-skipped songs out of shuffle, the daily mix and the other smart mixes. */
    val skipAware: Boolean = true,
)

// ------------------------------------------------------------------ browsing groups

enum class DetailKind { ALBUM, ARTIST, FOLDER, PLAYLIST, SMART }

data class DetailRef(val kind: DetailKind, val key: String, val title: String)

data class Group(
    val key: String,
    val title: String,
    val subtitle: String,
    val art: Song?,
    val songs: List<Song>,
)

fun albumsOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.albumId }.map { (id, list) ->
        Group(
            key = id.toString(),
            title = list.first().album.ifBlank { "Unknown album" },
            subtitle = list.first().artist,
            art = list.first(),
            songs = list,
        )
    }.sortedBy { it.title.lowercase() }

fun artistsOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.artist }.map { (artist, list) ->
        Group(artist, artist, "${list.size} songs", list.first(), list)
    }.sortedBy { it.title.lowercase() }

fun foldersOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.folder }.map { (path, list) ->
        Group(path, path.substringAfterLast('/').ifBlank { path }, path, list.first(), list)
    }.sortedBy { it.title.lowercase() }

fun songsFor(ref: DetailRef, songs: List<Song>, lib: LibraryData): List<Song> = when (ref.kind) {
    DetailKind.ALBUM -> songs.filter { it.albumId.toString() == ref.key }
    DetailKind.ARTIST -> songs.filter { it.artist == ref.key }
    DetailKind.FOLDER -> songs.filter { it.folder == ref.key }
    DetailKind.PLAYLIST -> {
        val byId = songs.associateBy { it.id }
        lib.playlists.firstOrNull { it.id == ref.key }?.let { pl ->
            val list = pl.songIds.mapNotNull { byId[it] }
            when (pl.sort) {
                PlaylistSort.MANUAL -> list
                PlaylistSort.TITLE -> list.sortedBy { it.title.lowercase() }
                PlaylistSort.ARTIST -> list.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
                PlaylistSort.LENGTH -> list.sortedByDescending { it.durationMs }
            }
        } ?: emptyList()
    }
    DetailKind.SMART -> when (ref.key) {
        "fav" -> songs.filter { it.id in lib.favorites }
        "top" -> mostPlayed(songs, lib).take(25)
        "forgotten" -> forgottenFavorites(songs, lib)
        "rightnow" -> rightNowMix(songs, lib)
        "skipped" -> oftenSkipped(songs, lib)
        "duel" -> duelChampions(songs, lib)
        else -> {
            val byId = songs.associateBy { it.id }
            lib.recent.mapNotNull { byId[it] }
        }
    }
}

/** Songs with at least one play, most played first. */
fun mostPlayed(songs: List<Song>, lib: LibraryData): List<Song> =
    songs.filter { (lib.plays[it.id] ?: 0) > 0 }.sortedByDescending { lib.plays[it.id] ?: 0 }

/** How many days without a play before a favourite counts as forgotten. */
const val FORGOTTEN_DAYS = 90

/**
 * Favourites you have not played for [FORGOTTEN_DAYS] days or more. A favourite with no play in the history counts too
 * (never played, or played before the history was kept). The ones you played most come first.
 */
fun forgottenFavorites(songs: List<Song>, lib: LibraryData): List<Song> {
    if (lib.favorites.isEmpty()) return emptyList()
    val today = java.time.LocalDate.now().toEpochDay()
    val last = HashMap<Long, Long>()
    for ((id, day) in lib.playLog) {
        val old = last[id]
        if (old == null || day > old) last[id] = day
    }
    return songs
        .filter { song ->
            val l = last[song.id]
            song.id in lib.favorites && (l == null || today - l >= FORGOTTEN_DAYS)
        }
        .sortedWith(compareByDescending<Song> { lib.plays[it.id] ?: 0 }.thenBy { it.title.lowercase() })
}

/** A fresh mix every day: leans on your most played songs, filled out with the rest of your library. */
fun dailyMix(allSongs: List<Song>, lib: LibraryData, size: Int = 12): List<Song> {
    val songs = skipFiltered(allSongs, lib)
    if (songs.isEmpty()) return emptyList()
    val day = Calendar.getInstance().let { it.get(Calendar.YEAR) * 1000 + it.get(Calendar.DAY_OF_YEAR) }
    val rnd = Random(day)
    val favourites = mostPlayed(songs, lib).take(40).shuffled(rnd).take(size * 2 / 3 + 1)
    val used = favourites.map { it.id }.toSet()
    val filler = songs.filter { it.id !in used }.shuffled(rnd).take(size - favourites.size)
    return (favourites + filler).shuffled(rnd).take(size)
}

/** Search, filter and sort for the Songs tab. */
fun applySortFilter(songs: List<Song>, query: String, s: AppSettings, lib: LibraryData): List<Song> {
    var list = songs
    if (query.isNotBlank()) {
        list = list.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    if (s.filterFav) list = list.filter { it.id in lib.favorites }
    list = when (s.filterLen) {
        LenFilter.ANY -> list
        LenFilter.SHORT -> list.filter { it.durationMs < 180_000L }
        LenFilter.MEDIUM -> list.filter { it.durationMs in 180_000L..360_000L }
        LenFilter.LONG -> list.filter { it.durationMs > 360_000L }
    }
    val cmp: Comparator<Song> = when (s.sortKey) {
        SortKey.TITLE -> compareBy<Song> { it.title.lowercase() }
        SortKey.ARTIST -> compareBy<Song> { it.artist.lowercase() }.thenBy { it.title.lowercase() }
        SortKey.ALBUM -> compareBy<Song> { it.album.lowercase() }.thenBy { it.title.lowercase() }
        SortKey.DURATION -> compareBy<Song> { it.durationMs }
        SortKey.ADDED -> compareBy<Song> { it.dateAdded }
        SortKey.PLAYS -> compareBy<Song> { lib.plays[it.id] ?: 0 }
    }
    return list.sortedWith(if (s.sortAsc) cmp else cmp.reversed())
}

/** Estimated listening totals, worked out from play counts and song lengths. */
class ListeningStats(
    val totalMs: Long,
    val totalPlays: Int,
    val distinctSongs: Int,
    val topArtists: List<Pair<String, Int>>,
)

fun listeningStats(songs: List<Song>, lib: LibraryData): ListeningStats {
    var ms = 0L
    var plays = 0
    var distinct = 0
    val perArtist = HashMap<String, Int>()
    for (song in songs) {
        val c = lib.plays[song.id] ?: 0
        if (c <= 0) continue
        ms += c.toLong() * song.durationMs
        plays += c
        distinct++
        perArtist[song.artist] = (perArtist[song.artist] ?: 0) + c
    }
    val top = perArtist.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }
    return ListeningStats(ms, plays, distinct, top)
}

/** How a playlist (or any song list) can be sorted when you look at it. LIST is the order the list already has. */
enum class ListSort(val label: String) {
    LIST("List order"), TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), LENGTH("Length"), ADDED("Date added"), PLAYS("Plays")
}

/** What you are looking for in a song list: a search, a sort and a few filters. Only changes what is shown. */
data class ListView(
    val query: String = "",
    val sort: ListSort = ListSort.LIST,
    val asc: Boolean = true,
    val favOnly: Boolean = false,
    val neverPlayed: Boolean = false,
    val len: LenFilter = LenFilter.ANY,
) {
    /** True when the list looks different from how it is stored. */
    val active: Boolean
        get() = query.isNotBlank() || sort != ListSort.LIST || !asc || favOnly || neverPlayed || len != LenFilter.ANY
}

fun applyListView(songs: List<Song>, v: ListView, lib: LibraryData): List<Song> {
    var list = songs
    if (v.query.isNotBlank()) {
        list = list.filter {
            it.title.contains(v.query, true) || it.artist.contains(v.query, true) || it.album.contains(v.query, true)
        }
    }
    if (v.favOnly) list = list.filter { it.id in lib.favorites }
    if (v.neverPlayed) list = list.filter { (lib.plays[it.id] ?: 0) == 0 }
    list = when (v.len) {
        LenFilter.ANY -> list
        LenFilter.SHORT -> list.filter { it.durationMs < 180_000L }
        LenFilter.MEDIUM -> list.filter { it.durationMs in 180_000L..360_000L }
        LenFilter.LONG -> list.filter { it.durationMs > 360_000L }
    }
    if (v.sort == ListSort.LIST) return if (v.asc) list else list.reversed()
    val cmp: Comparator<Song> = when (v.sort) {
        ListSort.TITLE -> compareBy<Song> { it.title.lowercase() }
        ListSort.ARTIST -> compareBy<Song> { it.artist.lowercase() }.thenBy { it.title.lowercase() }
        ListSort.ALBUM -> compareBy<Song> { it.album.lowercase() }.thenBy { it.title.lowercase() }
        ListSort.LENGTH -> compareBy<Song> { it.durationMs }
        ListSort.ADDED -> compareBy<Song> { it.dateAdded }
        ListSort.PLAYS -> compareBy<Song> { lib.plays[it.id] ?: 0 }
        ListSort.LIST -> compareBy<Song> { 0 }
    }
    return list.sortedWith(if (v.asc) cmp else cmp.reversed())
}

/** The two directions of a sort, as the words to show: first the ascending one, then the descending one. */
fun listDirectionLabels(sort: ListSort): Pair<String, String> = when (sort) {
    ListSort.LIST -> "As saved" to "Backwards"
    ListSort.TITLE, ListSort.ARTIST, ListSort.ALBUM -> "A to Z" to "Z to A"
    ListSort.LENGTH -> "Shortest first" to "Longest first"
    ListSort.ADDED -> "Oldest first" to "Newest first"
    ListSort.PLAYS -> "Least played" to "Most played"
}

fun sortDirectionLabels(key: SortKey): Pair<String, String> = when (key) {
    SortKey.TITLE, SortKey.ARTIST, SortKey.ALBUM -> "A to Z" to "Z to A"
    SortKey.DURATION -> "Shortest first" to "Longest first"
    SortKey.ADDED -> "Oldest first" to "Newest first"
    SortKey.PLAYS -> "Least played" to "Most played"
}

// ------------------------------------------------------------------ persistence

private val Context.libraryStore by preferencesDataStore(name = "aurora_library")

class LibraryStore(private val context: Context) {
    private object K {
        val playlists = stringPreferencesKey("playlists")
        val favorites = stringSetPreferencesKey("favorites")
        val plays = stringPreferencesKey("plays")
        val recent = stringPreferencesKey("recent")
        val playLog = stringPreferencesKey("play_log")
        val stickers = stringPreferencesKey("stickers")
        val edits = stringPreferencesKey("song_edits")
        val listen = stringPreferencesKey("listen_hours")
        val days = stringPreferencesKey("passport_days")
        val skips = stringPreferencesKey("skips")
        val songHours = stringPreferencesKey("song_hours")
        val duel = stringPreferencesKey("duel")
        val skipAware = booleanPreferencesKey("lab_skip_aware")
    }

    val flow: Flow<LibraryData> = context.libraryStore.data.map { p ->
        LibraryData(
            playlists = readPlaylists(p[K.playlists]),
            favorites = (p[K.favorites] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet(),
            plays = readPlays(p[K.plays]),
            recent = readIds(p[K.recent]),
            playLog = readLog(p[K.playLog]),
            stickers = readStickers(p[K.stickers]),
            edits = readEdits(p[K.edits]),
            listenLog = readListen(p[K.listen]),
            extraDays = readDays(p[K.days]),
            skips = readPlays(p[K.skips]),
            songHours = readListen(p[K.songHours]),
            duel = readDuel(p[K.duel]),
            skipAware = p[K.skipAware] ?: true,
        )
    }

    /** A skip: you moved on from the song within its first seconds. */
    suspend fun recordSkip(id: Long) {
        context.libraryStore.edit { p ->
            val skips = readPlays(p[K.skips]).toMutableMap()
            skips[id] = (skips[id] ?: 0) + 1
            p[K.skips] = JSONObject().also { o -> skips.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
        }
    }

    /** One duel: the winner takes points from the loser (Elo, everyone starts at 1000). */
    suspend fun recordDuel(winner: Long, loser: Long) {
        context.libraryStore.edit { p ->
            val d = readDuel(p[K.duel]).toMutableMap()
            val w = d[winner] ?: (1000 to 0)
            val l = d[loser] ?: (1000 to 0)
            val expected = 1.0 / (1.0 + Math.pow(10.0, (l.first - w.first) / 400.0))
            val kw = if (w.second < 10) 40.0 else 24.0
            val kl = if (l.second < 10) 40.0 else 24.0
            d[winner] = (w.first + Math.round(kw * (1.0 - expected)).toInt()) to (w.second + 1)
            d[loser] = (l.first - Math.round(kl * (1.0 - expected)).toInt()) to (l.second + 1)
            p[K.duel] = d.entries.joinToString(",") { "${it.key}:${it.value.first}:${it.value.second}" }
        }
    }

    /** Merges skips, duel scores and per-song hours from a backup; every number keeps the bigger value. */
    suspend fun mergeSmart(skips: Map<Long, Int>, duel: Map<Long, Pair<Int, Int>>, hours: Map<Long, List<Int>>) {
        context.libraryStore.edit { p ->
            if (skips.isNotEmpty()) {
                val cur = readPlays(p[K.skips]).toMutableMap()
                skips.forEach { (id, n) -> if (n > (cur[id] ?: 0)) cur[id] = n }
                p[K.skips] = JSONObject().also { o -> cur.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
            }
            if (duel.isNotEmpty()) {
                val cur = readDuel(p[K.duel]).toMutableMap()
                duel.forEach { (id, v) ->
                    val old = cur[id]
                    if (old == null || v.second > old.second) cur[id] = v
                }
                p[K.duel] = cur.entries.joinToString(",") { "${it.key}:${it.value.first}:${it.value.second}" }
            }
            if (hours.isNotEmpty()) {
                val cur = readListen(p[K.songHours]).toMutableMap()
                hours.forEach { (id, hrs) ->
                    val old = cur[id]
                    cur[id] = List(24) { h -> maxOf(old?.getOrElse(h) { 0 } ?: 0, hrs.getOrElse(h) { 0 }) }
                }
                p[K.songHours] = writeListen(cur)
            }
        }
    }

    suspend fun setSkipAware(on: Boolean) {
        context.libraryStore.edit { it[K.skipAware] = on }
    }

    suspend fun clearSkips() {
        context.libraryStore.edit { it.remove(K.skips) }
    }

    suspend fun clearSongHours() {
        context.libraryStore.edit { it.remove(K.songHours) }
    }

    suspend fun clearDuels() {
        context.libraryStore.edit { it.remove(K.duel) }
    }

    /**
     * Merges listening history from a backup. Nothing ever goes down: every count keeps the bigger of the two values,
     * so restoring the same backup twice changes nothing.
     */
    suspend fun mergeHistory(plays: Map<Long, Int>, listen: Map<Long, List<Int>>, days: Map<Long, Int>) {
        context.libraryStore.edit { p ->
            if (plays.isNotEmpty()) {
                val cur = readPlays(p[K.plays]).toMutableMap()
                plays.forEach { (id, n) -> if (n > (cur[id] ?: 0)) cur[id] = n }
                p[K.plays] = JSONObject().also { o -> cur.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
            }
            if (listen.isNotEmpty()) {
                val cur = readListen(p[K.listen]).toMutableMap()
                listen.forEach { (day, hours) ->
                    val old = cur[day]
                    cur[day] = List(24) { h -> maxOf(old?.getOrElse(h) { 0 } ?: 0, hours.getOrElse(h) { 0 }) }
                }
                p[K.listen] = writeListen(cur)
            }
            if (days.isNotEmpty()) {
                val cur = readDays(p[K.days]).toMutableMap()
                days.forEach { (day, n) -> if (n > (cur[day] ?: 0)) cur[day] = n }
                p[K.days] = cur.entries.joinToString(",") { "${it.key}:${it.value}" }
            }
        }
    }

    /** Gives a song an emoji sticker, or takes it away when [emoji] is null or blank. */
    suspend fun setSticker(id: Long, emoji: String?) {
        context.libraryStore.edit { p ->
            val cur = readStickers(p[K.stickers]).toMutableMap()
            if (emoji.isNullOrBlank()) cur.remove(id) else cur[id] = emoji
            p[K.stickers] = JSONObject().also { o -> cur.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
        }
    }

    /** Saves the edit for one song, or forgets it when [edit] is null or empty. */
    suspend fun setEdit(id: Long, edit: SongEdit?) {
        context.libraryStore.edit { p ->
            val cur = readEdits(p[K.edits]).toMutableMap()
            if (edit == null || edit.isEmpty) cur.remove(id) else cur[id] = edit
            p[K.edits] = writeEdits(cur)
        }
    }

    private fun readEdits(s: String?): Map<Long, SongEdit> {
        if (s.isNullOrBlank()) return emptyMap()
        return runCatching {
            val o = JSONObject(s)
            o.keys().asSequence().mapNotNull { k ->
                val id = k.toLongOrNull() ?: return@mapNotNull null
                val e = o.getJSONObject(k)
                id to SongEdit(
                    title = if (e.has("t")) e.getString("t") else null,
                    artist = if (e.has("a")) e.getString("a") else null,
                    album = if (e.has("b")) e.getString("b") else null,
                    art = if (e.has("c")) e.getString("c") else null,
                )
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    private fun writeEdits(map: Map<Long, SongEdit>): String {
        val o = JSONObject()
        map.forEach { (id, e) ->
            val j = JSONObject()
            e.title?.let { j.put("t", it) }
            e.artist?.let { j.put("a", it) }
            e.album?.let { j.put("b", it) }
            e.art?.let { j.put("c", it) }
            o.put(id.toString(), j)
        }
        return o.toString()
    }

    suspend fun toggleFavorite(id: Long) {
        context.libraryStore.edit { p ->
            val cur = (p[K.favorites] ?: emptySet()).toMutableSet()
            if (!cur.remove(id.toString())) cur.add(id.toString())
            p[K.favorites] = cur
        }
    }

    suspend fun addFavorites(ids: Set<Long>) {
        context.libraryStore.edit { p ->
            p[K.favorites] = (p[K.favorites] ?: emptySet()) + ids.map { it.toString() }
        }
    }

    suspend fun recordPlay(id: Long) {
        context.libraryStore.edit { p ->
            val plays = readPlays(p[K.plays]).toMutableMap()
            plays[id] = (plays[id] ?: 0) + 1
            p[K.plays] = JSONObject().also { o -> plays.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
            val recent = readIds(p[K.recent]).toMutableList()
            recent.remove(id)
            recent.add(0, id)
            p[K.recent] = JSONArray(recent.take(30)).toString()
            val log = readLog(p[K.playLog]).toMutableList()
            log.add(id to java.time.LocalDate.now().toEpochDay())
            p[K.playLog] = log.takeLast(3000).joinToString(",") { "${it.first}:${it.second}" }
            // Same play, counted per day and hour (kept about 2 years) for the Aurora passport.
            val nowTime = java.time.LocalDateTime.now()
            val today = nowTime.toLocalDate().toEpochDay()
            val listen = readListen(p[K.listen]).toMutableMap()
            val hours = (listen[today] ?: List(24) { 0 }).toMutableList()
            hours[nowTime.hour] = hours[nowTime.hour] + 1
            listen[today] = hours
            p[K.listen] = writeListen(listen.filterKeys { it >= today - 800 })
            // and which hour this song was played in, for the Right now mix
            val byHour = readListen(p[K.songHours]).toMutableMap()
            val songHrs = (byHour[id] ?: List(24) { 0 }).toMutableList()
            songHrs[nowTime.hour] = songHrs[nowTime.hour] + 1
            byHour[id] = songHrs
            p[K.songHours] = writeListen(byHour)
        }
    }

    /** Forget songs that were deleted from the phone: take them out of playlists, favorites and history. */
    suspend fun removeSongs(ids: Set<Long>) {
        val idStrings = ids.map { it.toString() }.toSet()
        context.libraryStore.edit { p ->
            p[K.playlists] = writePlaylists(
                readPlaylists(p[K.playlists]).map { pl -> pl.copy(songIds = pl.songIds.filter { it !in ids }) }
            )
            p[K.favorites] = (p[K.favorites] ?: emptySet()) - idStrings
            p[K.recent] = JSONArray(readIds(p[K.recent]).filter { it !in ids }).toString()
            p[K.edits] = writeEdits(readEdits(p[K.edits]) - ids)
        }
    }

    suspend fun editPlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        context.libraryStore.edit { p ->
            p[K.playlists] = writePlaylists(transform(readPlaylists(p[K.playlists])))
        }
    }

    private fun readPlays(s: String?): Map<Long, Int> {
        if (s.isNullOrBlank()) return emptyMap()
        return runCatching {
            val o = JSONObject(s)
            o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getInt(k) } }.toMap()
        }.getOrDefault(emptyMap())
    }

    private fun readIds(s: String?): List<Long> {
        if (s.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { a.getLong(it) }
        }.getOrDefault(emptyList())
    }

    private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    private fun readPlaylists(s: String?): List<Playlist> {
        if (s.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ids = o.optJSONArray("songs")
                Playlist(
                    id = o.getString("id"),
                    name = o.optString("name", "Playlist"),
                    songIds = if (ids == null) emptyList() else (0 until ids.length()).map { ids.getLong(it) },
                    accent = o.optInt("accent", 0),
                    icon = o.optInt("icon", 0),
                    cover = enumOr(o.optString("cover"), CoverStyle.MOSAIC),
                    shape = enumOr(o.optString("shape"), PlaylistShape.SOFT),
                    feel = enumOr(o.optString("feel"), PlaylistFeel.SQUISH),
                    response = o.optDouble("response", 0.6).toFloat(),
                    emoji = o.optString("emoji", ""),
                    accent2 = o.optInt("accent2", -1),
                    note = o.optString("note", ""),
                    pinned = o.optBoolean("pinned", false),
                    sort = enumOr(o.optString("sort"), PlaylistSort.MANUAL),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun writePlaylists(list: List<Playlist>): String {
        val a = JSONArray()
        list.forEach { p ->
            a.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
                    .put("accent", p.accent)
                    .put("icon", p.icon)
                    .put("cover", p.cover.name)
                    .put("shape", p.shape.name)
                    .put("feel", p.feel.name)
                    .put("response", p.response.toDouble())
                    .put("emoji", p.emoji)
                    .put("accent2", p.accent2)
                    .put("note", p.note)
                    .put("pinned", p.pinned)
                    .put("sort", p.sort.name)
            )
        }
        return a.toString()
    }
}

fun newPlaylistId(): String = UUID.randomUUID().toString()

private fun readLog(s: String?): List<Pair<Long, Long>> =
    s?.split(',')?.mapNotNull { e ->
        val a = e.split(':')
        if (a.size != 2) null else a[0].toLongOrNull()?.let { id -> a[1].toLongOrNull()?.let { day -> id to day } }
    }.orEmpty()

private fun readListen(s: String?): Map<Long, List<Int>> {
    if (s.isNullOrBlank()) return emptyMap()
    val out = HashMap<Long, IntArray>()
    for (e in s.split(',')) {
        val a = e.split(':')
        if (a.size != 3) continue
        val day = a[0].toLongOrNull() ?: continue
        val hour = a[1].toIntOrNull() ?: continue
        val count = a[2].toIntOrNull() ?: continue
        if (hour !in 0..23) continue
        out.getOrPut(day) { IntArray(24) }[hour] += count
    }
    return out.mapValues { it.value.toList() }
}

private fun writeListen(map: Map<Long, List<Int>>): String {
    val sb = StringBuilder()
    for ((day, hours) in map) {
        for (h in 0 until 24) {
            val c = hours.getOrElse(h) { 0 }
            if (c <= 0) continue
            if (sb.isNotEmpty()) sb.append(',')
            sb.append(day).append(':').append(h).append(':').append(c)
        }
    }
    return sb.toString()
}

private fun readDuel(s: String?): Map<Long, Pair<Int, Int>> =
    s?.split(',')?.mapNotNull { e ->
        val a = e.split(':')
        if (a.size != 3) null else {
            val id = a[0].toLongOrNull()
            val rating = a[1].toIntOrNull()
            val games = a[2].toIntOrNull()
            if (id == null || rating == null || games == null) null else id to (rating to games)
        }
    }?.toMap().orEmpty()

private fun readDays(s: String?): Map<Long, Int> =
    s?.split(',')?.mapNotNull { e ->
        val a = e.split(':')
        if (a.size != 2) null else a[0].toLongOrNull()?.let { day -> a[1].toIntOrNull()?.let { n -> day to n } }
    }?.toMap().orEmpty()

private fun readStickers(s: String?): Map<Long, String> {
    if (s.isNullOrBlank()) return emptyMap()
    return runCatching {
        val o = JSONObject(s)
        o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getString(k) } }.toMap()
    }.getOrDefault(emptyMap())
}
