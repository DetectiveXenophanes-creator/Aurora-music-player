package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import kotlin.random.Random

// ------------------------------------------------------------------ playlist model

enum class CoverStyle(val label: String) { MOSAIC("Mosaic"), ICON("Icon"), GRADIENT("Gradient") }
enum class PlaylistShape(val label: String, val corner: Int) {
    SOFT("Soft", 24), ROUND("Round", 40), SQUARE("Sharp", 8)
}
enum class PlaylistFeel(val label: String, val blurb: String) {
    SQUISH("Squish", "Shrinks under your finger"),
    BOUNCE("Bounce", "Springs back with a wobble"),
    TILT("Tilt", "Leans like a physical card"),
    GLOW("Glow", "Lights up its edge"),
    NONE("Still", "No reaction"),
}

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long> = emptyList(),
    val accent: Int = 0,          // index into playlistAccents, 0 = follow theme
    val icon: Int = 0,            // index into playlistIconCount
    val cover: CoverStyle = CoverStyle.MOSAIC,
    val shape: PlaylistShape = PlaylistShape.SOFT,
    val feel: PlaylistFeel = PlaylistFeel.SQUISH,
    val response: Float = 0.6f,
)

val playlistAccents: List<Int> = listOf(
    0x00000000, 0xFF6750A4, 0xFF0B6BCB, 0xFF00897B, 0xFF1B8A5A, 0xFFD9480F, 0xFFC2185B, 0xFFB00020,
).map { it.toInt() }
const val PLAYLIST_ICON_COUNT = 8

data class LibraryData(
    val playlists: List<Playlist> = emptyList(),
    val favorites: Set<Long> = emptySet(),
    val plays: Map<Long, Int> = emptyMap(),
    val recent: List<Long> = emptyList(),
)

// ------------------------------------------------------------------ browsing groups

enum class DetailKind { ALBUM, ARTIST, FOLDER, PLAYLIST, SMART }

data class DetailRef(val kind: DetailKind, val key: String, val title: String)

data class Group(
    val key: String,
    val title: String,
    val subtitle: String,
    val art: Song?,
    val songs: List<Song>,
)

fun albumsOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.albumId }.map { (id, list) ->
        Group(
            key = id.toString(),
            title = list.first().album.ifBlank { "Unknown album" },
            subtitle = list.first().artist,
            art = list.first(),
            songs = list,
        )
    }.sortedBy { it.title.lowercase() }

fun artistsOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.artist }.map { (artist, list) ->
        Group(artist, artist, "${list.size} songs", list.first(), list)
    }.sortedBy { it.title.lowercase() }

fun foldersOf(songs: List<Song>): List<Group> =
    songs.groupBy { it.folder }.map { (path, list) ->
        Group(path, path.substringAfterLast('/').ifBlank { path }, path, list.first(), list)
    }.sortedBy { it.title.lowercase() }

fun songsFor(ref: DetailRef, songs: List<Song>, lib: LibraryData): List<Song> = when (ref.kind) {
    DetailKind.ALBUM -> songs.filter { it.albumId.toString() == ref.key }
    DetailKind.ARTIST -> songs.filter { it.artist == ref.key }
    DetailKind.FOLDER -> songs.filter { it.folder == ref.key }
    DetailKind.PLAYLIST -> {
        val byId = songs.associateBy { it.id }
        lib.playlists.firstOrNull { it.id == ref.key }?.songIds?.mapNotNull { byId[it] } ?: emptyList()
    }
    DetailKind.SMART -> when (ref.key) {
        "fav" -> songs.filter { it.id in lib.favorites }
        "top" -> mostPlayed(songs, lib).take(25)
        else -> {
            val byId = songs.associateBy { it.id }
            lib.recent.mapNotNull { byId[it] }
        }
    }
}

/** Songs with at least one play, most played first. */
fun mostPlayed(songs: List<Song>, lib: LibraryData): List<Song> =
    songs.filter { (lib.plays[it.id] ?: 0) > 0 }.sortedByDescending { lib.plays[it.id] ?: 0 }

/** A fresh mix every day: leans on your most played songs, filled out with the rest of your library. */
fun dailyMix(songs: List<Song>, lib: LibraryData, size: Int = 12): List<Song> {
    if (songs.isEmpty()) return emptyList()
    val day = Calendar.getInstance().let { it.get(Calendar.YEAR) * 1000 + it.get(Calendar.DAY_OF_YEAR) }
    val rnd = Random(day)
    val favourites = mostPlayed(songs, lib).take(40).shuffled(rnd).take(size * 2 / 3 + 1)
    val used = favourites.map { it.id }.toSet()
    val filler = songs.filter { it.id !in used }.shuffled(rnd).take(size - favourites.size)
    return (favourites + filler).shuffled(rnd).take(size)
}

/** Search, filter and sort for the Songs tab. */
fun applySortFilter(songs: List<Song>, query: String, s: AppSettings, lib: LibraryData): List<Song> {
    var list = songs
    if (query.isNotBlank()) {
        list = list.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    if (s.filterFav) list = list.filter { it.id in lib.favorites }
    list = when (s.filterLen) {
        LenFilter.ANY -> list
        LenFilter.SHORT -> list.filter { it.durationMs < 180_000L }
        LenFilter.MEDIUM -> list.filter { it.durationMs in 180_000L..360_000L }
        LenFilter.LONG -> list.filter { it.durationMs > 360_000L }
    }
    val cmp: Comparator<Song> = when (s.sortKey) {
        SortKey.TITLE -> compareBy<Song> { it.title.lowercase() }
        SortKey.ARTIST -> compareBy<Song> { it.artist.lowercase() }.thenBy { it.title.lowercase() }
        SortKey.ALBUM -> compareBy<Song> { it.album.lowercase() }.thenBy { it.title.lowercase() }
        SortKey.DURATION -> compareBy<Song> { it.durationMs }
        SortKey.ADDED -> compareBy<Song> { it.dateAdded }
        SortKey.PLAYS -> compareBy<Song> { lib.plays[it.id] ?: 0 }
    }
    return list.sortedWith(if (s.sortAsc) cmp else cmp.reversed())
}

/** Estimated listening totals, worked out from play counts and song lengths. */
class ListeningStats(
    val totalMs: Long,
    val totalPlays: Int,
    val distinctSongs: Int,
    val topArtists: List<Pair<String, Int>>,
)

fun listeningStats(songs: List<Song>, lib: LibraryData): ListeningStats {
    var ms = 0L
    var plays = 0
    var distinct = 0
    val perArtist = HashMap<String, Int>()
    for (song in songs) {
        val c = lib.plays[song.id] ?: 0
        if (c <= 0) continue
        ms += c.toLong() * song.durationMs
        plays += c
        distinct++
        perArtist[song.artist] = (perArtist[song.artist] ?: 0) + c
    }
    val top = perArtist.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }
    return ListeningStats(ms, plays, distinct, top)
}

fun sortDirectionLabels(key: SortKey): Pair<String, String> = when (key) {
    SortKey.TITLE, SortKey.ARTIST, SortKey.ALBUM -> "A to Z" to "Z to A"
    SortKey.DURATION -> "Shortest first" to "Longest first"
    SortKey.ADDED -> "Oldest first" to "Newest first"
    SortKey.PLAYS -> "Least played" to "Most played"
}

// ------------------------------------------------------------------ persistence

private val Context.libraryStore by preferencesDataStore(name = "aurora_library")

class LibraryStore(private val context: Context) {
    private object K {
        val playlists = stringPreferencesKey("playlists")
        val favorites = stringSetPreferencesKey("favorites")
        val plays = stringPreferencesKey("plays")
        val recent = stringPreferencesKey("recent")
    }

    val flow: Flow<LibraryData> = context.libraryStore.data.map { p ->
        LibraryData(
            playlists = readPlaylists(p[K.playlists]),
            favorites = (p[K.favorites] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet(),
            plays = readPlays(p[K.plays]),
            recent = readIds(p[K.recent]),
        )
    }

    suspend fun toggleFavorite(id: Long) {
        context.libraryStore.edit { p ->
            val cur = (p[K.favorites] ?: emptySet()).toMutableSet()
            if (!cur.remove(id.toString())) cur.add(id.toString())
            p[K.favorites] = cur
        }
    }

    suspend fun addFavorites(ids: Set<Long>) {
        context.libraryStore.edit { p ->
            p[K.favorites] = (p[K.favorites] ?: emptySet()) + ids.map { it.toString() }
        }
    }

    suspend fun recordPlay(id: Long) {
        context.libraryStore.edit { p ->
            val plays = readPlays(p[K.plays]).toMutableMap()
            plays[id] = (plays[id] ?: 0) + 1
            p[K.plays] = JSONObject().also { o -> plays.forEach { (k, v) -> o.put(k.toString(), v) } }.toString()
            val recent = readIds(p[K.recent]).toMutableList()
            recent.remove(id)
            recent.add(0, id)
            p[K.recent] = JSONArray(recent.take(30)).toString()
        }
    }

    /** Forget songs that were deleted from the phone: take them out of playlists, favorites and history. */
    suspend fun removeSongs(ids: Set<Long>) {
        val idStrings = ids.map { it.toString() }.toSet()
        context.libraryStore.edit { p ->
            p[K.playlists] = writePlaylists(
                readPlaylists(p[K.playlists]).map { pl -> pl.copy(songIds = pl.songIds.filter { it !in ids }) }
            )
            p[K.favorites] = (p[K.favorites] ?: emptySet()) - idStrings
            p[K.recent] = JSONArray(readIds(p[K.recent]).filter { it !in ids }).toString()
        }
    }

    suspend fun editPlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        context.libraryStore.edit { p ->
            p[K.playlists] = writePlaylists(transform(readPlaylists(p[K.playlists])))
        }
    }

    private fun readPlays(s: String?): Map<Long, Int> {
        if (s.isNullOrBlank()) return emptyMap()
        return runCatching {
            val o = JSONObject(s)
            o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getInt(k) } }.toMap()
        }.getOrDefault(emptyMap())
    }

    private fun readIds(s: String?): List<Long> {
        if (s.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { a.getLong(it) }
        }.getOrDefault(emptyList())
    }

    private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    private fun readPlaylists(s: String?): List<Playlist> {
        if (s.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ids = o.optJSONArray("songs")
                Playlist(
                    id = o.getString("id"),
                    name = o.optString("name", "Playlist"),
                    songIds = if (ids == null) emptyList() else (0 until ids.length()).map { ids.getLong(it) },
                    accent = o.optInt("accent", 0),
                    icon = o.optInt("icon", 0),
                    cover = enumOr(o.optString("cover"), CoverStyle.MOSAIC),
                    shape = enumOr(o.optString("shape"), PlaylistShape.SOFT),
                    feel = enumOr(o.optString("feel"), PlaylistFeel.SQUISH),
                    response = o.optDouble("response", 0.6).toFloat(),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun writePlaylists(list: List<Playlist>): String {
        val a = JSONArray()
        list.forEach { p ->
            a.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
                    .put("accent", p.accent)
                    .put("icon", p.icon)
                    .put("cover", p.cover.name)
                    .put("shape", p.shape.name)
                    .put("feel", p.feel.name)
                    .put("response", p.response.toDouble())
            )
        }
        return a.toString()
    }
}

fun newPlaylistId(): String = UUID.randomUUID().toString()
