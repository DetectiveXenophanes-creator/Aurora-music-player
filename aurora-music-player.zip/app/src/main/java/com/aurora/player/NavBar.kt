package com.aurora.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

fun AppTab.icon(): ImageVector = when (this) {
    AppTab.HOME -> Icons.Rounded.Home
    AppTab.SONGS -> Icons.Rounded.MusicNote
    AppTab.PLAYLISTS -> Icons.Rounded.QueueMusic
    AppTab.ALBUMS -> Icons.Rounded.Album
    AppTab.FOLDERS -> Icons.Rounded.Folder
    AppTab.ARTISTS -> Icons.Rounded.Person
}

private val libraryTabs = listOf(AppTab.SONGS, AppTab.PLAYLISTS, AppTab.ALBUMS, AppTab.FOLDERS, AppTab.ARTISTS)

/**
 * Two separate floating pills: Home on the left, the library tabs on the right.
 * The selected tab expands to show its name and the others slide over to make room.
 */
@Composable
fun BottomNav(tab: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavPill(listOf(AppTab.HOME), tab, onSelect)
        NavPill(libraryTabs, tab, onSelect)
    }
}

@Composable
private fun NavPill(tabs: List<AppTab>, selected: AppTab, onSelect: (AppTab) -> Unit) {
    Row(
        Modifier.finish(RoundedCornerShape(percent = 50)).padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        tabs.forEach { t -> NavItem(t, t == selected) { onSelect(t) } }
    }
}

@Composable
private fun NavItem(tab: AppTab, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val showLabel = selected && LocalAppSettings.current.navLabels
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val container by animateColorAsState(
        targetValue = if (selected) cs.primaryContainer else Color.Transparent,
        animationSpec = motion.effects(),
        label = "navContainer",
    )
    val tint by animateColorAsState(
        targetValue = if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "navTint",
    )
    Row(
        Modifier
            .height(44.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(percent = 50))
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            }
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(tab.icon(), contentDescription = tab.label, tint = tint, modifier = Modifier.size(22.dp))
        AnimatedVisibility(
            visible = showLabel,
            enter = expandHorizontally(motion.spatial()) + fadeIn(motion.effects()),
            exit = shrinkHorizontally(motion.effects()) + fadeOut(motion.effects()),
        ) {
            Text(
                tab.label,
                color = tint,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                modifier = Modifier.padding(start = 6.dp),
            )
        }
    }
}
