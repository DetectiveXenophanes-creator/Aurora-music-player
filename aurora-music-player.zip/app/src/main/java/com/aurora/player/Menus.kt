package com.aurora.player

import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Rounded, themed replacement for the default black dropdown menu. */
@Composable
fun AuroraMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape((s.corner * 0.9f).coerceAtLeast(16f).dp)
    val glass = s.style == SurfaceStyle.GLASS
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = shape,
        containerColor = if (glass) cs.surfaceContainerHigh.copy(alpha = 0.94f) else cs.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 10.dp,
        border = BorderStroke(
            1.dp,
            if (glass && s.edgeHighlight) Color.White.copy(alpha = 0.18f) else cs.outlineVariant.copy(alpha = 0.5f),
        ),
    ) {
        Column(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            content()
        }
    }
}

@Composable
fun AuroraMenuItem(
    text: String,
    icon: ImageVector?,
    onClick: () -> Unit,
    highlighted: Boolean = false,
) {
    val cs = MaterialTheme.colorScheme
    val s = LocalAppSettings.current
    val shape = RoundedCornerShape((s.corner * 0.6f).coerceAtLeast(12f).dp)
    Row(
        Modifier
            .widthIn(min = 210.dp, max = 280.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(if (highlighted) cs.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (highlighted) cs.primary else cs.secondaryContainer.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (highlighted) cs.onPrimary else cs.onSecondaryContainer,
                    modifier = Modifier.size(19.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
        } else {
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = if (highlighted) cs.onPrimaryContainer else cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun AuroraMenuLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 4.dp),
    )
}

@Composable
fun AuroraMenuDivider() {
    Box(
        Modifier
            .padding(vertical = 4.dp, horizontal = 10.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    )
}

/** Themed bottom sheet with a rounded top, a custom drag handle and an optional title. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuroraSheet(
    onDismiss: () -> Unit,
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val r = (s.corner * 1.4f).coerceAtLeast(20f).dp
    val glass = s.style == SurfaceStyle.GLASS
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        shape = RoundedCornerShape(topStart = r, topEnd = r),
        containerColor = if (glass) cs.surfaceContainerHigh.copy(alpha = 0.95f) else cs.surfaceContainerHigh,
        contentColor = cs.onSurface,
        tonalElevation = 0.dp,
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 12.dp, bottom = 6.dp)
                    .width(44.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(cs.onSurfaceVariant.copy(alpha = 0.35f))
            )
        },
    ) {
        if (title != null) {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 4.dp, bottom = 10.dp),
            )
        }
        content()
    }
}

@Composable
fun SheetLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
}

/** Rounded choice pill used for sort keys, speed presets and similar. */
@Composable
fun AuroraChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) cs.primaryContainer else cs.secondaryContainer.copy(alpha = 0.55f))
            .clickable {
                haptic()
                onClick()
            }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) cs.onPrimaryContainer else cs.onSecondaryContainer,
            maxLines = 1,
        )
    }
}

/** Pick a playlist for the selected songs, or start a new one. */
@Composable
fun AddToPlaylistSheet(
    count: Int,
    playlists: List<Playlist>,
    onPick: (Playlist) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val corner = LocalAppSettings.current.corner
    val shape = RoundedCornerShape((corner * 0.7f).coerceAtLeast(14f).dp)
    AuroraSheet(onDismiss = onDismiss, title = if (count == 1) "Add 1 song to" else "Add $count songs to") {
        Column(
            Modifier
                .heightIn(max = 480.dp)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(cs.primaryContainer.copy(alpha = 0.7f))
                    .clickable(onClick = onNew)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Add, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Text("New playlist", style = MaterialTheme.typography.titleSmall, color = cs.onPrimaryContainer)
            }
            playlists.forEach { pl ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(cs.surfaceContainerHighest.copy(alpha = 0.55f))
                        .clickable { onPick(pl) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(playlistIcon(pl.icon), null, tint = cs.primary, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            verbatim(pl.name),
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            "${pl.songIds.size} songs",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
