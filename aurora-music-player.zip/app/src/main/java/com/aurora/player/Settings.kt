package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.map

enum class SurfaceStyle { MATTE, GLASS }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class BackgroundStyle { GRADIENT, ALBUM, FLAT }
enum class PlayShape { MORPH, CIRCLE, SQUIRCLE }
enum class SeekStyle { LINE, WAVY }
enum class ListDensity { COMFORTABLE, COMPACT }
enum class SquiggleMode { OFF, STATIC, ANIMATED }
enum class ArtShape(val label: String) { ROUNDED("Rounded"), CIRCLE("Circle"), VINYL("Vinyl") }
enum class UiFont(val label: String) { DEFAULT("Default"), SERIF("Serif"), MONO("Mono") }

/** A colour theme the user saved. Presets use the same shape (see Themes.kt). */
data class CustomTheme(
    val id: String,
    val name: String,
    val accent: Int,
    val spread: Float,
    val vibrancy: Float,
    val mode: ThemeMode,
    val amoled: Boolean,
)

fun encodeThemes(list: List<CustomTheme>): String {
    val arr = JSONArray()
    list.forEach { arr.put(themeToJson(it)) }
    return arr.toString()
}

fun themeToJson(t: CustomTheme): JSONObject = JSONObject()
    .put("id", t.id).put("name", t.name).put("accent", t.accent)
    .put("spread", t.spread.toDouble()).put("vibrancy", t.vibrancy.toDouble())
    .put("mode", t.mode.name).put("amoled", t.amoled)

fun themeFromJson(o: JSONObject): CustomTheme? = runCatching {
    CustomTheme(
        id = o.optString("id").ifBlank { "t" + System.currentTimeMillis() },
        name = o.getString("name").take(32),
        accent = o.getInt("accent"),
        spread = o.optDouble("spread", 1.0).toFloat().coerceIn(-3f, 3f),
        vibrancy = o.optDouble("vibrancy", 1.0).toFloat().coerceIn(0f, 1.5f),
        mode = ThemeMode.entries.firstOrNull { it.name == o.optString("mode") } ?: ThemeMode.DARK,
        amoled = o.optBoolean("amoled", false),
    )
}.getOrNull()

fun decodeThemes(s: String?): List<CustomTheme> = runCatching {
    val arr = JSONArray(s ?: "[]")
    (0 until arr.length()).mapNotNull { themeFromJson(arr.getJSONObject(it)) }
}.getOrDefault(emptyList())
enum class SortKey(val label: String) {
    TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), DURATION("Length"), ADDED("Date added"), PLAYS("Most played")
}
enum class LenFilter(val label: String) { ANY("Any"), SHORT("Under 3 min"), MEDIUM("3 to 6 min"), LONG("Over 6 min") }

enum class AppTab(val label: String) {
    HOME("Home"),
    SONGS("Songs"),
    PLAYLISTS("Playlists"),
    ALBUMS("Albums"),
    FOLDERS("Folders"),
    ARTISTS("Artists"),
}

/** Cards on the Home screen. Their order and visibility are customizable. */
enum class HomeSection(val label: String, val blurb: String) {
    MOST("Most played", "Your top song and its play count"),
    MIX("Daily mix", "A fresh set of songs every day"),
    TILES("Quick tiles", "Favorites, most played and recent"),
    STATS("Listening stats", "Time listened and top artists"),
    RECENT("Recently played", "The last songs you played"),
}

private fun parseHomeOrder(s: String?): List<HomeSection> {
    val parsed = s?.split(',')?.mapNotNull { n -> HomeSection.entries.firstOrNull { it.name == n } }.orEmpty().distinct()
    return parsed + HomeSection.entries.filter { it !in parsed }
}

data class AppSettings(
    // Customization
    val style: SurfaceStyle = SurfaceStyle.GLASS,
    val blur: Float = 24f,
    val glassTint: Float = 0.5f,
    val edgeHighlight: Boolean = true,
    val corner: Float = 24f,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val accent: Int = 0xFF6750A4.toInt(),
    val amoled: Boolean = false,
    val background: BackgroundStyle = BackgroundStyle.GRADIENT,
    val squiggles: SquiggleMode = SquiggleMode.ANIMATED,
    val playShape: PlayShape = PlayShape.MORPH,
    val seekStyle: SeekStyle = SeekStyle.LINE,
    val density: ListDensity = ListDensity.COMFORTABLE,
    val listArt: Boolean = true,
    val navLabels: Boolean = true,
    val artEdge: Float = 0.3f,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val spread: Float = 1f,
    val vibrancy: Float = 1f,
    val activeTheme: String = "",
    val customThemes: List<CustomTheme> = emptyList(),
    val auroraGlow: Float = 0.35f,
    val artShape: ArtShape = ArtShape.ROUNDED,
    val textScale: Float = 1f,
    val uiFont: UiFont = UiFont.DEFAULT,
    val bgFps: Int = 20,
    val batterySaver: Boolean = false,
    val homeOrder: List<HomeSection> = HomeSection.entries.toList(),
    val homeHidden: Set<HomeSection> = emptySet(),
    val mixSize: Int = 12,
    // Animations
    val animSet: AnimSet = AnimSet.SMOOTH,
    val animSpeed: Float = 0.8f,
    val animIntensity: Float = 0.5f,
    val listEntrance: Boolean = true,
    val artBreathing: Boolean = true,
    // Audio
    val playbackSpeed: Float = 1f,
    val playbackPitch: Float = 1f,
    val skipSilence: Boolean = false,
    val bassBoost: Float = 0f,
    val loudness: Float = 0f,
    val eqEnabled: Boolean = false,
    val eqGains: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
    // Sorting and filtering
    val sortKey: SortKey = SortKey.TITLE,
    val sortAsc: Boolean = true,
    val filterFav: Boolean = false,
    val filterLen: LenFilter = LenFilter.ANY,
    // Library
    val includeNonMusic: Boolean = false,
    val minDurationSec: Int = 0,
    val excludedFolders: Set<String> = emptySet(),
    // Player
    val haptics: Boolean = true,
    val keepScreenOn: Boolean = false,
    // Startup
    val startTab: AppTab = AppTab.HOME,
    val showIntro: Boolean = true,
    val setupDone: Boolean = false,
)

private val Context.dataStore by preferencesDataStore(name = "aurora_settings")

private inline fun <reified E : Enum<E>> Preferences.enumOf(
    key: Preferences.Key<String>,
    default: E,
): E = this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

class SettingsStore(private val context: Context) {
    private object K {
        val style = stringPreferencesKey("style")
        val blur = floatPreferencesKey("blur")
        val glassTint = floatPreferencesKey("glass_tint")
        val edge = booleanPreferencesKey("edge_highlight")
        val corner = floatPreferencesKey("corner")
        val theme = stringPreferencesKey("theme")
        val dynamic = booleanPreferencesKey("dynamic")
        val accent = intPreferencesKey("accent")
        val amoled = booleanPreferencesKey("amoled")
        val background = stringPreferencesKey("background")
        val squiggles = stringPreferencesKey("squiggles")
        val playShape = stringPreferencesKey("play_shape")
        val seekStyle = stringPreferencesKey("seek_style_v2")
        val density = stringPreferencesKey("density")
        val listArt = booleanPreferencesKey("list_art")
        val navLabels = booleanPreferencesKey("nav_labels")
        val animSet = stringPreferencesKey("anim_set")
        val animSpeed = floatPreferencesKey("anim_speed_v2")
        val animIntensity = floatPreferencesKey("anim_intensity")
        val listEntrance = booleanPreferencesKey("list_entrance")
        val artBreathing = booleanPreferencesKey("art_breathing")
        val pbSpeed = floatPreferencesKey("pb_speed")
        val pbPitch = floatPreferencesKey("pb_pitch")
        val skipSilence = booleanPreferencesKey("skip_silence")
        val bass = floatPreferencesKey("bass")
        val loudness = floatPreferencesKey("loudness")
        val nonMusic = booleanPreferencesKey("non_music")
        val eqOn = booleanPreferencesKey("eq_on")
        val eqGains = stringPreferencesKey("eq_gains")
        val sortKey = stringPreferencesKey("sort_key")
        val artEdge = floatPreferencesKey("art_edge")
        val language = stringPreferencesKey("language")
        val spread = floatPreferencesKey("spread")
        val vibrancy = floatPreferencesKey("vibrancy")
        val activeTheme = stringPreferencesKey("active_theme")
        val customThemes = stringPreferencesKey("custom_themes")
        val auroraGlow = floatPreferencesKey("aurora_glow")
        val artShape = stringPreferencesKey("art_shape")
        val textScale = floatPreferencesKey("text_scale")
        val uiFont = stringPreferencesKey("ui_font")
        val bgFps = intPreferencesKey("bg_fps")
        val batterySaver = booleanPreferencesKey("battery_saver")
        val homeOrder = stringPreferencesKey("home_order")
        val homeHidden = stringSetPreferencesKey("home_hidden")
        val mixSize = intPreferencesKey("mix_size")
        val sortAsc = booleanPreferencesKey("sort_asc")
        val filterFav = booleanPreferencesKey("filter_fav")
        val filterLen = stringPreferencesKey("filter_len")
        val minDur = intPreferencesKey("min_dur")
        val excluded = stringSetPreferencesKey("excluded_folders")
        val haptics = booleanPreferencesKey("haptics")
        val keepOn = booleanPreferencesKey("keep_on")
        val startTab = stringPreferencesKey("start_tab")
        val showIntro = booleanPreferencesKey("show_intro")
        val setupDone = booleanPreferencesKey("setup_done")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    /** Every stored setting as JSON, for backups. New settings are included automatically. */
    suspend fun exportJson(): JSONObject {
        val prefs = context.dataStore.data.first()
        val arr = JSONArray()
        for ((k, v) in prefs.asMap()) {
            val entry = JSONObject().put("k", k.name)
            when (v) {
                is String -> entry.put("t", "s").put("v", v)
                is Boolean -> entry.put("t", "b").put("v", v)
                is Int -> entry.put("t", "i").put("v", v)
                is Long -> entry.put("t", "l").put("v", v)
                is Float -> entry.put("t", "f").put("v", v.toDouble())
                is Set<*> -> entry.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            arr.put(entry)
        }
        return JSONObject().put("prefs", arr)
    }

    suspend fun importJson(o: JSONObject) {
        val arr = o.optJSONArray("prefs") ?: return
        context.dataStore.edit { p ->
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val name = e.getString("k")
                when (e.getString("t")) {
                    "s" -> p[stringPreferencesKey(name)] = e.getString("v")
                    "b" -> p[booleanPreferencesKey(name)] = e.getBoolean("v")
                    "i" -> p[intPreferencesKey(name)] = e.getInt("v")
                    "l" -> p[longPreferencesKey(name)] = e.getLong("v")
                    "f" -> p[floatPreferencesKey(name)] = e.getDouble("v").toFloat()
                    "ss" -> {
                        val a = e.getJSONArray("v")
                        p[stringSetPreferencesKey(name)] = (0 until a.length()).map { a.getString(it) }.toSet()
                    }
                }
            }
            p[K.setupDone] = true
        }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            style = p.enumOf(K.style, d.style),
            blur = p[K.blur] ?: d.blur,
            glassTint = p[K.glassTint] ?: d.glassTint,
            edgeHighlight = p[K.edge] ?: d.edgeHighlight,
            corner = p[K.corner] ?: d.corner,
            themeMode = p.enumOf(K.theme, d.themeMode),
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            accent = p[K.accent] ?: d.accent,
            amoled = p[K.amoled] ?: d.amoled,
            background = p.enumOf(K.background, d.background),
            squiggles = p.enumOf(K.squiggles, d.squiggles),
            playShape = p.enumOf(K.playShape, d.playShape),
            seekStyle = p.enumOf(K.seekStyle, d.seekStyle),
            density = p.enumOf(K.density, d.density),
            listArt = p[K.listArt] ?: d.listArt,
            navLabels = p[K.navLabels] ?: d.navLabels,
            animSet = p.enumOf(K.animSet, d.animSet),
            animSpeed = p[K.animSpeed] ?: d.animSpeed,
            animIntensity = p[K.animIntensity] ?: d.animIntensity,
            listEntrance = p[K.listEntrance] ?: d.listEntrance,
            artBreathing = p[K.artBreathing] ?: d.artBreathing,
            playbackSpeed = p[K.pbSpeed] ?: d.playbackSpeed,
            playbackPitch = p[K.pbPitch] ?: d.playbackPitch,
            skipSilence = p[K.skipSilence] ?: d.skipSilence,
            bassBoost = p[K.bass] ?: d.bassBoost,
            loudness = p[K.loudness] ?: d.loudness,
            includeNonMusic = p[K.nonMusic] ?: d.includeNonMusic,
            eqEnabled = p[K.eqOn] ?: d.eqEnabled,
            eqGains = p[K.eqGains]?.split(',')?.mapNotNull { it.toFloatOrNull() }?.takeIf { it.size == 5 } ?: d.eqGains,
            sortKey = p.enumOf(K.sortKey, d.sortKey),
            artEdge = p[K.artEdge] ?: d.artEdge,
            language = p.enumOf(K.language, d.language),
            spread = p[K.spread] ?: d.spread,
            vibrancy = p[K.vibrancy] ?: d.vibrancy,
            activeTheme = p[K.activeTheme] ?: d.activeTheme,
            customThemes = decodeThemes(p[K.customThemes]),
            auroraGlow = p[K.auroraGlow] ?: d.auroraGlow,
            artShape = p.enumOf(K.artShape, d.artShape),
            textScale = p[K.textScale] ?: d.textScale,
            uiFont = p.enumOf(K.uiFont, d.uiFont),
            bgFps = p[K.bgFps] ?: d.bgFps,
            batterySaver = p[K.batterySaver] ?: d.batterySaver,
            homeOrder = parseHomeOrder(p[K.homeOrder]),
            homeHidden = (p[K.homeHidden] ?: emptySet())
                .mapNotNull { n -> HomeSection.entries.firstOrNull { it.name == n } }.toSet(),
            mixSize = p[K.mixSize] ?: d.mixSize,
            sortAsc = p[K.sortAsc] ?: d.sortAsc,
            filterFav = p[K.filterFav] ?: d.filterFav,
            filterLen = p.enumOf(K.filterLen, d.filterLen),
            minDurationSec = p[K.minDur] ?: d.minDurationSec,
            excludedFolders = p[K.excluded] ?: d.excludedFolders,
            haptics = p[K.haptics] ?: d.haptics,
            keepScreenOn = p[K.keepOn] ?: d.keepScreenOn,
            startTab = p.enumOf(K.startTab, d.startTab),
            showIntro = p[K.showIntro] ?: d.showIntro,
            setupDone = p[K.setupDone] ?: d.setupDone,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.style] = s.style.name
        p[K.blur] = s.blur
        p[K.glassTint] = s.glassTint
        p[K.edge] = s.edgeHighlight
        p[K.corner] = s.corner
        p[K.theme] = s.themeMode.name
        p[K.dynamic] = s.dynamicColor
        p[K.accent] = s.accent
        p[K.amoled] = s.amoled
        p[K.background] = s.background.name
        p[K.squiggles] = s.squiggles.name
        p[K.playShape] = s.playShape.name
        p[K.seekStyle] = s.seekStyle.name
        p[K.density] = s.density.name
        p[K.listArt] = s.listArt
        p[K.navLabels] = s.navLabels
        p[K.animSet] = s.animSet.name
        p[K.animSpeed] = s.animSpeed
        p[K.animIntensity] = s.animIntensity
        p[K.listEntrance] = s.listEntrance
        p[K.artBreathing] = s.artBreathing
        p[K.pbSpeed] = s.playbackSpeed
        p[K.pbPitch] = s.playbackPitch
        p[K.skipSilence] = s.skipSilence
        p[K.bass] = s.bassBoost
        p[K.loudness] = s.loudness
        p[K.nonMusic] = s.includeNonMusic
        p[K.eqOn] = s.eqEnabled
        p[K.eqGains] = s.eqGains.joinToString(",")
        p[K.sortKey] = s.sortKey.name
        p[K.artEdge] = s.artEdge
        p[K.language] = s.language.name
        p[K.spread] = s.spread
        p[K.vibrancy] = s.vibrancy
        p[K.activeTheme] = s.activeTheme
        p[K.customThemes] = encodeThemes(s.customThemes)
        p[K.auroraGlow] = s.auroraGlow
        p[K.artShape] = s.artShape.name
        p[K.textScale] = s.textScale
        p[K.uiFont] = s.uiFont.name
        p[K.bgFps] = s.bgFps
        p[K.batterySaver] = s.batterySaver
        p[K.homeOrder] = s.homeOrder.joinToString(",") { it.name }
        p[K.homeHidden] = s.homeHidden.map { it.name }.toSet()
        p[K.mixSize] = s.mixSize
        p[K.sortAsc] = s.sortAsc
        p[K.filterFav] = s.filterFav
        p[K.filterLen] = s.filterLen.name
        p[K.minDur] = s.minDurationSec
        p[K.excluded] = s.excludedFolders
        p[K.haptics] = s.haptics
        p[K.keepOn] = s.keepScreenOn
        p[K.startTab] = s.startTab.name
        p[K.showIntro] = s.showIntro
        p[K.setupDone] = s.setupDone
    }
}
