package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class SurfaceStyle { MATTE, GLASS }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val style: SurfaceStyle = SurfaceStyle.GLASS,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val accent: Int = 0xFF6750A4.toInt(),
    val blur: Float = 24f,
    val corner: Float = 24f,
    val amoled: Boolean = false,
)

private val Context.dataStore by preferencesDataStore(name = "aurora_settings")

class SettingsStore(private val context: Context) {
    private object K {
        val style = stringPreferencesKey("style")
        val theme = stringPreferencesKey("theme")
        val dynamic = booleanPreferencesKey("dynamic")
        val accent = intPreferencesKey("accent")
        val blur = floatPreferencesKey("blur")
        val corner = floatPreferencesKey("corner")
        val amoled = booleanPreferencesKey("amoled")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            style = p[K.style]?.let { runCatching { SurfaceStyle.valueOf(it) }.getOrNull() } ?: d.style,
            themeMode = p[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.themeMode,
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            accent = p[K.accent] ?: d.accent,
            blur = p[K.blur] ?: d.blur,
            corner = p[K.corner] ?: d.corner,
            amoled = p[K.amoled] ?: d.amoled,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.style] = s.style.name
        p[K.theme] = s.themeMode.name
        p[K.dynamic] = s.dynamicColor
        p[K.accent] = s.accent
        p[K.blur] = s.blur
        p[K.corner] = s.corner
        p[K.amoled] = s.amoled
    }
}
