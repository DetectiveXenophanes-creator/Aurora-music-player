package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class SurfaceStyle { MATTE, GLASS }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class BackgroundStyle { GRADIENT, ALBUM, FLAT }
enum class PlayShape { MORPH, CIRCLE, SQUIRCLE }
enum class SeekStyle { LINE, WAVY }
enum class ListDensity { COMFORTABLE, COMPACT }
enum class SquiggleMode { OFF, STATIC, ANIMATED }

enum class AppTab(val label: String) {
    HOME("Home"),
    SONGS("Songs"),
    PLAYLISTS("Playlists"),
    ALBUMS("Albums"),
    FOLDERS("Folders"),
    ARTISTS("Artists"),
}

data class AppSettings(
    // Customization
    val style: SurfaceStyle = SurfaceStyle.GLASS,
    val blur: Float = 24f,
    val glassTint: Float = 0.5f,
    val edgeHighlight: Boolean = true,
    val corner: Float = 24f,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val accent: Int = 0xFF6750A4.toInt(),
    val amoled: Boolean = false,
    val background: BackgroundStyle = BackgroundStyle.GRADIENT,
    val squiggles: SquiggleMode = SquiggleMode.ANIMATED,
    val playShape: PlayShape = PlayShape.MORPH,
    val seekStyle: SeekStyle = SeekStyle.LINE,
    val density: ListDensity = ListDensity.COMFORTABLE,
    val listArt: Boolean = true,
    val navLabels: Boolean = true,
    // Animations
    val animSet: AnimSet = AnimSet.SMOOTH,
    val animSpeed: Float = 0.8f,
    val animIntensity: Float = 0.5f,
    val listEntrance: Boolean = true,
    val artBreathing: Boolean = true,
    // Audio
    val playbackSpeed: Float = 1f,
    val playbackPitch: Float = 1f,
    val skipSilence: Boolean = false,
    val bassBoost: Float = 0f,
    val loudness: Float = 0f,
    // Library
    val includeNonMusic: Boolean = false,
    val minDurationSec: Int = 0,
    val excludedFolders: Set<String> = emptySet(),
    // Player
    val haptics: Boolean = true,
    val keepScreenOn: Boolean = false,
    // Startup
    val startTab: AppTab = AppTab.HOME,
    val showIntro: Boolean = true,
    val setupDone: Boolean = false,
)

private val Context.dataStore by preferencesDataStore(name = "aurora_settings")

private inline fun <reified E : Enum<E>> Preferences.enumOf(
    key: Preferences.Key<String>,
    default: E,
): E = this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

class SettingsStore(private val context: Context) {
    private object K {
        val style = stringPreferencesKey("style")
        val blur = floatPreferencesKey("blur")
        val glassTint = floatPreferencesKey("glass_tint")
        val edge = booleanPreferencesKey("edge_highlight")
        val corner = floatPreferencesKey("corner")
        val theme = stringPreferencesKey("theme")
        val dynamic = booleanPreferencesKey("dynamic")
        val accent = intPreferencesKey("accent")
        val amoled = booleanPreferencesKey("amoled")
        val background = stringPreferencesKey("background")
        val squiggles = stringPreferencesKey("squiggles")
        val playShape = stringPreferencesKey("play_shape")
        val seekStyle = stringPreferencesKey("seek_style_v2")
        val density = stringPreferencesKey("density")
        val listArt = booleanPreferencesKey("list_art")
        val navLabels = booleanPreferencesKey("nav_labels")
        val animSet = stringPreferencesKey("anim_set")
        val animSpeed = floatPreferencesKey("anim_speed_v2")
        val animIntensity = floatPreferencesKey("anim_intensity")
        val listEntrance = booleanPreferencesKey("list_entrance")
        val artBreathing = booleanPreferencesKey("art_breathing")
        val pbSpeed = floatPreferencesKey("pb_speed")
        val pbPitch = floatPreferencesKey("pb_pitch")
        val skipSilence = booleanPreferencesKey("skip_silence")
        val bass = floatPreferencesKey("bass")
        val loudness = floatPreferencesKey("loudness")
        val nonMusic = booleanPreferencesKey("non_music")
        val minDur = intPreferencesKey("min_dur")
        val excluded = stringSetPreferencesKey("excluded_folders")
        val haptics = booleanPreferencesKey("haptics")
        val keepOn = booleanPreferencesKey("keep_on")
        val startTab = stringPreferencesKey("start_tab")
        val showIntro = booleanPreferencesKey("show_intro")
        val setupDone = booleanPreferencesKey("setup_done")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            style = p.enumOf(K.style, d.style),
            blur = p[K.blur] ?: d.blur,
            glassTint = p[K.glassTint] ?: d.glassTint,
            edgeHighlight = p[K.edge] ?: d.edgeHighlight,
            corner = p[K.corner] ?: d.corner,
            themeMode = p.enumOf(K.theme, d.themeMode),
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            accent = p[K.accent] ?: d.accent,
            amoled = p[K.amoled] ?: d.amoled,
            background = p.enumOf(K.background, d.background),
            squiggles = p.enumOf(K.squiggles, d.squiggles),
            playShape = p.enumOf(K.playShape, d.playShape),
            seekStyle = p.enumOf(K.seekStyle, d.seekStyle),
            density = p.enumOf(K.density, d.density),
            listArt = p[K.listArt] ?: d.listArt,
            navLabels = p[K.navLabels] ?: d.navLabels,
            animSet = p.enumOf(K.animSet, d.animSet),
            animSpeed = p[K.animSpeed] ?: d.animSpeed,
            animIntensity = p[K.animIntensity] ?: d.animIntensity,
            listEntrance = p[K.listEntrance] ?: d.listEntrance,
            artBreathing = p[K.artBreathing] ?: d.artBreathing,
            playbackSpeed = p[K.pbSpeed] ?: d.playbackSpeed,
            playbackPitch = p[K.pbPitch] ?: d.playbackPitch,
            skipSilence = p[K.skipSilence] ?: d.skipSilence,
            bassBoost = p[K.bass] ?: d.bassBoost,
            loudness = p[K.loudness] ?: d.loudness,
            includeNonMusic = p[K.nonMusic] ?: d.includeNonMusic,
            minDurationSec = p[K.minDur] ?: d.minDurationSec,
            excludedFolders = p[K.excluded] ?: d.excludedFolders,
            haptics = p[K.haptics] ?: d.haptics,
            keepScreenOn = p[K.keepOn] ?: d.keepScreenOn,
            startTab = p.enumOf(K.startTab, d.startTab),
            showIntro = p[K.showIntro] ?: d.showIntro,
            setupDone = p[K.setupDone] ?: d.setupDone,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.style] = s.style.name
        p[K.blur] = s.blur
        p[K.glassTint] = s.glassTint
        p[K.edge] = s.edgeHighlight
        p[K.corner] = s.corner
        p[K.theme] = s.themeMode.name
        p[K.dynamic] = s.dynamicColor
        p[K.accent] = s.accent
        p[K.amoled] = s.amoled
        p[K.background] = s.background.name
        p[K.squiggles] = s.squiggles.name
        p[K.playShape] = s.playShape.name
        p[K.seekStyle] = s.seekStyle.name
        p[K.density] = s.density.name
        p[K.listArt] = s.listArt
        p[K.navLabels] = s.navLabels
        p[K.animSet] = s.animSet.name
        p[K.animSpeed] = s.animSpeed
        p[K.animIntensity] = s.animIntensity
        p[K.listEntrance] = s.listEntrance
        p[K.artBreathing] = s.artBreathing
        p[K.pbSpeed] = s.playbackSpeed
        p[K.pbPitch] = s.playbackPitch
        p[K.skipSilence] = s.skipSilence
        p[K.bass] = s.bassBoost
        p[K.loudness] = s.loudness
        p[K.nonMusic] = s.includeNonMusic
        p[K.minDur] = s.minDurationSec
        p[K.excluded] = s.excludedFolders
        p[K.haptics] = s.haptics
        p[K.keepOn] = s.keepScreenOn
        p[K.startTab] = s.startTab.name
        p[K.showIntro] = s.showIntro
        p[K.setupDone] = s.setupDone
    }
}
