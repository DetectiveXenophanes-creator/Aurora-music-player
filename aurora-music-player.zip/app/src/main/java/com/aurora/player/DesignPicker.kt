package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** The list of design styles. Picking one also sets that style's usual corner roundness (adjustable afterwards). */
@Composable
fun DesignPicker(s: AppSettings, onUpdate: SettingsUpdate) {
    val cs = MaterialTheme.colorScheme
    DesignStyle.entries.forEach { d ->
        val on = d == s.design
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (on) cs.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
                .clickable { onUpdate { it.copy(design = d, corner = d.corner) } }
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Text(d.label, style = MaterialTheme.typography.bodyLarge)
                Text(d.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            RadioButton(selected = on, onClick = { onUpdate { it.copy(design = d, corner = d.corner) } })
        }
    }
}
