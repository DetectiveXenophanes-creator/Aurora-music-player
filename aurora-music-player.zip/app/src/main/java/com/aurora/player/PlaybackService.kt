package com.aurora.player

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.os.Build
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private data class AudioPrefs(
    val speed: Float,
    val pitch: Float,
    val skipSilence: Boolean,
    val bass: Float,
    val loudness: Float,
    val eqEnabled: Boolean,
    val eqGains: List<Float>,
    val crossfadeSec: Int = 0,
    val volumeLevel: Int = 0,
)

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loudnessFx: LoudnessEnhancer? = null
    private var bassFx: BassBoost? = null
    private var eqFx: Equalizer? = null
    private var prefs = AudioPrefs(1f, 1f, false, 0f, 0f, false, listOf(0f, 0f, 0f, 0f, 0f))

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = exo
        // Tapping the media notification (also on the lock screen) must open Aurora. Without a session activity,
        // some phones hand the tap to their own music app instead.
        val openApp = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionIntent = PendingIntent.getActivity(
            this,
            0,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        session = MediaSession.Builder(this, exo).setSessionActivity(sessionIntent).build()

        exo.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attachEffects(audioSessionId)
            }
        })
        // Keep home screen widgets in step with what is playing.
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = pushWidget()
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = pushWidget()
            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) = pushWidget()
        })
        attachEffects(exo.audioSessionId)

        scope.launch {
            SettingsStore(this@PlaybackService).flow
                .map {
                    AudioPrefs(it.playbackSpeed, it.playbackPitch, it.skipSilence, it.bassBoost, it.loudness, it.eqEnabled, it.eqGains, it.crossfadeSec, it.volumeLevel)
                }
                .distinctUntilChanged()
                .collect { applyPrefs(it) }
        }
    }

    private fun pushWidget() {
        val p = player ?: return
        val md = p.mediaMetadata
        WidgetState.saveSong(
            this,
            md.title?.toString() ?: "",
            md.artist?.toString() ?: "",
            md.artworkUri?.toString() ?: "",
            p.isPlaying,
            p.currentMediaItem != null,
        )
        AuroraWidget.refreshAll(this)
    }

    /** Buttons on the home screen widget arrive here. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = player
        when (intent?.action) {
            AuroraWidget.ACTION_TOGGLE -> p?.let { if (it.isPlaying) it.pause() else it.play() }
            AuroraWidget.ACTION_NEXT -> p?.seekToNext()
            AuroraWidget.ACTION_PREV -> p?.seekToPrevious()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun applyPrefs(p: AudioPrefs) {
        prefs = p
        val exo = player ?: return
        exo.playbackParameters = PlaybackParameters(p.speed, p.pitch)
        exo.skipSilenceEnabled = p.skipSilence
        applyEffectLevels()
        applyLevelling()
        updateFade()
        updateOffload()
    }

    // ---- crossfade: the end of a song fades out and the start of the next one fades in
    private var fadeJob: Job? = null

    private fun updateFade() {
        fadeJob?.cancel()
        val exo = player ?: return
        if (prefs.crossfadeSec <= 0) {
            exo.volume = 1f
            return
        }
        val fadeMs = prefs.crossfadeSec * 1000L
        fadeJob = scope.launch {
            while (true) {
                val dur = exo.duration
                val pos = exo.currentPosition
                if (!exo.isPlaying) { delay(500); continue }
                if (dur == C.TIME_UNSET || dur <= fadeMs * 2) { exo.volume = 1f; delay(1000); continue }
                val level = when {
                    pos < fadeMs -> pos / fadeMs.toFloat()
                    dur - pos < fadeMs -> (dur - pos) / fadeMs.toFloat()
                    else -> 1f
                }.coerceIn(0f, 1f)
                exo.volume = level * level   // squared so the fade sounds even to the ear
                // Smooth steps while fading; otherwise sleep until the fade-out is about to start (checked twice a second at most)
                delay(if (level < 1f) 50L else minOf(500L, (dur - fadeMs - pos).coerceAtLeast(50L)))
            }
        }
    }

    // ---- volume levelling: a gentle compressor and limiter, so loud and quiet parts (and songs) sound closer together
    private var fxSession = C.AUDIO_SESSION_ID_UNSET
    private var levelFx: Any? = null

    private fun releaseLevelling() {
        runCatching { (levelFx as? DynamicsProcessing)?.release() }
        levelFx = null
    }

    private fun applyLevelling() {
        releaseLevelling()
        if (prefs.volumeLevel <= 0 || fxSession == C.AUDIO_SESSION_ID_UNSET || Build.VERSION.SDK_INT < 28) return
        runCatching { levelFx = buildLevelling(fxSession, prefs.volumeLevel) }
    }

    @androidx.annotation.RequiresApi(28)
    private fun buildLevelling(session: Int, level: Int): DynamicsProcessing {
        val strong = level >= 2
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION, 2, false, 0, true, 1, false, 0, true,
        ).build()
        val dp = DynamicsProcessing(0, session, cfg)
        for (ch in 0 until 2) {
            dp.setMbcBandByChannelIndex(
                ch, 0,
                DynamicsProcessing.MbcBand(
                    true, 20000f, 20f, 250f,
                    if (strong) 4f else 2f,      // ratio
                    if (strong) -30f else -24f,  // threshold (dB)
                    6f, -90f, 1f, 0f,
                    if (strong) 8f else 4f,      // make-up gain (dB)
                ),
            )
            dp.setLimiterByChannelIndex(ch, DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f))
        }
        dp.setEnabled(true)
        return dp
    }

    /**
     * Audio offload lets the phone's audio chip decode the music, so the main processor can sleep while it plays.
     * It cannot be combined with speed/pitch changes, skip silence or the sound effects, so it switches itself off
     * while any of those is in use. If a phone does not support it, playback silently keeps working as before.
     */
    @androidx.annotation.OptIn(UnstableApi::class)
    private fun updateOffload() {
        val exo = player ?: return
        val plain = prefs.speed == 1f && prefs.pitch == 1f && !prefs.skipSilence &&
            prefs.bass <= 0.01f && prefs.loudness <= 0.01f && !prefs.eqEnabled && prefs.volumeLevel == 0
        val mode = if (plain) {
            TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED
        } else {
            TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
        }
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setAudioOffloadPreferences(
                TrackSelectionParameters.AudioOffloadPreferences.Builder()
                    .setAudioOffloadMode(mode)
                    .setIsGaplessSupportRequired(true)
                    .build()
            )
            .build()
    }

    private fun attachEffects(sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        runCatching { eqFx?.release() }
        loudnessFx = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        bassFx = runCatching { BassBoost(0, sessionId) }.getOrNull()
        eqFx = runCatching { Equalizer(0, sessionId) }.getOrNull()
        fxSession = sessionId
        applyEffectLevels()
        applyLevelling()
    }

    private fun applyEffectLevels() {
        runCatching {
            loudnessFx?.setTargetGain((prefs.loudness * 1000f).toInt())
            loudnessFx?.setEnabled(prefs.loudness > 0.01f)
        }
        runCatching {
            bassFx?.setStrength((prefs.bass * 1000f).toInt().toShort())
            bassFx?.setEnabled(prefs.bass > 0.01f)
        }
        runCatching {
            val eq = eqFx ?: return@runCatching
            eq.setEnabled(prefs.eqEnabled)
            val range = eq.bandLevelRange
            val minL = range[0].toInt()
            val maxL = range[1].toInt()
            val centers = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
            for (b in 0 until eq.numberOfBands.toInt()) {
                val hz = eq.getCenterFreq(b.toShort()) / 1000f
                var best = 0
                var bestDist = Float.MAX_VALUE
                for (i in centers.indices) {
                    val d = kotlin.math.abs(kotlin.math.ln(hz / centers[i]))
                    if (d < bestDist) { bestDist = d; best = i }
                }
                val gainDb = prefs.eqGains.getOrElse(best) { 0f }
                eq.setBandLevel(b.toShort(), (gainDb * 100f).toInt().coerceIn(minL, maxL).toShort())
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        // The widget should not keep showing a pause button once playback is gone.
        val last = WidgetState.song(this)
        WidgetState.saveSong(this, last.title, last.artist, last.artUri, false, last.has)
        AuroraWidget.refreshAll(this)
        scope.cancel()
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        runCatching { eqFx?.release() }
        releaseLevelling()
        session?.run {
            player.release()
            release()
        }
        session = null
        player = null
        super.onDestroy()
    }
}
