package com.aurora.player

import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.LoudnessEnhancer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private data class AudioPrefs(
    val speed: Float,
    val pitch: Float,
    val skipSilence: Boolean,
    val bass: Float,
    val loudness: Float,
)

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loudnessFx: LoudnessEnhancer? = null
    private var bassFx: BassBoost? = null
    private var prefs = AudioPrefs(1f, 1f, false, 0f, 0f)

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = exo
        session = MediaSession.Builder(this, exo).build()

        exo.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attachEffects(audioSessionId)
            }
        })
        attachEffects(exo.audioSessionId)

        scope.launch {
            SettingsStore(this@PlaybackService).flow
                .map { AudioPrefs(it.playbackSpeed, it.playbackPitch, it.skipSilence, it.bassBoost, it.loudness) }
                .distinctUntilChanged()
                .collect { applyPrefs(it) }
        }
    }

    private fun applyPrefs(p: AudioPrefs) {
        prefs = p
        val exo = player ?: return
        exo.playbackParameters = PlaybackParameters(p.speed, p.pitch)
        exo.skipSilenceEnabled = p.skipSilence
        applyEffectLevels()
    }

    private fun attachEffects(sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        loudnessFx = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        bassFx = runCatching { BassBoost(0, sessionId) }.getOrNull()
        applyEffectLevels()
    }

    private fun applyEffectLevels() {
        runCatching {
            loudnessFx?.setTargetGain((prefs.loudness * 1000f).toInt())
            loudnessFx?.setEnabled(prefs.loudness > 0.01f)
        }
        runCatching {
            bassFx?.setStrength((prefs.bass * 1000f).toInt().toShort())
            bassFx?.setEnabled(prefs.bass > 0.01f)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        session?.run {
            player.release()
            release()
        }
        session = null
        player = null
        super.onDestroy()
    }
}
