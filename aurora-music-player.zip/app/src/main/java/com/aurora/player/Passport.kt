package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** One badge of the Aurora passport. It is earned once [value] reaches [target]. */
private class Badge(val emoji: String, val title: String, val hint: String, val value: Int, val target: Int) {
    val earned: Boolean get() = value >= target
}

private class Passport(
    val current: Int,
    val best: Int,
    val playedToday: Boolean,
    val activeDays: Int,
    val hourTotals: IntArray,
    val dayCounts: Map<Long, Int>,
    val badges: List<Badge>,
)

/**
 * Works out streaks, per-hour totals and badges. Days come from the old play log (so existing listeners keep their
 * streak) and from the new hourly log. Hours are only known for plays made after the hourly log was added.
 */
private fun buildPassport(songs: List<Song>, lib: LibraryData): Passport {
    val today = java.time.LocalDate.now().toEpochDay()
    val counts = HashMap<Long, Int>()
    for ((_, day) in lib.playLog) counts[day] = (counts[day] ?: 0) + 1
    val hourTotals = IntArray(24)
    for ((day, hours) in lib.listenLog) {
        for (h in 0 until 24) hourTotals[h] += hours.getOrElse(h) { 0 }
        counts[day] = maxOf(counts[day] ?: 0, hours.sum())
    }

    for ((day, n) in lib.extraDays) counts[day] = maxOf(counts[day] ?: 0, n)

    var best = 0
    var run = 0
    var prev = Long.MIN_VALUE
    for (day in counts.keys.sorted()) {
        run = if (prev != Long.MIN_VALUE && day == prev + 1) run + 1 else 1
        if (run > best) best = run
        prev = day
    }
    val playedToday = counts.containsKey(today)
    var current = 0
    var cursor = if (playedToday) today else today - 1
    while (counts.containsKey(cursor)) {
        current++
        cursor--
    }

    val night = (0..4).sumOf { hourTotals[it] }
    val early = (5..8).sumOf { hourTotals[it] }
    val maxDay = counts.values.maxOrNull() ?: 0
    val totalPlays = lib.plays.values.sum()
    val distinct = lib.plays.count { it.value > 0 }
    val stats = listeningStats(songs, lib)
    val hoursListened = (stats.totalMs / 3_600_000L).toInt()
    val topArtist = stats.topArtists.firstOrNull()?.second ?: 0

    val badges = listOf(
        Badge("🔥", "Warm-up", "3 days in a row", best, 3),
        Badge("⚡", "On fire", "7 days in a row", best, 7),
        Badge("🏆", "Unstoppable", "30 days in a row", best, 30),
        Badge("🦉", "Night owl", "10 plays between midnight and 5 AM", night, 10),
        Badge("🐦", "Early bird", "10 plays between 5 and 9 AM", early, 10),
        Badge("🏃", "Marathoner", "25 plays in a single day", maxDay, 25),
        Badge("🧭", "Explorer", "Play 50 different songs", distinct, 50),
        Badge("💯", "Century", "100 plays in total", totalPlays, 100),
        Badge("🎧", "Devoted", "1000 plays in total", totalPlays, 1000),
        Badge("⏳", "Full day", "Listen for 24 hours in total", hoursListened, 24),
        Badge("💖", "Collector", "25 favourite songs", lib.favorites.size, 25),
        Badge("🎤", "Superfan", "50 plays of one artist", topArtist, 50),
        Badge("📅", "Regular", "Listen on 30 different days", counts.size, 30),
    )
    return Passport(current, best, playedToday, counts.size, hourTotals, counts, badges)
}

private fun hourLabel(h: Int): String {
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12 " + if (h < 12) "AM" else "PM"
}

/** The Home card: listening streak, a 24 hour listening clock, a 12 week calendar and the badges. */
@Composable
fun PassportCard(songs: List<Song>, lib: LibraryData, shape: RoundedCornerShape) {
    val cs = MaterialTheme.colorScheme
    val data = remember(songs, lib.playLog, lib.listenLog, lib.extraDays, lib.plays, lib.favorites) { buildPassport(songs, lib) }
    val primary = cs.primary
    val track = cs.onSurface.copy(alpha = 0.10f)
    val totalHours = data.hourTotals.sum()
    val peakHour = if (totalHours > 0) (data.hourTotals.indices.maxByOrNull { data.hourTotals[it] } ?: 0) else 0

    Column(
        Modifier.fillMaxWidth().cardGlow(shape).cardFinish(shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("AURORA PASSPORT", style = MaterialTheme.typography.labelMedium, color = primary)

        // ---- streak
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(verbatim("🔥"), fontSize = 40.sp)
            Column(Modifier.padding(start = 12.dp)) {
                Text(
                    "${data.current} day streak",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = primary,
                )
                Text(
                    when {
                        data.current == 0 -> "Play a song to start your streak"
                        !data.playedToday -> "Play something today to keep it going"
                        else -> "Your streak is safe for today"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                Text(
                    "Best ${data.best} days  •  ${data.activeDays} days listened",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
        }

        // ---- listening clock
        Column {
            Text("Listening clock", style = MaterialTheme.typography.titleMedium)
            Text(
                if (totalHours > 0) "When you press play, around the clock" else "Fills up as you listen. Hours are counted from this update.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.size(240.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val outer = size.minDimension / 2f - 28.dp.toPx()
                    val inner = outer * 0.45f
                    val stroke = 7.dp.toPx()
                    val maxHour = (data.hourTotals.maxOrNull() ?: 0).coerceAtLeast(1)
                    for (h in 0 until 24) {
                        val a = (h / 24f) * 2f * PI.toFloat() - PI.toFloat() / 2f
                        val dx = cos(a)
                        val dy = sin(a)
                        drawLine(
                            track,
                            Offset(c.x + dx * inner, c.y + dy * inner),
                            Offset(c.x + dx * outer, c.y + dy * outer),
                            stroke,
                            StrokeCap.Round,
                        )
                        val v = data.hourTotals[h]
                        if (v > 0) {
                            val len = inner + (outer - inner) * (0.12f + 0.88f * v / maxHour)
                            drawLine(
                                primary,
                                Offset(c.x + dx * inner, c.y + dy * inner),
                                Offset(c.x + dx * len, c.y + dy * len),
                                stroke,
                                StrokeCap.Round,
                            )
                        }
                    }
                }
                val label = MaterialTheme.typography.labelSmall
                Text(verbatim("12 AM"), Modifier.align(Alignment.TopCenter), style = label, color = cs.onSurfaceVariant)
                Text(verbatim("6 AM"), Modifier.align(Alignment.CenterEnd), style = label, color = cs.onSurfaceVariant)
                Text(verbatim("12 PM"), Modifier.align(Alignment.BottomCenter), style = label, color = cs.onSurfaceVariant)
                Text(verbatim("6 PM"), Modifier.align(Alignment.CenterStart), style = label, color = cs.onSurfaceVariant)
                if (totalHours > 0) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(verbatim(hourLabel(peakHour)), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = primary)
                        Text("busiest hour", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
            }
        }

        // ---- 12 week calendar
        Text("Last 12 weeks", style = MaterialTheme.typography.titleMedium)
        val today = remember { java.time.LocalDate.now() }
        val start = remember(today) { today.minusDays((today.dayOfWeek.value - 1).toLong()).minusWeeks(11) }
        Canvas(Modifier.fillMaxWidth().aspectRatio(12f / 7f)) {
            val gap = 4.dp.toPx()
            val cell = minOf((size.width - gap * 11f) / 12f, (size.height - gap * 6f) / 7f)
            val corner = CornerRadius(cell * 0.28f, cell * 0.28f)
            for (col in 0 until 12) {
                for (row in 0 until 7) {
                    val date = start.plusDays((col * 7 + row).toLong())
                    if (date.isAfter(today)) continue
                    val n = data.dayCounts[date.toEpochDay()] ?: 0
                    val color = when {
                        n <= 0 -> track
                        n == 1 -> primary.copy(alpha = 0.35f)
                        n <= 3 -> primary.copy(alpha = 0.6f)
                        n <= 7 -> primary.copy(alpha = 0.8f)
                        else -> primary
                    }
                    drawRoundRect(color, Offset(col * (cell + gap), row * (cell + gap)), Size(cell, cell), corner)
                }
            }
        }

        // ---- badges
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Badges", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text(
                verbatim("${data.badges.count { it.earned }} / ${data.badges.size}"),
                style = MaterialTheme.typography.labelLarge,
                color = cs.onSurfaceVariant,
            )
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(data.badges, key = { it.title }) { BadgeTile(it) }
        }
    }
}

@Composable
private fun BadgeTile(b: Badge) {
    val cs = MaterialTheme.colorScheme
    val earned = b.earned
    Column(
        Modifier
            .width(104.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (earned) cs.primaryContainer else cs.onSurface.copy(alpha = 0.06f))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(verbatim(b.emoji), fontSize = 28.sp, modifier = Modifier.alpha(if (earned) 1f else 0.35f))
        Text(
            b.title,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (earned) cs.onPrimaryContainer else cs.onSurfaceVariant,
        )
        Text(
            b.hint,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            minLines = 3,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            color = cs.onSurfaceVariant,
        )
        Text(
            if (earned) "Earned" else "${b.value.coerceAtMost(b.target)}/${b.target}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = if (earned) cs.primary else cs.onSurfaceVariant,
        )
    }
}
