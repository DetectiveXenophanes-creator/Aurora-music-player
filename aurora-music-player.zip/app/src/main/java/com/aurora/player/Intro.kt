package com.aurora.player

import android.os.Build
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** First-run setup: access, look, motion and which tab to open on. */
@Composable
fun SetupScreen(
    s: AppSettings,
    granted: Boolean,
    onRequest: () -> Unit,
    onUpdate: SettingsUpdate,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val total = 7
    var step by rememberSaveable { mutableIntStateOf(0) }
    var showLanguages by remember { mutableStateOf(false) }
    var name by rememberSaveable { mutableStateOf(s.userName) }
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(null)
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                LanguageButton(s.language, { showLanguages = true }, Modifier.align(Alignment.CenterEnd))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (i in 0 until total) {
                    val w by animateDpAsState(
                        targetValue = if (i == step) 28.dp else 8.dp,
                        animationSpec = motion.spatial(),
                        label = "dot",
                    )
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(8.dp)
                            .width(w.coerceAtLeast(8.dp))
                            .clip(CircleShape)
                            .background(if (i <= step) cs.primary else cs.primary.copy(alpha = 0.25f))
                    )
                }
            }
            }
            Spacer(Modifier.height(16.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = { motion.tab(targetState > initialState) },
                label = "setupStep",
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) { st ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    when (st) {
                        0 -> {
                            Box(
                                Modifier.popIn().size(96.dp).clip(RoundedCornerShape(32.dp)).background(cs.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.MusicNote, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(52.dp))
                            }
                            StepTitle("Welcome to Aurora", "Let's make it yours. This takes about a minute.")
                        }
                        1 -> {
                            StepTitle("Find your music", "Aurora plays the songs already on your phone. It needs permission to see them.")
                            SettingCard("Music access") {
                                if (granted) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.CheckCircle, null, tint = cs.primary)
                                        Text("  Access granted", style = MaterialTheme.typography.bodyLarge)
                                    }
                                } else {
                                    Button(onClick = onRequest) { Text("Allow access") }
                                }
                            }
                        }
                        2 -> {
                            StepTitle("What should we call you?", "Aurora says hello on the Home screen. You can skip this.")
                            SettingCard("Your name") {
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { v ->
                                        name = v.take(24)
                                        onUpdate { it.copy(userName = name) }
                                    },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("Optional") },
                                )
                            }
                        }
                        3 -> {
                            StepTitle("Pick a look", "You can change all of this later in Settings.")
                            SettingCard("Finish") {
                                Segmented(
                                    options = listOf("Matte" to SurfaceStyle.MATTE, "Frosted glass" to SurfaceStyle.GLASS),
                                    selected = s.style,
                                    onSelect = { v -> onUpdate { it.copy(style = v) } },
                                )
                            }
                            SettingCard("Design style") { DesignPicker(s, onUpdate) }
                            SettingCard("Theme") {
                                Segmented(
                                    options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
                                    selected = s.themeMode,
                                    onSelect = { v -> onUpdate { it.copy(themeMode = v) } },
                                )
                                if (canDynamic) {
                                    ToggleRow("Material You colours", "Use colours from your wallpaper", s.dynamicColor, true) { v ->
                                        onUpdate { it.copy(dynamicColor = v) }
                                    }
                                }
                            }
                        }
                        4 -> {
                            StepTitle("How much motion?", "Pick how lively the animations feel.")
                            SettingCard("Intensity") {
                                Segmented(
                                    options = listOf("Subtle" to 0.25f, "Balanced" to 0.5f, "Lively" to 1f),
                                    selected = listOf(0.25f, 0.5f, 1f).firstOrNull { abs(it - s.animIntensity) < 0.03f } ?: -1f,
                                    onSelect = { v -> onUpdate { it.copy(animIntensity = v) } },
                                )
                            }
                            SettingCard("Style") {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimSet.entries.forEach { a ->
                                        FilterChip(
                                            selected = s.animSet == a,
                                            onClick = { onUpdate { it.copy(animSet = a) } },
                                            label = { Text(a.label) },
                                        )
                                    }
                                }
                            }
                        }
                        5 -> {
                            StepTitle("Where should Aurora open?", "Choose the tab you want to see first.")
                            SettingCard("Start on") {
                                StartTabPicker(s.startTab) { v -> onUpdate { it.copy(startTab = v) } }
                            }
                        }
                        else -> {
                            Box(
                                Modifier.popIn().size(96.dp).clip(CircleShape).background(cs.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.CheckCircle, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(52.dp))
                            }
                            StepTitle("You're all set", tr("Aurora will open on") + " " + tr(s.startTab.label) + ". " + tr("Enjoy the music.") + " " + tr("Next, a short friendly tour."))
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) {
                    TextButton(onClick = { step -= 1 }) { Text("Back") }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = {
                    if (step < total - 1) step += 1 else onUpdate { it.copy(setupDone = true) }
                }) {
                    Text(if (step < total - 1) "Next" else "Start listening")
                }
            }
        }
    }
    if (showLanguages) {
        LanguageSheet(
            current = s.language,
            onPick = { l -> onUpdate { it.copy(language = l) }; showLanguages = false },
            onDismiss = { showLanguages = false },
        )
    }
}

@Composable
private fun StepTitle(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Start)
    }
}
