package com.aurora.player

import android.os.Build
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** Music-themed opening: an audio spectrum swells over the squiggle background, then the name fades in. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val progress = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(3400, easing = LinearEasing))
        onDone()
    }
    LaunchedEffect(skip) { if (skip) onDone() }

    val clock by rememberInfiniteTransition(label = "introClock").animateFloat(
        0f, 1000f,
        infiniteRepeatable(tween(1_000_000, easing = LinearEasing)),
        label = "clock",
    )
    val p = progress.value
    val fade = if (p > 0.86f) 1f - (p - 0.86f) / 0.14f else 1f
    val titleA = ((p - 0.30f) / 0.25f).coerceIn(0f, 1f)
    val tagA = ((p - 0.50f) / 0.25f).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.coerceIn(0f, 1f) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { skip = true },
    ) {
        AuroraBackground(null)
        Canvas(Modifier.fillMaxSize()) {
            val n = 29
            val grow = FastOutSlowInEasing.transform(min(1f, p / 0.45f))
            val bw = size.width * 0.78f / (n * 1.7f)
            val gap = bw * 0.7f
            val startX = (size.width - (n * bw + (n - 1) * gap)) / 2f
            val cy = size.height * 0.40f
            val maxH = size.height * 0.16f
            for (i in 0 until n) {
                val x = i / (n - 1f) * 2f - 1f
                val env = 1f - x * x
                val wobble = 0.3f + 0.7f * abs(sin(clock * 3.0f + i * 0.55f))
                val h = (maxH * env * wobble * grow).coerceAtLeast(bw / 2f)
                drawRoundRect(
                    color = lerp(cs.primary, cs.tertiary, i / (n - 1f)),
                    topLeft = Offset(startX + i * (bw + gap), cy - h),
                    size = Size(bw, h * 2f),
                    cornerRadius = CornerRadius(bw / 2f),
                )
            }
        }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(0.64f))
            Text(
                "Aurora",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = (10f - 8f * titleA).sp,
                color = cs.onBackground,
                modifier = Modifier.graphicsLayer {
                    alpha = titleA
                    val sc = 0.92f + 0.08f * titleA
                    scaleX = sc
                    scaleY = sc
                },
            )
            Text(
                "Your music, your style",
                style = MaterialTheme.typography.bodyLarge,
                color = cs.onSurfaceVariant,
                modifier = Modifier.graphicsLayer { alpha = tagA },
            )
            Spacer(Modifier.weight(0.36f))
        }
    }
}

/** First-run setup: access, look, motion and which tab to open on. */
@Composable
fun SetupScreen(
    s: AppSettings,
    granted: Boolean,
    onRequest: () -> Unit,
    onUpdate: SettingsUpdate,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val total = 6
    var step by rememberSaveable { mutableIntStateOf(0) }
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(null)
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (i in 0 until total) {
                    val w by animateDpAsState(
                        targetValue = if (i == step) 28.dp else 8.dp,
                        animationSpec = motion.spatial(),
                        label = "dot",
                    )
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(8.dp)
                            .width(w.coerceAtLeast(8.dp))
                            .clip(CircleShape)
                            .background(if (i <= step) cs.primary else cs.primary.copy(alpha = 0.25f))
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = { motion.tab(targetState > initialState) },
                label = "setupStep",
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) { st ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    when (st) {
                        0 -> {
                            Box(
                                Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(cs.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.MusicNote, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(52.dp))
                            }
                            StepTitle("Welcome to Aurora", "Let's make it yours. This takes about a minute.")
                        }
                        1 -> {
                            StepTitle("Find your music", "Aurora plays the songs already on your phone. It needs permission to see them.")
                            SettingCard("Music access") {
                                if (granted) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.CheckCircle, null, tint = cs.primary)
                                        Text("  Access granted", style = MaterialTheme.typography.bodyLarge)
                                    }
                                } else {
                                    Button(onClick = onRequest) { Text("Allow access") }
                                }
                            }
                        }
                        2 -> {
                            StepTitle("Pick a look", "You can change all of this later in Settings.")
                            SettingCard("Finish") {
                                Segmented(
                                    options = listOf("Matte" to SurfaceStyle.MATTE, "Frosted glass" to SurfaceStyle.GLASS),
                                    selected = s.style,
                                    onSelect = { v -> onUpdate { it.copy(style = v) } },
                                )
                            }
                            SettingCard("Theme") {
                                Segmented(
                                    options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
                                    selected = s.themeMode,
                                    onSelect = { v -> onUpdate { it.copy(themeMode = v) } },
                                )
                                if (canDynamic) {
                                    ToggleRow("Material You colours", "Use colours from your wallpaper", s.dynamicColor, true) { v ->
                                        onUpdate { it.copy(dynamicColor = v) }
                                    }
                                }
                            }
                        }
                        3 -> {
                            StepTitle("How much motion?", "Pick how lively the animations feel.")
                            SettingCard("Intensity") {
                                Segmented(
                                    options = listOf("Subtle" to 0.25f, "Balanced" to 0.5f, "Lively" to 1f),
                                    selected = listOf(0.25f, 0.5f, 1f).firstOrNull { abs(it - s.animIntensity) < 0.03f } ?: -1f,
                                    onSelect = { v -> onUpdate { it.copy(animIntensity = v) } },
                                )
                            }
                            SettingCard("Style") {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimSet.entries.forEach { a ->
                                        FilterChip(
                                            selected = s.animSet == a,
                                            onClick = { onUpdate { it.copy(animSet = a) } },
                                            label = { Text(a.label) },
                                        )
                                    }
                                }
                            }
                        }
                        4 -> {
                            StepTitle("Where should Aurora open?", "Choose the tab you want to see first.")
                            SettingCard("Start on") {
                                StartTabPicker(s.startTab) { v -> onUpdate { it.copy(startTab = v) } }
                            }
                        }
                        else -> {
                            Box(
                                Modifier.size(96.dp).clip(CircleShape).background(cs.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.CheckCircle, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(52.dp))
                            }
                            StepTitle("You're all set", "Aurora will open on ${s.startTab.label}. Enjoy the music.")
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (step > 0) {
                    TextButton(onClick = { step -= 1 }) { Text("Back") }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = {
                    if (step < total - 1) step += 1 else onUpdate { it.copy(setupDone = true) }
                }) {
                    Text(if (step < total - 1) "Next" else "Start listening")
                }
            }
        }
    }
}

@Composable
private fun StepTitle(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Start)
    }
}
