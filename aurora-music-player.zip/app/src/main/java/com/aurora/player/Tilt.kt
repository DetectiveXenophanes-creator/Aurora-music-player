package com.aurora.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.awaitCancellation
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Depth tilt: the cover turns a little with the phone and a soft shine slides across it.
 *
 * The state is read only while drawing (inside graphicsLayer and drawBehind), never while composing, so a sensor
 * reading redraws the cover's layer and nothing else. The sensor is registered only while this screen is on screen
 * and the app is visible, and only when [rememberTilt] is asked for it.
 */
class TiltState {
    /** Degrees of turn round the horizontal axis and the vertical axis, already limited to the strength. */
    val rx = mutableFloatStateOf(0f)
    val ry = mutableFloatStateOf(0f)

    /** Where the shine sits, -1 (left) to 1 (right). */
    val shine = mutableFloatStateOf(0f)

    /** The largest turn in degrees (about 8 at full strength). Written from composition, read by the sensor thread. */
    @Volatile
    var maxDeg: Float = 5f
}

/** The tilt of the Now Playing screen, or null when the effect is off. Provided by NowPlayingScreen. */
val LocalTilt = staticCompositionLocalOf<TiltState?> { null }

// If the cover seems to turn the wrong way on a phone, flip the sign here.
private const val RX_SIGN = 1f
private const val RY_SIGN = -1f

/** 20 degrees of phone movement away from the resting pose give the full turn. */
private const val FULL_RANGE = 20f

/** Returns the tilt state while [enabled] (and keeps the sensor running only while the app is visible), else null. */
@Composable
fun rememberTilt(enabled: Boolean, strength: Float): TiltState? {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val state = remember { TiltState() }
    SideEffect { state.maxDeg = 8f * strength.coerceIn(0.3f, 1f) }
    LaunchedEffect(enabled, lifecycle) {
        if (!enabled) return@LaunchedEffect
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return@LaunchedEffect
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return@LaunchedEffect
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            val listener = TiltListener(state)
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            try {
                awaitCancellation()
            } finally {
                manager.unregisterListener(listener)
                state.rx.floatValue = 0f
                state.ry.floatValue = 0f
                state.shine.floatValue = 0f
            }
        }
    }
    return if (enabled) state else null
}

/**
 * Smooths the accelerometer (low-pass), works out how the phone is held, and compares that with a resting pose that
 * follows the phone slowly: a phone held steadily settles flat after a few seconds, a quick movement shows as a turn.
 * Tilt only works while the phone is held upright-ish (the screen's top edge up); lying flat or in landscape it eases
 * back to flat.
 */
private class TiltListener(private val st: TiltState) : SensorEventListener {
    private var gx = 0f
    private var gy = 0f
    private var gz = 0f
    private var started = false
    private var haveNeutral = false
    private var nPitch = 0f
    private var nRoll = 0f
    private var last = 0L

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0]
        val ay = e.values[1]
        val az = e.values[2]
        val dt = if (last == 0L) 0.02f else ((e.timestamp - last) / 1_000_000_000f).coerceIn(0.001f, 0.2f)
        last = e.timestamp
        if (!started) {
            gx = ax
            gy = ay
            gz = az
            started = true
        }
        val a = 1f - exp(-dt / 0.08f)
        gx += (ax - gx) * a
        gy += (ay - gy) * a
        gz += (az - gz) * a
        val g = sqrt(gx * gx + gy * gy + gz * gz)
        if (g < 1f) return
        val maxDeg = st.maxDeg
        var rx: Float
        var ry: Float
        var shine: Float
        if (gy > 0.25f * g) {
            val pitch = Math.toDegrees(atan2(gz, gy).toDouble()).toFloat()
            val roll = Math.toDegrees(atan2(gx, gy).toDouble()).toFloat()
            if (!haveNeutral) {
                nPitch = pitch
                nRoll = roll
                haveNeutral = true
            }
            val n = 1f - exp(-dt / 4f)
            nPitch += (pitch - nPitch) * n
            nRoll += (roll - nRoll) * n
            val tp = pitch - nPitch
            val tr = roll - nRoll
            rx = (tp / FULL_RANGE * maxDeg).coerceIn(-maxDeg, maxDeg) * RX_SIGN
            ry = (tr / FULL_RANGE * maxDeg).coerceIn(-maxDeg, maxDeg) * RY_SIGN
            shine = (tr / FULL_RANGE).coerceIn(-1f, 1f)
        } else {
            // flat on a table or in landscape: ease back to rest and forget the resting pose
            haveNeutral = false
            rx = st.rx.floatValue * 0.9f
            ry = st.ry.floatValue * 0.9f
            shine = st.shine.floatValue * 0.9f
        }
        // a write only when it is visible, so a still phone costs nothing
        if (abs(rx - st.rx.floatValue) > 0.04f) st.rx.floatValue = rx
        if (abs(ry - st.ry.floatValue) > 0.04f) st.ry.floatValue = ry
        if (abs(shine - st.shine.floatValue) > 0.005f) st.shine.floatValue = shine
    }
}

/** Turns the layer with the phone. The values are read in the layer block, so only the layer is redrawn. */
fun Modifier.depthTilt(tilt: TiltState?): Modifier =
    if (tilt == null) this else this.graphicsLayer {
        rotationX = tilt.rx.floatValue
        rotationY = tilt.ry.floatValue
        cameraDistance = 14f * density
    }

/** One soft diagonal band of light, one unit big, moved and scaled while drawing so nothing is allocated per frame. */
private val ShineBrush = Brush.horizontalGradient(
    listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
    startX = 0f,
    endX = 1f,
)

/** The shine over the cover. Give it the cover's size with [modifier] and the cover's shape as [shape]. */
@Composable
fun TiltShine(tilt: TiltState?, shape: Shape, modifier: Modifier = Modifier) {
    if (tilt == null) return
    Box(
        modifier
            .clip(shape)
            .drawBehind {
                val w = size.width
                val h = size.height
                val cx = w * (0.5f + 0.6f * tilt.shine.floatValue)
                withTransform({
                    translate(cx, h / 2f)
                    rotate(20f, Offset.Zero)
                    scale(w * 0.45f, h * 1.6f, Offset.Zero)
                    translate(-0.5f, -0.5f)
                }) {
                    drawRect(ShineBrush, Offset.Zero, Size(1f, 1f), 0.5f)
                }
            },
    )
}
