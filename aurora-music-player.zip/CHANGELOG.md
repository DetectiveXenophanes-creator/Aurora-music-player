# Changelog

## Song editor + battery pass

### New: song editor
- "Edit song info" in every song menu (song lists, Now Playing, playlists, albums, search).
- Change title, artist, album and cover art (picked with the system photo picker, no permission needed).
- "Use original cover" and "Restore original" undo your changes.
- Edits are stored inside Aurora and laid over the song everywhere: lists, queue, notification, lock screen, widget.
  Your audio files are never modified. Editing an artist regroups the song under that artist.
- Covers are shrunk to max 1200 px and kept in the app's private `covers` folder; deleted with the song.

### Battery
- Position tracking only runs while music is actually playing (it used to tick forever, even when paused).
- In the background the player is checked every 5 s instead of every 2 s, and wakes instantly when you open the app.
- Glow/ambient animation clock now stops fully when the app is off screen (it kept ticking while music played with the screen off).
- Audio offload: the phone's audio chip decodes the music so the CPU can sleep. Turns itself off while speed/pitch,
  skip silence, equalizer, bass or loudness are in use. Unsupported phones fall back to normal playback.
- "Balanced" power profile is cheaper: glow 15 -> 10 fps, spinning/mascot 25 -> 20 fps.

### Build
- Google's Maven Central mirror added ahead of Maven Central, plus longer timeouts and retries (fixes the "Could not find ... .jar" CI failure).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.
- No app can promise a fixed "5%" battery figure: it depends on the phone, screen time and settings. Settings -> Power profile -> Efficient saves the most.

## Player styles + crossfade + volume levelling

### New: Player styles (Settings > Player)
- A gallery of five styles with small previews: Orbit, Classic, Vinyl, Waves, Compact.
- Tapping a style applies a bundle of the existing player settings (design, layout, cover shape, progress style, play button style),
  so everything can still be fine-tuned afterwards. The selected style is outlined; "Custom" shows when you changed things yourself.

### New: Transitions and volume (Settings > Audio)
- Crossfade 0 to 12 seconds: each song fades out at its end and the next fades in (songs do not overlap).
- Volume levelling Off / Light / Strong: a gentle compressor and limiter that evens out loud and quiet parts.
  Needs Android 9+, and turns audio offload off while it is on (a little more battery).

### Notes
- Not compiled here. If the GitHub build fails, the first `e:` line tells where.
- Sleep-timer fade and crossfade both change the volume; use one of them at a time if you hear odd volume jumps.
