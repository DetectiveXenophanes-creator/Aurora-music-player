# Changelog

## v31 (3.10.0): Player look. Five new ways to make the Now Playing screen your own

New settings page **Settings > Look and feel > Player look** with a live preview for every feature. Everything is Standard or off by default, so nothing changes until you pick something. All five work in **both** Now Playing designs (Orbit, the default, and Panel). Not compiled and not run on a phone by me (no compiler here): the pure logic was tested in Python (`tools/playerlook_check.py`), the rest needs your build and your eyes.

### What is new
- **Control skins**: Standard, Piano keys, Tape deck, Glass, Dial knob. Only previous, play and next change; the pill row (shuffle, repeat, favourite) and the round shuffle, repeat buttons of Orbit stay. Keys: white keys for skip, a black key for play with a bar of the theme colour at its foot while music plays. Tape: beveled buttons that sink when pressed, Play stays sunk and tinted while music plays. Glass: frosted pills (also readable on light themes). Knob: a big dial with 21 tick marks that light up while playing and a pointer that turns, small round knobs for skip.
- **Title styles**: Standard, Poster (heavy capitals, words stacked on two lines), Handwritten (cursive), Outline (hollow letters in the theme colour), Spaced (small capitals, wide letter spacing). Plus **alignment** (Auto, Left, Centre, Right; Auto keeps what each design did) and an **artist chip** (the artist in a small rounded chip). The scrolling titles setting, the title size and the old centre-title setting still work.
- **Depth tilt**: the cover turns up to about 8 degrees with the phone and a soft shine slides across it. Strength 30 to 100%. The sensor (accelerometer, smoothed, with a resting pose that follows the phone slowly so a steadily held phone settles flat) is registered only while Now Playing is open and the app is visible, and never in battery saver or Lite. It works with the phone held upright; lying flat or in landscape it eases back to flat. Applies to the Orbit disc and to the Panel cover (inside its cover frame).
- **Layout composer**: put Title, Seek bar and Buttons in any order (portrait, Orbit and Panel), cover size Small / Medium / Large, spacing Compact / Normal / Roomy, with a small schematic. Large trims the gaps around the cover (and in Orbit the space between ring and cover) so the cover gets every spare pixel; Small makes it 78%. Landscape uses cover size and spacing only. The stored order is repaired to a valid order every time it is read.
- **Stage backgrounds**: None, Spotlight (two swaying beams), Fireflies (28 drifting lights), Rain (46 streaks and 6 slow drops), Colour wash (the cover huge and faint, no blur, no clock). Drawn above the normal background and behind the player.

### Smoothness
- Spotlight, Fireflies and Rain are one canvas in their own graphics layer, driven by `rememberThrottledClock` at 20 fps (it pauses while scrolling and while the app is off screen). Brushes are made once and moved with `withTransform`, particle start values are made once, nothing is allocated per tick. They run only while music plays and are off in battery saver.
- The tilt values are read only in `graphicsLayer` and `drawBehind` (draw phase), never in composition, and a write happens only when the value changed visibly.
- `asLite()` switches Depth tilt and Stage backgrounds off.

### What changed, file by file
- `PlayerLook.kt` (new): the enums (`ControlSkin`, `TitleStyle`, `TitleAlign`, `NpSection`, `CoverSize`, `NpDensity`, `NpStage`), order helpers (`parseOrder`, `repairOrder`, `moveNpSection`), `StyledTitle`, `StyledArtist`, `SkinPlay`, `SkinSkip` and the four skins.
- `Tilt.kt` (new): `TiltState`, `LocalTilt`, `rememberTilt`, the sensor listener, `Modifier.depthTilt`, `TiltShine`. If the cover turns the wrong way on a phone, flip `RX_SIGN` / `RY_SIGN` at the top.
- `Stage.kt` (new): `StageBackground`.
- `PlayerLookTab.kt` (new): the settings page and its previews, built from the same composables as the real player.
- `NowPlayingOrbit.kt`: layout order, cover size and spacing; `OrbitInfo` uses `StyledTitle` / `StyledArtist`; `OrbitControls` uses `SkinSkip` / `SkinPlay` when a skin is picked; `OrbitDisc` has the tilt and the shine.
- `NowPlayingScreen.kt` (Panel and the screen host): `StageBackground` behind the player, tilt provided to both designs, `NpSections` (order and spacing), cover size, `NpInfo` uses the title styles, `NpControls` uses the skins, `NpArt` has the tilt and the shine.
- `Settings.kt`: 10 new settings (`controlSkin`, `titleStyle`, `titleAlign`, `artistChip`, `depthTilt`, `tiltStrength`, `npOrder`, `npCoverSize`, `npDensity`, `npStage`) in all places, and all ten keys are in `lookKeys` (look profiles include them).
- `SettingsScreen.kt`: tab `PLAYERLOOK` (after Atmosphere), in the Look and feel group. `Extras.kt`: `asLite()`.
- `tools/gen_settings_index.py` knows the new tab; `SettingsIndex.kt` regenerated (324 entries). `tools/playerlook_check.py` (new) is the Python test of the order and tilt maths.
- `app/build.gradle.kts`: 3.10.0 (versionCode 31).

## v30 (3.9.2): build fix. The GitHub build failed, this makes it compile

The build of 3.9.0 and 3.9.1 stopped with `Unresolved reference 'drawOutline'` in `Frames.kt` (three places, the Neon cover frame). Nothing else was reported in the log.
- `Frames.kt`: `drawOutline` is no longer used. A small `strokeOutline` function draws the outline by hand with `drawRect`, `drawPath` and `addRoundRect`, which are already used elsewhere in the app. The Neon frame looks exactly the same.
- The owner had tried an `import androidx.compose.ui.graphics.drawscope.drawOutline` by hand, which does not exist either (the error then showed at line 30, the import itself). That line is not needed any more and must not be added back.
- No other change. `app/build.gradle.kts`: 3.9.2 (versionCode 30). Not compiled by me (no compiler here): if the build still fails, send the first `e:` lines.

## v29 (3.9.1): smoothness update. No new features, only fewer dropped frames

This is a performance update. It was written from a read-through of how the screen is drawn, not from measurements on a phone (there is no phone in the build environment), so the honest test is yours: please tell me if scrolling and animations feel smoother, and if anything still stutters, where.

### What was making frames drop
- **The animated backdrop shared one layer with all the lists.** The moving background and every scrolling page sit inside the same haze source. Each backdrop tick (up to 30 a second) therefore redrew everything in it and fed every glass bar (dock, header, mini player) a new image to blur again. That is a lot of work for a slow drifting light.
- **The backdrop built new shaders and paths on every tick.** Liquid light made 7 gradient shaders and up to 21 paths plus gradients every tick, the soft orbs made 6 shaders, and the Curtains rays made 28 gradient shaders. That is constant allocation and garbage collection, which shows up as stutter.
- **Decorative animation ran while you scrolled**, so the scroll and the backdrop fought for the same frames.

### What changed
- **The background has its own layer.** A backdrop tick now redraws only the background, not the lists on top of it. The colour fill is inside the same layer, so the additive glows still look exactly as before.
- **Animations wait while you scroll.** While a list moves (and for 0.3 seconds after) the moving backdrop, the glows and the edge light stand still, then carry on from the same moment. Everything is driven by one flag that only the small animated pieces read, so the screen itself does not recompose when a scroll starts or stops.
- **Nothing is allocated per tick any more** in Liquid light, the soft orbs and the Curtains rays. Gradients are built once per palette (one unit big, moved and scaled while drawing) and the neck paths are reused. One visible difference: a neck between two dots of different colours is now one blended colour (the average) instead of a gradient.
- **The v28 effects are lighter.** Grain, vignette, warm tint and edge light each draw in their own layer, so the edge light breathing no longer redraws the screen behind it. Living colours now glides in 8 steps instead of recomposing the colours on every frame.
- **Auto smooth (new, Settings > Customization > Performance).** In Auto mode the app listens to Android's own frame timings (passive: it never asks for extra frames, so it costs nothing while the screen is still). If at least 18% of frames are late in three windows of two seconds in a row, it switches to Lite by itself for the session (no blur, still background, no grain or edge light, no colour glide). The Performance card says when this has happened and has a button to try full quality again. Choosing Full or Lite yourself always wins.
- **Lite now also switches off grain and edge light.**

### Under the hood (file by file)
- `Smooth.kt` (new): `LocalScrolling` (holds a State), `SmoothState`, `FrameWatch` (`Window.OnFrameMetricsAvailableListener` on its own thread), `rememberFrameWatch`.
- `Ambient.kt`: `rememberThrottledClock` pauses while scrolling. `Aurora.kt`: the old aurora glow does too.
- `Components.kt`: `AuroraBackground` root `Box` has `graphicsLayer { }`.
- `Backdrop.kt`: `unitGlow`, `unitFace`, `unitRay`, `BlobScratch`, `bridgeInto` (replaces `bridgePath`, same maths), `withTransform` drawing for orbs, dots and rays.
- `MainScreen.kt`: scroll watching in `hideConnection.onPreScroll`, `LocalScrolling` provided, Auto uses `SmoothState.struggling`, `rememberFrameWatch`.
- `Atmosphere.kt`, `Living.kt`, `Extras.kt` (`asLite`), `SettingsScreen.kt` (Performance card text, status and button).
- `app/build.gradle.kts`: 3.9.1 (versionCode 29). Not compiled or run on a phone yet (see WIP.md).

## v28: Atmosphere (living colours, film grain, vignette, edge light, evening warmth) and cover frames

New design features for the whole app, none of them about the mini player. They live on a new page, **Settings > Atmosphere** (Look and feel group). Everything is **off by default**, so nothing changes until you switch something on. The effects are drawn over the whole app, the settings page included, so every change shows live right where you are.

### New: Living colours
The colours of the **whole app** glide to the colours of the album cover that is playing (about two thirds of a second when the song changes), mixed with your theme. A strength slider (20 to 100%) decides how much of the cover wins. Before, only the Now Playing screen could take the cover colours. It works with every theme and keeps AMOLED black. Without a cover the app keeps your theme. Switching it on or off never restarts a screen.

### New: Atmosphere effects
- **Film grain:** a fine speckle over the screen, like film. It never moves, so it costs almost no battery.
- **Vignette:** the corners fade to dark and pull the eye to the middle.
- **Edge light:** a soft coloured light along the four edges. It breathes slowly while music plays (12 steps a second) and stands still in battery saver or when nothing plays. The colours come from the theme (primary, secondary, tertiary) or, with "Colour from the cover", from the album cover with slightly shifted hues on the sides and the bottom.
- **Evening warmth:** a warm amber tint like a night light. "Only in the evening" fades it in from 19:00, keeps it until 06:00 and fades it out by 07:00 (checked once a minute); off means all day. The page tells you whether it is on right now.
All of them draw in one layer that never takes a touch, sits above the screens and below the tour, and draws nothing at all when every effect is off.

### New: Cover frames (on the big cover of Now Playing)
- **Lifted:** a deep soft shadow in the colour of the theme.
- **Neon:** a glowing outline that follows any cover shape (works around the spinning vinyl too).
- **Polaroid:** a white instant photo, tilted 1.6 degrees, with the song's name written underneath in cursive.
- **Stamp:** a postage stamp with a perforated edge all round.
- **Film:** a strip of film with sprocket holes down both sides.
- **Gallery:** a cream matte with a thin line, like a print on a gallery wall.
Polaroid, Stamp, Film and Gallery need the Rounded or Squircle cover shape; with another shape they draw nothing and the page says so. Lifted and Neon work with every shape. The page shows a live preview with your own cover.

### New: Moods
One tap sets living colours, effects and frame together: **Clean**, **Cinema** (grain, vignette, a steady warm tint, gallery frame), **Neon night** (edge light from the cover, living colours, neon frame), **Cozy evening** (warm evenings, grain, polaroid) and **Dreamy** (living colours, edge light, lifted frame). The chip shows which mood matches your settings, or Custom when you have mixed your own.

### Under the hood (file by file)
- `Living.kt` (new): `lerpScheme` (mixes 33 colour roles), `livingScheme` (reuses `coverScheme`), `LivingColors` (wraps `Root`; keeps the content in the same place in the tree whether the feature is on or off; theme changes still apply instantly when it is off).
- `Atmosphere.kt` (new): `AtmosphereLayer` = `StillAtmosphere` (warm tint, vignette, grain, drawn once) + `EdgeLight` (own throttled clock). `eveningFactor`, a tiling grain brush made from a 160 px bitmap of 2 px specks.
- `Frames.kt` (new): `CoverFrame`, `effectiveFrame`, `npArtShape`, `StampShape` (half circles bitten out of every edge with `arcTo`), `CoverFrameBox` (each frame decides the shape of the cover inside it).
- `AtmosphereTab.kt` (new): the settings page and the moods. `SettingsScreen.kt`: tab `ATMOSPHERE`. Search index: 312 entries.
- `NowPlayingScreen.kt`: `NpArt` draws the cover inside `CoverFrameBox`. `MainScreen.kt`: `LivingColors` around `Root`, `AtmosphereLayer` before the tour overlay.
- `Settings.kt`: 9 new settings (`livingColors`, `livingStrength`, `grain`, `vignette`, `edgeLight`, `edgeCover`, `warmth`, `warmAuto`, `coverFrame`), all in the look profiles.
- `tools/atmosphere_check.py` (new): Python port of the evening schedule and the stamp outline. The stamp was drawn and looked right on all four edges, and the schedule was printed for the whole day.
- `app/build.gradle.kts`: 3.9.0 (versionCode 28). Not compiled or run on a phone yet (see WIP.md).

## v27: Island removed, five new mini player styles, and mini players that sit where the dock is

### Changed: where the floating mini players sit
- **Radial dock:** the mini player now sits **in the dock's own row**, beside the corner button, exactly where the classic one did. Floating designs use a short version that fits the 72 dp row (Card and Cover get a compact layout, everything respects the Size setting without outgrowing the row). While the radial menu is open every design shrinks to the cover and a play button, as the classic one does.
- **Every other dock** (Floating, Attached): the mini player floats **just above the dock**. The "Under the header" position is gone.
- Radial: gap, margin and "Hide with the dock" do not apply (the row decides), so the settings page hides them there. Side and Width still work.

### Removed
- **Island** is gone. If it was selected, the app falls back to Classic.

### New styles (10 choices now: Classic, Pill, Card, Disc, Cover and five new ones)
Each new style shows progress in a way of its own:
- **Cassette:** a little tape with two reels that turn while it plays. The tape winds from the left reel to the right as the song goes, so the reels change size.
- **Ticket:** a concert ticket with punched notches and a dashed tear line. The artist is in spaced capitals and a barcode, made from the song's name, fills in as it plays.
- **Wave:** every song gets its own waveform, drawn from its name. The played part is lit and the bars at the playhead bounce. **Tap or drag along it to jump** to any spot.
- **Dial:** a retro radio. The play button is the knob, the song is the station, and a glowing needle sweeps a tuning scale. **Drag the needle to tune** to any moment.
- **Neon:** a neon sign on a dark panel (dark in every theme). The glass tube lights up around the whole edge as the song plays, with an occasional flicker.
Card, Cover and Pill got small upgrades too: their progress and play badge use the cover colour (see below).

### New features of my own
- **Colour from the cover** (on by default, Settings > Mini player > Extras): progress, reels, needle, barcode, neon and the Disc badge take the main colour of the album cover. Greys fall back to the theme colour, and the colour is made brighter in dark themes and deeper in light themes so it is always easy to see.
- **Swipe up to open** (on by default): swipe any floating mini player upwards to open the full player. Swipe sideways still skips.
- **A little bounce** when a new song starts (not with minimal animations).
- **Scrub from the mini player:** Wave and Dial seek inside the song without opening anything.

### Settings page (Settings > Mini player)
- The **preview** can now show three situations: above a bar dock, in the Radial dock's row (on the side you chose), and with the radial menu open. It starts with the one that matches your dock.
- The Position card tells you which placement your dock gives, and only shows the sliders that apply.
- New card **Extras** with the two new switches. All new settings are searchable (296 entries) and are part of look profiles.

### Under the hood (file by file)
- `FloatingMini.kt` (rewritten): `FloatMini` (Island removed, 5 added), `FloatAlign`, `FloatMiniState` (+ `accent`, `onSeek`), `effectiveScale` (caps the Size in the dock row), `floatMiniShape(settings, dockRow)`, `floatRowAlignment`, `readableAccent`, `rememberLiveMiniState` (one place that builds the live state, used by the radial slot and the floating host), dock-row and narrow versions, `miniGestures` (skip, swipe up, bounce). `FloatPos` is removed.
- `FloatingMiniStyles.kt` (new): `TicketShape` (rounded rectangle minus two circles via `Path.combine`), `CassetteMini`, `TicketMini`, `WaveMini`, `DialMini`, `NeonMini`, `scrubbable` (tap and drag to seek).
- `MainScreen.kt`: the Radial slot draws the floating design (or the classic bar); the floating host above the dock only runs when the dock is not Radial; list padding is back to the simple rule (Radial adds no height).
- `Settings.kt`: `floatPos` removed; new `floatTint`, `floatSwipeUp` (field, key, read, write, look keys).
- `MiniPlayerTab.kt`: rewritten for the above. `app/build.gradle.kts`: 3.8.0 (versionCode 27).
- Checked in a sketch: the Cassette label text had to be padded by two reel radii, not one (fixed before shipping).
- Not compiled or run on a phone yet (see WIP.md).

## v26: floating mini players (5 new designs, their own settings page and a live preview)

### New: mini players that are not joined to the dock (Current interface)
Until now the mini player always sat in the same column as the dock, directly above it. There are now **five floating designs** that have their own spot on the screen. Pick one in **Settings > Mini player** (new page, in the Look and feel group). **Classic** is still the default and is exactly the old behaviour, so nothing changes until you choose a design.
- **Pill**: a slim, fully round capsule with the cover, the song and a play button inside a progress ring that follows your play button shape.
- **Card**: a roomier card with a bigger cover, a progress bar and previous, play and next buttons in one row under the song.
- **Disc**: a round bubble. The cover turns like a record while music plays (and stops when paused or in a minimal animation set), a ring around it fills with the song, and a small button plays and pauses. Tap the disc to open the player.
- **Island**: a small dark capsule (dark in every theme) with four live bars that jump while it plays. The song fills the capsule from the left like a battery.
- **Cover**: the album cover is the whole card, with a dark fade at the bottom for the song and white controls and a thin progress line.
All five open the full player with the same grow-out animation as before, support swipe to skip, follow Size, Cover, Progress and Skip buttons, glow with the mini player glow setting, and keep the lists from hiding behind them.

### New: the Mini player settings page
- **Preview**: a small copy of the screen (header, song rows, dock) with the chosen design on it, in the chosen place. It uses the real design code. Tap play, swipe it, change a setting and it follows at once. It shows your current song (or a sample when nothing plays).
- **Design**: Classic, Pill, Card, Disc, Island, Cover, each with a one line description.
- **Position**: above the dock or under the header; left, middle or right; gap from the dock or header (0 to 60 dp); side margin (6 to 40 dp); width (55 to 100%, not for the Disc); and "Hide with the dock", which slides it away together with the dock while you scroll.
- **What it shows**: Size, Cover, Progress, Skip buttons and Swipe to skip (the same settings as in Layout and Interface, so they stay in step).
- **Start over**: back to the Classic mini player.
- While the Legacy interface is on, the Design and Position cards are greyed with a reason; the preview then shows the classic look.
- All the new settings are searchable in Settings.

### Behaviour details
- Above the dock, the player floats just over the dock (or over the corner button in the Radial dock) and settles lower while the dock is scrolled away. In the Radial dock the floating player fades out while the arc is open.
- Under the header, the lists start below the player instead of behind it.
- The Disc and Island animations tick about 20 and 11 times a second only while music plays and the player is on screen, to stay gentle on the battery.

### Under the hood (file by file)
- `FloatingMini.kt` (new): enums `FloatMini`, `FloatPos`, `FloatAlign`; `FloatMiniState` (title, artist, cover, playing, `progress: () -> Float` that is only called while drawing, and the four actions); `FloatingMini()` plus the five designs; shared pieces (`SongLines`, `MiniArt`, `RoundButton`, `BarProgress`, `RingProgress`, `EqBars`, `swipeToSkip`); `floatMiniHeight`, `floatMiniShape`, `floatAlignment`. The designs do not know the player: the real screen and the preview both feed them a `FloatMiniState`.
- `MiniPlayerTab.kt` (new): the settings page and `MiniPreview`.
- `MainScreen.kt`: `floating` / `floatOnTop`; `miniExtra` depends on the design; list padding follows it; for a floating design the dock column and the radial slot draw no mini player and a new host block (own `AnimatedVisibility` with the same `sharedBounds` morph, clipped to the design's shape) draws it.
- `Settings.kt`: 7 new settings `floatMini`, `floatPos`, `floatAlign`, `floatGap`, `floatMargin`, `floatWidth`, `floatHide` (field, key, read with limits, write, and in `lookKeys`, so look profiles include them).
- `SettingsScreen.kt`: new `SettingsTab.MINIPLAYER`; `ChipPicker` is now `internal`. `ModernUi.kt`: `shapeOutlinePath` is now `internal`.
- `tools/gen_settings_index.py` knows `MiniPlayerTab.kt`; `SettingsIndex.kt` regenerated (294 entries).
- `app/build.gradle.kts`: version 3.7.0 (versionCode 26).
- Not compiled or run on a phone yet (see WIP.md).

## v25: Backdrop fixes, and Liquid light now has dots that really join

### Fixed: the Backdrop card looked greyed out (Settings > Design > Backdrop, Current interface)
The card was dimmed to 38% as if it were switched off, so the style chips, colour chips and sliders looked disabled even though they worked. The description line had been passed in the slot that means "this card is disabled because...". It is now a normal line of text at the top of the card, so everything is full strength.

### Changed: Liquid light is now real liquid
Before, it was only big soft glows laid over each other, so nothing ever looked like a dot, and nothing joined. Now:
- **Seven solid dots** drift on slow looping paths and meet often. When two come close a **neck grows between them and they join into one shape**, then they stretch, the neck gets thin and they pull apart again (lava lamp look). Three or four dots can join into one blob.
- The neck is filled with a colour blend between the two dots, so the join matches. Each dot is lighter in the middle.
- The neck thins out smoothly before it breaks, so nothing pops in or out.
- The old soft glow is still there underneath, much dimmer, as ambient light.
- **Speed**, **Brightness** and **Size** work as before. Size now makes the dots bigger or smaller. Brightness is the strength of the whole dot layer, so there are no seams where dots overlap.
- Same battery rules as before: it stands still in battery saver, under full-screen pages, and when the music is paused (unless Keep animating while paused is on), and it follows your background frame rate (8 to 30).
- Plain canvas drawing only, no special effects, so it works on every Android version the app supports.

### Changed: the other styles show more detail
- **Curtains**: thin shimmering rays now hang from each band, so it is not just a smooth glow.
- **Waves**: each wave has a thin bright line along its top.
- Night sky and Plain are unchanged.

### Under the hood (file by file)
- `SettingsScreen.kt`: `SettingCard("Backdrop")` no longer passes a second argument; the description is the first `Text` inside the card (bodySmall, `onSurfaceVariant`). The second parameter of `SettingCard` greys the card out, so it must not be used for subtitles.
- `Backdrop.kt`: Liquid light is drawn in two canvases. `drawOrbs` (dimmer, ambient) and the new `drawBlobs` in a layer with `graphicsLayer { alpha; compositingStrategy = Offscreen }`. New `bridgePath` (metaball neck: two cubic curves and two lines from the tangent points, `acos` arguments clamped, pairs with `d <= |r1 - r2|` skipped, neck fades to nothing at the reach). `drawCurtainBands` gets rays, `drawWaves` gets crest lines. New imports (`CompositingStrategy`, `graphicsLayer`, `SolidColor`, `Stroke`, `abs`, `acos`, `atan2`, `hypot`).
- `tools/metaball_check.py` (new): Python port of the neck maths and the dot motion. It draws test shapes (touching, apart, stretching, uneven sizes) and runs a 10 minute simulation. Result at default Size: a clearly visible join exists 96% of the time, the longest stretch with no join is 2 seconds, about 2.8 joined pairs at once. At Size 60% it is 73%, at 160% the dots join almost always.
- `app/build.gradle.kts`: version 3.6.1 (versionCode 25).
- No new settings, so `lookKeys`, backups and look profiles are unchanged. The settings search index was regenerated and did not change.
- Not compiled or run on a phone yet (see WIP.md).

## v24: Moving backdrop for Current, and four new smart features

### New: Backdrop (Current interface)
The Current interface now has its own **moving background** instead of the old gradient, album art and flat looks. The old background options are **greyed out in Current** (Settings > Design > Background says "Legacy only") and still work in Legacy exactly as before. The gradient, album art, pattern, aurora glow and squiggle layers are not drawn in Current. Glow orbs stay (they are a Current feature).
- **Styles**: Liquid light (big soft balls of colour drifting and melting together), Curtains (northern-light bands rippling across the top), Waves (layers of slow waves with a low sun glow), Night sky (twinkling stars, two slow colour clouds and a shooting star every 9 seconds) and Plain.
- **Colours**: Theme (follows your accent and your cover colours if on), Aurora, Sunset, Ocean, Candy, Rainbow, or Custom with two colours you pick by hue.
- **Speed**, **Brightness** and **Size** sliders. Settings > Design > Backdrop.
- Uses the existing battery rules: it stands still in battery saver and under full-screen pages, runs at your background frame rate, and when the music is paused it holds still unless Keep animating while paused (Resting) is on. The Now playing page still shows the dimmed cover on top of the backdrop.
- Backdrop settings are part of look profiles and backups.

### New features (all new to Aurora, and as far as I know to music players)
1. **Fit my time** (Home): choose 10 to 90 minutes and a source (Anything, Favorites, Not heard much) and Aurora builds a mix whose songs add up to that time, normally within about 2 seconds. Play it or tap Another mix. Shows how far off it is ("right on time", "2s short"). It tries a first pick, then a few hundred swaps and drops, keeping every change that lands closer.
2. **Skip memory**: Aurora notices when you press next (or jump to another song) in a song's first seconds. Songs you skip at least 3 times, and more than you play them, are kept out of Shuffle, the Daily mix and the other smart mixes. Playlists under 12 songs are never filtered and you can always play anything yourself. New smart playlist **Often skipped** (Playlists tab) shows every song skipped twice or more. On by default, switch off in Settings > Smart extras.
3. **Right now** (Home and Playlists): remembers the hour of every play (from this version on) and builds a mix of the songs you usually play at the hour you are in (the hours next to it count half). Home shows a short learning note until it has enough, about a few days of listening.
4. **Song duel** (Home): two songs side by side, tap the better one (a small play button previews a song). Every pick updates an Elo rating, like chess. It pairs songs with few duels against songs close to them in rating, using your favorites if you have 8 or more. New smart playlist **Duel champions** shows the top rated.

- **Settings > Sound and library > Smart extras** (new tab): the skip switch and how many songs are kept out, hours learned, duels played, and a button to forget each kind of data.
- All three Home cards are normal Home sections: hide or move them in Settings > Home sections. Fresh installs get them after Forgotten favourites; existing users get them at the bottom.
- Skips, song hours and duel scores are included in backups and merged on restore (the bigger value wins).

### Under the hood
- `Backdrop.kt` (new): `AuroraBackdrop`, the five styles, palettes, `BackdropHueRow`. `Components.kt`: `AuroraBackground` draws the backdrop in Current and the old layers in Legacy. 7 new settings (`backdrop`, `backdrop_palette`, `backdrop_speed`, `backdrop_intensity`, `backdrop_scale`, `backdrop_a`, `backdrop_b`) added to `Settings.kt` and to `lookKeys`.
- `Library.kt`: `skips`, `songHours`, `duel`, `skipAware` in `LibraryData`; `recordSkip`, `recordDuel`, `mergeSmart`, clear functions; `recordPlay` also logs the hour per song; `dailyMix` skips often-skipped songs.
- `Smart.kt` (new): `skipFiltered`, `rightNowMix`, `fitToTime`, `pickDuel`, `duelChampions`. `SmartHome.kt` (new): the three cards. `LabTab.kt` (new): Smart extras tab.
- `PlayerViewModel.kt`: skip detection in `onPositionDiscontinuity`, skip-aware `shuffleAll`, backup of the new data.
- Version 3.6.0 (versionCode 24).

### Notes
- Not compiled here. If the GitHub build fails, send me the first `e:` line. I checked the Fit my time algorithm in a Python copy (lands within about 2 seconds for libraries of 40 songs and up).
- Right now and Skip memory start learning from this version; nothing is known about the past.
- Backdrop colours with a light theme use soft colour blobs instead of glowing light.
- New text is English only for now.

## v23: Look profiles, your song comes back, playlist sort and filter

### Fixed: Aurora now remembers what was playing
Before, closing the app (or Android closing it) threw the queue away, and you had to find the song again. Now Aurora saves the **queue, the song, the spot in the song, shuffle and repeat**, and brings them back the next time you open it. It comes back **paused**, so nothing starts blasting. If music is still playing (you only swiped the app away while it played), it simply carries on and nothing is reloaded.
- Saved when the song or queue changes, on pause, when the app goes to the background, when it closes, and every 4 seconds while playing.
- Songs deleted from the phone are skipped. If the saved song is gone, the queue comes back from its first song.
- An empty queue never overwrites the saved one.

### New: Look profiles (Settings > Look and feel > Look profiles)
- **Save this look**: stores your colours, fonts, layouts, glow, mascot, dock, player and Home cards under a name (up to 20). Make one for night, the car, work.
- **Apply** switches everything in one tap. Anything the profile does not mention goes back to its default, so profiles never leave bits of the previous look behind.
- **Update to my current look**, **Rename**, **Delete** are in each profile's menu.
- **By time of day**: give a profile a time (Set a time), then switch on **Switch automatically**. The profile whose time passed most recently is the one that shows. It is applied once per day at its time, so a look you pick by hand stays until the next time comes round. It checks once a minute while Aurora is open.
- Profiles hold 135 appearance settings only. They never touch what plays (equalizer, speed, crossfade), music folders, sorting, language, your saved colour themes, your name or the icon.
- Profiles are included in backups. Restore adds missing ones and never removes any.

### New: Sort and filter inside playlists
- Open a playlist (or a "Made for you" list like Forgotten favourites) and you get a **search box** and a **Sort and filter** button.
- **Sort by** list order, title, artist, album, length, date added or plays, in either direction. Plays and date added start with the biggest first.
- **Filter**: favorites only, never played, and length (under 3 min, 3 to 6 min, over 6 min).
- A line under the buttons shows how many songs match and what is switched on. **Clear** resets everything.
- It only changes what you see, not the playlist. **Play**, **Shuffle** and tapping a song use the list the way it is shown, so you can search "love", then Shuffle just those songs. Removing a song from the playlist still works while filtered.

### Under the hood
- `PlayerViewModel.kt`: `saveSession` and `restoreSession` (SharedPreferences `last_session`), listener events, the polling loop and `uiVisible`.
- `Settings.kt`: `SettingsStore.captureLook` and `applyLook`, with the `lookKeys` list (135 names, all checked against the real keys).
- `LookProfiles.kt` (new): `ProfileStore` (own DataStore `aurora_profiles`), the schedule and `ProfileAutoEffect` (called from `MainScreen.kt`).
- `ProfilesTab.kt` (new): the tab. `SettingsScreen.kt` got the `PROFILES` tab. Search index regenerated.
- `Library.kt`: `ListSort`, `ListView`, `applyListView`, `listDirectionLabels`. `BrowseScreens.kt`: new `DetailScreen` tools and `ListViewSheet`. `MainScreen.kt` turns them on for playlists and "Made for you" lists.
- Backup: new `profiles` list.
- Version 3.5.0 (versionCode 23).

### Notes
- Not compiled here. If the GitHub build fails, send me the first `e:` line.
- A new look setting added later has to be added to `lookKeys` in `Settings.kt` to be part of profiles.
- The sort and filter you pick in a playlist is not remembered after you leave it.
- New text is English only for now.

## v22: App icons (colours + your own)

### New settings tab: Icons (Settings > Look and feel > Icons)
Two pages, **Presets** and **Make your own**.

**Presets**
- **Colour icons**: 9 real launcher icons: Aurora, Red, Orange, Amber, Green, Teal, Blue, Pink and Mono. Tap one and the Aurora icon on your home screen changes. They are the normal Aurora artwork with its colours turned, so they all look like Aurora. Some launchers take a few seconds, and some briefly hide or move the icon when it switches.
- **Follow my colour**: switch it on and the icon follows your accent colour, picking the closest of the 9 (greys and near-blacks get Mono). Changes are applied 1.5 seconds after you stop moving the colour.
- **My icons**: the icons you made, as tiles. Tap one to add it to the home screen, rename it or delete it.

**Make your own**
- Choose a picture (PNG or JPG). Aurora turns it into a vector on the phone: it shrinks the picture, picks 2 to 8 colours, traces the edge of each colour region and straightens the outlines down to the real corners.
- Sliders and switches: **Colours** (2 to 8), **Remove the background** (clears the colour that fills the edges), **Background colour** (9 swatches) and a **Name**.
- A live preview shows the result and how many shapes it has. **Save to My icons** puts it in Presets.

### Important: what Android allows
Android only lets the real launcher icon come from inside the app, picked when the app is built. So the 9 colour icons switch the real icon, but your own icons cannot. They are added as a **home screen shortcut** that opens Aurora with your icon, and you can remove the original Aurora icon from your home screen yourself. The settings text says so.

### Under the hood
- `AndroidManifest.xml`: the launcher entry moved from `MainActivity` into `activity-alias` entries (`IconAurora` on, 8 colour ones off). Switching turns the new one on first, then the others off, with DONT_KILL_APP.
- New resources: `drawable/ic_launcher_background_<colour>.xml`, `ic_launcher_foreground_<colour>.xml` and `mipmap-anydpi-v26/ic_launcher_<colour>.xml`, made by turning the hue of the original artwork (Mono removes the colour).
- `AppIcons.kt` (new): preset list, `current/apply/nearest`, `pinCustom` (home screen shortcut with an adaptive bitmap), `IconStore` (own DataStore `aurora_icons`: your icons as JSON, plus the follow switch) and `IconAutoEffect`, called from `MainScreen.kt`.
- `IconVector.kt` (new): `VectorIcon`, `IconTracer` (k-means colours, background flood fill, majority smoothing, edge tracing, Douglas-Peucker), JSON, drawing and `VectorIconView`.
- `IconsTab.kt` (new): the tab. `SettingsScreen.kt` got an `ICONS` tab and its place in the list. Search index regenerated (`tools/gen_settings_index.py` now also scans `IconsTab.kt`).
- **Backups include your own icons** (new `icons` list). Restore adds the ones that are missing and never removes any. Up to 30 icons are kept.
- Version 3.4.0 (versionCode 22).

### Notes
- Still not compiled here. If the GitHub build fails, send me the first `e:` line. I tested the outline tracing logic in a Python copy (a disc with a hole and a square gave the right outlines), but not the Android parts.
- New text is English only for now (other languages fall back to English).

## v21: Passport in backups + Forgotten favourites

### New: Forgotten favourites
- Favorites you have not played for 90 days or more, the ones you played most first. A favorite with no play in your history counts too (never played, or played before the history was kept).
- **Home**: new section "Forgotten favourites" with a Shuffle button. It only shows when there is something to show. Hide or move it in Settings > Home sections. Fresh installs get it after the Daily mix.
- **Playlists tab**: a fourth smart playlist, "Forgotten favourites", with Play and Shuffle.
- Tapping it opens the normal song list. The 90 days is `FORGOTTEN_DAYS` in `Library.kt`.

### Backups now include your listening history
- Backup file gets a new `history` block: play counts (songs listed by title, artist and length, like playlists), plays per hour, and the days you listened on. Songs deleted from the phone are skipped.
- Restore matches the songs the same way as playlists, then **merges**: every number keeps the bigger of the current and the backed-up value. Restoring the same backup twice changes nothing and never lowers your streak, badges or counts.
- Streaks, badges, the listening clock and the 12 week calendar all come back. Backups made before this version have no history, and restore still works for them.
- New `extraDays` in `LibraryData` (DataStore key `passport_days`) holds days from a restored backup so the streak can use them. `LibraryStore.mergeHistory` does the merge.
- Backup tab text updated (it used to say history is not included).
- Version 3.3.0 (versionCode 21).

### Notes
- Still not compiled here. If the GitHub build fails, send me the first `e:` line.

## v20: Aurora passport (streaks, badges, listening clock)

### New: Aurora passport (Home)
- **Listening streak**: how many days in a row you played music. If you have not played yet today, the streak stays alive until midnight and the card reminds you. Also shows your best streak and total days listened.
- **Listening clock**: a 24 hour dial (midnight at the top). Each hour gets a bar that grows with how often you press play, and the middle shows your busiest hour.
- **Last 12 weeks**: a calendar grid, darker squares are days with more plays.
- **13 badges** with progress: Warm-up, On fire, Unstoppable (streaks), Night owl, Early bird, Marathoner, Explorer, Century, Devoted, Full day, Collector, Superfan, Regular. Earned badges are lit, locked ones show progress like 7/10.
- It is a normal Home section: hide, show or move it in Settings > Home sections ("Aurora passport"). Existing users get it at the bottom of Home.

### Under the hood
- `Library.kt`: new `listenLog` (plays per day and hour, kept about 2 years) saved in its own DataStore key `listen_hours`. `recordPlay` fills it.
- Streaks and calendar also read the old play log, so your history before this update still counts. Hours are only known for plays made after this update, so the clock and the Night owl / Early bird badges start empty.
- New file `Passport.kt`. `HomeSection` got a `PASSPORT` entry (`Settings.kt`) and `HomeScreen.kt` shows it.
- Not in backups yet (backups never included play history).
- Version 3.2.0 (versionCode 20).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.

## Earlier (v16 to v19)
- v19: seek buddy also rides the Orbit ring.
- v18: Fun extras (seek buddy, song stickers, song story line, shake actions, flip to pause).
- v17: synced lyrics, per-output EQ, swipe actions, resume long tracks, "On this day", Slim and Mini widgets.
- v16: Player styles gallery, crossfade, volume levelling.

## Song editor + battery pass

### New: song editor
- "Edit song info" in every song menu (song lists, Now Playing, playlists, albums, search).
- Change title, artist, album and cover art (picked with the system photo picker, no permission needed).
- "Use original cover" and "Restore original" undo your changes.
- Edits are stored inside Aurora and laid over the song everywhere: lists, queue, notification, lock screen, widget.
  Your audio files are never modified. Editing an artist regroups the song under that artist.
- Covers are shrunk to max 1200 px and kept in the app's private `covers` folder; deleted with the song.

### Battery
- Position tracking only runs while music is actually playing (it used to tick forever, even when paused).
- In the background the player is checked every 5 s instead of every 2 s, and wakes instantly when you open the app.
- Glow/ambient animation clock now stops fully when the app is off screen (it kept ticking while music played with the screen off).
- Audio offload: the phone's audio chip decodes the music so the CPU can sleep. Turns itself off while speed/pitch,
  skip silence, equalizer, bass or loudness are in use. Unsupported phones fall back to normal playback.
- "Balanced" power profile is cheaper: glow 15 -> 10 fps, spinning/mascot 25 -> 20 fps.

### Build
- Google's Maven Central mirror added ahead of Maven Central, plus longer timeouts and retries (fixes the "Could not find ... .jar" CI failure).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.
- No app can promise a fixed "5%" battery figure: it depends on the phone, screen time and settings. Settings -> Power profile -> Efficient saves the most.

## Player styles + crossfade + volume levelling

### New: Player styles (Settings > Player)
- A gallery of five styles with small previews: Orbit, Classic, Vinyl, Waves, Compact.
- Tapping a style applies a bundle of the existing player settings (design, layout, cover shape, progress style, play button style),
  so everything can still be fine-tuned afterwards. The selected style is outlined; "Custom" shows when you changed things yourself.

### New: Transitions and volume (Settings > Audio)
- Crossfade 0 to 12 seconds: each song fades out at its end and the next fades in (songs do not overlap).
- Volume levelling Off / Light / Strong: a gentle compressor and limiter that evens out loud and quiet parts.
  Needs Android 9+, and turns audio offload off while it is on (a little more battery).

### Notes
- Not compiled here. If the GitHub build fails, the first `e:` line tells where.
- Sleep-timer fade and crossfade both change the volume; use one of them at a time if you hear odd volume jumps.

## Lyrics, per-device EQ, swipe actions, resume, On this day, more widgets

### Synced lyrics (Now Playing > notes button, both player designs)
- Reads lyrics saved inside MP3 files (ID3 USLT), a `.lrc` file next to the song (only where Android allows it),
  or an `.lrc` / `.txt` file you add yourself with "Add lyrics file" (kept inside Aurora, per song).
- Synced lines follow the music and highlight; tap a line to jump there. Size button (3 sizes) and Centre/Left.
- Not supported yet: lyrics saved inside FLAC/M4A tags and word-by-word highlighting.

### Separate EQ per output (Settings > Audio > Equalizer)
- Remembers the equalizer for phone speaker, wired headphones and Bluetooth, and switches when the output changes.
- Switches while Aurora is open (it is checked when the output changes and when the app starts).

### Swipe actions (Settings > Interface > Song rows)
- Pick what swiping a song right or left does: Nothing, Play next, Add to queue, Favorite. Off by default.

### Resume long tracks (Settings > Audio > Playback)
- Songs of 20+ minutes remember where you stopped and continue from there when you play them again.

### On this day (Home)
- New Home section with songs you played on today's date in earlier years. History starts with this version, so it fills up over time.
  Show, hide or move it in Settings > Home.

### Widgets
- Two new styles: Slim (extra thin bar) and Mini (small cover, title, one play button). Also selectable inside existing widgets.

### Notes
- Version code 17. Not compiled here; if the GitHub build fails send the first `e:` line.

## Fun extras (new, not in other players)

Settings > Player > Fun extras

- **Seek buddy**: pick an emoji friend (rocket, turtle, fox, moon, UFO, cat, frog, note) that rides along the progress bar.
- **Song stickers**: song menu > Set sticker. One emoji per song, shown next to the title in lists.
  Home gets a **Mood mixes** row (show/hide/move it in Settings > Home): tap an emoji to shuffle every song with that sticker.
- **Song story**: a fun fact under the title on Now Playing (play count, rank, playlists, first listen, how long ago it was added...).
  Tap it for the next fact. Works in both Orbit and Panel designs. Can be switched off.
- **Shake your phone**: shake to play next, previous, or toggle shuffle (Gentle / Normal / Hard strength).
- **Flip to pause**: put the phone face down to pause, turn it face up to continue.
  Gestures use the motion sensor only while music plays and a gesture is switched on.

Version code 18. Not compiled here; if the GitHub build fails send the first `e:` line.

## Seek buddy in the Orbit player
- The seek buddy now rides around the progress ring of the Orbit player (it takes the place of the round handle and grows while you drag).
- Version code 19.
