# Changelog

## v21: Passport in backups + Forgotten favourites

### New: Forgotten favourites
- Favorites you have not played for 90 days or more, the ones you played most first. A favorite with no play in your history counts too (never played, or played before the history was kept).
- **Home**: new section "Forgotten favourites" with a Shuffle button. It only shows when there is something to show. Hide or move it in Settings > Home sections. Fresh installs get it after the Daily mix.
- **Playlists tab**: a fourth smart playlist, "Forgotten favourites", with Play and Shuffle.
- Tapping it opens the normal song list. The 90 days is `FORGOTTEN_DAYS` in `Library.kt`.

### Backups now include your listening history
- Backup file gets a new `history` block: play counts (songs listed by title, artist and length, like playlists), plays per hour, and the days you listened on. Songs deleted from the phone are skipped.
- Restore matches the songs the same way as playlists, then **merges**: every number keeps the bigger of the current and the backed-up value. Restoring the same backup twice changes nothing and never lowers your streak, badges or counts.
- Streaks, badges, the listening clock and the 12 week calendar all come back. Backups made before this version have no history, and restore still works for them.
- New `extraDays` in `LibraryData` (DataStore key `passport_days`) holds days from a restored backup so the streak can use them. `LibraryStore.mergeHistory` does the merge.
- Backup tab text updated (it used to say history is not included).
- Version 3.3.0 (versionCode 21).

### Notes
- Still not compiled here. If the GitHub build fails, send me the first `e:` line.

## v20: Aurora passport (streaks, badges, listening clock)

### New: Aurora passport (Home)
- **Listening streak**: how many days in a row you played music. If you have not played yet today, the streak stays alive until midnight and the card reminds you. Also shows your best streak and total days listened.
- **Listening clock**: a 24 hour dial (midnight at the top). Each hour gets a bar that grows with how often you press play, and the middle shows your busiest hour.
- **Last 12 weeks**: a calendar grid, darker squares are days with more plays.
- **13 badges** with progress: Warm-up, On fire, Unstoppable (streaks), Night owl, Early bird, Marathoner, Explorer, Century, Devoted, Full day, Collector, Superfan, Regular. Earned badges are lit, locked ones show progress like 7/10.
- It is a normal Home section: hide, show or move it in Settings > Home sections ("Aurora passport"). Existing users get it at the bottom of Home.

### Under the hood
- `Library.kt`: new `listenLog` (plays per day and hour, kept about 2 years) saved in its own DataStore key `listen_hours`. `recordPlay` fills it.
- Streaks and calendar also read the old play log, so your history before this update still counts. Hours are only known for plays made after this update, so the clock and the Night owl / Early bird badges start empty.
- New file `Passport.kt`. `HomeSection` got a `PASSPORT` entry (`Settings.kt`) and `HomeScreen.kt` shows it.
- Not in backups yet (backups never included play history).
- Version 3.2.0 (versionCode 20).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.

## Earlier (v16 to v19)
- v19: seek buddy also rides the Orbit ring.
- v18: Fun extras (seek buddy, song stickers, song story line, shake actions, flip to pause).
- v17: synced lyrics, per-output EQ, swipe actions, resume long tracks, "On this day", Slim and Mini widgets.
- v16: Player styles gallery, crossfade, volume levelling.

## Song editor + battery pass

### New: song editor
- "Edit song info" in every song menu (song lists, Now Playing, playlists, albums, search).
- Change title, artist, album and cover art (picked with the system photo picker, no permission needed).
- "Use original cover" and "Restore original" undo your changes.
- Edits are stored inside Aurora and laid over the song everywhere: lists, queue, notification, lock screen, widget.
  Your audio files are never modified. Editing an artist regroups the song under that artist.
- Covers are shrunk to max 1200 px and kept in the app's private `covers` folder; deleted with the song.

### Battery
- Position tracking only runs while music is actually playing (it used to tick forever, even when paused).
- In the background the player is checked every 5 s instead of every 2 s, and wakes instantly when you open the app.
- Glow/ambient animation clock now stops fully when the app is off screen (it kept ticking while music played with the screen off).
- Audio offload: the phone's audio chip decodes the music so the CPU can sleep. Turns itself off while speed/pitch,
  skip silence, equalizer, bass or loudness are in use. Unsupported phones fall back to normal playback.
- "Balanced" power profile is cheaper: glow 15 -> 10 fps, spinning/mascot 25 -> 20 fps.

### Build
- Google's Maven Central mirror added ahead of Maven Central, plus longer timeouts and retries (fixes the "Could not find ... .jar" CI failure).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.
- No app can promise a fixed "5%" battery figure: it depends on the phone, screen time and settings. Settings -> Power profile -> Efficient saves the most.

## Player styles + crossfade + volume levelling

### New: Player styles (Settings > Player)
- A gallery of five styles with small previews: Orbit, Classic, Vinyl, Waves, Compact.
- Tapping a style applies a bundle of the existing player settings (design, layout, cover shape, progress style, play button style),
  so everything can still be fine-tuned afterwards. The selected style is outlined; "Custom" shows when you changed things yourself.

### New: Transitions and volume (Settings > Audio)
- Crossfade 0 to 12 seconds: each song fades out at its end and the next fades in (songs do not overlap).
- Volume levelling Off / Light / Strong: a gentle compressor and limiter that evens out loud and quiet parts.
  Needs Android 9+, and turns audio offload off while it is on (a little more battery).

### Notes
- Not compiled here. If the GitHub build fails, the first `e:` line tells where.
- Sleep-timer fade and crossfade both change the volume; use one of them at a time if you hear odd volume jumps.

## Lyrics, per-device EQ, swipe actions, resume, On this day, more widgets

### Synced lyrics (Now Playing > notes button, both player designs)
- Reads lyrics saved inside MP3 files (ID3 USLT), a `.lrc` file next to the song (only where Android allows it),
  or an `.lrc` / `.txt` file you add yourself with "Add lyrics file" (kept inside Aurora, per song).
- Synced lines follow the music and highlight; tap a line to jump there. Size button (3 sizes) and Centre/Left.
- Not supported yet: lyrics saved inside FLAC/M4A tags and word-by-word highlighting.

### Separate EQ per output (Settings > Audio > Equalizer)
- Remembers the equalizer for phone speaker, wired headphones and Bluetooth, and switches when the output changes.
- Switches while Aurora is open (it is checked when the output changes and when the app starts).

### Swipe actions (Settings > Interface > Song rows)
- Pick what swiping a song right or left does: Nothing, Play next, Add to queue, Favorite. Off by default.

### Resume long tracks (Settings > Audio > Playback)
- Songs of 20+ minutes remember where you stopped and continue from there when you play them again.

### On this day (Home)
- New Home section with songs you played on today's date in earlier years. History starts with this version, so it fills up over time.
  Show, hide or move it in Settings > Home.

### Widgets
- Two new styles: Slim (extra thin bar) and Mini (small cover, title, one play button). Also selectable inside existing widgets.

### Notes
- Version code 17. Not compiled here; if the GitHub build fails send the first `e:` line.

## Fun extras (new, not in other players)

Settings > Player > Fun extras

- **Seek buddy**: pick an emoji friend (rocket, turtle, fox, moon, UFO, cat, frog, note) that rides along the progress bar.
- **Song stickers**: song menu > Set sticker. One emoji per song, shown next to the title in lists.
  Home gets a **Mood mixes** row (show/hide/move it in Settings > Home): tap an emoji to shuffle every song with that sticker.
- **Song story**: a fun fact under the title on Now Playing (play count, rank, playlists, first listen, how long ago it was added...).
  Tap it for the next fact. Works in both Orbit and Panel designs. Can be switched off.
- **Shake your phone**: shake to play next, previous, or toggle shuffle (Gentle / Normal / Hard strength).
- **Flip to pause**: put the phone face down to pause, turn it face up to continue.
  Gestures use the motion sensor only while music plays and a gesture is switched on.

Version code 18. Not compiled here; if the GitHub build fails send the first `e:` line.

## Seek buddy in the Orbit player
- The seek buddy now rides around the progress ring of the Orbit player (it takes the place of the round handle and grows while you drag).
- Version code 19.
