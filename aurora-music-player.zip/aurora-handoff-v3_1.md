# Aurora handoff: v3.1.0 delivered (previous build: v3.0.0)


This file summarizes the whole chat and the exact state of the delivered v3.0.0 project (`aurora-music-player.zip`), so a new session can continue without the history.

## v3.1.0 (this delivery, on top of v3.0.0)
User asked for: (1) outline on the selected pill of the floating pill dock, (2) fix Interface size > 100% overlapping/hiding the Orbit player buttons (Repeat hidden), (3) a new Radial dock (one corner button, tapped = radial menu of the tabs; mini player beside it, shrinks while open, returns when closed) with cool animations, (4) a few practical customizable features of my choice.
- **Radial dock** (`RadialDock.kt`, new): `DockStyle.RADIAL`, `RadialSide` (LEFT, RIGHT), `radialScale` (button size 80 to 130%). `RadialDock(tab, open, onOpenChange, onSelect, hideButton, mini)` draws, inside a `BoxWithConstraints`: `RadialScrim` (dim, glow bloom, self-drawing arc, tap outside closes), one `RadialItem` per dock tab (offset and graphicsLayer read an `Animatable` per tab in the layout/draw phase, so nothing recomposes per frame; staggered spring with overshoot and a small spin; optional name pills under each button via `navLabels`) and `RadialRow` (corner button + mini player; a `gap` spring widens while open so the mini player gets shorter). `fanFor()` sizes the arc: as big as needed to separate the tabs but leaving about 120 dp for the mini player; on narrow screens (for example Interface size 120%) the tab buttons shrink.
  - `MainScreen.kt`: `radial = modern && dockStyle == RADIAL`; the old bottom `Column` (mini player + dock) is the `else` branch. Radial adds no mini-player height to `contentPadding`. `radialOpen` (saveable) closes on back, when an overlay opens, or when Radial is switched off. `hideBars` slides the corner button away (the mini player takes its space).
  - `ModernMiniPlayer(..., narrow = true)` shows only cover and a smaller play ring (no text, no skip).
- **Pill outline:** setting `pillOutline` (default on). `PillItem` fades in a 2 dp border in the nav colour around the selected pill; the radial selected tab and corner button use it too.
- **Interface size fix:** `OrbitControls` is now a `BoxWithConstraints` that computes a `fit` factor (0.5 to 1) from the available width and scales every button (toggles, skips, play and its icon) with it. `OrbitToggle` and `OrbitPlay` take explicit sizes.
- **Tabs in the dock:** `dockHidden` set; `AppSettings.dockTabs()` (at least two stay). Used by `ModernDock`, `DockBody` (marker index now uses `tabs.indexOf(tab)`) and `RadialDock`. Settings > Interface > Tabs in the dock.
- **Sleep timer "End of song":** `PlayerViewModel.sleepAtSongEnd()` and `sleepEndOfSong`; the controller listener pauses on the next AUTO or REPEAT media item transition and seeks to 0; cleared on queue end and by any other timer.
- **Save queue as playlist:** button in the queue sheet (`QueueSheet` in `NowPlayingScreen.kt`) creates "Queue <date>" with the queue's songs.
- Translations: 15 rows added to `tools/translations2.txt` (Radial, Left, Right, Corner, the radial blurb, dock tab texts, sleep and queue texts); `Translations2.kt` and `SettingsIndex.kt` were regenerated. About page says 3.1.0, versionCode 15.
- **Not compiled yet** (as with 2.7 to 3.0). Things to check first: `RadialDock.kt` (`Dp` helpers `coerceAtLeast`, `minOf` on `Dp`, `Animatable<Float, *>` parameter, `drawArc` named arguments, `wrapContentWidth(unbounded = true)`), the `else Column` and the `RadialDock { slot, narrow -> ... }` trailing lambda in `MainScreen.kt`, `ModernMiniPlayer(... narrow = narrow) { }` call, `OrbitControls` Dp arithmetic. Ask for the `e: file` lines.
- Ideas not done: dock tab order, long-press the corner button to open the player, per-tab icons.

## Chat summary, in order
1. **v2.8 (first request in this chat).** The user uploaded a v2.7 handoff and project zip and asked for: more widget types including one with Lumi, more Lumi customization, a massive UI overhaul that keeps every feature, and a Settings switch between the new UI ("Current") and the old one ("Legacy"). Delivered: Current/Legacy interface (`UiVersion`), `ModernUi.kt`, a Lumi rewrite with many options and a shared `drawLumi` renderer, four new widget types (Lumi, Lumi pal, Square, Vinyl), Settings > Interface tab.
2. **v2.9.** The user asked for a completely different Current look, a completely different Now Playing, neat animations and grow effects on interaction, customizable glow, and new features of my choice. Delivered: the glow system (`Glow.kt`, Settings > Glow), touch effects (squish, grow, grow and glow), a large-title header, a dock with a sliding marker, a mini player with swipe-to-skip, and the **Orbit player** (round spinning cover inside a draggable progress ring, double tap to jump 10 s, hold to favorite, speed chip).
3. **Screenshot feedback.** The user sent four screenshots and asked to fix: the play button glow not following its shape or icon (cause: a drop shadow showing through the outlined style), the Home Shuffle button being squashed into a vertical strip, the dock marker and icons colliding and poking through the dock edge, a revamped pill dock, the mini player progress ring following the play button shape, and Legacy-only settings being locked in Current. Delivered as v2.9.1 together with the battery work below.
4. **Battery.** The user said the app used about 25% battery and asked for extreme optimization without losing quality. Delivered in v2.9.1: `Ambient.kt` (power profiles Efficient, Balanced, Smooth; "keep animating while paused"; follow Android battery saver), a throttled clock for every decorative animation, nothing animating while nothing plays, the equalizer bars no longer animating forever, slower position polling in the background, packaging excludes. The user could not be given a measured saving; the sandbox cannot run the app.
5. **v3.0.0 request (done in this delivery).** The user asked for: (a) new customization features not in the app yet, (b) a revamp of playlists with more customization, (c) the pill dock with two modes (joined to the phone border, and floating with each tab separate), (d) a cleaned-up Settings with a search bar, (e) every new string from this update and the last one translated into all supported languages, (f) optimization of every feature. The first session ran out of room and handed over a WIP zip; the second session finished everything below.

The user said they are proud of the app, wants friendly fun UI, lots of customization, smooth animations, short clear mobile-friendly explanations, and good performance on low-end phones.

## What v3.0.0 delivered (all items of the request are done)

### Settings home, search and a new Playlists section (`SettingsScreen.kt`, `SettingsSearch.kt`, `SettingsIndex.kt`)
- `SettingsTab` is now `internal enum class SettingsTab(label, icon, blurb)` with 18 entries (added PLAYLISTS). `settingsGroups` lists the home order: Look and feel, Screens, Sound and library, App.
- `SettingsPage` keeps `section` (-1 = home) and `query` in `rememberSaveable`. The page title, the header back arrow and the system back all go section -> home -> close, through the `onBack` passed to `OverlayPage` (no extra `BackHandler`).
- Search (`searchSettings` in `SettingsSearch.kt`): every word must appear in the English and the translated text of the title, card, section name and keywords, with accents and case ignored (`foldText`). Best matches first, 40 results at most.
- Tapping a result opens the section and sets `LocalSettingsFocus` to the card title. `SettingCard` waits 380 ms, calls `BringIntoViewRequester.bringIntoView()`, flashes a 2 dp primary border and clears the focus after about 2.3 s.
- `SettingsIndex.kt` is **generated**: `python3 tools/gen_settings_index.py`. It reads `SettingCard("..")`, `ToggleRow("..")`, `SliderRow("..")` and `Text("..", style = ...labelLarge)` titles inside each `XTab` function (titles with `$` are skipped). Synonyms live in `TAB_KEYWORDS` and `KEYWORDS` inside the script. **Run it again after any change to a settings screen.**
- New `PlaylistsTab`: layout, card size (grid only), order, song count, notes, smart playlists row.

### Settings that were added without UI in the WIP are now applied
- `uiScale`: `Theme.kt` multiplies the density by it (chips 85, 92, 100, 110, 120%, Interface tab > Size). Chips instead of a slider because a slider would rescale itself under the finger. `textScale` already existed since an earlier version (it was declared twice in the WIP, which would not compile; the copy is removed).
- `hideBars` (OFF, DOCK, HEADER, BOTH): a `NestedScrollConnection` on the haze-source box in `Root` (`MainScreen.kt`); the header and the dock are in `AnimatedVisibility`. It resets when the tab, the detail page or the setting changes, and the header stays while songs are selected.
- `marqueeTitles`: `Modifier.titleMarquee(on)` in `Extras.kt` on the mini players (both UIs) and the Orbit title.
- `sleepFade`: chips Off, 10, 20, 30 s in Player > Sleep timer (the VM already ramps the volume).
- `rowDensity` was **dropped**: it duplicated the existing `ListDensity` (`density`: Compact, Comfortable, Spacious), which already drives `SongRow`.
- The Interface tab now describes the four Pill/Bar x Attached/Floating dock combinations.

### Translations (`tools/translations2.txt` -> `Translations2.kt`)
- Source of truth: `tools/translations2.txt`, rows `English|pl|es|fr|de|pt|it|tr|ru|ja|zh` (`#` = a number, no `|` inside). `python3 tools/gen_translations.py` writes `Translations2.kt` (`TABLE_X1..` plus `EXTRA_TABLES`, each constant under 24 KB because of the 64 KB Kotlin string limit), skips keys already in `Translations.kt`, and writes `tools/missing_translations.txt` (UI strings in the code that still have no row). `Translations.table` loads `TABLE_1..4 + EXTRA_TABLES`.
- About 420 rows: tab names and subtitles, all card and row texts, enum labels, motion sets, design styles, Lumi options, widget configuration, playlist screen, theme names, Orbit label, restore messages.
- Left in English on purpose: Aurora, Lumi, Design, Layout, Startup and Backup (the tour refers to these tab names), file formats, Hz values, widget class names. Not translatable as written: the "Added N to NAME" toast and the " copy" suffix of a duplicated playlist.

### Optimization
- Songs list: `contentType`, remembered summary line. Playlist grids: `contentType`. Earlier in the WIP: playlist order and per-card song lists are remembered. Everything else already had keys and remembered derived lists; `Art` uses Coil's size-to-constraints, nothing to change.

### Tools (project root `tools/`)
- `gen_settings_index.py`, `gen_translations.py`, `check_structure.py` (bracket balance, duplicate imports; its "duplicate top-level Modifier/DrawScope/AppSettings/ColorSource" lines and the unbalanced `()` in Music.kt and SettingsScreen.kt, and `{}` in SettingsScreen.kt, are known false positives from string templates; the same offsets existed before this work).

### Things to check when it is first built (nothing of v2.7 to v3.0 has been compiled yet)
- `SettingsScreen.kt`: `OutlinedTextField` and `BringIntoViewRequester` imports, `tr(...)` used inside `forEach` (inline, should be fine), `animateContentSize`-free `AnimatedContent` over `section`.
- `MainScreen.kt`: the header and dock are now inside `AnimatedVisibility`; the legacy top bar lost its own `align` (the wrapper aligns it). `ModernHeader` and `AuroraTopBar` take the same arguments as before.
- `Extras.kt`: `titleMarquee` uses `basicMarquee(iterations, initialDelayMillis, velocity)`; if the Compose version in use names a parameter differently, drop `velocity`.
- `PlaylistsScreen.kt` (rewritten in the WIP): unused or missing icon imports (`ViewAgenda`, `GridView`, `ViewList`, `SwapVert`, `PushPin`, `ContentCopy`). `ModernDock` has an early `return` in the floating Pill branch and `PillItem` has a new `separate` parameter.
- Exhaustive `when` over the changed enums (`PlaylistSort`, `PlaylistFeel`, `HideBars`) was checked by reading: all exhaustive.

## The project
- **Aurora** is an Android-only native music player. Kotlin, Jetpack Compose, Media3 (ExoPlayer, MediaSession) 1.5.1, DataStore for settings.
- Compose BOM 2025.05.00. Package and applicationId: `com.aurora.player`. minSdk 26.
- It is delivered as a single project zip (the build needs the name `aurora-music-player.zip`), with the project files at the zip root (`app/`, `build.gradle.kts`, `README.md`, ...).
- The user is on a **Redmi Note 14 Pro+ with HyperOS** (Hyper Island media controls). They use the app on a phone and send screenshots of build logs.

## How the user builds it
- GitHub Actions workflow in their repo. Steps: checkout, unzip `aurora-music-player.zip` into `project/`, setup-java, setup-gradle, build debug APK, upload artifact, release with `softprops/action-gh-release@v2`.
- The unzip step needs the file name **all lowercase** (`aurora-music-player.zip`). A capital A caused a failed run earlier.
- Open warning (harmless for now): actions still target Node.js 20 (`checkout@v4`, `setup-java@v4`, `upload-artifact@v4`, `setup-gradle@v4`, `action-gh-release@v2`). Newer versions of those actions would remove it.
- The sandbox I work in has **no Kotlin compiler or Gradle**. Only structural checks are possible (bracket balance, duplicate imports, duplicate functions). Always ask the user for the `e: file` lines of a failed build.

## Build status
- v2.5 and v2.6.0 were built and run by the user. They confirmed the Hyper Island seek bar problem was fixed in v2.6.0.
- **v2.7.0 through v3.1.0 have not been built yet.** v2.8.0 and v2.9.0 are large changes (new UI layer, Lumi rewrite, four widget types, glow system, Orbit player) written without a compiler. Expect possible compile errors, especially in `Mascot.kt`, `ModernUi.kt`, `Glow.kt`, `NowPlayingOrbit.kt`, `Controls.kt` (`pressScale`), `Components.kt` (`sleekFinish`), `Widget.kt` and `WidgetConfigActivity.kt`. Ask for the `e: file` lines.

## What each version added

### v2.4
- Seek bar studio: Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars, Steps. Thumb shape, thickness, colour or gradient, wave height and length, time-left toggle.
- Design styles beyond Material You (Soft, Outlined, Neo-brutal, Glossy), navigation bar styles (Split pills, One bar, Classic), button shapes.
- Cover colours, greeting with the user's name, performance mode (Auto, Full, Lite).
- Tour after setup, bouncy intro, springy pop-in animation.

### v2.5
- Icon reverted to the original dark night-sky design.
- Tour became an overlay on the real tabs, guided by **Lumi**, a cat made of northern lights (drawn in Canvas).
- Fixed the greeting name field where the cursor jumped before each letter (local text state).
- Nine design styles (added Neon, Candy, Paper, Terminal), border thickness slider, eight more colour themes, background patterns, Squircle and Cookie cover shapes, cursive font.

### v2.6
- **Bug fix:** tapping the media notification (lock screen) opened Mi Music. Cause: no session activity. Fixed with `setSessionActivity` in `PlaybackService`, plus `MainActivity` handling `onNewIntent` and an "open full player" request.
- Home screen widget: three layouts (Classic, Compact, Cover), per-widget options in `WidgetConfigActivity`.
- Lumi customization: seven palettes, hats, eyewear, headphones, scarf, blush, name, size.
- Layout tab: song rows, mini player, Now Playing toggles, colours for play button and selected tab.
- Four more animation presets (Jelly, Pop, Glide, Dreamy) and page transitions (Slide, Fade, Zoom, Rise).

### v2.7
- Lumi moods fade smoothly: asleep (no song), drowsy (paused), awake (playing). Floating notes while listening. She reacts to touch (hop, squish, wiggle, happy eyes, hearts, vibration).
- Now Playing morphs out of the mini player using Compose shared-element transitions (`SharedTransitionLayout`, `sharedBounds`, key `"player"`).
- Player controls are very customizable (Settings > Layout): arrangement, button size, play button width, spacing, which buttons show, title size and alignment, "Now Playing" heading toggle.
- Play button: seven shapes (Morph, Circle, Squircle, Soft, Square, Sharp, Leaf), four styles (Solid, Soft, Outline, Gradient), colour source, glow, icon size.
- Widget buttons copy the player's buttons (colours, shapes, play style), with a "Minimal" alternative.
- Tour translated into all ten languages and shows a picture of the player for player-related steps.

### v3.0.0 (current)
- Settings home with search, Playlists settings, playlist revamp (pin, duplicate, notes, emoji, stack, second colour, sort, Lift feel, Pill shape), Attached and Floating pill dock, interface size, hide bars while scrolling, scrolling titles, sleep timer fade, ten-language translations of everything new. Details in the section above.

### v2.9.1
- **Battery work** (`Ambient.kt`): `PowerProfile` (EFFICIENT, BALANCED, SMOOTH; setting `powerProfile`, default BALANCED), `ambientWhenPaused` (default false), `autoSaver` (default true). `rememberThrottledClock(running, fps)` is a delay-based clock that does not tick while not running; glow pulse and colour cycle (`rememberGlowState(seed, playing)`), `GlowOrbs`, equalizer bars use it. `AppSettings.ambientMoving(playing, paused)` decides whether decorative animations move. `LocalIsPlaying` is provided in `Root`. `AuroraGlowLayer` and `SquiggleLayer` also rest when nothing plays. Spin (`NowPlayingOrbit`, vinyl in `NowPlayingScreen`) and seek wave add `delay(spinFrameMs())` after each frame. Lumi runs at `mascotFrameMs()` while awake and holds still when asleep or dozing. `AuroraApp` runs settings through `.withPower(rememberPowerSaveMode())`. `PlayerViewModel.uiVisible` (set from a lifecycle observer in `Root`) slows the 400 ms position poll to 2 s in the background. `EqualizerBars` used to run three infinite transitions forever, even when paused.
- **Play button:** `rememberPlayCorners(playing)` returns `PlayCorners` shared by `PlayPauseButton`, the Orbit burst ring and the mini player's `ShapeProgress` (a hand-built rounded-rect `Path` from the top middle, measured with `PathMeasure`). In Current, `PlayPauseButton` uses `Modifier.glow(shape)` instead of `shadow` (the shadow showed through the outlined style) plus a radial halo behind the icon; `showGlow = false` for the mini player.
- **Dock:** `ModernDockHeight` is 68 dp. LINE marker is a 24 dp bar on the top edge with a radial cone of light below it that fades before the icon; the label size ignores font scale (`dockLabelSp`). PILL is rebuilt: `PillItem` widens with an animated weight and shows the tab name inside the capsule.
- **Settings:** `SettingCard(title, disabledReason, content)` and `Dimmed(disabled) { }` dim and lock controls. Legacy-only: navigation bar style (locked in Current). Orbit-only locks: seek bar tab, player arrangement, play button width, space between, centre title, skip arrows, cover shape, artwork edge softness. New Battery tab. `packaging.resources.excludes` in `app/build.gradle.kts`.

### v2.9
- **Glow system** (`Glow.kt`): `rememberGlowState(seed)` in `Root` provides `LocalGlow` (colour as a lambda and a pulse `State`, both only read while drawing, so a colour cycle or pulse never recomposes). `Modifier.glow(shape, enabled, boost)` draws stacked outline strokes behind an element (put it before clip/background). `Modifier.cardGlow(shape)` is the softer one for cards. `GlowOrbs()` is called from `AuroraBackground`. Settings: `glowOn/Strength/Size/Tint/Pulse/Orbs` plus per-place switches `glowDock/Mini/Cards/Playing/Buttons/Art`. Lite mode turns off pulse, orbs and card glow. Only the Current UI glows.
- **Touch effects:** `pressScale` (`Controls.kt`) reads `touchFx` (SQUISH, GROW, GLOW, OFF) and `touchGrow` in Current; Legacy always squishes. GROW uses an underdamped spring, GLOW adds a radial halo drawn behind. `SongRow` now uses `pressScale` and glows when playing (Current only).
- **Current look:** `HeaderStyle.LARGE` (default) with `modernHeaderHeight(settings)`; `ModernDock` has a sliding marker (`DockIndicator.LINE` or `PILL`) with spring overshoot; `ModernMiniPlayer` glows and swipes sideways to skip (`miniSwipe`, thresholds 140 px); Home hero has Play all and Shuffle.
- **Orbit player** (`NowPlayingOrbit.kt`, used when Current and `npDesign == ORBIT`, otherwise the v2.8 panel or the legacy layout): `OrbitDisc` (round cover, spin with `orbitSpin`, double tap left/right for plus or minus 10 s, long press favorites, `orbitGestures`), `OrbitRing` (drag or tap to seek, `RingStyle` SOLID, GRADIENT or DOTS, thickness `orbitRing`), `OrbitTimes` (shows the preview time while dragging), `OrbitControls`, `OrbitPlay` (glow burst on play or pause), `OrbitChips` (favorite, queue, sleep, sound, playback speed chip cycling 0.75, 1, 1.25, 1.5, 2). It honours `npShowShuffle/Repeat/Skip/Fav` and `npTitleScale` and `npButtonScale`.
- **Settings:** new Glow tab (preview, glow options, per-place switches, touch effect); Interface tab gained Player (design and Orbit options), dock marker, mini player swipe, and the three header styles.

### v2.8
- **Current / Legacy interface** (`UiVersion` in `Settings.kt`, default CURRENT, switch in Settings > Interface, the first settings tab). Legacy is the untouched v2.7 code path. Current is a layer on top of the same features:
  - `ModernUi.kt`: `ModernHeader` (frosted full-width bar or clean fade, `HeaderStyle`), `ModernDock` (one slim dock, floating or attached, `DockStyle`), `ModernMiniPlayer` (capsule with a progress ring), `ModernHomeHero` (Home card).
  - `Components.kt`: `finish` and `cardFinish` call `sleekFinish` when the design is Material You and the UI is Current (hairline edge, tonal fill, same glass blur for bars). `OverlayPage` (settings and other overlays) uses `ModernHeader` in Current.
  - `MainScreen.kt`: `AuroraApp` bumps `corner` by 20% in Current (the Settings sliders still show the stored value because `SettingsPage` gets `rawSettings`). `Root` branches on `modern` for content padding, header, mini player and navigation. `homeHero` and `npPanel` toggles control the Home card and the player panel (`NowPlayingScreen.kt`, portrait only).
  - `NavStyle` and the legacy nav pills are only used in Legacy.
- **Lumi rewrite** (`Mascot.kt`): drawing moved to `DrawScope.drawLumi(...)` so the app and the widgets share it. `MascotLook` gained ears, eyes, tail, neck, mark, wings, sparkles, hue (below 0 means use the palette), glow, flow. Settings also has `mascotNotes`, `mascotTouch`, `mascotSpeed`. `renderLumiBitmap(px, look, mood, notes)` draws her off-screen with `CanvasDrawScope` for widgets (mood 0 asleep, 1 drowsy, 2 awake).
- **Widgets:** layouts 3 Lumi, 4 Lumi pal, 5 Square, 6 Vinyl (`widget_lumi.xml`, `widget_lumi_pal.xml`, `widget_square.xml`, `widget_vinyl.xml`). They share the id set of the old layouts, plus `w_lumi`. Each also has its own picker entry: `AuroraLumiWidget`, `AuroraLumiPalWidget`, `AuroraSquareWidget`, `AuroraVinylWidget` are empty subclasses of the now `open` `AuroraWidget`, with providers in `res/xml/aurora_widget_*_info.xml` and receivers in the manifest. `WidgetRender.defaultLayout` picks the starting layout from the provider class. `WidgetState.saveLumi/lumi/lumiNotes` store her look as one `|` separated string, written from `Root`. `AuroraWidget.refreshAll` loops over all five provider classes.

## Code map (`app/src/main/java/com/aurora/player/`)
- New since v2.8: `ModernUi.kt` (Current UI: header, dock, mini player, Home card), `Glow.kt` (glow system), `NowPlayingOrbit.kt` (Orbit player), `Ambient.kt` (power profile, throttled clock, power-save receiver).
- `MainActivity.kt`, `MainScreen.kt` (app flow, `Root`, mini player), `PlayerViewModel.kt`, `PlaybackService.kt` (Media3 session, widget hooks).
- `Settings.kt` (all enums, `AppSettings`, DataStore keys, read and write), `SettingsScreen.kt` (all tabs and shared widgets such as `SettingCard`, `SliderRow`, `ToggleRow`, `ChipPicker`).
- `Controls.kt` (seek bar, play, skip, action pills), `NowPlayingScreen.kt`, `NavBar.kt`, `Components.kt` (surface finishes per design style, backgrounds, patterns), `Theme.kt`, `Themes.kt`, `Motion.kt`.
- `Mascot.kt` (Lumi), `Tutorial.kt` (tour overlay and player preview), `Intro.kt` (setup screens), `Aurora.kt` (intro animation, background layers), `Extras.kt` (helpers: lite mode, cover colours, colour sources, cookie shape).
- `Widget.kt` (state, store, renderer, provider), `WidgetConfigActivity.kt`, widget layouts and drawables under `res/layout` and `res/drawable`.
- `Translate.kt` (`AppLanguage`, `translate`, the `Text` shim, `order` of languages), `Translations.kt` (tables `TABLE_1` to `TABLE_4`, registered in `Translations.table`).
- `PlaylistsScreen.kt` (playlist cards, covers, the Playlists tab, the playlist editor), `Library.kt` (playlist model and JSON, `songsFor`).

## Conventions and gotchas
- New files in 3.0.0: `SettingsSearch.kt` (search), `SettingsIndex.kt` (generated), `Translations2.kt` (generated), `tools/` (scripts and `translations2.txt`).
- **Adding a setting:** add the field to `AppSettings`, a key in `K`, and a line each in the read and write functions in `Settings.kt`. Then add UI in `SettingsScreen.kt`. Enum settings are stored by name.
- **Translations:** pipe-separated rows `English|pl|es|fr|de|pt|it|tr|ru|ja|zh` in `TABLE_1` to `TABLE_4`. The `Text` shim in `Translate.kt` translates automatically. Use `verbatim(...)` to skip translation. Keep "Lumi" literal in rows because the tour swaps in the user's chosen name.
- All UI strings up to v3.0.0 are translated (see `tools/translations2.txt`). Any new English text needs a row there, then run `tools/gen_translations.py`; `tools/missing_translations.txt` lists what is still missing.
- Lite mode (`asLite()` in `Extras.kt`) overrides settings for low-end phones: matte surfaces, battery saver, lower frame rate, no entrance animations or glow.
- When patching files with Python slices, check that the end marker comes after the start marker. A reversed pair once duplicated half of `NowPlayingScreen.kt`. It was repaired.
- Local composable names must not shadow Kotlin functions (`repeat` was renamed to `repeatPill`).

## Known risks to check on the first build (v2.7 and v2.8)
- Shared-element morph (`sharedBounds`, `OverlayClip`, `BoundsTransform`) is experimental API and untested.
- New `PlayShape`, `PlayStyle` and control code in `Controls.kt` and `NowPlayingScreen.kt`.
- Widget buttons use new layouts (`w_prev_box`, `w_play_box`, `w_next_box`). The widget takes the app's button look only after the app has been opened once.
- Widget play buttons only work while the playback service is alive.
- v2.8: `CanvasDrawScope` / `ImageBitmap` off-screen drawing in `renderLumiBitmap`; the `Canvas as GfxCanvas` import alias in `Mascot.kt`; `CircularProgressIndicator(progress = { })` in `ModernUi.kt`; `if (...) item {} else item {}` in `HomeScreen.kt`; the new widget XML (vinyl overlay uses `layout_gravity` on the play box).
- v2.9.1: `PathMeasure.getSegment` and `Path.arcTo(Rect, ...)` in `ModernUi.kt`; `LocalLifecycleOwner` from `androidx.lifecycle.compose` in `MainScreen.kt`; `registerReceiver` for `ACTION_POWER_SAVE_MODE_CHANGED` in `Ambient.kt`.
- v2.9: `combinedClickable(interactionSource, indication, ...)` in `SongRow`; `drawArc` with `Brush.sweepGradient` inside `withTransform`; `Modifier.glow` strokes through a hand-written `strokeOutline`; `OrbitDisc` gesture lambdas using `return@pointerInput`.
- v2.8: new setting labels (Interface tab, Lumi options, widget types) are English-only.

## Open ideas and follow-ups
- Translate the new settings labels into the ten languages.
- If Current feels wrong on some screen (Songs rows, Playlists, Albums), refine `sleekFinish` or add per-screen layouts; the first pass only changes shell, Home, player panel and surfaces.
- Update the GitHub Actions versions to clear the Node.js 20 warning (the user has not sent the workflow file yet).
- Test the morph, widget and touch reactions on the user's device and adjust from feedback.
- The user likes: lots of customization, friendly and fun UI, smooth animations, good performance on low-end phones, short and clear explanations on mobile.
