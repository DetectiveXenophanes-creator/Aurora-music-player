package com.aurora.player

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils

/** Opens when you add the widget (and again from its settings). Pick a look, then tap Save. */
class WidgetConfigActivity : ComponentActivity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        // If the person backs out, the widget is not added.
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val start = WidgetStore.load(this, widgetId, WidgetRender.defaultLayout(AppWidgetManager.getInstance(this), widgetId))
        val store = SettingsStore(this)
        setContent {
            val settings by store.flow.collectAsState(initial = AppSettings())
            CompositionLocalProvider(LocalAppSettings provides settings) {
                AuroraTheme(settings) {
                    ConfigScreen(
                        start = start,
                        onSave = { opts ->
                            WidgetStore.save(this, widgetId, opts)
                            AuroraWidget.refreshAll(this)
                            setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                            finish()
                        },
                    )
                }
            }
        }
    }
}

private val bgNames = listOf("App theme", "Accent", "Dark", "Light", "Custom")
private val layoutNames = listOf("Classic", "Compact", "Cover", "Lumi", "Lumi pal", "Square", "Vinyl")
private val radiusNames = listOf("Square", "Soft", "Round", "Pill")
private val shapeNames = listOf("Square", "Rounded", "Circle")
private val sizeNames = listOf("Small", "Medium", "Large")

@Composable
private fun <T> Chips(names: List<String>, values: List<T>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n -> AuroraChip(n, values[i] == selected) { onSelect(values[i]) } }
    }
}

@Composable
private fun ConfigScreen(start: WidgetOpts, onSave: (WidgetOpts) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var o by remember { mutableStateOf(start) }
    val theme = remember { WidgetState.theme(context) }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Customize widget", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            WidgetPreview(o, theme)

            SettingCard("Layout") {
                Chips(layoutNames, listOf(0, 1, 2, 3, 4, 5, 6), o.layout) { v -> o = o.copy(layout = v) }
                Text(
                    when (o.layout) {
                        0 -> "Cover, title, artist and all three buttons."
                        1 -> "A slim bar. Good for one row of icons."
                        2 -> "The album art fills the whole widget."
                        3 -> "Lumi on the left with the song and buttons. Tap her to play or pause."
                        4 -> "A small square with Lumi, the song and buttons. Tap her to play or pause."
                        5 -> "A big square cover with the song and buttons under it."
                        else -> "A round record with the play button on top and skip buttons at the sides."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            SettingCard("Background") {
                Chips(bgNames.take(3), listOf(0, 1, 2), o.bg) { v -> o = o.copy(bg = v) }
                Chips(bgNames.drop(3), listOf(3, 4), o.bg) { v -> o = o.copy(bg = v) }
                if (o.bg == 4) {
                    SliderRow("Colour", o.hue, 0f..359f, "${o.hue.toInt()}") { v -> o = o.copy(hue = v) }
                    SliderRow("Brightness", o.shade, 0.15f..0.95f, "${(o.shade * 100).toInt()}%") { v -> o = o.copy(shade = v) }
                }
                SliderRow("Opacity", o.opacity, 0.1f..1f, "${(o.opacity * 100).toInt()}%") { v -> o = o.copy(opacity = v) }
            }
            SettingCard("Corners") {
                Chips(radiusNames, listOf(0, 1, 2, 3), o.radius) { v -> o = o.copy(radius = v) }
            }
            SettingCard("Cover art") {
                val lumi = o.layout == 3 || o.layout == 4
                ToggleRow(
                    "Show cover",
                    if (lumi) "Lumi takes the place of the cover in this layout" else "The album picture",
                    (o.showArt || o.layout == 2) && !lumi,
                    o.layout != 2 && !lumi,
                ) { v -> o = o.copy(showArt = v) }
                if (o.layout != 2 && !lumi && o.layout != 6) Chips(shapeNames, listOf(0, 1, 2), o.artShape) { v -> o = o.copy(artShape = v) }
            }
            SettingCard("Text") {
                Chips(sizeNames, listOf(0, 1, 2), o.textSize) { v -> o = o.copy(textSize = v) }
                ToggleRow("Show artist", "Under the song title", o.showArtist, true) { v -> o = o.copy(showArtist = v) }
            }
            SettingCard("Buttons") {
                Text("Look", style = MaterialTheme.typography.labelLarge)
                Chips(listOf("Like the player", "Minimal"), listOf(0, 1), o.controlStyle) { v -> o = o.copy(controlStyle = v) }
                ToggleRow("Previous and next", "Turn off to keep only play and pause", o.showButtons, true) { v -> o = o.copy(showButtons = v) }
                if (o.controlStyle == 1) {
                    ToggleRow("Round play button", "A coloured circle behind play", o.plate, true) { v -> o = o.copy(plate = v) }
                }
            }
            Button(onClick = { onSave(o) }, modifier = Modifier.fillMaxWidth()) { Text("Save widget") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

/** A drawn stand-in for the real widget so you see changes as you make them. */
@Composable
private fun WidgetPreview(o: WidgetOpts, theme: WidgetState.Theme) {
    val bg = WidgetRender.backgroundColor(o, theme)
    val bgColor = Color(bg).copy(alpha = o.opacity.coerceIn(0.1f, 1f))
    val radius = WidgetRender.RADII[o.radius.coerceIn(0, 3)].dp
    val cover = o.layout == 2
    val text = if (cover) Color.White else Color(WidgetRender.readableOn(bg))
    val shape = RoundedCornerShape(radius)
    val plate = Color(theme.primary)
    val artShape = when (o.artShape) {
        0 -> RoundedCornerShape(0.dp)
        1 -> RoundedCornerShape(10.dp)
        else -> CircleShape
    }
    val height = when (o.layout) {
        1 -> 62.dp
        2 -> 150.dp
        3 -> 92.dp
        4, 5, 6 -> 170.dp
        else -> 92.dp
    }
    if (o.layout >= 3) {
        NewTypePreview(o, bgColor, shape, text, plate, height)
        return
    }
    Box(Modifier.fillMaxWidth().height(height).clip(shape).background(bgColor)) {
        if (cover) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color(theme.primary).copy(alpha = 0.55f), Color(ColorUtils.blendARGB(theme.primary, android.graphics.Color.BLACK, 0.6f))),
                    ),
                ),
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)))))
        }
        Row(
            Modifier.fillMaxSize().padding(if (o.layout == 1) 8.dp else 10.dp),
            verticalAlignment = if (cover) Alignment.Bottom else Alignment.CenterVertically,
        ) {
            if (!cover && o.showArt) {
                val side = if (o.layout == 1) 44.dp else 64.dp
                Box(Modifier.size(side).clip(artShape).background(text.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MusicNote, null, tint = text, modifier = Modifier.size(side / 2))
                }
                Spacer(Modifier.size(10.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("Song title", color = text, fontWeight = FontWeight.Bold, maxLines = 1)
                if (o.showArtist) Text("Artist name", color = text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (o.layout == 0) {
                    Spacer(Modifier.height(4.dp))
                    PreviewButtons(o, text, plate)
                }
            }
            if (o.layout != 0) PreviewButtons(o, text, plate)
        }
    }
}

@Composable
private fun PreviewButtons(o: WidgetOpts, text: Color, plate: Color) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val ctl = remember { WidgetState.controls(context) }
    val match = o.controlStyle == 0
    fun pill(pct: Float) = RoundedCornerShape(percent = pct.toInt().coerceIn(0, 50))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        if (o.showButtons) {
            Box(
                Modifier.size(34.dp, 28.dp).clip(pill(ctl.skipPct)).background(if (match) Color(ctl.skipBg) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.SkipPrevious, null, tint = if (match) Color(ctl.skipFg) else text, modifier = Modifier.size(20.dp)) }
        }
        val playBg = when {
            match -> Color(ctl.playBg).copy(alpha = if (ctl.playOutline) 0.27f else 1f)
            o.plate -> plate
            else -> Color.Transparent
        }
        val playFg = when {
            match -> if (ctl.playOutline) Color(ctl.playBg) else Color(ctl.playFg)
            o.plate -> Color(WidgetRender.readableOn(plate.toArgb()))
            else -> text
        }
        Box(
            Modifier.size(46.dp, 32.dp).clip(if (match) pill(ctl.playPct) else CircleShape).background(playBg),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.PlayArrow, null, tint = playFg, modifier = Modifier.size(22.dp)) }
        if (o.showButtons) {
            Box(
                Modifier.size(34.dp, 28.dp).clip(pill(ctl.skipPct)).background(if (match) Color(ctl.skipBg) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.SkipNext, null, tint = if (match) Color(ctl.skipFg) else text, modifier = Modifier.size(20.dp)) }
        }
    }
}

/** Stand-in for the Lumi, Lumi pal, Square and Vinyl layouts. */
@Composable
private fun NewTypePreview(o: WidgetOpts, bgColor: Color, shape: RoundedCornerShape, text: Color, plate: Color, height: androidx.compose.ui.unit.Dp) {
    val coverShape = if (o.layout == 6) CircleShape else RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth().height(height).clip(shape).background(bgColor)) {
        when (o.layout) {
            3 -> Row(Modifier.fillMaxSize().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AuroraCat(Modifier.size(72.dp), asleep = false, bounce = true)
                Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                    Text("Song title", color = text, fontWeight = FontWeight.Bold, maxLines = 1)
                    if (o.showArtist) Text("Artist name", color = text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
                PreviewButtons(o, text, plate)
            }
            4 -> Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { AuroraCat(Modifier.size(92.dp), asleep = false, bounce = true) }
                Text("Song title", color = text, fontWeight = FontWeight.Bold, maxLines = 1)
                if (o.showArtist) Text("Artist name", color = text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Spacer(Modifier.height(6.dp))
                PreviewButtons(o, text, plate)
            }
            else -> Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(84.dp).clip(coverShape).background(text.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                        if (o.layout == 6) {
                            Icon(Icons.Rounded.PlayArrow, null, tint = text, modifier = Modifier.size(34.dp))
                        } else {
                            Icon(Icons.Rounded.MusicNote, null, tint = text, modifier = Modifier.size(40.dp))
                        }
                    }
                }
                Text("Song title", color = text, fontWeight = FontWeight.Bold, maxLines = 1)
                if (o.showArtist) Text("Artist name", color = text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (o.layout == 5) {
                    Spacer(Modifier.height(6.dp))
                    PreviewButtons(o, text, plate)
                }
            }
        }
    }
}
