package com.aurora.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/** How one home screen widget looks. Every widget you add has its own copy. */
data class WidgetOpts(
    val layout: Int = 0, // 0 classic, 1 compact, 2 cover, 3 Lumi, 4 Lumi pal, 5 square, 6 vinyl
    val bg: Int = 0, // 0 app theme, 1 accent, 2 dark, 3 light, 4 custom
    val hue: Float = 260f,
    val shade: Float = 0.35f,
    val opacity: Float = 0.92f,
    val radius: Int = 2, // index into WidgetRender.RADII
    val showArt: Boolean = true,
    val artShape: Int = 1, // 0 square, 1 rounded, 2 circle
    val showButtons: Boolean = true,
    val showArtist: Boolean = true,
    val plate: Boolean = true,
    val textSize: Int = 1, // 0 small, 1 medium, 2 large
    val controlStyle: Int = 0, // 0 like the player, 1 minimal icons
)

object WidgetStore {
    private fun prefs(c: Context) = c.getSharedPreferences("aurora_widget_opts", Context.MODE_PRIVATE)

    fun load(c: Context, id: Int, defaultLayout: Int = 0): WidgetOpts {
        val p = prefs(c)
        val d = WidgetOpts(layout = defaultLayout)
        fun k(n: String) = "${id}_$n"
        return WidgetOpts(
            layout = p.getInt(k("layout"), d.layout),
            bg = p.getInt(k("bg"), d.bg),
            hue = p.getFloat(k("hue"), d.hue),
            shade = p.getFloat(k("shade"), d.shade),
            opacity = p.getFloat(k("opacity"), d.opacity),
            radius = p.getInt(k("radius"), d.radius),
            showArt = p.getBoolean(k("showArt"), d.showArt),
            artShape = p.getInt(k("artShape"), d.artShape),
            showButtons = p.getBoolean(k("showButtons"), d.showButtons),
            showArtist = p.getBoolean(k("showArtist"), d.showArtist),
            plate = p.getBoolean(k("plate"), d.plate),
            textSize = p.getInt(k("textSize"), d.textSize),
            controlStyle = p.getInt(k("controlStyle"), d.controlStyle),
        )
    }

    fun save(c: Context, id: Int, o: WidgetOpts) {
        fun k(n: String) = "${id}_$n"
        prefs(c).edit()
            .putInt(k("layout"), o.layout)
            .putInt(k("bg"), o.bg)
            .putFloat(k("hue"), o.hue)
            .putFloat(k("shade"), o.shade)
            .putFloat(k("opacity"), o.opacity)
            .putInt(k("radius"), o.radius)
            .putBoolean(k("showArt"), o.showArt)
            .putInt(k("artShape"), o.artShape)
            .putBoolean(k("showButtons"), o.showButtons)
            .putBoolean(k("showArtist"), o.showArtist)
            .putBoolean(k("plate"), o.plate)
            .putInt(k("textSize"), o.textSize)
            .putInt(k("controlStyle"), o.controlStyle)
            .apply()
    }

    fun delete(c: Context, id: Int) {
        val p = prefs(c)
        val e = p.edit()
        p.all.keys.filter { it.startsWith("${id}_") }.forEach { e.remove(it) }
        e.apply()
    }
}

/** What the widgets show: the current song and the app's colours. Written by the player service and the app. */
object WidgetState {
    class Song(val title: String, val artist: String, val artUri: String, val playing: Boolean, val has: Boolean)
    class Theme(val primary: Int, val surface: Int, val onSurface: Int)
    /** How the player's own buttons look, so the widget can copy them. */
    class Controls(
        val skipBg: Int,
        val skipFg: Int,
        val playBg: Int,
        val playFg: Int,
        val skipPct: Float,
        val playPct: Float,
        val playOutline: Boolean,
    )

    private fun prefs(c: Context) = c.getSharedPreferences("aurora_widget_state", Context.MODE_PRIVATE)

    fun saveSong(c: Context, title: String, artist: String, artUri: String, playing: Boolean, has: Boolean) {
        prefs(c).edit()
            .putString("title", title)
            .putString("artist", artist)
            .putString("art", artUri)
            .putBoolean("playing", playing)
            .putBoolean("has", has)
            .apply()
    }

    fun song(c: Context): Song {
        val p = prefs(c)
        return Song(
            p.getString("title", "") ?: "",
            p.getString("artist", "") ?: "",
            p.getString("art", "") ?: "",
            p.getBoolean("playing", false),
            p.getBoolean("has", false),
        )
    }

    fun saveTheme(c: Context, primary: Int, surface: Int, onSurface: Int) {
        val p = prefs(c)
        if (p.getInt("t_primary", 0) == primary && p.getInt("t_surface", 0) == surface && p.getInt("t_on", 0) == onSurface) return
        p.edit().putInt("t_primary", primary).putInt("t_surface", surface).putInt("t_on", onSurface).apply()
        AuroraWidget.refreshAll(c)
    }

    fun saveControls(
        c: Context,
        skipBg: Int, skipFg: Int, playBg: Int, playFg: Int,
        skipPct: Float, playPct: Float, playOutline: Boolean,
    ) {
        val p = prefs(c)
        val same = p.getInt("c_skip_bg", 0) == skipBg && p.getInt("c_skip_fg", 0) == skipFg &&
            p.getInt("c_play_bg", 0) == playBg && p.getInt("c_play_fg", 0) == playFg &&
            p.getFloat("c_skip_pct", -1f) == skipPct && p.getFloat("c_play_pct", -1f) == playPct &&
            p.getBoolean("c_play_outline", false) == playOutline
        if (same) return
        p.edit()
            .putInt("c_skip_bg", skipBg).putInt("c_skip_fg", skipFg)
            .putInt("c_play_bg", playBg).putInt("c_play_fg", playFg)
            .putFloat("c_skip_pct", skipPct).putFloat("c_play_pct", playPct)
            .putBoolean("c_play_outline", playOutline)
            .apply()
        AuroraWidget.refreshAll(c)
    }

    fun controls(c: Context): Controls {
        val p = prefs(c)
        return Controls(
            p.getInt("c_skip_bg", 0xFF4A4458.toInt()),
            p.getInt("c_skip_fg", 0xFFE8DEF8.toInt()),
            p.getInt("c_play_bg", 0xFFD0BCFF.toInt()),
            p.getInt("c_play_fg", 0xFF381E72.toInt()),
            p.getFloat("c_skip_pct", 50f),
            p.getFloat("c_play_pct", 50f),
            p.getBoolean("c_play_outline", false),
        )
    }

    /** Remembers how Lumi looks so the Lumi widgets can draw her. Redraws the widgets when her look changes. */
    fun saveLumi(c: Context, s: AppSettings) {
        val look = s.mascotLook()
        val sig = listOf(
            look.palette.name, look.hat.name, look.eyewear.name, look.headphones, look.scarf, look.blush,
            look.ears.name, look.eyes.name, look.tail.name, look.neck.name, look.mark.name,
            look.wings, look.sparkles, look.hue, look.glow, look.flow, s.mascotNotes,
        ).joinToString("|")
        val p = prefs(c)
        if (p.getString("l_sig", null) == sig) return
        p.edit().putString("l_sig", sig).apply()
        AuroraWidget.refreshAll(c)
    }

    fun lumi(c: Context): MascotLook {
        val parts = prefs(c).getString("l_sig", null)?.split("|") ?: return MascotLook()
        if (parts.size < 17) return MascotLook()
        return runCatching {
            MascotLook(
                palette = MascotPalette.valueOf(parts[0]),
                hat = MascotHat.valueOf(parts[1]),
                eyewear = MascotEyewear.valueOf(parts[2]),
                headphones = parts[3].toBoolean(),
                scarf = parts[4].toBoolean(),
                blush = parts[5].toBoolean(),
                ears = MascotEars.valueOf(parts[6]),
                eyes = MascotEyes.valueOf(parts[7]),
                tail = MascotTail.valueOf(parts[8]),
                neck = MascotNeck.valueOf(parts[9]),
                mark = MascotMark.valueOf(parts[10]),
                wings = parts[11].toBoolean(),
                sparkles = parts[12].toBoolean(),
                hue = parts[13].toFloat(),
                glow = parts[14].toFloat(),
                flow = parts[15].toBoolean(),
            )
        }.getOrDefault(MascotLook())
    }

    fun lumiNotes(c: Context): Boolean =
        prefs(c).getString("l_sig", null)?.split("|")?.getOrNull(16)?.toBoolean() ?: true

    fun theme(c: Context): Theme {
        val p = prefs(c)
        return Theme(
            p.getInt("t_primary", 0xFF6750A4.toInt()),
            p.getInt("t_surface", 0xFF2B2930.toInt()),
            p.getInt("t_on", 0xFFE6E0E9.toInt()),
        )
    }
}

object WidgetRender {
    val RADII = intArrayOf(0, 14, 26, 40)
    private val DARK = 0xFF14141B.toInt()
    private val LIGHT = 0xFFF4F1F8.toInt()

    private var cachedUri: String? = null
    private var cachedBmp: Bitmap? = null

    fun backgroundColor(o: WidgetOpts, t: WidgetState.Theme): Int = when (o.bg) {
        0 -> t.surface
        1 -> t.primary
        2 -> DARK
        3 -> LIGHT
        else -> Color.HSVToColor(floatArrayOf(o.hue.coerceIn(0f, 359f), 0.5f, o.shade.coerceIn(0.15f, 0.95f)))
    }

    fun readableOn(bg: Int): Int = if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1B1B1F.toInt() else 0xFFF2F0F7.toInt()

    private fun loadArt(c: Context, uri: String, target: Int): Bitmap? {
        if (uri.isEmpty()) return null
        if (uri == cachedUri) cachedBmp?.let { return it }
        val bmp = runCatching {
            val u = Uri.parse(uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }.getOrNull()
        if (bmp != null) {
            cachedUri = uri
            cachedBmp = bmp
        }
        return bmp
    }

    /** Centre-crops [src] into a [w] x [h] bitmap with rounded corners. */
    private fun cropRounded(src: Bitmap, w: Int, h: Int, radius: Float, scrim: Boolean): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val scale = max(w / src.width.toFloat(), h / src.height.toFloat())
        val m = Matrix()
        m.setScale(scale, scale)
        m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        shader.setLocalMatrix(m)
        paint.shader = shader
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        canvas.drawRoundRect(rect, radius, radius, paint)
        if (scrim) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.shader = LinearGradient(
                0f, h * 0.35f, 0f, h.toFloat(),
                Color.argb(0, 0, 0, 0), Color.argb(200, 0, 0, 0), Shader.TileMode.CLAMP,
            )
            canvas.drawRoundRect(rect, radius, radius, sp)
        }
        return out
    }

    private fun servicePi(c: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            c,
            code,
            Intent(c, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun openPi(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(c, 10, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** A widget added from the Lumi, Square or Vinyl entries in the picker starts with that layout. */
    fun defaultLayout(mgr: AppWidgetManager, id: Int): Int {
        val cls = mgr.getAppWidgetInfo(id)?.provider?.className ?: return 0
        return when {
            cls.endsWith("AuroraLumiPalWidget") -> 4
            cls.endsWith("AuroraLumiWidget") -> 3
            cls.endsWith("AuroraSquareWidget") -> 5
            cls.endsWith("AuroraVinylWidget") -> 6
            else -> 0
        }
    }

    fun build(c: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val o = WidgetStore.load(c, id, defaultLayout(mgr, id))
        val song = WidgetState.song(c)
        val theme = WidgetState.theme(c)
        val d = c.resources.displayMetrics.density
        val layoutRes = when (o.layout) {
            1 -> R.layout.widget_compact
            2 -> R.layout.widget_cover
            3 -> R.layout.widget_lumi
            4 -> R.layout.widget_lumi_pal
            5 -> R.layout.widget_square
            6 -> R.layout.widget_vinyl
            else -> R.layout.widget_classic
        }
        val v = RemoteViews(c.packageName, layoutRes)
        val cover = o.layout == 2
        val lumiLayout = o.layout == 3 || o.layout == 4
        val bg = backgroundColor(o, theme)
        val radiusIndex = o.radius.coerceIn(0, RADII.size - 1)
        val radiusDp = RADII[radiusIndex]

        v.setImageViewResource(
            R.id.w_bg,
            when (radiusIndex) {
                0 -> R.drawable.widget_bg_0
                1 -> R.drawable.widget_bg_14
                2 -> R.drawable.widget_bg_26
                else -> R.drawable.widget_bg_40
            },
        )
        v.setInt(R.id.w_bg, "setColorFilter", bg)
        v.setInt(R.id.w_bg, "setImageAlpha", (o.opacity.coerceIn(0.1f, 1f) * 255).toInt())

        // Art
        val artSizeDp = when (o.layout) {
            1 -> 44
            5 -> 150
            6 -> 110
            else -> 64
        }
        var textColor = readableOn(bg)
        if (cover) {
            val sizeInfo = mgr.getAppWidgetOptions(id)
            val wDp = sizeInfo.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
            val hDp = sizeInfo.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 150)
            val scale = min(1f, 600f / max(wDp * d, hDp * d))
            val wPx = (wDp * d * scale).toInt().coerceAtLeast(64)
            val hPx = (hDp * d * scale).toInt().coerceAtLeast(64)
            val art = if (song.has) loadArt(c, song.artUri, max(wPx, hPx)) else null
            if (art != null) {
                v.setImageViewBitmap(R.id.w_art, cropRounded(art, wPx, hPx, radiusDp * d * scale, true))
                v.setViewVisibility(R.id.w_art, View.VISIBLE)
                textColor = Color.WHITE
            } else {
                v.setViewVisibility(R.id.w_art, View.GONE)
            }
        } else if (o.showArt && !lumiLayout) {
            val px = (artSizeDp * d).toInt()
            val art = if (song.has) loadArt(c, song.artUri, px) else null
            if (art != null) {
                val r = when {
                    o.layout == 6 -> px / 2f
                    o.artShape == 0 -> 0f
                    o.artShape == 1 -> px * 0.18f
                    else -> px / 2f
                }
                v.setImageViewBitmap(R.id.w_art, cropRounded(art, px, px, r, false))
            } else {
                v.setImageViewResource(R.id.w_art, R.drawable.ic_w_note)
                v.setInt(R.id.w_art, "setColorFilter", textColor)
            }
            v.setViewVisibility(R.id.w_art, View.VISIBLE)
        } else {
            v.setViewVisibility(R.id.w_art, View.GONE)
        }

        // Lumi: she sleeps with no song, dozes while paused and bounces while music plays. Tapping her plays or pauses.
        if (lumiLayout) {
            val mood = when {
                !song.has -> 0
                song.playing -> 2
                else -> 1
            }
            val px = ((if (o.layout == 4) 110 else 76) * d).toInt().coerceAtLeast(64)
            v.setImageViewBitmap(R.id.w_lumi, renderLumiBitmap(px, WidgetState.lumi(c), mood, WidgetState.lumiNotes(c)))
            v.setOnClickPendingIntent(R.id.w_lumi, servicePi(c, AuroraWidget.ACTION_TOGGLE, 1))
        }

        // Text
        val titleSp = floatArrayOf(13f, 15f, 17f)[o.textSize.coerceIn(0, 2)] - if (o.layout == 1) 1f else 0f
        v.setTextViewText(R.id.w_title, if (song.has) song.title else "Aurora")
        v.setTextViewText(R.id.w_artist, if (song.has) song.artist else "Tap to open")
        v.setTextColor(R.id.w_title, textColor)
        v.setTextColor(R.id.w_artist, (textColor and 0x00FFFFFF) or 0xB3000000.toInt())
        v.setTextViewTextSize(R.id.w_title, TypedValue.COMPLEX_UNIT_SP, titleSp)
        v.setTextViewTextSize(R.id.w_artist, TypedValue.COMPLEX_UNIT_SP, titleSp - 3f)
        v.setViewVisibility(R.id.w_artist, if (o.showArtist) View.VISIBLE else View.GONE)

        // Buttons. By default they copy the player's own buttons: same colours, same shapes.
        val ctl = WidgetState.controls(c)
        val match = o.controlStyle == 0
        fun shapeRes(pct: Float): Int = when {
            pct >= 45f -> R.drawable.widget_bg_40
            pct >= 28f -> R.drawable.widget_bg_14
            pct >= 14f -> R.drawable.widget_btn_8
            else -> R.drawable.widget_btn_4
        }
        val showSkip = if (o.showButtons) View.VISIBLE else View.GONE
        v.setViewVisibility(R.id.w_prev_box, showSkip)
        v.setViewVisibility(R.id.w_next_box, showSkip)
        v.setImageViewResource(R.id.w_play, if (song.playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        if (match) {
            for (id in intArrayOf(R.id.w_prev_bg, R.id.w_next_bg)) {
                v.setViewVisibility(id, View.VISIBLE)
                v.setImageViewResource(id, shapeRes(ctl.skipPct))
                v.setInt(id, "setColorFilter", ctl.skipBg)
            }
            v.setInt(R.id.w_prev, "setColorFilter", ctl.skipFg)
            v.setInt(R.id.w_next, "setColorFilter", ctl.skipFg)
            v.setViewVisibility(R.id.w_plate, View.VISIBLE)
            v.setImageViewResource(R.id.w_plate, shapeRes(ctl.playPct))
            v.setInt(R.id.w_plate, "setColorFilter", ctl.playBg)
            v.setInt(R.id.w_plate, "setImageAlpha", if (ctl.playOutline) 70 else 255)
            v.setInt(R.id.w_play, "setColorFilter", if (ctl.playOutline) ctl.playBg else ctl.playFg)
        } else {
            v.setViewVisibility(R.id.w_prev_bg, View.GONE)
            v.setViewVisibility(R.id.w_next_bg, View.GONE)
            v.setInt(R.id.w_prev, "setColorFilter", textColor)
            v.setInt(R.id.w_next, "setColorFilter", textColor)
            if (o.plate) {
                val plate = if (ColorUtils.calculateContrast(theme.primary, bg) < 1.6 && !(cover && textColor == Color.WHITE)) textColor else theme.primary
                v.setViewVisibility(R.id.w_plate, View.VISIBLE)
                v.setImageViewResource(R.id.w_plate, R.drawable.widget_bg_40)
                v.setInt(R.id.w_plate, "setColorFilter", plate)
                v.setInt(R.id.w_plate, "setImageAlpha", 255)
                v.setInt(R.id.w_play, "setColorFilter", readableOn(plate))
            } else {
                v.setViewVisibility(R.id.w_plate, View.GONE)
                v.setInt(R.id.w_play, "setColorFilter", textColor)
            }
        }

        v.setOnClickPendingIntent(R.id.w_play_box, servicePi(c, AuroraWidget.ACTION_TOGGLE, 1))
        v.setOnClickPendingIntent(R.id.w_prev_box, servicePi(c, AuroraWidget.ACTION_PREV, 2))
        v.setOnClickPendingIntent(R.id.w_next_box, servicePi(c, AuroraWidget.ACTION_NEXT, 3))
        v.setOnClickPendingIntent(R.id.w_root, openPi(c))
        return v
    }
}

open class AuroraWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        exec.execute {
            try {
                renderAll(context, appWidgetManager, appWidgetIds)
            } finally {
                pending.finish()
            }
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle,
    ) {
        refresh(context, appWidgetManager, intArrayOf(appWidgetId))
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { WidgetStore.delete(context, it) }
    }

    companion object {
        const val ACTION_TOGGLE = "com.aurora.player.widget.TOGGLE"
        const val ACTION_NEXT = "com.aurora.player.widget.NEXT"
        const val ACTION_PREV = "com.aurora.player.widget.PREV"
        private val exec = Executors.newSingleThreadExecutor()

        private fun renderAll(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                runCatching { mgr.updateAppWidget(id, WidgetRender.build(c, mgr, id)) }
            }
        }

        fun refresh(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val app = c.applicationContext
            exec.execute { renderAll(app, mgr, ids) }
        }

        /** Redraws every widget on the home screen. Cheap when there are none. */
        fun refreshAll(c: Context) {
            val app = c.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val classes = listOf(
                AuroraWidget::class.java,
                AuroraLumiWidget::class.java,
                AuroraLumiPalWidget::class.java,
                AuroraSquareWidget::class.java,
                AuroraVinylWidget::class.java,
            )
            for (cls in classes) {
                val ids = mgr.getAppWidgetIds(ComponentName(app, cls))
                if (ids.isNotEmpty()) refresh(app, mgr, ids)
            }
        }
    }
}

/** Extra entries in the widget picker. They all share one renderer and only differ in the layout they start with. */
class AuroraLumiWidget : AuroraWidget()
class AuroraLumiPalWidget : AuroraWidget()
class AuroraSquareWidget : AuroraWidget()
class AuroraVinylWidget : AuroraWidget()
