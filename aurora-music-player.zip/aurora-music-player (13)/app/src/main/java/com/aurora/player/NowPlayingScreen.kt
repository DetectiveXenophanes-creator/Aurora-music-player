package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val lib by vm.library.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val sleepEnd by vm.sleepEndOfSong.collectAsState()
    val settings = LocalAppSettings.current
    val motion = LocalMotion.current
    val haze = remember { HazeState() }
    val song = ui.current
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showSound by remember { mutableStateOf(false) }

    val view = LocalView.current
    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    val artScale by animateFloatAsState(
        targetValue = if (!settings.artBreathing || ui.isPlaying) 1f else 1f - 0.12f * motion.amount.coerceAtMost(1f),
        animationSpec = motion.spatial(),
        label = "artScale",
    )

    val cover = if (settings.coverColors) rememberCoverSeed(song) else null
    val baseScheme = MaterialTheme.colorScheme
    val scheme = remember(cover, baseScheme, settings.spread) {
        if (cover == null) baseScheme else coverScheme(baseScheme, cover, settings.spread)
    }
    MaterialTheme(colorScheme = scheme, shapes = MaterialTheme.shapes, typography = MaterialTheme.typography) {
    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize().blockTouches()) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(song, overlayArt = true)
            }

            BoxWithConstraints(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
            ) {
                val landscape = maxWidth > maxHeight
                val compact = maxHeight < 520.dp
                val mainH = if (compact) 56.dp else 72.dp
                val pillH = if (compact) 44.dp else 52.dp

                if (settings.uiVersion == UiVersion.CURRENT && settings.npDesign == NpDesign.ORBIT) {
                    OrbitPlayer(
                        vm = vm,
                        ui = ui,
                        lib = lib,
                        song = song,
                        sleepLeft = sleepLeft,
                        artScale = artScale,
                        landscape = landscape,
                        compact = compact,
                        onClose = onClose,
                        onSleep = { showSleep = true },
                        onSound = { showSound = true },
                        onQueue = { showQueue = true },
                    )
                } else if (landscape) {
                    // two panes: art on the left, everything else on the right
                    Column(Modifier.align(Alignment.TopCenter).widthIn(max = 1100.dp).fillMaxSize()) {
                        NpTopBar(onClose, { showSleep = true }, { showSound = true }, { showQueue = true })
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                            Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                                NpArtRow(vm, song, artScale, settings.corner, settings.artEdge, settings.artShape, ui.isPlaying)
                            }
                            Column(
                                Modifier.weight(1f).fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                            ) {
                                NpInfo(song)
                                Spacer(Modifier.height(4.dp))
                                NpSeek(vm, ui.duration, ui.isPlaying, ui.audioInfo)
                                Spacer(Modifier.height(if (compact) 8.dp else 16.dp))
                                NpControls(vm, ui, lib, song, mainH, pillH)
                            }
                        }
                    }
                } else {
                    Column(Modifier.align(Alignment.TopCenter).widthIn(max = 560.dp).fillMaxSize()) {
                        NpTopBar(onClose, { showSleep = true }, { showSound = true }, { showQueue = true })
                        Spacer(Modifier.height(16.dp))
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            NpArtRow(vm, song, artScale, settings.corner, settings.artEdge, settings.artShape, ui.isPlaying)
                        }
                        if (settings.uiVersion == UiVersion.CURRENT && settings.npPanel) {
                            // Current: title, seek bar and buttons sit together in one rounded panel under the cover.
                            Spacer(Modifier.height(14.dp))
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .cardFinish(RoundedCornerShape((settings.corner * 1.3f).dp))
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                            ) {
                                NpInfo(song)
                                Spacer(Modifier.height(6.dp))
                                NpSeek(vm, ui.duration, ui.isPlaying, ui.audioInfo)
                                Spacer(Modifier.height(14.dp))
                                NpControls(vm, ui, lib, song, mainH, pillH)
                            }
                            Spacer(Modifier.height(8.dp))
                        } else {
                            Spacer(Modifier.height(18.dp))
                            NpInfo(song)
                            Spacer(Modifier.height(6.dp))
                            NpSeek(vm, ui.duration, ui.isPlaying, ui.audioInfo)
                            Spacer(Modifier.height(16.dp))
                            NpControls(vm, ui, lib, song, mainH, pillH)
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
    }

    if (showSleep) {
        SleepSheet(
            sleepLeft = sleepLeft,
            endOfSong = sleepEnd,
            onEndOfSong = { vm.sleepAtSongEnd(); showSleep = false },
            onPick = { vm.setSleepTimer(it); showSleep = false },
            onDismiss = { showSleep = false },
        )
    }
    if (showQueue) {
        QueueSheet(vm, ui.isPlaying) { showQueue = false }
    }
    if (showSound) {
        SoundSheet(s = settings, onUpdate = { vm.updateSettings(it) }, onDismiss = { showSound = false })
    }
}

// ------------------------------------------------------------------ pieces

@Composable
private fun NpTopBar(onClose: () -> Unit, onSleep: () -> Unit, onSound: () -> Unit, onQueue: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        RoundIconButton(Icons.Rounded.KeyboardArrowDown, "Close", onClose)
        if (LocalAppSettings.current.npTopTitle) {
            Text(
                "Now Playing",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
        } else {
            Spacer(Modifier.weight(1f))
        }
        RoundIconButton(Icons.Rounded.Bedtime, "Sleep timer", onSleep)
        RoundIconButton(Icons.Rounded.Tune, "Sound: speed, pitch, equalizer", onSound)
        RoundIconButton(Icons.Rounded.QueueMusic, "Queue", onQueue)
    }
}

/** Artwork with a small previous arrow on the left and next arrow on the right. */
@Composable
private fun NpArtRow(
    vm: PlayerViewModel,
    song: Song?,
    artScale: Float,
    corner: Float,
    edge: Float,
    shape: ArtShape,
    playing: Boolean,
) {
    Row(
        Modifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (LocalAppSettings.current.npArrows) ArtArrow(forward = false, onClick = { vm.previous() })
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            NpArt(song, artScale, corner, edge, shape, playing)
        }
        if (LocalAppSettings.current.npArrows) ArtArrow(forward = true, onClick = { vm.next() })
    }
}

@Composable
private fun NpArt(song: Song?, artScale: Float, corner: Float, edge: Float, shape: ArtShape, playing: Boolean) {
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val batterySaver = LocalAppSettings.current.batterySaver
    val round = shape == ArtShape.CIRCLE || shape == ArtShape.VINYL
    val vinyl = shape == ArtShape.VINYL
    val artShape: Shape = when (shape) {
        ArtShape.ROUNDED -> RoundedCornerShape((corner * 1.3f).dp)
        ArtShape.CIRCLE, ArtShape.VINYL -> CircleShape
        ArtShape.SQUIRCLE -> RoundedCornerShape(percent = 30)
        ArtShape.COOKIE -> CookieShape
    }

    // The vinyl turns only while music plays. The angle lives in a state that is read when drawing,
    // so spinning never recomposes anything.
    val angle = remember { mutableFloatStateOf(0f) }
    val spinning = vinyl && playing && !batterySaver
    val spinMs = LocalAppSettings.current.spinFrameMs()
    LaunchedEffect(spinning) {
        if (!spinning) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    var a = angle.floatValue + (now - last) / 1_000_000_000f * 36f
                    if (a >= 360f) a -= 360f
                    angle.floatValue = a
                }
                last = now
            }
            delay(spinMs)
        }
    }
    val hole = cs.background
    Box(
        Modifier
            .aspectRatio(1f)
            .graphicsLayer {
                scaleX = artScale
                scaleY = artScale
            },
    ) {
        AnimatedContent(
            targetState = song,
            transitionSpec = { motion.songChange() },
            label = "art",
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { rotationZ = if (vinyl) angle.floatValue else 0f },
        ) { s ->
            if (s != null) {
                Art(
                    s.artUri,
                    Modifier
                        .fillMaxSize()
                        .softEdges(edge, circular = round)
                        .drawWithContent {
                            drawContent()
                            if (vinyl) {
                                val c = center
                                val r = size.minDimension / 2f
                                // faint grooves and the centre hole of a record
                                for (i in 1..4) {
                                    drawCircle(Color.Black.copy(alpha = 0.10f), radius = r * (0.40f + 0.12f * i), center = c, style = Stroke(1.dp.toPx()))
                                }
                                drawCircle(Color.Black.copy(alpha = 0.35f), radius = r * 0.13f, center = c)
                                drawCircle(hole, radius = r * 0.065f, center = c)
                            }
                        },
                    artShape,
                )
            }
        }
    }
}

@Composable
private fun NpInfo(song: Song?) {
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val st = LocalAppSettings.current
    val align = if (st.npTitleCenter) TextAlign.Center else TextAlign.Start
    val titleStyle = MaterialTheme.typography.headlineSmall.let { it.copy(fontSize = it.fontSize * st.npTitleScale) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier.weight(1f).padding(end = 12.dp),
            horizontalAlignment = if (st.npTitleCenter) Alignment.CenterHorizontally else Alignment.Start,
        ) {
            AnimatedContent(
                targetState = song?.title?.let { verbatim(it) } ?: "Nothing playing",
                transitionSpec = { motion.text() },
                label = "title",
            ) { t ->
                Text(
                    t,
                    style = titleStyle,
                    fontWeight = FontWeight.Bold,
                    textAlign = align,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            AnimatedContent(
                targetState = song?.artist?.let { verbatim(it) } ?: "",
                transitionSpec = { motion.text() },
                label = "artist",
            ) { a ->
                Text(
                    a,
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.onSurfaceVariant,
                    textAlign = align,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (song != null) {
            SongMenu(song, null) { open ->
                RoundIconButton(Icons.Rounded.MoreVert, "More", open)
            }
        }
    }
}

/**
 * The only part of Now Playing that follows the playback position. Keeping it in its own composable means
 * the artwork, title and buttons are not redrawn every 400 ms.
 */
@Composable
private fun NpSeek(vm: PlayerViewModel, duration: Long, playing: Boolean, audioInfo: String) {
    val remaining = LocalAppSettings.current.seekRemaining
    val pos by vm.position.collectAsState()
    val cs = MaterialTheme.colorScheme
    var preview by remember { mutableStateOf<Float?>(null) }
    val progress = if (duration > 0) (pos.toFloat() / duration).coerceIn(0f, 1f) else 0f

    SeekBar(
        progress = progress,
        playing = playing,
        onPreview = { preview = it },
        onSeek = { f -> vm.seekTo((f * duration).toLong()) },
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            fmt(((preview ?: progress) * duration).toLong()),
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant,
        )
        if (audioInfo.isNotEmpty() && LocalAppSettings.current.npAudioChip) FormatChip(audioInfo)
        Text(
            if (remaining) "-" + fmt((duration - ((preview ?: progress) * duration).toLong()).coerceAtLeast(0L)) else fmt(duration),
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { vm.updateSettings { it.copy(seekRemaining = !it.seekRemaining) } }
                .padding(horizontal = 6.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun NpControls(
    vm: PlayerViewModel,
    ui: PlayerUi,
    lib: LibraryData,
    song: Song?,
    mainH: androidx.compose.ui.unit.Dp,
    pillH: androidx.compose.ui.unit.Dp,
) {
    val s = LocalAppSettings.current
    val gap = s.npGap.dp
    val main = mainH * s.npButtonScale
    val pill = pillH * s.npButtonScale
    val fav = song != null && song.id in lib.favorites
    val prev: @Composable (Modifier) -> Unit = { m ->
        if (s.npShowSkip) SkipButton(forward = false, onClick = { vm.previous() }, modifier = m.height(main), iconSize = 32.dp)
    }
    val play: @Composable (Modifier) -> Unit = { m ->
        PlayPauseButton(playing = ui.isPlaying, onClick = { vm.togglePlay() }, modifier = m.height(main), iconSize = 34.dp)
    }
    val next: @Composable (Modifier) -> Unit = { m ->
        if (s.npShowSkip) SkipButton(forward = true, onClick = { vm.next() }, modifier = m.height(main), iconSize = 32.dp)
    }
    val shufflePill: @Composable (Modifier) -> Unit = { m ->
        if (s.npShowShuffle) {
            ActionPill(
                active = ui.shuffle,
                icon = Icons.Rounded.Shuffle,
                description = "Shuffle",
                onClick = { vm.toggleShuffle() },
                modifier = m.height(pill),
            )
        }
    }
    val repeatPill: @Composable (Modifier) -> Unit = { m ->
        if (s.npShowRepeat) {
            ActionPill(
                active = ui.repeat != Player.REPEAT_MODE_OFF,
                icon = if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                description = "Repeat",
                onClick = { vm.cycleRepeat() },
                modifier = m.height(pill),
            )
        }
    }
    val heartPill: @Composable (Modifier) -> Unit = { m ->
        if (s.npShowFav) {
            ActionPill(
                active = fav,
                icon = if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                description = "Favorite",
                onClick = { song?.let { vm.toggleFavorite(it.id) } },
                modifier = m.height(pill),
            )
        }
    }
    val playWeight = s.npPlayWeight.coerceIn(0.8f, 3f)
    val showActions = s.npShowShuffle || s.npShowRepeat || s.npShowFav

    @Composable
    fun mainRow() {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
            prev(Modifier.weight(1f))
            play(Modifier.weight(playWeight))
            next(Modifier.weight(1f))
        }
    }

    @Composable
    fun actionRow() {
        if (!showActions) return
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
            shufflePill(Modifier.weight(1f))
            repeatPill(Modifier.weight(1f))
            heartPill(Modifier.weight(1f))
        }
    }

    when (s.npLayout) {
        NpLayout.CLASSIC -> {
            mainRow()
            if (showActions) Spacer(Modifier.height(gap))
            actionRow()
        }
        NpLayout.SPLIT -> {
            actionRow()
            if (showActions) Spacer(Modifier.height(gap))
            mainRow()
        }
        NpLayout.ONE_ROW -> {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                shufflePill(Modifier.weight(0.7f))
                prev(Modifier.weight(1f))
                play(Modifier.weight(playWeight * 1.1f))
                next(Modifier.weight(1f))
                repeatPill(Modifier.weight(0.7f))
            }
            if (s.npShowFav) {
                Spacer(Modifier.height(gap))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    heartPill(Modifier.fillMaxWidth(0.5f))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ sheets

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SleepSheet(sleepLeft: Long?, endOfSong: Boolean, onEndOfSong: () -> Unit, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AuroraSheet(onDismiss = onDismiss, title = "Sleep timer") {
        Column(
            Modifier.padding(start = 24.dp, end = 24.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (sleepLeft != null) {
                Text(
                    "Music stops in ${(sleepLeft / 60_000) + 1} min",
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.primary,
                )
            } else if (endOfSong) {
                Text("Music stops when this song ends", style = MaterialTheme.typography.titleMedium, color = cs.primary)
            } else {
                Text(
                    "Pause the music automatically after:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    AuroraChip("$m min", false) { onPick(m) }
                }
                AuroraChip("End of song", endOfSong) { onEndOfSong() }
            }
            if (sleepLeft != null || endOfSong) {
                FilledTonalButton(onClick = { onPick(null) }) { Text("Turn off timer") }
            }
        }
    }
}

@Composable
private fun QueueSheet(vm: PlayerViewModel, playing: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val corner = LocalAppSettings.current.corner
    val queue = remember { vm.queueSnapshot() }
    val index = remember { vm.currentIndex() }
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (index - 1).coerceIn(0, (queue.size - 1).coerceAtLeast(0)),
    )
    val rowShape = RoundedCornerShape((corner * 0.7f).coerceAtLeast(14f).dp)

    AuroraSheet(onDismiss = onDismiss, title = "Up next") {
        val context = LocalContext.current
        val savedText = tr("Queue saved as a playlist")
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${queue.size} songs in the queue",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            if (queue.isNotEmpty()) {
                TextButton(onClick = {
                    val stamp = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date())
                    vm.createPlaylist("Queue $stamp", queue.map { it.id })
                    Toast.makeText(context, savedText, Toast.LENGTH_SHORT).show()
                }) { Text("Save as playlist") }
            }
        }
        LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = 480.dp),
            state = listState,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            itemsIndexed(queue) { i, q ->
                val current = i == index
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(rowShape)
                        .background(
                            if (current) cs.primaryContainer.copy(alpha = 0.7f)
                            else cs.surfaceContainerHighest.copy(alpha = 0.55f)
                        )
                        .clickable { vm.jumpTo(i); onDismiss() }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Art(q.artUri, Modifier.size(46.dp), RoundedCornerShape(12.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(
                            verbatim(q.title),
                            style = MaterialTheme.typography.titleSmall,
                            color = if (current) cs.onPrimaryContainer else cs.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            verbatim(q.artist),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (current) {
                        EqualizerBars(active = playing, color = cs.primary)
                    } else {
                        Text("${i + 1}", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.size(6.dp))
                }
            }
        }
    }
}
