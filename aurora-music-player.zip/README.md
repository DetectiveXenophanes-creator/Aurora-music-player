# Aurora 2.1

Native Android music player (Kotlin, Jetpack Compose, Media3).

- Material You colours, matte or frosted-glass finish, drifting squiggly lines and circles in the background
- Home (daily mix, most played, listening stats), Songs, Playlists (customizable look and feel), Albums, Folders, Artists
- Songs: search, sort (title, artist, album, length, date added, most played) and filter (favorites, length)
- Reference-style Now Playing: line or wavy seek bar, format chip, pill controls, queue, sleep timer, Sound sheet (speed, pitch, equalizer)
- Five-band equalizer with presets, bass boost, loudness
- Animation sets with speed and intensity controls
- Backup and restore of playlists (song names, not audio), favorites and settings
- Tablet and landscape layouts (width-capped pages, adaptive grids, two-pane Now Playing)

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
The debug build type is configured as an optimized, non-debuggable build (R8 on) so Compose runs smoothly.
If that ever breaks the build, delete the `buildTypes { debug { ... } }` block in app/build.gradle.kts.
