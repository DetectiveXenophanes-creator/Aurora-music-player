# Aurora 2.3

Native Android music player (Kotlin, Jetpack Compose, Media3).

- Material You colours, matte or frosted-glass finish, drifting squiggly lines and circles in the background
- Home (daily mix, most played, listening stats), Songs, Playlists (customizable look and feel), Albums, Folders, Artists
- Songs: search, sort (title, artist, album, length, date added, most played) and filter (favorites, length)
- Reference-style Now Playing: line or wavy seek bar, format chip, pill controls, queue, sleep timer, Sound sheet (speed, pitch, equalizer)
- Five-band equalizer with presets, bass boost, loudness
- Animation sets with speed and intensity controls
- Themes tab: 13 preset themes, Material You, a live custom theme editor (hue, vibrancy, colour spread), saved themes and shareable theme codes
- 10 languages besides English (Polish, Spanish, French, German, Portuguese, Italian, Turkish, Russian, Japanese, Chinese) with a language button on the setup screen
- Northern-lights intro screen and an optional themed aurora glow behind the whole app
- Cover shapes (rounded, circle, spinning vinyl), font and text size, battery saver and background frame rate
- Backup and restore of playlists (song names, not audio), favorites and settings
- Tablet and landscape layouts (width-capped pages, adaptive grids, two-pane Now Playing)

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
The debug build type is configured as an optimized, non-debuggable build (R8 on) so Compose runs smoothly.
If that ever breaks the build, delete the `buildTypes { debug { ... } }` block in app/build.gradle.kts.

Adding a language: add its code to `order` in Translate.kt (and an entry in `AppLanguage`), then append one column to every row in Translations.kt. Blank cells fall back to English.
