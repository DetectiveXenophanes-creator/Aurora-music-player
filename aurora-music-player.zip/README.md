# Aurora 2.0

Native Android music player (Kotlin, Jetpack Compose, Media3).

- Material You colours, matte or frosted-glass finish, squiggle-line background
- Home (daily mix, most played), Songs, Playlists (customizable look and feel), Albums, Folders, Artists
- Reference-style Now Playing: line or wavy seek bar, format chip, pill controls, queue, sleep timer
- Animation sets with speed and intensity controls
- Audio settings (speed, pitch, skip silence, bass, loudness), folder scanning, startup tab, intro and setup

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
