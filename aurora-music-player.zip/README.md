# Aurora

Native Android music player (Kotlin, Jetpack Compose, Media3).

- Material You dynamic colour, with a generated accent palette fallback
- Matte or frosted-glass finish for bars, panels and cards (blur strength adjustable)
- Adjustable corner roundness, light/dark/system, true-black AMOLED mode
- Background playback with a media notification and lock-screen controls
- Plays the music already on the phone (MediaStore)

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
