# Changelog

## Song editor + battery pass

### New: song editor
- "Edit song info" in every song menu (song lists, Now Playing, playlists, albums, search).
- Change title, artist, album and cover art (picked with the system photo picker, no permission needed).
- "Use original cover" and "Restore original" undo your changes.
- Edits are stored inside Aurora and laid over the song everywhere: lists, queue, notification, lock screen, widget.
  Your audio files are never modified. Editing an artist regroups the song under that artist.
- Covers are shrunk to max 1200 px and kept in the app's private `covers` folder; deleted with the song.

### Battery
- Position tracking only runs while music is actually playing (it used to tick forever, even when paused).
- In the background the player is checked every 5 s instead of every 2 s, and wakes instantly when you open the app.
- Glow/ambient animation clock now stops fully when the app is off screen (it kept ticking while music played with the screen off).
- Audio offload: the phone's audio chip decodes the music so the CPU can sleep. Turns itself off while speed/pitch,
  skip silence, equalizer, bass or loudness are in use. Unsupported phones fall back to normal playback.
- "Balanced" power profile is cheaper: glow 15 -> 10 fps, spinning/mascot 25 -> 20 fps.

### Build
- Google's Maven Central mirror added ahead of Maven Central, plus longer timeouts and retries (fixes the "Could not find ... .jar" CI failure).

### Notes
- I could not compile or run this here. If the GitHub build shows an error, send me the first `e:` line.
- No app can promise a fixed "5%" battery figure: it depends on the phone, screen time and settings. Settings -> Power profile -> Efficient saves the most.

## Player styles + crossfade + volume levelling

### New: Player styles (Settings > Player)
- A gallery of five styles with small previews: Orbit, Classic, Vinyl, Waves, Compact.
- Tapping a style applies a bundle of the existing player settings (design, layout, cover shape, progress style, play button style),
  so everything can still be fine-tuned afterwards. The selected style is outlined; "Custom" shows when you changed things yourself.

### New: Transitions and volume (Settings > Audio)
- Crossfade 0 to 12 seconds: each song fades out at its end and the next fades in (songs do not overlap).
- Volume levelling Off / Light / Strong: a gentle compressor and limiter that evens out loud and quiet parts.
  Needs Android 9+, and turns audio offload off while it is on (a little more battery).

### Notes
- Not compiled here. If the GitHub build fails, the first `e:` line tells where.
- Sleep-timer fade and crossfade both change the volume; use one of them at a time if you hear odd volume jumps.

## Lyrics, per-device EQ, swipe actions, resume, On this day, more widgets

### Synced lyrics (Now Playing > notes button, both player designs)
- Reads lyrics saved inside MP3 files (ID3 USLT), a `.lrc` file next to the song (only where Android allows it),
  or an `.lrc` / `.txt` file you add yourself with "Add lyrics file" (kept inside Aurora, per song).
- Synced lines follow the music and highlight; tap a line to jump there. Size button (3 sizes) and Centre/Left.
- Not supported yet: lyrics saved inside FLAC/M4A tags and word-by-word highlighting.

### Separate EQ per output (Settings > Audio > Equalizer)
- Remembers the equalizer for phone speaker, wired headphones and Bluetooth, and switches when the output changes.
- Switches while Aurora is open (it is checked when the output changes and when the app starts).

### Swipe actions (Settings > Interface > Song rows)
- Pick what swiping a song right or left does: Nothing, Play next, Add to queue, Favorite. Off by default.

### Resume long tracks (Settings > Audio > Playback)
- Songs of 20+ minutes remember where you stopped and continue from there when you play them again.

### On this day (Home)
- New Home section with songs you played on today's date in earlier years. History starts with this version, so it fills up over time.
  Show, hide or move it in Settings > Home.

### Widgets
- Two new styles: Slim (extra thin bar) and Mini (small cover, title, one play button). Also selectable inside existing widgets.

### Notes
- Version code 17. Not compiled here; if the GitHub build fails send the first `e:` line.

## Fun extras (new, not in other players)

Settings > Player > Fun extras

- **Seek buddy**: pick an emoji friend (rocket, turtle, fox, moon, UFO, cat, frog, note) that rides along the progress bar.
- **Song stickers**: song menu > Set sticker. One emoji per song, shown next to the title in lists.
  Home gets a **Mood mixes** row (show/hide/move it in Settings > Home): tap an emoji to shuffle every song with that sticker.
- **Song story**: a fun fact under the title on Now Playing (play count, rank, playlists, first listen, how long ago it was added...).
  Tap it for the next fact. Works in both Orbit and Panel designs. Can be switched off.
- **Shake your phone**: shake to play next, previous, or toggle shuffle (Gentle / Normal / Hard strength).
- **Flip to pause**: put the phone face down to pause, turn it face up to continue.
  Gestures use the motion sensor only while music plays and a gesture is switched on.

Version code 18. Not compiled here; if the GitHub build fails send the first `e:` line.
