package com.aurora.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun rememberHaptic(): () -> Unit {
    val h = LocalHapticFeedback.current
    val on = LocalAppSettings.current.haptics
    return remember(h, on) {
        {
            if (on) h.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }
}

/** Squishes the element while it is pressed. Strength depends on the animation set. */
@Composable
fun Modifier.pressScale(source: InteractionSource): Modifier {
    val motion = LocalMotion.current
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) motion.pressScale else 1f,
        animationSpec = motion.spatial(),
        label = "press",
    )
    return this.graphicsLayer {
        scaleX = s
        scaleY = s
    }
}

/** Fade and rise in, staggered by index. Only used for the first rows that appear. */
@Composable
fun Modifier.enterAnim(enabled: Boolean, index: Int): Modifier {
    val motion = LocalMotion.current
    if (!enabled || !motion.enabled) return this
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((index.coerceAtMost(12) * motion.staggerMs).toLong())
        p.animateTo(1f, motion.spatial())
    }
    return this.graphicsLayer {
        alpha = p.value.coerceIn(0f, 1f)
        translationY = (1f - p.value) * 60f
    }
}

// ---------------------------------------------------------------- play / pause

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

private val pauseLeft = floatArrayOf(0f, 0f, 0.36f, 0f, 0.36f, 1f, 0f, 1f)
private val playLeft = floatArrayOf(0f, 0f, 0.5f, 0.25f, 0.5f, 0.75f, 0f, 1f)
private val pauseRight = floatArrayOf(0.64f, 0f, 1f, 0f, 1f, 1f, 0.64f, 1f)
private val playRight = floatArrayOf(0.5f, 0.25f, 1f, 0.5f, 1f, 0.5f, 0.5f, 0.75f)

private fun DrawScope.morphQuad(a: FloatArray, b: FloatArray, t: Float, shiftX: Float, color: Color, inset: Float) {
    val path = Path()
    val w = size.width - 2 * inset
    val h = size.height - 2 * inset
    for (i in 0 until 4) {
        val x = inset + lerpF(a[i * 2], b[i * 2], t) * w + shiftX
        val y = inset + lerpF(a[i * 2 + 1], b[i * 2 + 1], t) * h
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color)
    drawPath(path, color, style = Stroke(width = inset * 0.9f, join = StrokeJoin.Round))
}

/** Pause bars that morph into a play triangle (and back) with the current animation set. */
@Composable
fun PlayPauseIcon(playing: Boolean, tint: Color, iconSize: Dp) {
    val motion = LocalMotion.current
    val t by animateFloatAsState(
        targetValue = if (playing) 0f else 1f,
        animationSpec = motion.spatial(),
        label = "playPauseMorph",
    )
    Canvas(Modifier.size(iconSize)) {
        val inset = size.width * 0.12f
        morphQuad(pauseLeft, playLeft, t, t * size.width * 0.05f, tint, inset)
        morphQuad(pauseRight, playRight, t, t * size.width * 0.05f, tint, inset)
    }
}

@Composable
fun PlayPauseButton(
    playing: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 80.dp,
    tonal: Boolean = false,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val pct by animateFloatAsState(
        targetValue = when (s.playShape) {
            PlayShape.CIRCLE -> 50f
            PlayShape.SQUIRCLE -> 30f
            PlayShape.MORPH -> if (playing) 30f else 50f
        },
        animationSpec = motion.spatial(),
        label = "playShape",
    )
    val shape = RoundedCornerShape(diameter * (pct.coerceIn(0f, 50f) / 100f))
    val container = if (tonal) cs.primaryContainer else cs.primary
    val content = if (tonal) cs.onPrimaryContainer else cs.onPrimary
    Box(
        modifier
            .size(diameter)
            .pressScale(source)
            .clip(shape)
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        PlayPauseIcon(playing, content, diameter * 0.42f)
    }
}

// ---------------------------------------------------------------- skip

@Composable
fun SkipButton(
    forward: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 76.dp,
    height: Dp = 60.dp,
    iconSize: Dp = 30.dp,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val scope = rememberCoroutineScope()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val pct by animateFloatAsState(
        targetValue = if (pressed) 28f else 50f,
        animationSpec = motion.spatial(),
        label = "skipShape",
    )
    val nudge = remember { Animatable(0f) }
    val dist = with(LocalDensity.current) { 14.dp.toPx() }
    val dir = if (forward) 1f else -1f

    Box(
        modifier
            .size(width, height)
            .pressScale(source)
            .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
            .background(cs.secondaryContainer)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
                if (motion.enabled) {
                    scope.launch {
                        // Icon slides out in its direction, then re-enters from behind.
                        nudge.snapTo(0f)
                        nudge.animateTo(dir * dist, tween(90))
                        nudge.snapTo(-dir * dist)
                        nudge.animateTo(0f, motion.spatial())
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (forward) Icons.Rounded.SkipNext else Icons.Rounded.SkipPrevious,
            contentDescription = if (forward) "Next" else "Previous",
            tint = cs.onSecondaryContainer,
            modifier = Modifier
                .size(iconSize)
                .graphicsLayer {
                    translationX = nudge.value
                    alpha = (1f - abs(nudge.value) / dist).coerceIn(0f, 1f)
                },
        )
    }
}

@Composable
fun ToggleIcon(active: Boolean, icon: ImageVector, description: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val container by animateColorAsState(
        targetValue = if (active) cs.primaryContainer else Color.Transparent,
        animationSpec = motion.effects(),
        label = "toggleContainer",
    )
    val tint by animateColorAsState(
        targetValue = if (active) cs.onPrimaryContainer else cs.onSurfaceVariant,
        animationSpec = motion.effects(),
        label = "toggleTint",
    )
    val pct by animateFloatAsState(
        targetValue = if (active) 30f else 50f,
        animationSpec = motion.spatial(),
        label = "toggleShape",
    )
    Box(
        Modifier
            .size(48.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
            .background(container)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = tint)
    }
}

// ---------------------------------------------------------------- equalizer

@Composable
fun EqualizerBars(active: Boolean, color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(
        0.25f, 1f,
        infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "a",
    )
    val b by t.animateFloat(
        0.30f, 1f,
        infiniteRepeatable(tween(690, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b",
    )
    val c by t.animateFloat(
        0.20f, 1f,
        infiniteRepeatable(tween(410, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "c",
    )
    val level by animateFloatAsState(if (active) 1f else 0f, animationSpec = tween(250), label = "eqLevel")
    Canvas(modifier) {
        val bw = size.width / 5f
        val hs = floatArrayOf(a, b, c)
        for (i in 0 until 3) {
            val hh = size.height * (0.25f + (hs[i] - 0.25f) * level)
            drawRoundRect(
                color,
                topLeft = Offset(bw * i * 2f, size.height - hh),
                size = Size(bw, hh),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}

// ---------------------------------------------------------------- seek bar

private fun fracOf(x: Float, width: Int, pad: Float): Float =
    if (width <= 2 * pad) 0f else ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)

/**
 * Seek bar. In WAVY mode the played part is a travelling sine wave that flattens when paused or
 * while you drag. The thumb is a pill that grows when touched.
 */
@Composable
fun SeekBar(
    progress: Float,
    playing: Boolean,
    wavy: Boolean,
    onPreview: (Float?) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val motion = LocalMotion.current
    var dragging by remember { mutableStateOf<Float?>(null) }
    val currentOnSeek by rememberUpdatedState(onSeek)
    val currentOnPreview by rememberUpdatedState(onPreview)

    val amp by animateFloatAsState(
        targetValue = if (wavy && playing && dragging == null) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "waveAmp",
    )
    val thumbGrow by animateFloatAsState(
        targetValue = if (dragging != null) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "thumbGrow",
    )
    val shown by animateFloatAsState(
        targetValue = dragging ?: progress,
        animationSpec = if (dragging != null) snap() else tween(420, easing = LinearEasing),
        label = "seekProgress",
    )
    val infinite = rememberInfiniteTransition(label = "wave")
    val speed = motion.waveSpeed
    val phase by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(if (speed > 0f) (1800 / speed).toInt() else 1_000_000, easing = LinearEasing)),
        label = "phase",
    )
    val primary = cs.primary
    val track = cs.primary.copy(alpha = 0.25f)

    Canvas(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .pointerInput(Unit) {
                val pad = 8.dp.toPx()
                detectTapGestures { o -> currentOnSeek(fracOf(o.x, size.width, pad)) }
            }
            .pointerInput(Unit) {
                val pad = 8.dp.toPx()
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val f = fracOf(o.x, size.width, pad)
                        dragging = f
                        currentOnPreview(f)
                    },
                    onDragEnd = {
                        dragging?.let { currentOnSeek(it) }
                        dragging = null
                        currentOnPreview(null)
                    },
                    onDragCancel = {
                        dragging = null
                        currentOnPreview(null)
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val f = fracOf(change.position.x, size.width, pad)
                        dragging = f
                        currentOnPreview(f)
                    },
                )
            },
    ) {
        val pad = 8.dp.toPx()
        val w = size.width
        val cy = size.height / 2f
        val stroke = 6.dp.toPx()
        val ampPx = 5.dp.toPx() * amp
        val wavelength = 30.dp.toPx()
        val x = pad + (w - 2 * pad) * shown.coerceIn(0f, 1f)
        val gap = 4.dp.toPx() + 3.dp.toPx() * thumbGrow

        if (x + gap < w - pad) {
            drawLine(track, Offset(x + gap, cy), Offset(w - pad, cy), stroke, StrokeCap.Round)
        }

        val end = (x - gap).coerceAtLeast(pad)
        val path = Path()
        var px = pad
        path.moveTo(px, cy + ampPx * sin(-phase))
        while (px < end) {
            px = min(px + 3f, end)
            val taper = min(1f, (px - pad) / (24.dp.toPx()))
            path.lineTo(px, cy + ampPx * taper * sin((px - pad) / wavelength * 2f * PI.toFloat() - phase))
        }
        drawPath(path, primary, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))

        val th = 22.dp.toPx() + 8.dp.toPx() * thumbGrow
        val tw = 5.dp.toPx() - 1.5.dp.toPx() * thumbGrow
        drawRoundRect(
            primary,
            topLeft = Offset(x - tw / 2f, cy - th / 2f),
            size = Size(tw, th),
            cornerRadius = CornerRadius(tw / 2f),
        )
    }
}
