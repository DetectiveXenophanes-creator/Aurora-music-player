package com.aurora.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource

@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val pos by vm.position.collectAsState()
    val settings = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val haze = remember { HazeState() }
    val song = ui.current
    val panelShape = RoundedCornerShape((settings.corner * 1.4f).dp)
    var preview by remember { mutableStateOf<Float?>(null) }

    val view = LocalView.current
    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    val progress = if (ui.duration > 0) (pos.toFloat() / ui.duration).coerceIn(0f, 1f) else 0f
    val artScale by animateFloatAsState(
        targetValue = if (!settings.artBreathing || ui.isPlaying) 1f else 0.88f,
        animationSpec = motion.spatial(),
        label = "artScale",
    )

    CompositionLocalProvider(LocalHazeState provides haze) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AuroraBackground(song, overlayArt = true)
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }
                    Text("Now playing", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.weight(1f))

                Box(
                    Modifier
                        .fillMaxWidth(0.82f)
                        .aspectRatio(1f)
                        .graphicsLayer {
                            scaleX = artScale
                            scaleY = artScale
                        },
                ) {
                    AnimatedContent(
                        targetState = song,
                        transitionSpec = { motion.songChange() },
                        label = "art",
                        modifier = Modifier.fillMaxSize(),
                    ) { s ->
                        if (s != null) Art(s.artUri, Modifier.fillMaxSize(), panelShape)
                    }
                }
                Spacer(Modifier.weight(1f))

                Column(Modifier.fillMaxWidth().finish(panelShape).padding(20.dp)) {
                    AnimatedContent(
                        targetState = song?.title ?: "Nothing playing",
                        transitionSpec = { motion.text() },
                        label = "title",
                    ) { t ->
                        Text(
                            t,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    AnimatedContent(
                        targetState = song?.artist ?: "",
                        transitionSpec = { motion.text() },
                        label = "artist",
                    ) { a ->
                        Text(
                            a,
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    SeekBar(
                        progress = progress,
                        playing = ui.isPlaying,
                        wavy = settings.seekStyle == SeekStyle.WAVY,
                        onPreview = { preview = it },
                        onSeek = { f -> vm.seekTo((f * ui.duration).toLong()) },
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            fmt(((preview ?: progress) * ui.duration).toLong()),
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Text(fmt(ui.duration), style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ToggleIcon(ui.shuffle, Icons.Rounded.Shuffle, "Shuffle") { vm.toggleShuffle() }
                        SkipButton(forward = false, onClick = { vm.previous() }, width = 64.dp, height = 56.dp)
                        PlayPauseButton(playing = ui.isPlaying, onClick = { vm.togglePlay() }, diameter = 80.dp)
                        SkipButton(forward = true, onClick = { vm.next() }, width = 64.dp, height = 56.dp)
                        ToggleIcon(
                            active = ui.repeat != Player.REPEAT_MODE_OFF,
                            icon = if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            description = "Repeat",
                        ) { vm.cycleRepeat() }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
