package com.aurora.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

@Composable
fun SongsScreen(
    songs: List<Song>,
    currentId: Long?,
    playing: Boolean,
    granted: Boolean,
    onRequest: () -> Unit,
    padding: PaddingValues,
    onPlay: (Song, List<Song>) -> Unit,
    onShuffleAll: (List<Song>) -> Unit,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val compact = s.density == ListDensity.COMPACT
    val shape = RoundedCornerShape(s.corner.dp)
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    // Rows that have already played their entrance animation do not play it again.
    val seen = remember { HashSet<Long>() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding(),
            bottom = padding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 8.dp),
    ) {
        if (!granted) {
            item {
                InfoCard(
                    title = "Allow music access",
                    body = "Aurora needs permission to read the audio files on your phone.",
                    action = "Allow",
                    onAction = onRequest,
                )
            }
        } else {
            item {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search songs, artists, albums") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth().cardFinish(shape),
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(onClick = { onShuffleAll(filtered) }, enabled = filtered.isNotEmpty()) {
                        Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Shuffle all")
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${filtered.size} songs",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (songs.isEmpty()) {
                item { InfoCard("No music found", "Copy some audio files onto this phone and reopen Aurora.", null) {} }
            }
            itemsIndexed(filtered, key = { _, song -> song.id }) { index, song ->
                val animate = remember { seen.add(song.id) } && s.listEntrance
                SongRow(
                    song = song,
                    current = song.id == currentId,
                    playing = playing,
                    modifier = Modifier
                        .animateItem(
                            fadeInSpec = if (motion.enabled) motion.effects<Float>() else null,
                            placementSpec = if (motion.enabled) motion.spatial<IntOffset>() else null,
                            fadeOutSpec = if (motion.enabled) motion.effects<Float>() else null,
                        )
                        .enterAnim(animate, index),
                ) { onPlay(song, filtered) }
            }
        }
    }
}

@Composable
private fun SongRow(song: Song, current: Boolean, playing: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    val compact = s.density == ListDensity.COMPACT
    val shape = RoundedCornerShape(s.corner.dp)
    val artSize = if (compact) 40.dp else 52.dp
    val pad = if (compact) 6.dp else 10.dp
    val borderColor by animateColorAsState(
        targetValue = if (current) cs.primary.copy(alpha = 0.7f) else Color.Transparent,
        animationSpec = motion.effects(),
        label = "rowBorder",
    )
    val titleColor by animateColorAsState(
        targetValue = if (current) cs.primary else cs.onSurface,
        animationSpec = motion.effects(),
        label = "rowTitle",
    )
    Row(
        modifier
            .fillMaxWidth()
            .cardFinish(shape)
            .border(1.5.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(pad),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (s.listArt) {
            Art(song.artUri, Modifier.size(artSize), RoundedCornerShape((s.corner * 0.5f).dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = if (s.listArt) 12.dp else 8.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.titleMedium,
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                song.artist,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (current) {
            EqualizerBars(active = playing, color = cs.primary)
            Spacer(Modifier.width(10.dp))
        }
        Text(fmt(song.durationMs), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun InfoCard(title: String, body: String, action: String?, onAction: () -> Unit) {
    val corner = LocalAppSettings.current.corner
    Column(
        Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) FilledTonalButton(onClick = onAction) { Text(action) }
    }
}
