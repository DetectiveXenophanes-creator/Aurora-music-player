package com.aurora.player

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private val swatches = listOf(
    0xFF6750A4, 0xFF0B6BCB, 0xFF00897B, 0xFF1B8A5A,
    0xFFD9480F, 0xFFC2185B, 0xFFB00020, 0xFF5D4037,
).map { it.toInt() }

private enum class SettingsTab(val label: String, val icon: ImageVector) {
    CUSTOMIZATION("Customization", Icons.Rounded.Palette),
    ANIMATIONS("Animations", Icons.Rounded.AutoAwesome),
    PLAYER("Player", Icons.Rounded.PlayCircle),
    ABOUT("About", Icons.Rounded.Info),
}

@Composable
fun SettingsScreen(
    s: AppSettings,
    padding: PaddingValues,
    onUpdate: ((AppSettings) -> AppSettings) -> Unit,
) {
    val motion = LocalMotion.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(top = padding.calculateTopPadding()),
    ) {
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SettingsTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t.ordinal,
                    onClick = { tab = t.ordinal },
                    label = { Text(t.label) },
                    leadingIcon = { Icon(t.icon, null, Modifier.size(18.dp)) },
                )
            }
        }

        AnimatedContent(
            targetState = tab,
            transitionSpec = { motion.tab(targetState > initialState) },
            label = "settingsTab",
            modifier = Modifier.fillMaxSize(),
        ) { t ->
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(
                        start = 16.dp,
                        end = 16.dp,
                        top = 12.dp,
                        bottom = padding.calculateBottomPadding(),
                    ),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when (SettingsTab.entries[t]) {
                    SettingsTab.CUSTOMIZATION -> CustomizationTab(s, onUpdate)
                    SettingsTab.ANIMATIONS -> AnimationsTab(s, onUpdate)
                    SettingsTab.PLAYER -> PlayerTab(s, onUpdate)
                    SettingsTab.ABOUT -> AboutTab(onUpdate)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ tabs

@Composable
private fun CustomizationTab(s: AppSettings, onUpdate: ((AppSettings) -> AppSettings) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val canDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    SettingCard("Component finish") {
        Segmented(
            options = listOf("Matte" to SurfaceStyle.MATTE, "Frosted glass" to SurfaceStyle.GLASS),
            selected = s.style,
            onSelect = { v -> onUpdate { it.copy(style = v) } },
        )
        Text(
            if (s.style == SurfaceStyle.GLASS)
                "Bars and panels blur what is behind them. Full blur needs Android 12 or newer; older phones get a frosted tint."
            else
                "Solid, opaque surfaces with no transparency.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
        )
        if (s.style == SurfaceStyle.GLASS) {
            SliderRow("Blur strength", s.blur, 4f..48f, "${s.blur.roundToInt()}") { v -> onUpdate { it.copy(blur = v) } }
            SliderRow("Frost tint", s.glassTint, 0.1f..0.9f, "${(s.glassTint * 100).roundToInt()}%") { v ->
                onUpdate { it.copy(glassTint = v) }
            }
            ToggleRow("Glass edge highlight", "A light rim around glass panels", s.edgeHighlight, true) { v ->
                onUpdate { it.copy(edgeHighlight = v) }
            }
        }
    }

    SettingCard("Shape and layout") {
        SliderRow("Corner roundness", s.corner, 6f..40f, "${s.corner.roundToInt()}") { v -> onUpdate { it.copy(corner = v) } }
        Text("Play button shape", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Morph" to PlayShape.MORPH, "Circle" to PlayShape.CIRCLE, "Squircle" to PlayShape.SQUIRCLE),
            selected = s.playShape,
            onSelect = { v -> onUpdate { it.copy(playShape = v) } },
        )
        Text("Song list density", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Comfortable" to ListDensity.COMFORTABLE, "Compact" to ListDensity.COMPACT),
            selected = s.density,
            onSelect = { v -> onUpdate { it.copy(density = v) } },
        )
        ToggleRow("Album art in song list", "Show cover thumbnails", s.listArt, true) { v ->
            onUpdate { it.copy(listArt = v) }
        }
        ToggleRow("Navigation labels", "Show text under the bottom icons", s.navLabels, true) { v ->
            onUpdate { it.copy(navLabels = v) }
        }
    }

    SettingCard("Colour") {
        Segmented(
            options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
            selected = s.themeMode,
            onSelect = { v -> onUpdate { it.copy(themeMode = v) } },
        )
        ToggleRow(
            title = "Material You colours",
            subtitle = if (canDynamic) "Use colours from your wallpaper" else "Needs Android 12 or newer",
            checked = s.dynamicColor && canDynamic,
            enabled = canDynamic,
        ) { v -> onUpdate { it.copy(dynamicColor = v) } }
        Text("Accent colour", style = MaterialTheme.typography.labelLarge)
        val dynamicActive = s.dynamicColor && canDynamic
        Row(
            Modifier.horizontalScroll(rememberScrollState()).alpha(if (dynamicActive) 0.4f else 1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            swatches.forEach { c ->
                val selected = !dynamicActive && s.accent == c
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (selected) 3.dp else 0.dp, cs.onSurface, CircleShape)
                        .clickable { onUpdate { it.copy(accent = c, dynamicColor = false) } }
                )
            }
        }
        ToggleRow("True black (AMOLED)", "Pure black backgrounds in dark mode", s.amoled, true) { v ->
            onUpdate { it.copy(amoled = v) }
        }
    }

    SettingCard("Background") {
        Segmented(
            options = listOf(
                "Gradient" to BackgroundStyle.GRADIENT,
                "Album art" to BackgroundStyle.ALBUM,
                "Flat" to BackgroundStyle.FLAT,
            ),
            selected = s.background,
            onSelect = { v -> onUpdate { it.copy(background = v) } },
        )
    }

    SettingCard("Now playing") {
        Text("Seek bar style", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Wavy" to SeekStyle.WAVY, "Line" to SeekStyle.LINE),
            selected = s.seekStyle,
            onSelect = { v -> onUpdate { it.copy(seekStyle = v) } },
        )
    }
}

@Composable
private fun AnimationsTab(s: AppSettings, onUpdate: ((AppSettings) -> AppSettings) -> Unit) {
    val cs = MaterialTheme.colorScheme
    SettingCard("Animation set") {
        AnimSet.entries.forEach { set ->
            val selected = s.animSet == set
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onUpdate { it.copy(animSet = set) } }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = selected, onClick = { onUpdate { it.copy(animSet = set) } })
                Column(Modifier.weight(1f)) {
                    Text(set.label, style = MaterialTheme.typography.bodyLarge)
                    Text(set.blurb, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }

    SettingCard("Try it") {
        Text("Tap the track to feel the selected set.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        MotionPreview()
    }

    SettingCard("Speed") {
        SliderRow("Animation speed", s.animSpeed, 0.5f..2f, "%.1f×".format(s.animSpeed)) { v ->
            onUpdate { it.copy(animSpeed = v) }
        }
    }

    SettingCard("Effects") {
        ToggleRow("List entrance", "Rows rise in one after another", s.listEntrance, true) { v ->
            onUpdate { it.copy(listEntrance = v) }
        }
        ToggleRow("Artwork breathing", "Cover shrinks slightly while paused", s.artBreathing, true) { v ->
            onUpdate { it.copy(artBreathing = v) }
        }
    }
}

@Composable
private fun PlayerTab(s: AppSettings, onUpdate: ((AppSettings) -> AppSettings) -> Unit) {
    SettingCard("Feedback") {
        ToggleRow("Haptic feedback", "Small vibration when you tap player buttons", s.haptics, true) { v ->
            onUpdate { it.copy(haptics = v) }
        }
        ToggleRow("Keep screen on", "While the Now Playing screen is open", s.keepScreenOn, true) { v ->
            onUpdate { it.copy(keepScreenOn = v) }
        }
    }
    SettingCard("Library") {
        Text("Hide short tracks", style = MaterialTheme.typography.labelLarge)
        Segmented(
            options = listOf("Show all" to 0, "Under 30s" to 30, "Under 60s" to 60),
            selected = s.minDurationSec,
            onSelect = { v -> onUpdate { it.copy(minDurationSec = v) } },
        )
    }
}

@Composable
private fun AboutTab(onUpdate: ((AppSettings) -> AppSettings) -> Unit) {
    SettingCard("Aurora") {
        Text("Version 1.1.0", style = MaterialTheme.typography.bodyLarge)
        Text(
            "A native Android music player with Material You colours, matte or frosted glass finishes and swappable animation sets.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    SettingCard("Reset") {
        FilledTonalButton(onClick = { onUpdate { AppSettings() } }) { Text("Reset all settings") }
    }
}

// ------------------------------------------------------------------ pieces

@Composable
private fun MotionPreview() {
    val motion = LocalMotion.current
    val cs = MaterialTheme.colorScheme
    var right by remember { mutableStateOf(false) }
    val x by animateFloatAsState(
        targetValue = if (right) 1f else 0f,
        animationSpec = motion.spatial(),
        label = "preview",
    )
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(cs.surfaceContainerHighest.copy(alpha = 0.5f))
            .clickable { right = !right },
    ) {
        Box(
            Modifier
                .padding(8.dp)
                .offset(x = (maxWidth - 64.dp) * x)
                .size(48.dp)
                .clip(CircleShape)
                .background(cs.primary)
        )
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable () -> Unit) {
    val corner = LocalAppSettings.current.corner
    Column(
        Modifier.fillMaxWidth().cardFinish(RoundedCornerShape(corner.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val dragging by source.collectIsDraggedAsState()
    var local by remember { mutableFloatStateOf(value) }
    if (!dragging) local = value
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Text(display, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = local,
            onValueChange = { local = it; onChange(it) },
            valueRange = range,
            interactionSource = source,
        )
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (label, value) ->
            SegmentedButton(
                selected = value == selected,
                onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
                label = { Text(label) },
            )
        }
    }
}
