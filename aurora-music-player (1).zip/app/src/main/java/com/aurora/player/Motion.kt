package com.aurora.player

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import kotlin.math.max
import kotlin.math.roundToInt

enum class AnimSet(val label: String, val blurb: String) {
    SMOOTH("Smooth", "Gentle, eased motion. The balanced default."),
    BOUNCY("Bouncy", "Springy and playful, with a bit of overshoot."),
    SNAPPY("Snappy", "Fast and crisp. Responds instantly."),
    FLUID("Fluid", "Slow, floaty and soft, like liquid."),
    MINIMAL("Minimal", "Almost no motion. Quick fades only."),
}

/** One animation set: springs, fades, press feel and screen transitions all come from here. */
@Immutable
class Motion(val set: AnimSet, speed: Float) {
    private val k = speed.coerceIn(0.4f, 2.5f)
    val enabled: Boolean = set != AnimSet.MINIMAL

    private val damping = when (set) {
        AnimSet.SMOOTH -> 0.9f
        AnimSet.BOUNCY -> 0.45f
        AnimSet.SNAPPY -> 0.8f
        AnimSet.FLUID -> 0.7f
        AnimSet.MINIMAL -> 1f
    }
    private val stiffness = when (set) {
        AnimSet.SMOOTH -> 380f
        AnimSet.BOUNCY -> 300f
        AnimSet.SNAPPY -> 900f
        AnimSet.FLUID -> 120f
        AnimSet.MINIMAL -> 1500f
    } * k * k
    private val fadeMs = when (set) {
        AnimSet.SMOOTH -> 300
        AnimSet.BOUNCY -> 250
        AnimSet.SNAPPY -> 140
        AnimSet.FLUID -> 520
        AnimSet.MINIMAL -> 90
    }

    val staggerMs: Int = when (set) {
        AnimSet.SMOOTH -> 28
        AnimSet.BOUNCY -> 38
        AnimSet.SNAPPY -> 14
        AnimSet.FLUID -> 50
        AnimSet.MINIMAL -> 0
    }
    val pressScale: Float = when (set) {
        AnimSet.SMOOTH -> 0.94f
        AnimSet.BOUNCY -> 0.84f
        AnimSet.SNAPPY -> 0.96f
        AnimSet.FLUID -> 0.92f
        AnimSet.MINIMAL -> 1f
    }
    val waveSpeed: Float = when (set) {
        AnimSet.SMOOTH -> 1f
        AnimSet.BOUNCY -> 1.5f
        AnimSet.SNAPPY -> 2f
        AnimSet.FLUID -> 0.6f
        AnimSet.MINIMAL -> 0f
    } * k

    /** Spring used for size, position, shape and scale. */
    fun <T> spatial(): FiniteAnimationSpec<T> = spring<T>(dampingRatio = damping, stiffness = stiffness)

    /** Tween used for fades and colour changes. */
    fun <T> effects(): FiniteAnimationSpec<T> =
        tween<T>(durationMillis = max(1, (fadeMs / k).roundToInt()), easing = FastOutSlowInEasing)

    fun tab(forward: Boolean): ContentTransform {
        val dir = if (forward) 1 else -1
        return when (set) {
            AnimSet.MINIMAL -> fadeIn(effects()) togetherWith fadeOut(effects())
            AnimSet.SNAPPY ->
                (slideInHorizontally(spatial()) { it * dir / 2 } + fadeIn(effects())) togetherWith
                    (slideOutHorizontally(spatial()) { -it * dir / 2 } + fadeOut(effects()))
            AnimSet.BOUNCY ->
                (slideInHorizontally(spatial()) { it * dir / 3 } + fadeIn(effects()) + scaleIn(spatial(), 0.85f)) togetherWith
                    (fadeOut(effects()) + scaleOut(effects(), 0.9f))
            AnimSet.FLUID ->
                (slideInVertically(spatial()) { it / 10 } + fadeIn(effects()) + scaleIn(spatial(), 0.94f)) togetherWith
                    (slideOutVertically(effects()) { -it / 14 } + fadeOut(effects()))
            AnimSet.SMOOTH ->
                (slideInHorizontally(spatial()) { it * dir / 4 } + fadeIn(effects())) togetherWith
                    (slideOutHorizontally(spatial()) { -it * dir / 4 } + fadeOut(effects()))
        }
    }

    fun songChange(): ContentTransform =
        if (!enabled) {
            fadeIn(effects()) togetherWith fadeOut(effects())
        } else {
            (fadeIn(effects()) + scaleIn(spatial(), 0.82f)) togetherWith (fadeOut(effects()) + scaleOut(effects(), 1.12f))
        }

    fun text(): ContentTransform =
        if (!enabled) {
            fadeIn(effects()) togetherWith fadeOut(effects())
        } else {
            (slideInVertically(spatial()) { it / 2 } + fadeIn(effects())) togetherWith
                (slideOutVertically(effects()) { -it / 2 } + fadeOut(effects()))
        }

    fun miniEnter(): EnterTransition = slideInVertically(spatial()) { it } + fadeIn(effects())
    fun miniExit(): ExitTransition = slideOutVertically(effects()) { it } + fadeOut(effects())
}

val LocalMotion = staticCompositionLocalOf { Motion(AnimSet.SMOOTH, 1f) }
