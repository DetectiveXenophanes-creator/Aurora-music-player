package com.aurora.player

import androidx.compose.foundation.Canvas
import kotlin.math.roundToInt
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** The moving background of the Current interface. The Legacy interface keeps the old background settings. */
enum class BackdropStyle(val label: String) {
    ORBS("Liquid light"), CURTAINS("Curtains"), WAVES("Waves"), NIGHT("Night sky"), PLAIN("Plain")
}

enum class BackdropPalette(val label: String) {
    THEME("Theme"), AURORA("Aurora"), SUNSET("Sunset"), OCEAN("Ocean"), CANDY("Candy"), RAINBOW("Rainbow"), CUSTOM("Custom")
}

private fun backdropColors(p: BackdropPalette, cs: ColorScheme, a: Int, b: Int): List<Color> = when (p) {
    BackdropPalette.THEME -> listOf(cs.primary, cs.tertiary, cs.secondary)
    BackdropPalette.AURORA -> listOf(Color(0xFF2EE6A6), Color(0xFF3AA9FF), Color(0xFF8A5CFF))
    BackdropPalette.SUNSET -> listOf(Color(0xFFFF7A59), Color(0xFFFF4F9A), Color(0xFF8E44FF))
    BackdropPalette.OCEAN -> listOf(Color(0xFF00C2FF), Color(0xFF00E5B0), Color(0xFF2F5BFF))
    BackdropPalette.CANDY -> listOf(Color(0xFFFF6FD8), Color(0xFF7AF0FF), Color(0xFFFFE066))
    BackdropPalette.RAINBOW -> listOf(
        Color(0xFFFF5A5A), Color(0xFFFFC93C), Color(0xFF4CE08B), Color(0xFF3AA9FF), Color(0xFFB45CFF),
    )
    BackdropPalette.CUSTOM -> listOf(Color(a), Color(b), lerp(Color(a), Color(b), 0.5f))
}

/**
 * Moving light behind the whole Current interface. Five styles, all drawn with a handful of shapes and redrawn at the
 * background frame rate. It stands still in battery saver, under full-screen pages, and (unless "Animate when paused"
 * is on) while the music is paused.
 */
@Composable
fun AuroraBackdrop() {
    val s = LocalAppSettings.current
    if (s.backdrop == BackdropStyle.PLAIN) return
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val paused = LocalBackgroundPaused.current
    val playing = LocalIsPlaying.current
    val running = !paused && !s.batterySaver && (playing || s.ambientWhenPaused)
    val clock = rememberThrottledClock(running, s.bgFps.coerceIn(8, 30))
    val colors = remember(s.backdropPalette, s.backdropColorA, s.backdropColorB, cs.primary, cs.secondary, cs.tertiary) {
        backdropColors(s.backdropPalette, cs, s.backdropColorA, s.backdropColorB)
    }
    val k = s.backdropIntensity * if (dark) 0.55f else 0.40f
    val blend = if (dark) BlendMode.Plus else BlendMode.SrcOver
    val style = s.backdrop
    val speed = s.backdropSpeed
    val scale = s.backdropScale
    Canvas(Modifier.fillMaxSize()) {
        val t = clock.value * speed
        when (style) {
            BackdropStyle.ORBS -> drawOrbs(t, colors, k, scale, blend)
            BackdropStyle.CURTAINS -> drawCurtainBands(t, colors, k, scale, blend)
            BackdropStyle.WAVES -> drawWaves(t, colors, k, scale, blend)
            BackdropStyle.NIGHT -> drawNight(t, colors, k, scale, dark, blend)
            BackdropStyle.PLAIN -> Unit
        }
    }
}

/** Big soft balls of colour that float around on slow loops and melt into each other. */
private fun DrawScope.drawOrbs(t: Float, colors: List<Color>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val m = max(w, h)
    for (i in 0 until 6) {
        val c = colors[i % colors.size]
        val sp = 0.07f + 0.035f * (i % 3)
        val cx = w * (0.5f + 0.44f * sin(t * sp * 2.1f + i * 1.7f))
        val cy = h * (0.5f + 0.42f * cos(t * sp * 1.7f + i * 2.3f))
        val r = m * (0.30f + 0.08f * (i % 4)) * scale
        val pulse = 0.85f + 0.15f * sin(t * 0.35f + i)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(c.copy(alpha = (k * pulse).coerceIn(0f, 1f)), Color.Transparent),
                center = Offset(cx, cy),
                radius = r,
            ),
            radius = r,
            center = Offset(cx, cy),
            blendMode = blend,
        )
    }
}

/** Northern-light bands that ripple across the upper part of the screen. */
private fun DrawScope.drawCurtainBands(t: Float, colors: List<Color>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val steps = 28
    for (i in 0 until 4) {
        val c = colors[i % colors.size]
        val baseY = h * (0.16f + 0.09f * i)
        val amp = h * 0.07f * scale
        val band = h * (0.30f + 0.06f * i) * scale
        val path = Path()
        for (s in 0..steps) {
            val u = s / steps.toFloat()
            val y = baseY + amp * sin(u * (3.2f + i) + t * (0.20f + 0.05f * i) + i * 1.9f) +
                amp * 0.5f * sin(u * 9f - t * 0.33f + i)
            if (s == 0) path.moveTo(w * u, y) else path.lineTo(w * u, y)
        }
        for (s in steps downTo 0) {
            val u = s / steps.toFloat()
            val y = baseY + band * (0.6f + 0.4f * sin(u * 5.5f + t * 0.17f + i * 2.4f)) +
                amp * sin(u * (3.2f + i) + t * (0.20f + 0.05f * i) + i * 1.9f)
            path.lineTo(w * u, y)
        }
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(c.copy(alpha = 0f), c.copy(alpha = (k * 0.95f).coerceIn(0f, 1f)), c.copy(alpha = 0f)),
                startY = baseY - amp * 1.5f,
                endY = baseY + band * 1.1f,
            ),
            blendMode = blend,
        )
    }
}

/** Layers of slow waves rising from the bottom, with a soft glow high up like a low sun. */
private fun DrawScope.drawWaves(t: Float, colors: List<Color>, k: Float, scale: Float, blend: BlendMode) {
    val w = size.width
    val h = size.height
    drawCircle(
        brush = Brush.radialGradient(
            listOf(colors[0].copy(alpha = (k * 0.7f).coerceIn(0f, 1f)), Color.Transparent),
            center = Offset(w * 0.5f, h * 0.22f),
            radius = w * 0.7f * scale,
        ),
        radius = w * 0.7f * scale,
        center = Offset(w * 0.5f, h * 0.22f),
        blendMode = blend,
    )
    val step = max(8f, w / 40f)
    for (i in 0 until 5) {
        val c = colors[(i + 1) % colors.size]
        val base = h * (0.52f + 0.09f * i)
        val amp = h * (0.035f + 0.008f * i) * scale
        val dir = if (i % 2 == 0) 1f else -1f
        val path = Path()
        path.moveTo(0f, h)
        var x = 0f
        while (x <= w + step) {
            val u = x / w
            val y = base + amp * sin(u * (2.2f + 0.7f * i) * PI.toFloat() + t * (0.25f + 0.07f * i) * dir + i * 1.3f) +
                amp * 0.4f * sin(u * 11f + t * 0.4f + i)
            path.lineTo(x, y)
            x += step
        }
        path.lineTo(w, h)
        path.close()
        drawPath(
            path,
            Brush.verticalGradient(
                listOf(c.copy(alpha = (k * (0.55f + 0.1f * i)).coerceIn(0f, 1f)), c.copy(alpha = 0f)),
                startY = base - amp,
                endY = h,
            ),
            blendMode = blend,
        )
    }
}

private class Sparkle(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float)

private val sparkles = Random(7).let { rnd ->
    List(110) { Sparkle(rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * 1.6f, 0.4f + rnd.nextFloat() * 1.6f, rnd.nextFloat() * 6.28f) }
}

private fun fract(v: Float): Float = v - kotlin.math.floor(v)

/** Twinkling stars that drift sideways under two slow clouds of colour, with a shooting star now and then. */
private fun DrawScope.drawNight(t: Float, colors: List<Color>, k: Float, scale: Float, dark: Boolean, blend: BlendMode) {
    val w = size.width
    val h = size.height
    val m = max(w, h)
    for (i in 0 until 2) {
        val c = colors[i % colors.size]
        val cx = w * (0.3f + 0.4f * i + 0.12f * sin(t * 0.05f + i * 2f))
        val cy = h * (0.25f + 0.35f * i + 0.08f * cos(t * 0.04f + i))
        drawCircle(
            brush = Brush.radialGradient(
                listOf(c.copy(alpha = (k * 0.8f).coerceIn(0f, 1f)), Color.Transparent),
                center = Offset(cx, cy),
                radius = m * 0.55f * scale,
            ),
            radius = m * 0.55f * scale,
            center = Offset(cx, cy),
            blendMode = blend,
        )
    }
    val bright = (0.35f + 0.65f * min(1f, k * 1.8f))
    for ((i, st) in sparkles.withIndex()) {
        val tw = 0.5f + 0.5f * sin(t * st.speed + st.phase)
        val px = fract(st.x + t * 0.004f * (0.4f + st.r * 0.3f)) * w
        val base = if (dark) Color.White else colors[i % colors.size]
        val tint = if (dark) lerp(base, colors[i % colors.size], 0.3f) else base
        drawCircle(
            tint.copy(alpha = ((0.15f + 0.85f * tw) * bright).coerceIn(0f, 1f)),
            radius = st.r * scale * (0.8f + 0.4f * tw),
            center = Offset(px, st.y * h),
        )
    }
    // a shooting star every nine seconds
    val cycle = (t / 9f).toInt()
    val p = (t % 9f) / 1.2f
    if (p in 0f..1f) {
        val sx = fract(sin(cycle * 12.9898f) * 43758.547f) * w * 0.8f + w * 0.2f
        val sy = fract(sin(cycle * 78.233f) * 12345.679f) * h * 0.4f
        val len = w * 0.22f
        val head = Offset(sx - p * len * 1.6f, sy + p * len * 0.8f)
        val tail = Offset(head.x + len * 0.5f, head.y - len * 0.25f)
        val a = (1f - p) * bright
        drawLine(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, (if (dark) Color.White else colors[0]).copy(alpha = a)),
                start = tail,
                end = head,
            ),
            start = tail,
            end = head,
            strokeWidth = 2.2f * scale,
            cap = StrokeCap.Round,
        )
    }
}

/** A rainbow bar and a hue slider for picking one of the two custom backdrop colours. */
@Composable
fun BackdropHueRow(label: String, color: Int, onPick: (Int) -> Unit) {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(color, hsv)
    val hue = hsv[0]
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .background(
                Brush.horizontalGradient(
                    listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map {
                        Color(android.graphics.Color.HSVToColor(floatArrayOf(it, 0.7f, 1f)))
                    }
                )
            )
    )
    SliderRow(label, hue, 0f..360f, "${hue.roundToInt()}°") { v ->
        onPick(android.graphics.Color.HSVToColor(floatArrayOf(v.coerceIn(0f, 360f), 0.7f, 1f)))
    }
}
