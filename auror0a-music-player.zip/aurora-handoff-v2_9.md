# Aurora handoff, v2.9.0

Summary of the work done across this chat, so a new session can pick up without the history.

## The project
- **Aurora** is an Android-only native music player. Kotlin, Jetpack Compose, Media3 (ExoPlayer, MediaSession) 1.5.1, DataStore for settings.
- Compose BOM 2025.05.00. Package and applicationId: `com.aurora.player`. minSdk 26.
- It is delivered as a single project zip, `aurora-music-player.zip`, with the project files at the zip root (`app/`, `build.gradle.kts`, `README.md`, ...).
- The user is on a **Redmi Note 14 Pro+ with HyperOS** (Hyper Island media controls). They use the app on a phone and send screenshots of build logs.

## How the user builds it
- GitHub Actions workflow in their repo. Steps: checkout, unzip `aurora-music-player.zip` into `project/`, setup-java, setup-gradle, build debug APK, upload artifact, release with `softprops/action-gh-release@v2`.
- The unzip step needs the file name **all lowercase** (`aurora-music-player.zip`). A capital A caused a failed run earlier.
- Open warning (harmless for now): actions still target Node.js 20 (`checkout@v4`, `setup-java@v4`, `upload-artifact@v4`, `setup-gradle@v4`, `action-gh-release@v2`). Newer versions of those actions would remove it.
- The sandbox I work in has **no Kotlin compiler or Gradle**. Only structural checks are possible (bracket balance, duplicate imports, duplicate functions). Always ask the user for the `e: file` lines of a failed build.

## Build status
- v2.5 and v2.6.0 were built and run by the user. They confirmed the Hyper Island seek bar problem was fixed in v2.6.0.
- **v2.7.0, v2.8.0 and v2.9.0 have not been built yet.** v2.8.0 and v2.9.0 are large changes (new UI layer, Lumi rewrite, four widget types, glow system, Orbit player) written without a compiler. Expect possible compile errors, especially in `Mascot.kt`, `ModernUi.kt`, `Glow.kt`, `NowPlayingOrbit.kt`, `Controls.kt` (`pressScale`), `Components.kt` (`sleekFinish`), `Widget.kt` and `WidgetConfigActivity.kt`. Ask for the `e: file` lines.

## What each version added

### v2.4
- Seek bar studio: Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars, Steps. Thumb shape, thickness, colour or gradient, wave height and length, time-left toggle.
- Design styles beyond Material You (Soft, Outlined, Neo-brutal, Glossy), navigation bar styles (Split pills, One bar, Classic), button shapes.
- Cover colours, greeting with the user's name, performance mode (Auto, Full, Lite).
- Tour after setup, bouncy intro, springy pop-in animation.

### v2.5
- Icon reverted to the original dark night-sky design.
- Tour became an overlay on the real tabs, guided by **Lumi**, a cat made of northern lights (drawn in Canvas).
- Fixed the greeting name field where the cursor jumped before each letter (local text state).
- Nine design styles (added Neon, Candy, Paper, Terminal), border thickness slider, eight more colour themes, background patterns, Squircle and Cookie cover shapes, cursive font.

### v2.6
- **Bug fix:** tapping the media notification (lock screen) opened Mi Music. Cause: no session activity. Fixed with `setSessionActivity` in `PlaybackService`, plus `MainActivity` handling `onNewIntent` and an "open full player" request.
- Home screen widget: three layouts (Classic, Compact, Cover), per-widget options in `WidgetConfigActivity`.
- Lumi customization: seven palettes, hats, eyewear, headphones, scarf, blush, name, size.
- Layout tab: song rows, mini player, Now Playing toggles, colours for play button and selected tab.
- Four more animation presets (Jelly, Pop, Glide, Dreamy) and page transitions (Slide, Fade, Zoom, Rise).

### v2.7
- Lumi moods fade smoothly: asleep (no song), drowsy (paused), awake (playing). Floating notes while listening. She reacts to touch (hop, squish, wiggle, happy eyes, hearts, vibration).
- Now Playing morphs out of the mini player using Compose shared-element transitions (`SharedTransitionLayout`, `sharedBounds`, key `"player"`).
- Player controls are very customizable (Settings > Layout): arrangement, button size, play button width, spacing, which buttons show, title size and alignment, "Now Playing" heading toggle.
- Play button: seven shapes (Morph, Circle, Squircle, Soft, Square, Sharp, Leaf), four styles (Solid, Soft, Outline, Gradient), colour source, glow, icon size.
- Widget buttons copy the player's buttons (colours, shapes, play style), with a "Minimal" alternative.
- Tour translated into all ten languages and shows a picture of the player for player-related steps.

### v2.9 (current)
- **Glow system** (`Glow.kt`): `rememberGlowState(seed)` in `Root` provides `LocalGlow` (colour as a lambda and a pulse `State`, both only read while drawing, so a colour cycle or pulse never recomposes). `Modifier.glow(shape, enabled, boost)` draws stacked outline strokes behind an element (put it before clip/background). `Modifier.cardGlow(shape)` is the softer one for cards. `GlowOrbs()` is called from `AuroraBackground`. Settings: `glowOn/Strength/Size/Tint/Pulse/Orbs` plus per-place switches `glowDock/Mini/Cards/Playing/Buttons/Art`. Lite mode turns off pulse, orbs and card glow. Only the Current UI glows.
- **Touch effects:** `pressScale` (`Controls.kt`) reads `touchFx` (SQUISH, GROW, GLOW, OFF) and `touchGrow` in Current; Legacy always squishes. GROW uses an underdamped spring, GLOW adds a radial halo drawn behind. `SongRow` now uses `pressScale` and glows when playing (Current only).
- **Current look:** `HeaderStyle.LARGE` (default) with `modernHeaderHeight(settings)`; `ModernDock` has a sliding marker (`DockIndicator.LINE` or `PILL`) with spring overshoot; `ModernMiniPlayer` glows and swipes sideways to skip (`miniSwipe`, thresholds 140 px); Home hero has Play all and Shuffle.
- **Orbit player** (`NowPlayingOrbit.kt`, used when Current and `npDesign == ORBIT`, otherwise the v2.8 panel or the legacy layout): `OrbitDisc` (round cover, spin with `orbitSpin`, double tap left/right for plus or minus 10 s, long press favorites, `orbitGestures`), `OrbitRing` (drag or tap to seek, `RingStyle` SOLID, GRADIENT or DOTS, thickness `orbitRing`), `OrbitTimes` (shows the preview time while dragging), `OrbitControls`, `OrbitPlay` (glow burst on play or pause), `OrbitChips` (favorite, queue, sleep, sound, playback speed chip cycling 0.75, 1, 1.25, 1.5, 2). It honours `npShowShuffle/Repeat/Skip/Fav` and `npTitleScale` and `npButtonScale`.
- **Settings:** new Glow tab (preview, glow options, per-place switches, touch effect); Interface tab gained Player (design and Orbit options), dock marker, mini player swipe, and the three header styles.

### v2.8
- **Current / Legacy interface** (`UiVersion` in `Settings.kt`, default CURRENT, switch in Settings > Interface, the first settings tab). Legacy is the untouched v2.7 code path. Current is a layer on top of the same features:
  - `ModernUi.kt`: `ModernHeader` (frosted full-width bar or clean fade, `HeaderStyle`), `ModernDock` (one slim dock, floating or attached, `DockStyle`), `ModernMiniPlayer` (capsule with a progress ring), `ModernHomeHero` (Home card).
  - `Components.kt`: `finish` and `cardFinish` call `sleekFinish` when the design is Material You and the UI is Current (hairline edge, tonal fill, same glass blur for bars). `OverlayPage` (settings and other overlays) uses `ModernHeader` in Current.
  - `MainScreen.kt`: `AuroraApp` bumps `corner` by 20% in Current (the Settings sliders still show the stored value because `SettingsPage` gets `rawSettings`). `Root` branches on `modern` for content padding, header, mini player and navigation. `homeHero` and `npPanel` toggles control the Home card and the player panel (`NowPlayingScreen.kt`, portrait only).
  - `NavStyle` and the legacy nav pills are only used in Legacy.
- **Lumi rewrite** (`Mascot.kt`): drawing moved to `DrawScope.drawLumi(...)` so the app and the widgets share it. `MascotLook` gained ears, eyes, tail, neck, mark, wings, sparkles, hue (below 0 means use the palette), glow, flow. Settings also has `mascotNotes`, `mascotTouch`, `mascotSpeed`. `renderLumiBitmap(px, look, mood, notes)` draws her off-screen with `CanvasDrawScope` for widgets (mood 0 asleep, 1 drowsy, 2 awake).
- **Widgets:** layouts 3 Lumi, 4 Lumi pal, 5 Square, 6 Vinyl (`widget_lumi.xml`, `widget_lumi_pal.xml`, `widget_square.xml`, `widget_vinyl.xml`). They share the id set of the old layouts, plus `w_lumi`. Each also has its own picker entry: `AuroraLumiWidget`, `AuroraLumiPalWidget`, `AuroraSquareWidget`, `AuroraVinylWidget` are empty subclasses of the now `open` `AuroraWidget`, with providers in `res/xml/aurora_widget_*_info.xml` and receivers in the manifest. `WidgetRender.defaultLayout` picks the starting layout from the provider class. `WidgetState.saveLumi/lumi/lumiNotes` store her look as one `|` separated string, written from `Root`. `AuroraWidget.refreshAll` loops over all five provider classes.

## Code map (`app/src/main/java/com/aurora/player/`)
- `MainActivity.kt`, `MainScreen.kt` (app flow, `Root`, mini player), `PlayerViewModel.kt`, `PlaybackService.kt` (Media3 session, widget hooks).
- `Settings.kt` (all enums, `AppSettings`, DataStore keys, read and write), `SettingsScreen.kt` (all tabs and shared widgets such as `SettingCard`, `SliderRow`, `ToggleRow`, `ChipPicker`).
- `Controls.kt` (seek bar, play, skip, action pills), `NowPlayingScreen.kt`, `NavBar.kt`, `Components.kt` (surface finishes per design style, backgrounds, patterns), `Theme.kt`, `Themes.kt`, `Motion.kt`.
- `Mascot.kt` (Lumi), `Tutorial.kt` (tour overlay and player preview), `Intro.kt` (setup screens), `Aurora.kt` (intro animation, background layers), `Extras.kt` (helpers: lite mode, cover colours, colour sources, cookie shape).
- `Widget.kt` (state, store, renderer, provider), `WidgetConfigActivity.kt`, widget layouts and drawables under `res/layout` and `res/drawable`.
- `Translate.kt`, `Translations.kt` (translation tables).

## Conventions and gotchas
- **Adding a setting:** add the field to `AppSettings`, a key in `K`, and a line each in the read and write functions in `Settings.kt`. Then add UI in `SettingsScreen.kt`. Enum settings are stored by name.
- **Translations:** pipe-separated rows `English|pl|es|fr|de|pt|it|tr|ru|ja|zh` in `TABLE_1` to `TABLE_4`. The `Text` shim in `Translate.kt` translates automatically. Use `verbatim(...)` to skip translation. Keep "Lumi" literal in rows because the tour swaps in the user's chosen name.
- New setting labels (v2.4 onward) are English-only. Only the tour is fully translated.
- Lite mode (`asLite()` in `Extras.kt`) overrides settings for low-end phones: matte surfaces, battery saver, lower frame rate, no entrance animations or glow.
- When patching files with Python slices, check that the end marker comes after the start marker. A reversed pair once duplicated half of `NowPlayingScreen.kt`. It was repaired.
- Local composable names must not shadow Kotlin functions (`repeat` was renamed to `repeatPill`).

## Known risks to check on the first build (v2.7 and v2.8)
- Shared-element morph (`sharedBounds`, `OverlayClip`, `BoundsTransform`) is experimental API and untested.
- New `PlayShape`, `PlayStyle` and control code in `Controls.kt` and `NowPlayingScreen.kt`.
- Widget buttons use new layouts (`w_prev_box`, `w_play_box`, `w_next_box`). The widget takes the app's button look only after the app has been opened once.
- Widget play buttons only work while the playback service is alive.
- v2.8: `CanvasDrawScope` / `ImageBitmap` off-screen drawing in `renderLumiBitmap`; the `Canvas as GfxCanvas` import alias in `Mascot.kt`; `CircularProgressIndicator(progress = { })` in `ModernUi.kt`; `if (...) item {} else item {}` in `HomeScreen.kt`; the new widget XML (vinyl overlay uses `layout_gravity` on the play box).
- v2.9: `combinedClickable(interactionSource, indication, ...)` in `SongRow`; `drawArc` with `Brush.sweepGradient` inside `withTransform`; `Modifier.glow` strokes through a hand-written `strokeOutline`; `OrbitDisc` gesture lambdas using `return@pointerInput`.
- v2.8: new setting labels (Interface tab, Lumi options, widget types) are English-only.

## Open ideas and follow-ups
- Translate the new settings labels into the ten languages.
- If Current feels wrong on some screen (Songs rows, Playlists, Albums), refine `sleekFinish` or add per-screen layouts; the first pass only changes shell, Home, player panel and surfaces.
- Update the GitHub Actions versions to clear the Node.js 20 warning (the user has not sent the workflow file yet).
- Test the morph, widget and touch reactions on the user's device and adjust from feedback.
- The user likes: lots of customization, friendly and fun UI, smooth animations, good performance on low-end phones, short and clear explanations on mobile.
