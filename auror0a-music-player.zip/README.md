# Aurora 3.0.0

Native Android music player (Kotlin, Jetpack Compose, Media3).

- **New in 3.0.0: Settings you can search, and playlists with a look of their own.** Settings opens on a home screen with a search box and four groups (Look and feel, Screens, Sound and library, App). Search finds sections, cards and single settings in your language or in English, and tapping a result scrolls to the card and flashes it. New **Playlists** settings (grid, list or big cards, card size, order, song count, notes, smart playlists row). Playlists got pinning, duplicating, notes, emoji and stack covers, a second colour, per-playlist song order, a "Lift" touch feel and a Pill shape. The Pill dock has two modes: Attached (one bar joined to the screen edge) and Floating (every tab its own capsule). New in Interface: interface size (85 to 120%), hide the dock and/or header while scrolling, and scrolling titles for long song names. New in Player: fade the volume out at the end of the sleep timer (10, 20 or 30 s). Every new text is translated into all ten languages. Smaller list and playlist work was done to keep scrolling light.
- **2.9.1: much lower battery use, same looks.** New Settings > Battery tab with a power profile (Efficient, Balanced, Smooth), "keep animating while paused" (off by default: backgrounds, glow and Lumi hold still when nothing plays) and "follow Android battery saver". Under the hood: every decorative animation (glow breathing, drifting glow, spinning cover, seek bar waves, Lumi, equalizer bars) now runs on its own slow clock instead of redrawing at every screen refresh, and none of them run while nothing is playing. The equalizer bars used to animate forever even when paused. The song position is checked less often while the app is in the background
- 2.9.1 fixes: the play button glow now follows the button's real shape and lights up behind the icon (no more dark shape showing through the outlined style), the mini player's progress ring follows the play button's shape, a rebuilt Pill dock (the selected tab widens into a capsule with its name), the dock marker and icons no longer collide or poke through the edge, the Home Shuffle button is a round tonal button, and settings that the Current interface or the Orbit player does not use are dimmed and locked (they unlock again in Legacy)
- **New in 2.9: the Current interface got its own identity.** A large bold title with a glowing accent, a dock with a glowing marker that springs between tabs (glow line or pill), a mini player you can swipe to skip, and a new **Orbit** player: a round spinning cover inside a progress ring you drag to seek, with double-tap to jump 10 seconds, press and hold to favorite, a speed button and a burst of glow every time you play or pause. The v2.8 panel player is still there as "Panel"
- **Glow** (Settings > Glow): strength, size, colour (primary, secondary, tertiary, album cover or a slow colour cycle), breathing, drifting background glow, and a switch for each place it glows (dock, mini player, Home cards, the playing song, play button, cover and ring)
- **Touch effects** (Settings > Glow): squish, grow with a springy bounce, or grow with a halo that blooms behind what you press, with adjustable strength. Rows, buttons, cards and the dock all use it
- Home card also has a Shuffle button
- **New in 2.8: a redesigned interface.** Settings > Interface switches between **Current** (new) and **Legacy** (the layout from 2.7 and before). Every feature works in both.
- Current: a slim navigation dock (floating or attached to the screen edge), a full-width frosted header with a big title (or a clean fade), a round mini player with a progress ring around the play button, crisper hairline surfaces with rounder corners, a Home card with greeting, Lumi and Play all, and a rounded control panel in the player
- Four more widget types in the widget picker: **Lumi** (wide, with Lumi and the buttons), **Lumi pal** (small square), **Square** (big cover) and **Vinyl** (round record). Lumi widgets draw her with your look, show her asleep, drowsy or bouncing to match playback, and tapping her plays or pauses. All layouts are also selectable inside the widget customizer
- Lumi customization: pick any colour with a slider, ears (pointy, round, tall), eyes (classic, big, sparkle), tail (curly, fluffy, long, none), markings (stripes, spots, star), neck (bell, bow tie, star), wings, sparkles on or off, music notes on or off, touch reactions on or off, colour flow, glow strength and animation speed
- Material You colours, matte or frosted-glass finish, drifting squiggly lines and circles in the background
- Home (daily mix, most played, listening stats), Songs, Playlists (customizable look and feel), Albums, Folders, Artists
- Songs: search, sort (title, artist, album, length, date added, most played) and filter (favorites, length)
- Reference-style Now Playing: eight seek bar styles, format chip, pill controls, queue, sleep timer, Sound sheet (speed, pitch, equalizer)
- Design styles beyond Material You: Soft, Outlined, Neo-brutal and Glossy (Settings > Design), plus navigation bar styles (split pills, one bar, classic) and button shapes
- Seek bar studio (Settings > Seek bar): Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars, Steps; thumb shape, thickness, colour or gradient, wave height and length, time left toggle
- Cover colours (Now Playing takes its colours from the album art) and a Home greeting with your name
- Short, friendly tour that floats over the real tabs, guided by Lumi, a cat made of northern lights (replay from Settings > Startup). Lumi also naps on Home and bounces when music plays (can be hidden)
- Now Playing grows out of the mini player (shared-element morph) instead of sliding up
- Lumi moves smoothly between asleep, drowsy (paused) and awake (music playing), floats music notes while you listen, and reacts when you touch her
- Widget buttons copy the player's buttons: same colours, shapes and play button style (or switch to Minimal)
- Very customizable player controls: arrangement, button size, play button width, spacing, which buttons show, title size and alignment; play button shapes, styles (solid, soft, outline, gradient), glow and icon size
- The tour is translated into all supported languages and shows a picture of the player when it explains it
- Fix: tapping the media notification (including on the lock screen) now opens Aurora's full player instead of the phone's own music app
- Home screen widget with three layouts (Classic, Compact, Cover), its own colours, opacity, corners, cover shape, text size and buttons; every widget is customised separately
- Lumi can be dressed up: seven colour palettes, party hat, crown, bow or halo, glasses or sunglasses, headphones, scarf, rosy cheeks, her own name and size
- New Layout tab: song row style, spacing, cover shape, what each row shows, mini player size and parts, Now Playing toggles, and colours for the play button and selected tab
- Four more animation presets (Jelly, Pop, Glide, Dreamy) and a page transition picker (Slide, Fade, Zoom, Rise)
- Nine design styles: Material You, Soft, Outlined, Neo-brutal, Glossy, Neon, Candy, Paper and Terminal, with a border thickness slider
- Eight more colour themes, background patterns (dots, grid, stars, confetti, stripes), squircle and cookie cover shapes, and a cursive font
- Springy, bouncy intro and pop-in animations
- Performance mode (Auto, Full, Lite): Auto detects low-RAM or older phones and turns off blur, glow and entrance animations
- Five-band equalizer with presets, bass boost, loudness
- Animation sets with speed and intensity controls
- Themes tab: 13 preset themes, Material You, a live custom theme editor (hue, vibrancy, colour spread), saved themes and shareable theme codes
- 10 languages besides English (Polish, Spanish, French, German, Portuguese, Italian, Turkish, Russian, Japanese, Chinese) with a language button on the setup screen
- Northern-lights intro screen and an optional themed aurora glow behind the whole app
- Cover shapes (rounded, circle, spinning vinyl), font and text size, battery saver and background frame rate
- Backup and restore of playlists (song names, not audio), favorites and settings
- Tablet and landscape layouts (width-capped pages, adaptive grids, two-pane Now Playing)

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
The debug build type is configured as an optimized, non-debuggable build (R8 on) so Compose runs smoothly.
If that ever breaks the build, delete the `buildTypes { debug { ... } }` block in app/build.gradle.kts.

Adding a language: add its code to `order` in Translate.kt (and an entry in `AppLanguage`), then append one column to every row in Translations.kt. Blank cells fall back to English.
