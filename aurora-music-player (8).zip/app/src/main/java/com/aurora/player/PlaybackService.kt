package com.aurora.player

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private data class AudioPrefs(
    val speed: Float,
    val pitch: Float,
    val skipSilence: Boolean,
    val bass: Float,
    val loudness: Float,
    val eqEnabled: Boolean,
    val eqGains: List<Float>,
)

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loudnessFx: LoudnessEnhancer? = null
    private var bassFx: BassBoost? = null
    private var eqFx: Equalizer? = null
    private var prefs = AudioPrefs(1f, 1f, false, 0f, 0f, false, listOf(0f, 0f, 0f, 0f, 0f))

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = exo
        // Tapping the media notification (also on the lock screen) must open Aurora. Without a session activity,
        // some phones hand the tap to their own music app instead.
        val openApp = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionIntent = PendingIntent.getActivity(
            this,
            0,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        session = MediaSession.Builder(this, exo).setSessionActivity(sessionIntent).build()

        exo.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attachEffects(audioSessionId)
            }
        })
        // Keep home screen widgets in step with what is playing.
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = pushWidget()
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = pushWidget()
            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) = pushWidget()
        })
        attachEffects(exo.audioSessionId)

        scope.launch {
            SettingsStore(this@PlaybackService).flow
                .map {
                    AudioPrefs(it.playbackSpeed, it.playbackPitch, it.skipSilence, it.bassBoost, it.loudness, it.eqEnabled, it.eqGains)
                }
                .distinctUntilChanged()
                .collect { applyPrefs(it) }
        }
    }

    private fun pushWidget() {
        val p = player ?: return
        val md = p.mediaMetadata
        WidgetState.saveSong(
            this,
            md.title?.toString() ?: "",
            md.artist?.toString() ?: "",
            md.artworkUri?.toString() ?: "",
            p.isPlaying,
            p.currentMediaItem != null,
        )
        AuroraWidget.refreshAll(this)
    }

    /** Buttons on the home screen widget arrive here. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = player
        when (intent?.action) {
            AuroraWidget.ACTION_TOGGLE -> p?.let { if (it.isPlaying) it.pause() else it.play() }
            AuroraWidget.ACTION_NEXT -> p?.seekToNext()
            AuroraWidget.ACTION_PREV -> p?.seekToPrevious()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun applyPrefs(p: AudioPrefs) {
        prefs = p
        val exo = player ?: return
        exo.playbackParameters = PlaybackParameters(p.speed, p.pitch)
        exo.skipSilenceEnabled = p.skipSilence
        applyEffectLevels()
    }

    private fun attachEffects(sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        runCatching { eqFx?.release() }
        loudnessFx = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        bassFx = runCatching { BassBoost(0, sessionId) }.getOrNull()
        eqFx = runCatching { Equalizer(0, sessionId) }.getOrNull()
        applyEffectLevels()
    }

    private fun applyEffectLevels() {
        runCatching {
            loudnessFx?.setTargetGain((prefs.loudness * 1000f).toInt())
            loudnessFx?.setEnabled(prefs.loudness > 0.01f)
        }
        runCatching {
            bassFx?.setStrength((prefs.bass * 1000f).toInt().toShort())
            bassFx?.setEnabled(prefs.bass > 0.01f)
        }
        runCatching {
            val eq = eqFx ?: return@runCatching
            eq.setEnabled(prefs.eqEnabled)
            val range = eq.bandLevelRange
            val minL = range[0].toInt()
            val maxL = range[1].toInt()
            val centers = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
            for (b in 0 until eq.numberOfBands.toInt()) {
                val hz = eq.getCenterFreq(b.toShort()) / 1000f
                var best = 0
                var bestDist = Float.MAX_VALUE
                for (i in centers.indices) {
                    val d = kotlin.math.abs(kotlin.math.ln(hz / centers[i]))
                    if (d < bestDist) { bestDist = d; best = i }
                }
                val gainDb = prefs.eqGains.getOrElse(best) { 0f }
                eq.setBandLevel(b.toShort(), (gainDb * 100f).toInt().coerceIn(minL, maxL).toShort())
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        // The widget should not keep showing a pause button once playback is gone.
        val last = WidgetState.song(this)
        WidgetState.saveSong(this, last.title, last.artist, last.artUri, false, last.has)
        AuroraWidget.refreshAll(this)
        scope.cancel()
        runCatching { loudnessFx?.release() }
        runCatching { bassFx?.release() }
        runCatching { eqFx?.release() }
        session?.run {
            player.release()
            release()
        }
        session = null
        player = null
        super.onDestroy()
    }
}
