package com.aurora.player

import androidx.compose.foundation.Canvas
import kotlin.math.PI
import kotlinx.coroutines.launch
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

private val ink = Color(0xFF10163A)

/** Everything about how the mascot looks. Comes from settings, but the Lumi page can also preview other looks. */
data class MascotLook(
    val palette: MascotPalette = MascotPalette.AURORA,
    val hat: MascotHat = MascotHat.NONE,
    val eyewear: MascotEyewear = MascotEyewear.NONE,
    val headphones: Boolean = false,
    val scarf: Boolean = false,
    val blush: Boolean = true,
)

fun AppSettings.mascotLook() = MascotLook(mascotPalette, mascotHat, mascotEyewear, mascotHeadphones, mascotScarf, mascotBlush)

/**
 * Lumi, the cat made of northern lights. The colours slowly flow through her body, she blinks, her tail wags and she
 * bounces when [bounce] is on. When [asleep] her eyes close and she breathes slowly. With [animate] off she is a still
 * picture, which is what Lite mode and Battery saver use.
 */
@Composable
fun AuroraCat(
    modifier: Modifier = Modifier,
    asleep: Boolean = false,
    bounce: Boolean = true,
    animate: Boolean = true,
    drowsy: Boolean = false,
    look: MascotLook = LocalAppSettings.current.mascotLook(),
) {
    val colors = remember(look.palette) { look.palette.colors.map { Color(it) } }
    val settings = LocalAppSettings.current
    // Moods fade into each other: asleep, drowsy (paused) and awake (music playing).
    val awake by animateFloatAsState(
        targetValue = when {
            asleep -> 0f
            drowsy -> 0.45f
            else -> 1f
        },
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "mascotAwake",
    )
    val dance by animateFloatAsState(
        targetValue = if (bounce && !asleep && !drowsy) 1f else 0f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "mascotDance",
    )
    // Touching her sets off a short happy reaction.
    val poke = remember { Animatable(0f) }
    val pokeScope = rememberCoroutineScope()
    val haptic = rememberHaptic()
    val paused = LocalBackgroundPaused.current
    val running = animate && !settings.batterySaver && !paused
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        var start = 0L
        while (true) {
            withFrameNanos { now ->
                if (start == 0L) start = now
                clock.floatValue = (now - start) / 1_000_000_000f
            }
            delay(24) // about 30 frames a second is plenty for a mascot
        }
    }

    Canvas(
        modifier.pointerInput(Unit) {
            detectTapGestures(
                onTap = {
                    haptic()
                    pokeScope.launch {
                        poke.snapTo(0f)
                        poke.animateTo(1f, tween(1200, easing = LinearEasing))
                    }
                },
            )
        },
    ) {
        val t = clock.floatValue
        val pk = poke.value
        val reacting = pk > 0.001f && pk < 0.999f
        val pi = PI.toFloat()
        // Poking wakes her up for a moment, even when she is asleep.
        val wake = maxOf(awake, (sin(pk * pi) * 1.5f).coerceIn(0f, 1f))
        val happy = if (reacting) sin(pk * pi).coerceIn(0f, 1f) else 0f
        val hop = if (reacting) -sin(pk * pi * 2.5f).coerceAtLeast(0f) * (1f - pk) * 9f else 0f
        val u = minOf(size.width, size.height) / 100f
        val ox = (size.width - 100f * u) / 2f
        val oy = (size.height - 100f * u) / 2f
        val bob = hop + if (!running) 0f else sin(t * 1.6f) * 0.9f * (1f - wake) + sin(t * 4.2f) * 1.8f * dance
        fun p(x: Float, y: Float) = Offset(ox + x * u, oy + (y + bob) * u)
        val squish = if (reacting) sin(pk * pi * 5f) * (1f - pk) * 0.06f else 0f
        val wiggle = if (reacting) sin(pk * pi * 6f) * (1f - pk) * 5f else 0f
        withTransform({
            scale(1f + squish, 1f - squish, pivot = Offset(ox + 50f * u, oy + 100f * u))
            rotate(wiggle, pivot = Offset(ox + 50f * u, oy + 85f * u))
        }) {

        val shift = (t * 0.18f % 1f) * 100f * u
        val brush = Brush.linearGradient(
            colors = colors,
            start = Offset(ox + shift - 100f * u, oy),
            end = Offset(ox + shift + 40f * u, oy + 100f * u),
            tileMode = TileMode.Mirror,
        )
        val round = Stroke(width = 5f * u, join = StrokeJoin.Round)

        // soft glow behind everything
        drawCircle(
            Brush.radialGradient(
                listOf(colors[2].copy(alpha = 0.28f), Color.Transparent),
                center = p(50f, 56f),
                radius = 56f * u,
            ),
            radius = 56f * u,
            center = p(50f, 56f),
        )

        // tail
        val wag = if (running) sin(t * 2.6f) * 6f * (0.25f + 0.75f * wake) else 0f
        val tail = Path().apply {
            moveTo(p(70f, 86f).x, p(70f, 86f).y)
            cubicTo(
                p(90f, 90f).x, p(90f, 90f).y,
                p(96f + wag, 68f).x, p(96f + wag, 68f).y,
                p(86f + wag, 50f).x, p(86f + wag, 50f).y,
            )
        }
        drawPath(tail, brush, style = Stroke(width = 9f * u, cap = StrokeCap.Round))

        // body
        drawOval(brush, p(23f, 61f), Size(54f * u, 38f * u))

        // ears
        val leftEar = Path().apply {
            moveTo(p(27f, 41f).x, p(27f, 41f).y)
            lineTo(p(29f, 13f).x, p(29f, 13f).y)
            lineTo(p(48f, 28f).x, p(48f, 28f).y)
            close()
        }
        val rightEar = Path().apply {
            moveTo(p(73f, 41f).x, p(73f, 41f).y)
            lineTo(p(71f, 13f).x, p(71f, 13f).y)
            lineTo(p(52f, 28f).x, p(52f, 28f).y)
            close()
        }
        drawPath(leftEar, brush)
        drawPath(leftEar, brush, style = round)
        drawPath(rightEar, brush)
        drawPath(rightEar, brush, style = round)
        val innerL = Path().apply {
            moveTo(p(31f, 35f).x, p(31f, 35f).y)
            lineTo(p(32f, 21f).x, p(32f, 21f).y)
            lineTo(p(42f, 29f).x, p(42f, 29f).y)
            close()
        }
        val innerR = Path().apply {
            moveTo(p(69f, 35f).x, p(69f, 35f).y)
            lineTo(p(68f, 21f).x, p(68f, 21f).y)
            lineTo(p(58f, 29f).x, p(58f, 29f).y)
            close()
        }
        drawPath(innerL, Color.White.copy(alpha = 0.45f))
        drawPath(innerR, Color.White.copy(alpha = 0.45f))

        // head
        drawOval(brush, p(22f, 24f), Size(56f * u, 48f * u))

        // face
        val open = if (!running) 1f else {
            val ph = t % 3.4f
            if (ph < 3.2f) 1f else abs((ph - 3.3f) / 0.1f).coerceIn(0f, 1f)
        }
        val eyeOpen = open * wake
        for (cx in listOf(39f, 61f)) {
            if (happy > 0.5f) {
                // happy "^ ^" eyes while she is being petted
                val eye = Path().apply {
                    moveTo(p(cx - 4.5f, 49f).x, p(cx - 4.5f, 49f).y)
                    quadraticTo(p(cx, 42.5f).x, p(cx, 42.5f).y, p(cx + 4.5f, 49f).x, p(cx + 4.5f, 49f).y)
                }
                drawPath(eye, ink, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round))
            } else if (eyeOpen < 0.16f) {
                val eye = Path().apply {
                    moveTo(p(cx - 5f, 48f).x, p(cx - 5f, 48f).y)
                    quadraticTo(p(cx, 53f).x, p(cx, 53f).y, p(cx + 5f, 48f).x, p(cx + 5f, 48f).y)
                }
                drawPath(eye, ink, style = Stroke(width = 1.8f * u, cap = StrokeCap.Round))
            } else {
                val ry = 5.6f * eyeOpen.coerceAtLeast(0.12f)
                drawOval(ink, p(cx - 4.2f, 48f - ry), Size(8.4f * u, 2f * ry * u))
                if (eyeOpen > 0.5f) drawCircle(Color.White, 1.4f * u, p(cx + 1.4f, 46.2f))
            }
        }
        // cheeks
        if (look.blush) {
            drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(32f, 58f))
            drawCircle(Color(0xFFFF9AD5).copy(alpha = 0.40f), 4f * u, p(68f, 58f))
        }
        // nose and mouth
        val nose = Path().apply {
            moveTo(p(47.5f, 54.5f).x, p(47.5f, 54.5f).y)
            lineTo(p(52.5f, 54.5f).x, p(52.5f, 54.5f).y)
            lineTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            close()
        }
        drawPath(nose, Color(0xFFFFB3D9))
        val mouth = Path().apply {
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(45.5f, 60.5f).x, p(45.5f, 60.5f).y)
            moveTo(p(50f, 57.2f).x, p(50f, 57.2f).y)
            quadraticTo(p(50f, 61f).x, p(50f, 61f).y, p(54.5f, 60.5f).x, p(54.5f, 60.5f).y)
        }
        drawPath(mouth, ink.copy(alpha = 0.8f), style = Stroke(width = 1.4f * u, cap = StrokeCap.Round))
        // whiskers
        val whisker = Color.White.copy(alpha = 0.6f)
        for ((a, b) in listOf(
            Offset(33f, 55f) to Offset(17f, 52f), Offset(33f, 58f) to Offset(17f, 60f),
            Offset(67f, 55f) to Offset(83f, 52f), Offset(67f, 58f) to Offset(83f, 60f),
        )) {
            drawLine(whisker, p(a.x, a.y), p(b.x, b.y), 1.1f * u, StrokeCap.Round)
        }


        // ---- accessories
        fun poly(vararg pts: Pair<Float, Float>): Path = Path().apply {
            pts.forEachIndexed { i, pt ->
                val o = p(pt.first, pt.second)
                if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y)
            }
            close()
        }
        val gold = Color(0xFFFFD54F)
        val hatPink = Color(0xFFFF5FA2)
        val soft = Stroke(width = 2.6f * u, join = StrokeJoin.Round)

        if (look.scarf) {
            val scarf = Color(0xFFFF5F7E)
            drawRoundRect(scarf, p(31f, 69f), Size(38f * u, 9f * u), CornerRadius(4.5f * u))
            drawRoundRect(Color(0xFFE04565), p(59f, 73f), Size(7f * u, 16f * u), CornerRadius(3.5f * u))
        }
        if (look.headphones) {
            val band = Path().apply {
                moveTo(p(19f, 46f).x, p(19f, 46f).y)
                cubicTo(p(19f, -4f).x, p(19f, -4f).y, p(81f, -4f).x, p(81f, -4f).y, p(81f, 46f).x, p(81f, 46f).y)
            }
            drawPath(band, Color(0xFF2B2F55), style = Stroke(width = 4.4f * u, cap = StrokeCap.Round))
            drawRoundRect(colors[2], p(12f, 38f), Size(11f * u, 21f * u), CornerRadius(5f * u))
            drawRoundRect(colors[2], p(77f, 38f), Size(11f * u, 21f * u), CornerRadius(5f * u))
            drawRoundRect(Color.White.copy(alpha = 0.35f), p(14.5f, 41f), Size(2.2f * u, 15f * u), CornerRadius(1.1f * u))
            drawRoundRect(Color.White.copy(alpha = 0.35f), p(79.5f, 41f), Size(2.2f * u, 15f * u), CornerRadius(1.1f * u))
        }
        when (look.eyewear) {
            MascotEyewear.NONE -> {}
            MascotEyewear.GLASSES -> {
                for (cx in listOf(39f, 61f)) drawCircle(ink, 8.6f * u, p(cx, 48f), style = Stroke(width = 1.6f * u))
                drawLine(ink, p(47.6f, 47f), p(52.4f, 47f), 1.6f * u, StrokeCap.Round)
                drawLine(ink, p(30.4f, 47f), p(26f, 45f), 1.4f * u, StrokeCap.Round)
                drawLine(ink, p(69.6f, 47f), p(74f, 45f), 1.4f * u, StrokeCap.Round)
            }
            MascotEyewear.SHADES -> {
                val lens = Color(0xF2111530)
                drawRoundRect(lens, p(29.5f, 42.5f), Size(19f * u, 12f * u), CornerRadius(4.5f * u))
                drawRoundRect(lens, p(51.5f, 42.5f), Size(19f * u, 12f * u), CornerRadius(4.5f * u))
                drawLine(lens, p(48f, 45f), p(52f, 45f), 1.8f * u, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.5f), p(32f, 45.5f), p(36f, 45.5f), 1.2f * u, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.5f), p(54f, 45.5f), p(58f, 45.5f), 1.2f * u, StrokeCap.Round)
            }
        }
        when (look.hat) {
            MascotHat.NONE -> {}
            MascotHat.PARTY -> {
                val cone = poly(44f to 25f, 66f to 25f, 56f to 4f)
                drawPath(cone, hatPink)
                drawPath(cone, hatPink, style = soft)
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(53f, 17f))
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(58f, 12f))
                drawCircle(Color.White.copy(alpha = 0.85f), 1.3f * u, p(57f, 20f))
                drawCircle(gold, 3f * u, p(56f, 4f))
            }
            MascotHat.CROWN -> {
                val crown = poly(36f to 25f, 36f to 11f, 43f to 18f, 50f to 7f, 57f to 18f, 64f to 11f, 64f to 25f)
                drawPath(crown, gold)
                drawPath(crown, gold, style = soft)
                drawCircle(hatPink, 1.7f * u, p(50f, 18f))
                drawCircle(Color(0xFF2ED9FF), 1.3f * u, p(41f, 21f))
                drawCircle(Color(0xFF2ED9FF), 1.3f * u, p(59f, 21f))
            }
            MascotHat.BOW -> {
                val left = poly(66f to 20f, 54f to 12f, 54f to 28f)
                val right = poly(66f to 20f, 78f to 12f, 78f to 28f)
                drawPath(left, hatPink)
                drawPath(left, hatPink, style = soft)
                drawPath(right, hatPink)
                drawPath(right, hatPink, style = soft)
                drawCircle(Color(0xFFFF2E88), 3.4f * u, p(66f, 20f))
            }
            MascotHat.HALO -> {
                drawOval(gold.copy(alpha = 0.30f), p(36f, 0.5f), Size(28f * u, 8f * u), style = Stroke(width = 5f * u))
                drawOval(gold, p(36f, 0.5f), Size(28f * u, 8f * u), style = Stroke(width = 2.2f * u))
            }
        }

        // sparkles, or a little "z z" when she sleeps
        if (wake < 0.98f) {
            val z = Path().apply {
                moveTo(p(74f, 14f).x, p(74f, 14f).y)
                lineTo(p(82f, 14f).x, p(82f, 14f).y)
                lineTo(p(74f, 24f).x, p(74f, 24f).y)
                lineTo(p(82f, 24f).x, p(82f, 24f).y)
            }
            drawPath(z, Color.White.copy(alpha = 0.8f * (1f - wake)), style = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (wake > 0.02f) {
            val spots = listOf(Offset(10f, 22f), Offset(91f, 26f), Offset(7f, 66f), Offset(93f, 90f))
            spots.forEachIndexed { i, o ->
                val twinkle = if (running) 0.35f + 0.65f * abs(sin(t * 1.7f + i * 1.3f)) else 0.8f
                val r = (2.4f + i % 2) * u
                val c = p(o.x, o.y)
                val star = Path().apply {
                    moveTo(c.x, c.y - r)
                    lineTo(c.x + r * 0.3f, c.y - r * 0.3f)
                    lineTo(c.x + r, c.y)
                    lineTo(c.x + r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x, c.y + r)
                    lineTo(c.x - r * 0.3f, c.y + r * 0.3f)
                    lineTo(c.x - r, c.y)
                    lineTo(c.x - r * 0.3f, c.y - r * 0.3f)
                    close()
                }
                drawPath(star, Color.White.copy(alpha = twinkle * wake))
            }
        }

        // little music notes float up while she listens
        if (dance > 0.02f && running) {
            for (i in 0..2) {
                val ph = (t * 0.55f + i / 3f) % 1f
                val nx = 78f + i * 6f + sin((t + i) * 2f) * 3f
                val ny = 34f - ph * 30f
                val a = ((1f - ph) * dance).coerceIn(0f, 1f)
                val c = p(nx, ny)
                drawCircle(Color.White.copy(alpha = a), 2.1f * u, c)
                drawLine(Color.White.copy(alpha = a), Offset(c.x + 1.9f * u, c.y), Offset(c.x + 1.9f * u, c.y - 7f * u), 1.3f * u, StrokeCap.Round)
            }
        }
        // hearts when she is petted
        if (reacting) {
            for (i in 0..2) {
                val a = (1f - pk).coerceIn(0f, 1f)
                val c = p(36f + i * 14f, 34f - pk * 26f - (i % 2) * 5f)
                val r = 3.2f * u
                val heart = Path().apply {
                    moveTo(c.x, c.y + r)
                    cubicTo(c.x - 2f * r, c.y - 0.2f * r, c.x - 1.2f * r, c.y - 1.8f * r, c.x, c.y - 0.6f * r)
                    cubicTo(c.x + 1.2f * r, c.y - 1.8f * r, c.x + 2f * r, c.y - 0.2f * r, c.x, c.y + r)
                    close()
                }
                drawPath(heart, Color(0xFFFF6FA8).copy(alpha = a))
            }
        }
        }
    }
}
