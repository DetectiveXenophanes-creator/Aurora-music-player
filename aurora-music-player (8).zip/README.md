# Aurora 2.7

Native Android music player (Kotlin, Jetpack Compose, Media3).

- Material You colours, matte or frosted-glass finish, drifting squiggly lines and circles in the background
- Home (daily mix, most played, listening stats), Songs, Playlists (customizable look and feel), Albums, Folders, Artists
- Songs: search, sort (title, artist, album, length, date added, most played) and filter (favorites, length)
- Reference-style Now Playing: eight seek bar styles, format chip, pill controls, queue, sleep timer, Sound sheet (speed, pitch, equalizer)
- Design styles beyond Material You: Soft, Outlined, Neo-brutal and Glossy (Settings > Design), plus navigation bar styles (split pills, one bar, classic) and button shapes
- Seek bar studio (Settings > Seek bar): Line, Wavy, Squiggle, Thick, Hairline, Dots, Bars, Steps; thumb shape, thickness, colour or gradient, wave height and length, time left toggle
- Cover colours (Now Playing takes its colours from the album art) and a Home greeting with your name
- Short, friendly tour that floats over the real tabs, guided by Lumi, a cat made of northern lights (replay from Settings > Startup). Lumi also naps on Home and bounces when music plays (can be hidden)
- Now Playing grows out of the mini player (shared-element morph) instead of sliding up
- Lumi moves smoothly between asleep, drowsy (paused) and awake (music playing), floats music notes while you listen, and reacts when you touch her
- Widget buttons copy the player's buttons: same colours, shapes and play button style (or switch to Minimal)
- Very customizable player controls: arrangement, button size, play button width, spacing, which buttons show, title size and alignment; play button shapes, styles (solid, soft, outline, gradient), glow and icon size
- The tour is translated into all supported languages and shows a picture of the player when it explains it
- Fix: tapping the media notification (including on the lock screen) now opens Aurora's full player instead of the phone's own music app
- Home screen widget with three layouts (Classic, Compact, Cover), its own colours, opacity, corners, cover shape, text size and buttons; every widget is customised separately
- Lumi can be dressed up: seven colour palettes, party hat, crown, bow or halo, glasses or sunglasses, headphones, scarf, rosy cheeks, her own name and size
- New Layout tab: song row style, spacing, cover shape, what each row shows, mini player size and parts, Now Playing toggles, and colours for the play button and selected tab
- Four more animation presets (Jelly, Pop, Glide, Dreamy) and a page transition picker (Slide, Fade, Zoom, Rise)
- Nine design styles: Material You, Soft, Outlined, Neo-brutal, Glossy, Neon, Candy, Paper and Terminal, with a border thickness slider
- Eight more colour themes, background patterns (dots, grid, stars, confetti, stripes), squircle and cookie cover shapes, and a cursive font
- Springy, bouncy intro and pop-in animations
- Performance mode (Auto, Full, Lite): Auto detects low-RAM or older phones and turns off blur, glow and entrance animations
- Five-band equalizer with presets, bass boost, loudness
- Animation sets with speed and intensity controls
- Themes tab: 13 preset themes, Material You, a live custom theme editor (hue, vibrancy, colour spread), saved themes and shareable theme codes
- 10 languages besides English (Polish, Spanish, French, German, Portuguese, Italian, Turkish, Russian, Japanese, Chinese) with a language button on the setup screen
- Northern-lights intro screen and an optional themed aurora glow behind the whole app
- Cover shapes (rounded, circle, spinning vinyl), font and text size, battery saver and background frame rate
- Backup and restore of playlists (song names, not audio), favorites and settings
- Tablet and landscape layouts (width-capped pages, adaptive grids, two-pane Now Playing)

Build: `gradle assembleDebug` (JDK 17, Android SDK 35). APK: app/build/outputs/apk/debug/app-debug.apk
The debug build type is configured as an optimized, non-debuggable build (R8 on) so Compose runs smoothly.
If that ever breaks the build, delete the `buildTypes { debug { ... } }` block in app/build.gradle.kts.

Adding a language: add its code to `order` in Translate.kt (and an entry in `AppLanguage`), then append one column to every row in Translations.kt. Blank cells fall back to English.
