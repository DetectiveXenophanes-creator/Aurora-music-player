package com.aurora.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Size of the fan: [r] is the distance from the corner button to the middle of every tab, [item] the size of a tab button. */
@Immutable
private class Fan(val r: Dp, val item: Dp)

private val RADIAL_MARGIN = 16.dp
private val RADIAL_ROW_H = 72.dp

/**
 * Works out how big the fan can be. Every tab sits on a quarter circle around the corner button. The circle is as big as
 * needed to keep neighbours apart, but never so big that the mini player (which sits beside the button) would have less
 * than about 120 dp left. On a narrow screen the tab buttons shrink a little instead.
 */
private fun fanFor(n: Int, scale: Float, maxW: Dp, fab: Dp): Fan {
    val item0 = 46.dp * scale
    if (n <= 1) return Fan(88.dp * scale, item0)
    val step = (PI / 2.0) / (n - 1)
    val k = (2.0 * sin(step / 2.0)).toFloat()
    val want = (item0 + 10.dp) / k
    val cap = (maxW - RADIAL_MARGIN - fab / 2 - item0 / 2 - 8.dp - 120.dp).coerceAtLeast(96.dp)
    val r = minOf(want, cap)
    val item = minOf(item0, r * k - 8.dp).coerceAtLeast(32.dp)
    return Fan(r, item)
}

private fun angleOf(i: Int, n: Int): Float = if (n <= 1) 45f else i * 90f / (n - 1)

/**
 * The Radial dock: one round button in a bottom corner. Tap it and the tabs fan out along a quarter circle with a springy,
 * staggered pop, a glowing arc draws itself behind them and the page dims. The mini player lives beside the button; while
 * the fan is open it slides narrower so it never sits under the tabs, and it grows back when the fan closes.
 *
 * [mini] draws the mini player. It gets the modifier that places it in the row and a flag that is true while it is short.
 */
@Composable
fun RadialDock(
    tab: AppTab,
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    onSelect: (AppTab) -> Unit,
    hideButton: Boolean,
    mini: @Composable (Modifier, Boolean) -> Unit,
) {
    val s = LocalAppSettings.current
    val motion = LocalMotion.current
    val tabs = s.dockTabs()
    val n = tabs.size
    val left = s.radialSide == RadialSide.LEFT
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val base = bottomInset + 8.dp
    val scale = s.radialScale.coerceIn(0.8f, 1.3f)
    val fab = 56.dp * scale

    // One slow progress for the page dimming, the arc and the button; one springy progress per tab for the pop.
    val openP = animateFloatAsState(
        targetValue = if (open) 1f else 0f,
        animationSpec = tween<Float>(if (motion.enabled) 380 else 120, easing = FastOutSlowInEasing),
        label = "radialOpen",
    )
    val prog = remember { List(AppTab.entries.size) { Animatable(0f) } }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(open, n) {
        val pop: AnimationSpec<Float> =
            if (motion.enabled) spring<Float>(dampingRatio = 0.52f, stiffness = 340f) else tween<Float>(120)
        if (open) {
            shown = true
            coroutineScope {
                for (i in 0 until n) launch {
                    delay(i * 38L)
                    prog[i].animateTo(1f, pop)
                }
            }
        } else {
            coroutineScope {
                for (i in 0 until n) launch {
                    delay((n - 1 - i) * 24L)
                    prog[i].animateTo(0f, tween<Float>(170, easing = FastOutSlowInEasing))
                }
            }
            shown = false
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fan = remember(n, scale, maxWidth) { fanFor(n, scale, maxWidth, fab) }
        if (shown) {
            RadialScrim(openP, open, left, fan, fab, base, onClose = { onOpenChange(false) })
            tabs.forEachIndexed { i, t ->
                RadialItem(
                    tab = t,
                    index = i,
                    count = n,
                    selected = t == tab,
                    left = left,
                    fan = fan,
                    fab = fab,
                    base = base,
                    progress = prog[i],
                    modifier = Modifier.align(if (left) Alignment.BottomStart else Alignment.BottomEnd),
                    onPick = {
                        onSelect(t)
                        onOpenChange(false)
                    },
                )
            }
        }
        RadialRow(
            tab = tab,
            open = open,
            left = left,
            fan = fan,
            fab = fab,
            base = base,
            openP = openP,
            hideButton = hideButton,
            onToggle = { onOpenChange(!open) },
            mini = mini,
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

/** The dim layer: a soft bloom of glow colour growing out of the corner, the arc the tabs sit on, and tap-outside-to-close. */
@Composable
private fun RadialScrim(
    openP: State<Float>,
    open: Boolean,
    left: Boolean,
    fan: Fan,
    fab: Dp,
    base: Dp,
    onClose: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val g = LocalGlow.current
    val strength = if (s.glowOn) s.glowStrength.coerceAtMost(1.2f) else 0.4f
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind {
                val p = openP.value
                if (p < 0.002f) return@drawBehind
                drawRect(Color.Black.copy(alpha = 0.38f * p))
                val c = g?.color?.invoke() ?: cs.primary
                val m = RADIAL_MARGIN.toPx() + fab.toPx() / 2f
                val cx = if (left) m else size.width - m
                val cy = size.height - (base + RADIAL_ROW_H / 2).toPx()
                val bloom = (fan.r + fan.item).toPx() * (0.6f + 0.6f * p)
                drawCircle(
                    Brush.radialGradient(
                        listOf(c.copy(alpha = (0.42f * p * strength).coerceIn(0f, 0.8f)), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = bloom,
                    ),
                    radius = bloom,
                    center = Offset(cx, cy),
                )
                // the arc draws itself from the horizontal up to the vertical
                val r = fan.r.toPx()
                val sweep = 90f * p
                drawArc(
                    color = c.copy(alpha = (0.5f * p).coerceIn(0f, 1f)),
                    startAngle = if (left) 0f else 180f,
                    sweepAngle = if (left) -sweep else sweep,
                    useCenter = false,
                    topLeft = Offset(cx - r, cy - r),
                    size = Size(2f * r, 2f * r),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
                )
            }
            .then(
                if (open) {
                    Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
                } else Modifier,
            ),
    )
}

/** One tab on the fan. It flies out of the corner button along the arc, spinning a little, and overshoots before it settles. */
@Composable
private fun RadialItem(
    tab: AppTab,
    index: Int,
    count: Int,
    selected: Boolean,
    left: Boolean,
    fan: Fan,
    fab: Dp,
    base: Dp,
    progress: Animatable<Float, *>,
    modifier: Modifier,
    onPick: () -> Unit,
) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val accent = s.navColor.tonal(cs)
    val rad = (angleOf(index, count) * PI / 180.0).toFloat()
    val cosA = cos(rad)
    val sinA = sin(rad)
    val container = if (selected) accent.first else Color.Transparent
    val tint = if (selected) accent.second else cs.onSurfaceVariant
    val fontScale = LocalDensity.current.fontScale
    Box(
        modifier
            .padding(
                start = if (left) RADIAL_MARGIN + fab / 2 - fan.item / 2 else 0.dp,
                end = if (left) 0.dp else RADIAL_MARGIN + fab / 2 - fan.item / 2,
                bottom = base + RADIAL_ROW_H / 2 - fan.item / 2,
            )
            .size(fan.item)
            .offset {
                val pr = progress.value
                val dx = fan.r.toPx() * cosA * pr
                IntOffset((if (left) dx else -dx).roundToInt(), (-fan.r.toPx() * sinA * pr).roundToInt())
            }
            .graphicsLayer {
                val pr = progress.value
                val sc = (0.3f + 0.7f * pr.coerceAtLeast(0f)) * (if (selected) 1.1f else 1f)
                scaleX = sc
                scaleY = sc
                alpha = (pr * 1.8f).coerceIn(0f, 1f)
                rotationZ = (1f - pr) * (if (left) -120f else 120f)
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .pressScale(source)
                .glow(CircleShape, selected && s.glowDock, 0.8f)
                .cardFinish(CircleShape)
                .background(container)
                .then(if (selected && s.pillOutline) Modifier.border(2.dp, s.navColor.solid(cs).first, CircleShape) else Modifier)
                .clickable(interactionSource = source, indication = LocalIndication.current) {
                    haptic()
                    onPick()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(tab.icon(), tab.label, tint = tint, modifier = Modifier.size(fan.item * 0.52f))
        }
        if (s.navLabels) {
            Text(
                tab.label,
                color = if (selected) cs.onPrimaryContainer else cs.onSurface,
                fontSize = (10.5f / fontScale.coerceAtLeast(1f)).sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = 20.dp)
                    .wrapContentWidth(Alignment.CenterHorizontally, unbounded = true)
                    .clip(RoundedCornerShape(50))
                    .background(if (selected) accent.first else cs.surfaceContainerHigh.copy(alpha = 0.92f))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            )
        }
    }
}

/** The bottom row: the corner button and the mini player. They swap sides with the corner setting. */
@Composable
private fun RadialRow(
    tab: AppTab,
    open: Boolean,
    left: Boolean,
    fan: Fan,
    fab: Dp,
    base: Dp,
    openP: State<Float>,
    hideButton: Boolean,
    onToggle: () -> Unit,
    mini: @Composable (Modifier, Boolean) -> Unit,
    modifier: Modifier,
) {
    val motion = LocalMotion.current
    // The button shrinks away while "hide bars while scrolling" is hiding the dock, and the mini player takes its place
    val slot by animateDpAsState(
        targetValue = if (hideButton && !open) 0.dp else fab,
        animationSpec = motion.spatial<Dp>(),
        label = "radialSlot",
    )
    // The gap the mini player leaves: small when the fan is closed, wide enough to clear the first tab when it is open
    val gap by animateDpAsState(
        targetValue = if (open) fan.r + fan.item / 2 + 8.dp - fab / 2 else 10.dp,
        animationSpec = motion.spatial<Dp>(),
        label = "radialGap",
    )
    val narrow = gap > 60.dp
    val button: @Composable () -> Unit = {
        Box(Modifier.width(slot).height(fab), contentAlignment = Alignment.Center) {
            RadialFab(
                tab = tab,
                openP = openP,
                onToggle = onToggle,
                modifier = Modifier
                    .requiredSize(fab)
                    .graphicsLayer {
                        val k = if (fab.value <= 0f) 1f else (slot / fab).coerceIn(0f, 1f)
                        scaleX = k
                        scaleY = k
                        alpha = k
                    },
            )
        }
    }
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = RADIAL_MARGIN)
            .padding(bottom = base)
            .height(RADIAL_ROW_H),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (left) {
            button()
            Spacer(Modifier.width(gap))
            mini(Modifier.weight(1f), narrow)
        } else {
            mini(Modifier.weight(1f), narrow)
            Spacer(Modifier.width(gap))
            button()
        }
    }
}

/**
 * The corner button. Closed, it shows the icon of the tab you are on. Opening turns the icon a quarter turn into a cross,
 * rounds the squircle into a circle and fills it with the selected-tab colour.
 */
@Composable
private fun RadialFab(tab: AppTab, openP: State<Float>, onToggle: () -> Unit, modifier: Modifier) {
    val s = LocalAppSettings.current
    val cs = MaterialTheme.colorScheme
    val haptic = rememberHaptic()
    val source = remember { MutableInteractionSource() }
    val accent = s.navColor.tonal(cs)
    val p = openP.value
    val shape = RoundedCornerShape(percent = (32 + 18 * p).roundToInt().coerceIn(0, 50))
    val outline = if (s.pillOutline) lerp(Color.Transparent, s.navColor.solid(cs).first, p) else Color.Transparent
    val tint = lerp(cs.primary, accent.second, p)
    Box(
        modifier
            .pressScale(source)
            .glow(shape, s.glowDock, 0.7f + 0.6f * p)
            .finish(shape)
            .background(lerp(Color.Transparent, accent.first, p))
            .border(2.dp, outline, shape)
            .clickable(interactionSource = source, indication = LocalIndication.current) {
                haptic()
                onToggle()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            tab.icon(),
            contentDescription = "Open menu",
            tint = tint,
            modifier = Modifier.size(26.dp).graphicsLayer {
                rotationZ = p * 90f
                alpha = 1f - p
                scaleX = 1f - 0.4f * p
                scaleY = 1f - 0.4f * p
            },
        )
        Icon(
            Icons.Rounded.Close,
            contentDescription = "Close menu",
            tint = tint,
            modifier = Modifier.size(26.dp).graphicsLayer {
                rotationZ = (p - 1f) * 90f
                alpha = p
                scaleX = 0.6f + 0.4f * p
                scaleY = 0.6f + 0.4f * p
            },
        )
    }
}
