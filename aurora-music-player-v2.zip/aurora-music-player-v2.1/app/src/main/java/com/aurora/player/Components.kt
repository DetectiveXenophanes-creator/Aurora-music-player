package com.aurora.player

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable
fun AuroraBackground(style: String, speed: Float, intensity: Float) {
    val phaseState = rememberDriftingPhase(speed, intensity)
    val colorScheme = MaterialTheme.colorScheme
    val primary = colorScheme.primary

    if (style == "Off" || style == "Still") {
        Box(modifier = Modifier.fillMaxSize().background(colorScheme.background))
        return
    }

    val phase = phaseState.value
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(colorScheme.background)

        val alphaMultiplier = (intensity / 100f).coerceIn(0f, 1f)

        for (i in 0..4) {
            val path = Path()
            val yOffset = size.height * (0.2f * i + 0.1f)
            val freq = 0.002f + i * 0.0005f
            val amp = (30f + i * 15f) * alphaMultiplier

            var x = 0f
            while (x <= size.width) {
                val y = yOffset + sin(x * freq + phase * 0.01f + i) * amp
                if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                x += 10f
            }
            drawPath(
                path = path,
                color = primary.copy(alpha = 0.08f + i * 0.02f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        if (style == "Squiggles") {
            for (j in 0..2) {
                val cx = size.width * (0.25f + j * 0.25f)
                val cy = size.height * (0.3f + (j % 2) * 0.4f)
                val baseRadius = 80.dp.toPx() + j * 20.dp.toPx()
                val circlePath = Path()
                val steps = 100
                for (step in 0..steps) {
                    val theta = (step.toFloat() / steps) * 2f * PI.toFloat()
                    val scallop = sin(theta * 6f + phase * 0.02f + j) * (15f * alphaMultiplier)
                    val r = baseRadius + scallop
                    val px = cx + r * cos(theta)
                    val py = cy + r * sin(theta)
                    if (step == 0) circlePath.moveTo(px, py) else circlePath.lineTo(px, py)
                }
                circlePath.close()
                drawPath(
                    path = circlePath,
                    color = primary.copy(alpha = 0.05f),
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun AuroraTopBar(
    title: String,
    onSettingsClick: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            actions()
            IconButton(onClick = onSettingsClick) {
                Icon(
                    imageVector = androidx.compose.material.icons.Icons.Rounded.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun AuroraMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = Modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .padding(4.dp)
    ) {
        content()
    }
}

@Composable
fun AuroraSheet(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(),
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            content = content
        )
    }
}