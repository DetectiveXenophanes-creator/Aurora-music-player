package com.aurora.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun SongsScreen(viewModel: PlayerViewModel) {
    var showFilterSheet by remember { mutableStateOf(false) }
    val state = viewModel.settingsState.value
    val songs = viewModel.songs

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("All Songs (${songs.size})", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = { showFilterSheet = true }) {
                Icon(imageVector = Icons.Rounded.FilterList, contentDescription = "Sort & Filter")
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(songs) { song ->
                ListItem(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.playSong(song, songs) },
                    headlineContent = { Text(song.title) },
                    supportingContent = { Text(song.artist) },
                    trailingContent = {
                        IconButton(onClick = { viewModel.toggleFavorite(song.id) }) {
                            Icon(
                                imageVector = if (state.favorites.contains(song.id)) androidx.compose.material.icons.Icons.Rounded.Favorite else androidx.compose.material.icons.Icons.Rounded.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (state.favorites.contains(song.id)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                )
            }
        }
    }

    if (showFilterSheet) {
        AuroraSheet(onDismiss = { showFilterSheet = false }) {
            Text("Sort & Filter", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Sort By", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SortKey.values().forEach { key ->
                    FilterChip(
                        selected = state.sortKey == key,
                        onClick = { viewModel.updateSettings { it.updateSort(key, state.sortAsc) } },
                        label = { Text(key.name) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Favorites Only")
                Spacer(modifier = Modifier.weight(1f))
                Switch(
                    checked = state.filterFav,
                    onCheckedChange = { viewModel.updateSettings { it.updateFilter(it.settingsFlow.value.filterFav.not(), state.filterLen) } }
                )
            }
        }
    }
}