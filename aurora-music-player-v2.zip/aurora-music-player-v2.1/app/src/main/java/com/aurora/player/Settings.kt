package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

val Context.dataStore by preferencesDataStore(name = "aurora_settings")

data class SettingsState(
    val animSet: String = "Smooth",
    val animSpeed: Float = 0.8f,
    val animIntensity: Float = 50f,
    val backgroundStyle: String = "Squiggles",
    val startTab: Int = 0,
    val haptics: Boolean = true,
    val hideShort: Boolean = true,
    val excludedFolders: Set<String> = emptySet(),
    val favorites: Set<Long> = emptySet(),
    val playCounts: Map<Long, Int> = emptyMap(),
    val playlists: List<Playlist> = emptyList(),
    val sortKey: SortKey = SortKey.TITLE,
    val sortAsc: Boolean = true,
    val filterFav: Boolean = false,
    val filterLen: LenFilter = LenFilter.ALL,
    val eqEnabled: Boolean = false,
    val eqGains: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f
)

class SettingsStore(private val context: Context) {
    private val gson = Gson()

    companion object {
        val ANIM_SET = stringPreferencesKey("anim_set")
        val ANIM_SPEED = floatPreferencesKey("anim_speed_v2")
        val ANIM_INTENSITY = floatPreferencesKey("anim_intensity")
        val BG_STYLE = stringPreferencesKey("bg_style")
        val START_TAB = intPreferencesKey("start_tab")
        val HAPTICS = booleanPreferencesKey("haptics")
        val HIDE_SHORT = booleanPreferencesKey("hide_short")
        val EXCLUDED = stringSetPreferencesKey("excluded_folders")
        val FAVORITES = stringSetPreferencesKey("favorites_set")
        val PLAY_COUNTS = stringPreferencesKey("play_counts_json")
        val PLAYLISTS = stringPreferencesKey("playlists_json")
        val SORT_KEY = stringPreferencesKey("sort_key")
        val SORT_ASC = booleanPreferencesKey("sort_asc")
        val FILTER_FAV = booleanPreferencesKey("filter_fav")
        val FILTER_LEN = stringPreferencesKey("filter_len")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_GAINS = stringPreferencesKey("eq_gains_json")
        val SPEED = floatPreferencesKey("playback_speed")
        val PITCH = floatPreferencesKey("playback_pitch")
    }

    val settingsFlow: Flow<SettingsState> = context.dataStore.data.map { prefs ->
        val favsStr = prefs[FAVORITES] ?: emptySet()
        val favs = favsStr.mapNotNull { it.toLongOrNull() }.toSet()

        val countsJson = prefs[PLAY_COUNTS] ?: "{}"
        val typeMap = object : TypeToken<Map<String, Int>>() {}.type
        val rawCounts: Map<String, Int> = try { gson.fromJson(countsJson, typeMap) ?: emptyMap() } catch(e: Exception) { emptyMap() }
        val counts = rawCounts.mapKeys { it.key.toLong() }

        val plJson = prefs[PLAYLISTS] ?: "[]"
        val typePl = object : TypeToken<List<Playlist>>() {}.type
        val playlists: List<Playlist> = try { gson.fromJson(plJson, typePl) ?: emptyList() } catch(e: Exception) { emptyList() }

        val gainsJson = prefs[EQ_GAINS] ?: "[0.0,0.0,0.0,0.0,0.0]"
        val typeGains = object : TypeToken<List<Float>>() {}.type
        val gains: List<Float> = try { gson.fromJson(gainsJson, typeGains) ?: listOf(0f,0f,0f,0f,0f) } catch(e: Exception) { listOf(0f,0f,0f,0f,0f) }

        SettingsState(
            animSet = prefs[ANIM_SET] ?: "Smooth",
            animSpeed = prefs[ANIM_SPEED] ?: 0.8f,
            animIntensity = prefs[ANIM_INTENSITY] ?: 50f,
            backgroundStyle = prefs[BG_STYLE] ?: "Squiggles",
            startTab = prefs[START_TAB] ?: 0,
            haptics = prefs[HAPTICS] ?: true,
            hideShort = prefs[HIDE_SHORT] ?: true,
            excludedFolders = prefs[EXCLUDED] ?: emptySet(),
            favorites = favs,
            playCounts = counts,
            playlists = playlists,
            sortKey = prefs[SORT_KEY]?.let { try { SortKey.valueOf(it) } catch(e:Exception){ SortKey.TITLE } } ?: SortKey.TITLE,
            sortAsc = prefs[SORT_ASC] ?: true,
            filterFav = prefs[FILTER_FAV] ?: false,
            filterLen = prefs[FILTER_LEN]?.let { try { LenFilter.valueOf(it) } catch(e:Exception){ LenFilter.ALL } } ?: LenFilter.ALL,
            eqEnabled = prefs[EQ_ENABLED] ?: false,
            eqGains = gains,
            speed = prefs[SPEED] ?: 1.0f,
            pitch = prefs[PITCH] ?: 1.0f
        )
    }

    suspend fun updateAnimSet(value: String) = context.dataStore.edit { it[ANIM_SET] = value }
    suspend fun updateAnimSpeed(value: Float) = context.dataStore.edit { it[ANIM_SPEED] = value }
    suspend fun updateAnimIntensity(value: Float) = context.dataStore.edit { it[ANIM_INTENSITY] = value }
    suspend fun updateBgStyle(value: String) = context.dataStore.edit { it[BG_STYLE] = value }
    suspend fun updateStartTab(value: Int) = context.dataStore.edit { it[START_TAB] = value }
    suspend fun updateHaptics(value: Boolean) = context.dataStore.edit { it[HAPTICS] = value }
    suspend fun updateHideShort(value: Boolean) = context.dataStore.edit { it[HIDE_SHORT] = value }
    suspend fun updateExcluded(value: Set<String>) = context.dataStore.edit { it[EXCLUDED] = value }

    suspend fun toggleFavorite(songId: Long) = context.dataStore.edit { prefs ->
        val current = (prefs[FAVORITES] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toMutableSet()
        if (current.contains(songId)) current.remove(songId) else current.add(songId)
        prefs[FAVORITES] = current.map { it.toString() }.toSet()
    }

    suspend fun incrementPlayCount(songId: Long) = context.dataStore.edit { prefs ->
        val countsJson = prefs[PLAY_COUNTS] ?: "{}"
        val typeMap = object : TypeToken<Map<String, Int>>() {}.type
        val rawCounts: MutableMap<String, Int> = try { gson.fromJson(countsJson, typeMap)?.toMutableMap() ?: mutableMapOf() } catch(e: Exception) { mutableMapOf() }
        val key = songId.toString()
        rawCounts[key] = (rawCounts[key] ?: 0) + 1
        prefs[PLAY_COUNTS] = gson.toJson(rawCounts)
    }

    suspend fun savePlaylists(playlists: List<Playlist>) = context.dataStore.edit { prefs ->
        prefs[PLAYLISTS] = gson.toJson(playlists)
    }

    suspend fun updateSort(key: SortKey, asc: Boolean) = context.dataStore.edit { prefs ->
        prefs[SORT_KEY] = key.name
        prefs[SORT_ASC] = asc
    }

    suspend fun updateFilter(fav: Boolean, len: LenFilter) = context.dataStore.edit { prefs ->
        prefs[FILTER_FAV] = fav
        prefs[FILTER_LEN] = len.name
    }

    suspend fun updateEq(enabled: Boolean, gains: List<Float>) = context.dataStore.edit { prefs ->
        prefs[EQ_ENABLED] = enabled
        prefs[EQ_GAINS] = gson.toJson(gains)
    }

    suspend fun updateSpeedPitch(speed: Float, pitch: Float) = context.dataStore.edit { prefs ->
        prefs[SPEED] = speed
        prefs[PITCH] = pitch
    }
}