package com.aurora.player

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun PlaylistsScreen(viewModel: PlayerViewModel) {
    val state = viewModel.settingsState.value
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlName by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text("Playlists (${state.playlists.size})", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = { showCreateDialog = true }) {
                Icon(imageVector = Icons.Rounded.Add, contentDescription = "Create Playlist")
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.playlists) { pl ->
                ListItem(
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)),
                    headlineContent = { Text(pl.name) },
                    supportingContent = { Text("${pl.songIds.size} songs") }
                )
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("New Playlist") },
            text = {
                OutlinedTextField(
                    value = newPlName,
                    onValueChange = { newPlName = it },
                    label = { Text("Playlist Name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newPlName.isNotBlank()) {
                        val updated = state.playlists + Playlist(System.currentTimeMillis(), newPlName, emptyList())
                        viewModel.updateSettings { it.savePlaylists(updated) }
                        newPlName = ""
                        showCreateDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}