package com.aurora.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun AuroraApp(viewModel: PlayerViewModel) {
    val state = viewModel.settingsState.value
    var showIntro by remember { mutableStateOf(true) }

    AuroraTheme {
        CompositionLocalProvider(
            LocalMotion provides MotionConfig(state.animSet, state.animSpeed, state.animIntensity)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AuroraBackground(
                    style = state.backgroundStyle,
                    speed = state.animSpeed,
                    intensity = state.animIntensity
                )

                if (showIntro) {
                    IntroScreen(onFinished = { showIntro = false })
                } else {
                    RootScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun RootScreen(viewModel: PlayerViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    var showNowPlaying by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            AuroraTopBar(
                title = when(selectedTab) {
                    0 -> "Home"
                    1 -> "Songs"
                    2 -> "Albums"
                    3 -> "Folders"
                    4 -> "Playlists"
                    else -> "Aurora"
                },
                onSettingsClick = { showSettings = true }
            )

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> HomeScreen(viewModel)
                    1 -> SongsScreen(viewModel)
                    2 -> AlbumsScreen(viewModel)
                    3 -> FoldersScreen(viewModel)
                    4 -> PlaylistsScreen(viewModel)
                }
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                if (viewModel.currentSong != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { showNowPlaying = true },
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(viewModel.currentSong?.title ?: "", style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                Text(viewModel.currentSong?.artist ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            }
                            IconButton(onClick = { viewModel.togglePlayPause() }) {
                                Icon(
                                    imageVector = if (viewModel.isPlaying) androidx.compose.material.icons.Icons.Rounded.Pause else androidx.compose.material.icons.Icons.Rounded.PlayArrow,
                                    contentDescription = "Play/Pause"
                                )
                            }
                        }
                    }
                }

                AuroraNavBar(
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it }
                )
            }
        }

        if (showNowPlaying) {
            Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                NowPlayingScreen(viewModel = viewModel, onBack = { showNowPlaying = false })
            }
        }

        if (showSettings) {
            Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                SettingsScreen(viewModel = viewModel, onBack = { showSettings = false })
            }
        }
    }
}