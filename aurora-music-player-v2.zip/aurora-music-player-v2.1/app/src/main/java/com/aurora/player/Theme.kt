package com.aurora.player

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

@Composable
fun AuroraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> darkColorScheme(
            primary = ColorScheme.primaryDark,
            background = ColorScheme.backgroundDark,
            surface = ColorScheme.surfaceDark
        )
        else -> lightColorScheme(
            primary = ColorScheme.primaryLight,
            background = ColorScheme.backgroundLight,
            surface = ColorScheme.surfaceLight
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

object ColorScheme {
    val primaryLight = androidx.compose.ui.graphics.Color(0xFF6750A4)
    val backgroundLight = androidx.compose.ui.graphics.Color(0xFFFDFCFE)
    val surfaceLight = androidx.compose.ui.graphics.Color(0xFFF4F3F7)

    val primaryDark = androidx.compose.ui.graphics.Color(0xFFD0BCFF)
    val backgroundDark = androidx.compose.ui.graphics.Color(0xFF0D0D0F)
    val surfaceDark = androidx.compose.ui.graphics.Color(0xFF16161A)
}