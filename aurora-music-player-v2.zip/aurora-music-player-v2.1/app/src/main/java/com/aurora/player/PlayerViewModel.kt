package com.aurora.player

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.google.gson.Gson

class PlayerViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsStore = SettingsStore(application)
    val settingsState: StateFlow<SettingsState> = settingsStore.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SettingsState()
    )

    var songs by mutableStateOf<List<Song>>(emptyList())
    var albums by mutableStateOf<List<Album>>(emptyList())
    var artists by mutableStateOf<List<Artist>>(emptyList())
    var currentSong by mutableStateOf<Song?>(null)
    var isPlaying by mutableStateOf(false)
    var currentPosition by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var queue by mutableStateOf<List<Song>>(emptyList())
    var queueIndex by mutableStateOf(0)

    init {
        loadLibrary()
    }

    fun loadLibrary() {
        viewModelScope.launch {
            val (s, al, ar) = LibraryLoader.loadMusic(getApplication(), settingsState.value)
            songs = s
            albums = al
            artists = ar
        }
    }

    fun playSong(song: Song, newQueue: List<Song> = songs) {
        queue = newQueue
        queueIndex = queue.indexOf(song).coerceAtLeast(0)
        currentSong = song
        isPlaying = true
        duration = song.duration
        viewModelScope.launch {
            settingsStore.incrementPlayCount(song.id)
        }
    }

    fun togglePlayPause() {
        isPlaying = !isPlaying
    }

    fun skipNext() {
        if (queue.isNotEmpty()) {
            queueIndex = (queueIndex + 1) % queue.size
            currentSong = queue[queueIndex]
            duration = currentSong?.duration ?: 0L
            isPlaying = true
        }
    }

    fun skipPrev() {
        if (queue.isNotEmpty()) {
            queueIndex = if (queueIndex - 1 < 0) queue.size - 1 else queueIndex - 1
            currentSong = queue[queueIndex]
            duration = currentSong?.duration ?: 0L
            isPlaying = true
        }
    }

    fun toggleFavorite(songId: Long) {
        viewModelScope.launch { settingsStore.toggleFavorite(songId) }
    }

    fun updateSettings(update: suspend (SettingsStore) -> Unit) {
        viewModelScope.launch {
            update(settingsStore)
            loadLibrary()
        }
    }

    fun createBackup(): String {
        val state = settingsState.value
        val backupMap = mapOf(
            "favorites" to state.favorites.toList(),
            "playCounts" to state.playCounts,
            "playlists" to state.playlists,
            "settings" to mapOf(
                "animSet" to state.animSet,
                "animSpeed" to state.animSpeed,
                "animIntensity" to state.animIntensity,
                "backgroundStyle" to state.backgroundStyle,
                "haptics" to state.haptics,
                "hideShort" to state.hideShort
            )
        )
        return Gson().toJson(backupMap)
    }
}