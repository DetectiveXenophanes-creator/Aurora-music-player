package com.aurora.player

import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

data class MotionConfig(
    val animSet: String,
    val speed: Float,
    val intensity: Float
)

val LocalMotion = compositionLocalOf { MotionConfig("Smooth", 0.8f, 50f) }

fun Modifier.auroraSpatial(type: String = "press", enabled: Boolean = true): Modifier = composed {
    if (!enabled) return@composed this
    val motion = LocalMotion.current
    val factor = motion.intensity / 50f

    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) (0.96f - 0.02f * (factor - 1f).coerceAtLeast(0f)) else 1f,
        animationSpec = spring(
            dampingRatio = when(motion.animSet) {
                "Bouncy" -> 0.4f
                "Snappy" -> 0.8f
                "Fluid" -> 0.5f
                "Minimal" -> 0.99f
                else -> 0.7f
            },
            stiffness = when(motion.animSet) {
                "Bouncy" -> 300f
                "Snappy" -> 800f
                "Fluid" -> 200f
                "Minimal" -> 1500f
                else -> 400f
            }
        ),
        label = "spatial_scale"
    )

    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

@Composable
fun rememberDriftingPhase(speed: Float, intensity: Float): State<Float> {
    val infiniteTransition = rememberInfiniteTransition(label = "drift")
    return infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (15000 / (speed.coerceAtLeast(0.1f))).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )
}