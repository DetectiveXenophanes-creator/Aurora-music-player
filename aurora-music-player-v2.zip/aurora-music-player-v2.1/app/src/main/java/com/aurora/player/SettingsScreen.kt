package com.aurora.player

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(viewModel: PlayerViewModel, onBack: () -> Unit) {
    val state = viewModel.settingsState.value

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            AuroraTopBar(title = "Settings", onSettingsClick = onBack)

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Appearance & Motion", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                }

                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Background Style")
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Squiggles", "Still", "Off").forEach { style ->
                                    FilterChip(
                                        selected = state.backgroundStyle == style,
                                        onClick = { viewModel.updateSettings { it.updateBgStyle(style) } },
                                        label = { Text(style) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Animation Speed: %.1fx".format(state.animSpeed))
                            Slider(
                                value = state.animSpeed,
                                onValueChange = { speed -> viewModel.updateSettings { it.updateAnimSpeed(speed) } },
                                valueRange = 0.2f..2.0f
                            )
                        }
                    }
                }

                item {
                    Text("Backup & Restore", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                }

                item {
                    Button(onClick = {
                        val json = viewModel.createBackup()
                    }) {
                        Text("Export Backup JSON")
                    }
                }
            }
        }
    }
}