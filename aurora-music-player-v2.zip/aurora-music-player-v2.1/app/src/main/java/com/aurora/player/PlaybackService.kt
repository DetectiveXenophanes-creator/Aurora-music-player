package com.aurora.player

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import android.media.audiofx.Equalizer

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    var player: ExoPlayer? = null
    var equalizer: Equalizer? = null

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player?.let {
            equalizer = Equalizer(0, it.audioSessionId).apply {
                enabled = false
            }
        }

        mediaSession = MediaSession.Builder(this, player!!).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    fun setEqualizerGains(enabled: Boolean, gains: List<Float>) {
        equalizer?.let { eq ->
            eq.enabled = enabled
            if (enabled && gains.size >= 5) {
                val numBands = eq.numberOfBands
                for (i in 0 until minOf(numBands.toInt(), 5)) {
                    val gainMillibels = (gains[i] * 100).toInt().toShort()
                    eq.setBandLevel(i.toShort(), gainMillibels)
                }
            }
        }
    }

    fun setPlaybackSpeedPitch(speed: Float, pitch: Float) {
        player?.setPlaybackSpeed(speed)
    }

    override fun onDestroy() {
        equalizer?.release()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}