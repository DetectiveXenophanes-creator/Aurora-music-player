package com.aurora.player

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun IntroScreen(onFinished: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    var selectedTab by remember { mutableStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .clickable {
                if (step == 0) step = 1 else if (step > 2) onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        when (step) {
            0 -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val infinite = rememberInfiniteTransition(label = "intro")
                    val phase = infinite.animateFloat(0f, 100f, infiniteRepeatable(tween(2000), RepeatMode.Restart), label = "p").value
                    Canvas(modifier = Modifier.size(120.dp)) {
                        for (i in 0..5) {
                            val h = (sin(phase + i) + 1f) * 30f + 20f
                            drawRect(
                                color = MaterialTheme.colorScheme.primary,
                                topLeft = androidx.compose.ui.geometry.Offset(i * 20f.dp.toPx(), size.height - h),
                                size = androidx.compose.ui.geometry.Size(12.dp.toPx(), h)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("Aurora", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.onBackground)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Tap anywhere to begin", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            1 -> {
                Column(modifier = Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Welcome to Aurora", style = MaterialTheme.typography.headlineLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Your native, frosted glass music player.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(onClick = { step = 2 }) {
                        Text("Continue Setup")
                    }
                }
            }
            2 -> {
                Column(modifier = Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Starting Tab", style = MaterialTheme.typography.headlineMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Home", "Songs", "Playlists").forEachIndexed { index, name ->
                            FilterChip(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                label = { Text(name) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(onClick = { onFinished() }) {
                        Text("Start Listening")
                    }
                }
            }
        }
    }
}