package com.aurora.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(viewModel: PlayerViewModel) {
    val state = viewModel.settingsState.value
    val songs = viewModel.songs

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Good day", style = MaterialTheme.typography.headlineMedium)
            Text("Your personal listening hub", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Listening Stats", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    val totalPlays = state.playCounts.values.sum()
                    val totalMillis = songs.filter { state.playCounts.containsKey(it.id) }.sumOf { it.duration * (state.playCounts[it.id] ?: 0) }
                    val hours = totalMillis / 3600000
                    Text("Total music time: ~$hours hours ($totalPlays tracks played)", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            Text("Most Played", style = MaterialTheme.typography.titleLarge)
        }

        items(songs.sortedByDescending { state.playCounts[it.id] ?: 0 }.take(3).size) { index ->
            val song = songs.sortedByDescending { state.playCounts[it.id] ?: 0 }.take(3)[index]
            ListItem(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { viewModel.playSong(song) },
                headlineContent = { Text(song.title) },
                supportingContent = { Text(song.artist) }
            )
        }
    }
}