package com.aurora.player

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val albumArtUri: Uri?,
    val dateAdded: Long = 0L,
    val playCount: Int = 0
)

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val artUri: Uri?,
    val songCount: Int
)

data class Artist(
    val id: Long,
    val name: String,
    val albumCount: Int,
    val songCount: Int
)

data class Playlist(
    val id: Long,
    val name: String,
    val songIds: List<Long>,
    val color: String = "#6750A4",
    val icon: String = "music",
    val coverStyle: String = "default",
    val cornerShape: String = "rounded",
    val feel: String = "bounce",
    val feelStrength: Float = 0.8f
)

enum class SortKey { TITLE, ARTIST, DURATION, DATE_ADDED }
enum class LenFilter { ALL, SHORT, LONG }