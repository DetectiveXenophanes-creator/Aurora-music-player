package com.aurora.player

import android.content.Context
import android.provider.MediaStore
import android.net.Uri
import android.content.ContentUris
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LibraryLoader {
    suspend fun loadMusic(context: Context, settings: SettingsState): Triple<List<Song>, List<Album>, List<Artist>> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()
        val albumsMap = mutableMapOf<Long, Album>()
        val artistsMap = mutableMapOf<String, Artist>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = if (settings.hideShort) "${MediaStore.Audio.Media.DURATION} >= 30000" else null

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            val sArtworkUri = Uri.parse("content://media/external/audio/albumart")

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown"
                val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                val album = cursor.getString(albumCol) ?: "Unknown Album"
                val duration = cursor.getLong(durCol)
                val albumId = cursor.getLong(albIdCol)
                val path = cursor.getString(dataCol) ?: ""
                val dateAdded = cursor.getLong(dateCol)

                if (shouldExclude(path, settings.excludedFolders)) continue

                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val artUri = ContentUris.withAppendedId(sArtworkUri, albumId)

                val song = Song(
                    id = id,
                    title = title,
                    artist = artist,
                    album = album,
                    duration = duration,
                    uri = uri,
                    albumArtUri = artUri,
                    dateAdded = dateAdded
                )
                songs.add(song)

                albumsMap.getOrPut(albumId) {
                    Album(albumId, album, artist, artUri, 0)
                }.let {
                    albumsMap[albumId] = it.copy(songCount = it.songCount + 1)
                }

                artistsMap.getOrPut(artist) {
                    Artist(artist.hashCode().toLong(), artist, 0, 0)
                }.let {
                    artistsMap[artist] = it.copy(songCount = it.songCount + 1)
                }
            }
        }

        val sortedSongs = applySortFilter(songs, settings)
        Triple(sortedSongs, albumsMap.values.toList(), artistsMap.values.toList())
    }

    private fun shouldExclude(path: String, excluded: Set<String>): Boolean {
        if (excluded.isEmpty()) return false
        val file = File(path)
        var parent = file.parentFile
        while (parent != null) {
            if (excluded.contains(parent.absolutePath)) return true
            parent = parent.parentFile
        }
        return false
    }

    fun applySortFilter(songs: List<Song>, settings: SettingsState): List<Song> {
        val filtered = songs.filter { song ->
            val matchesFav = if (settings.filterFav) settings.favorites.contains(song.id) else true
            val matchesLen = when (settings.filterLen) {
                LenFilter.ALL -> true
                LenFilter.SHORT -> song.duration < 180000
                LenFilter.LONG -> song.duration >= 300000
            }
            matchesFav && matchesLen
        }

        return when (settings.sortKey) {
            SortKey.TITLE -> if (settings.sortAsc) filtered.sortedBy { it.title.lowercase() } else filtered.sortedByDescending { it.title.lowercase() }
            SortKey.ARTIST -> if (settings.sortAsc) filtered.sortedBy { it.artist.lowercase() } else filtered.sortedByDescending { it.artist.lowercase() }
            SortKey.DURATION -> if (settings.sortAsc) filtered.sortedBy { it.duration } else filtered.sortedByDescending { it.duration }
            SortKey.DATE_ADDED -> if (settings.sortAsc) filtered.sortedBy { it.dateAdded } else filtered.sortedByDescending { it.dateAdded }
        }
    }
}