package com.aurora.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun AuroraSeekBar(
    position: Long,
    duration: Long,
    style: String,
    onSeek: (Long) -> Unit
) {
    val progress = if (duration > 0) (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { },
        contentAlignment = Alignment.Center
    ) {
        val primary = MaterialTheme.colorScheme.primary
        val outline = MaterialTheme.colorScheme.outlineVariant

        Canvas(modifier = Modifier.fillMaxWidth().height(24.dp)) {
            val y = size.height / 2f
            if (style == "Wave") {
                val path = androidx.compose.ui.graphics.Path()
                var x = 0f
                val width = size.width
                val phase = position * 0.01f
                while (x <= width) {
                    val waveY = y + sin(x * 0.05f + phase) * 4f * (x / width)
                    if (x == 0f) path.moveTo(x, waveY) else path.lineTo(x, waveY)
                    x += 5f
                }
                drawPath(path, outline, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

                val playedPath = androidx.compose.ui.graphics.Path()
                x = 0f
                val targetW = width * progress
                while (x <= targetW) {
                    val waveY = y + sin(x * 0.05f + phase) * 4f * (x / width)
                    if (x == 0f) playedPath.moveTo(x, waveY) else playedPath.lineTo(x, waveY)
                    x += 5f
                }
                drawPath(playedPath, primary, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round))
            } else {
                drawLine(outline, Offset(0f, y), Offset(size.width, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                drawLine(primary, Offset(0f, y), Offset(size.width * progress, y), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(primary, radius = 6.dp.toPx(), center = Offset(size.width * progress, y))
            }
        }
    }
}