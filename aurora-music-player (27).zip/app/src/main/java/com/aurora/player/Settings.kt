package com.aurora.player

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.map

enum class SurfaceStyle { MATTE, GLASS }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class BackgroundStyle { GRADIENT, ALBUM, FLAT }
enum class PlayShape(val label: String) {
    MORPH("Morph"), CIRCLE("Circle"), SQUIRCLE("Squircle"), SOFT("Soft"), SQUARE("Square"), SHARP("Sharp"), LEAF("Leaf"),
}
enum class PlayStyle(val label: String) { SOLID("Solid"), TONAL("Soft"), OUTLINE("Outline"), GRADIENT("Gradient") }
enum class NpLayout(val label: String) { CLASSIC("Classic"), SPLIT("Actions first"), ONE_ROW("One row") }
enum class SeekStyle(val label: String) {
    LINE("Line"), WAVY("Wavy"), SQUIGGLE("Squiggle"), THICK("Thick"), THIN("Hairline"),
    DOTS("Dots"), BARS("Bars"), STEPS("Steps"),
}
enum class SeekThumb(val label: String) { CIRCLE("Circle"), PILL("Pill"), SQUARE("Square"), NONE("None") }
enum class SeekColor(val label: String) { PRIMARY("Primary"), SECONDARY("Secondary"), TERTIARY("Tertiary"), GRADIENT("Gradient") }
enum class DesignStyle(val label: String, val blurb: String, val corner: Float) {
    MATERIAL("Material You", "Tonal colours from your wallpaper, matte or frosted glass.", 24f),
    SOFT("Soft", "Gentle, raised surfaces with soft light and shadow.", 28f),
    OUTLINE("Outlined", "Flat and clean, with thin lines instead of fills.", 14f),
    BRUTAL("Neo-brutal", "Bold borders, hard shadows and flat colour.", 8f),
    GLOSSY("Glossy", "Shiny, candy-like surfaces with a bright top edge.", 22f),
    NEON("Neon", "Dark surfaces with glowing coloured edges.", 18f),
    CANDY("Candy", "Chunky, colourful and bouncy, like a sweet shop.", 36f),
    PAPER("Paper", "Warm, flat cards that rest on the page with a soft shadow.", 12f),
    TERMINAL("Terminal", "Retro computer look: mono text and thin glowing lines.", 4f),
}
enum class BgPattern(val label: String) {
    NONE("None"), DOTS("Dots"), GRID("Grid"), STARS("Stars"), CONFETTI("Confetti"), STRIPES("Stripes"),
}
enum class ButtonShape(val label: String, val pct: Float) { PILL("Pill", 50f), SOFT("Soft", 34f), SQUARE("Square", 18f), SHARP("Sharp", 8f) }
enum class NavStyle(val label: String) { SPLIT("Split pills"), SINGLE("One bar"), CLASSIC("Classic") }
enum class PerfMode(val label: String) { AUTO("Auto"), FULL("Full"), LITE("Lite") }
enum class ListDensity { COMFORTABLE, COMPACT, SPACIOUS }
enum class RowStyle(val label: String) { CARD("Cards"), FLAT("Flat") }
enum class ListArtShape(val label: String) { SOFT("Soft"), CIRCLE("Circle"), SQUARE("Square") }
enum class MiniSize(val label: String) { SLIM("Slim"), NORMAL("Normal"), LARGE("Large") }
/** Which theme colour an individual element uses. Auto keeps the default for that element. */
enum class ColorSource(val label: String) { AUTO("Auto"), PRIMARY("Primary"), SECONDARY("Secondary"), TERTIARY("Tertiary") }
enum class MascotPalette(val label: String, val colors: List<Long>) {
    AURORA("Aurora", listOf(0xFF2EE6A6, 0xFF2ED9FF, 0xFF8A5CFF, 0xFFFF6FD8)),
    SUNSET("Sunset", listOf(0xFFFFD166, 0xFFFF8A5B, 0xFFFF4D8D, 0xFF9B5DE5)),
    OCEAN("Ocean", listOf(0xFF7CF7E4, 0xFF2ED9FF, 0xFF3A86FF, 0xFF4361EE)),
    CANDY("Candy", listOf(0xFFFFB3E6, 0xFFFF6FD8, 0xFFB388FF, 0xFF7FD1FF)),
    MINT("Mint", listOf(0xFFB9FBC0, 0xFF2EE6A6, 0xFF2EC4B6, 0xFF3DDC97)),
    GALAXY("Galaxy", listOf(0xFF6A5CFF, 0xFF8A5CFF, 0xFFC04DFF, 0xFFFF6FD8)),
    MOON("Moon", listOf(0xFFFFFFFF, 0xFFD9E2FF, 0xFFB0BEE8, 0xFF8FA0D6)),
}
enum class MascotHat(val label: String) { NONE("None"), PARTY("Party hat"), CROWN("Crown"), BOW("Bow"), HALO("Halo") }
enum class MascotEyewear(val label: String) { NONE("None"), GLASSES("Glasses"), SHADES("Sunglasses") }
/** Which interface the app uses. Current is the v2.8 overhaul, Legacy is the layout from v2.7 and before. */
enum class UiVersion(val label: String) { CURRENT("Current"), LEGACY("Legacy") }
enum class DockStyle(val label: String) { FLOATING("Floating"), ATTACHED("Attached"), RADIAL("Radial") }
/** Which bottom corner the Radial dock lives in. */
enum class RadialSide(val label: String) { LEFT("Left"), RIGHT("Right") }
enum class HeaderStyle(val label: String) { LARGE("Large title"), FROSTED("Frosted bar"), CLEAN("Clean") }
enum class PlaylistLayout(val label: String) { GRID("Grid"), LIST("List"), BIG("Big cards") }
enum class PlaylistSize(val label: String, val minWidth: Int) { SMALL("Small", 120), MEDIUM("Medium", 160), LARGE("Large", 210) }
enum class PlaylistOrder(val label: String) { MANUAL("As created"), NAME("Name"), SIZE("Most songs") }
enum class HideBars(val label: String) { OFF("Never"), DOCK("Dock"), HEADER("Header"), BOTH("Dock and header") }
enum class GlowTint(val label: String) {
    PRIMARY("Primary"), SECONDARY("Secondary"), TERTIARY("Tertiary"), COVER("Album cover"), CYCLE("Colour cycle"),
}
enum class TouchFx(val label: String) { SQUISH("Squish"), GROW("Grow"), GLOW("Grow and glow"), OFF("None") }
enum class NpDesign(val label: String) { ORBIT("Orbit"), PANEL("Panel") }
enum class RingStyle(val label: String) { SOLID("Solid"), GRADIENT("Gradient"), DOTS("Dots") }
enum class DockIndicator(val label: String) { LINE("Glow line"), PILL("Pill") }
enum class MascotEars(val label: String) { POINTY("Pointy"), ROUND("Round"), TALL("Tall") }
enum class MascotEyes(val label: String) { CLASSIC("Classic"), BIG("Big"), SPARKLE("Sparkle") }
enum class MascotTail(val label: String) { CURLY("Curly"), FLUFFY("Fluffy"), LONG("Long"), NONE("None") }
enum class MascotNeck(val label: String) { NONE("None"), BELL("Bell"), BOWTIE("Bow tie"), STAR("Star") }
enum class MascotMark(val label: String) { NONE("None"), STRIPES("Stripes"), SPOTS("Spots"), STAR("Star mark") }
enum class SquiggleMode { OFF, STATIC, ANIMATED }
enum class ArtShape(val label: String) {
    ROUNDED("Rounded"), CIRCLE("Circle"), VINYL("Vinyl"), SQUIRCLE("Squircle"), COOKIE("Cookie"),
}
enum class UiFont(val label: String) { DEFAULT("Default"), SERIF("Serif"), MONO("Mono"), CURSIVE("Cursive") }

/** A colour theme the user saved. Presets use the same shape (see Themes.kt). */
data class CustomTheme(
    val id: String,
    val name: String,
    val accent: Int,
    val spread: Float,
    val vibrancy: Float,
    val mode: ThemeMode,
    val amoled: Boolean,
)

fun encodeThemes(list: List<CustomTheme>): String {
    val arr = JSONArray()
    list.forEach { arr.put(themeToJson(it)) }
    return arr.toString()
}

fun themeToJson(t: CustomTheme): JSONObject = JSONObject()
    .put("id", t.id).put("name", t.name).put("accent", t.accent)
    .put("spread", t.spread.toDouble()).put("vibrancy", t.vibrancy.toDouble())
    .put("mode", t.mode.name).put("amoled", t.amoled)

fun themeFromJson(o: JSONObject): CustomTheme? = runCatching {
    CustomTheme(
        id = o.optString("id").ifBlank { "t" + System.currentTimeMillis() },
        name = o.getString("name").take(32),
        accent = o.getInt("accent"),
        spread = o.optDouble("spread", 1.0).toFloat().coerceIn(-3f, 3f),
        vibrancy = o.optDouble("vibrancy", 1.0).toFloat().coerceIn(0f, 1.5f),
        mode = ThemeMode.entries.firstOrNull { it.name == o.optString("mode") } ?: ThemeMode.DARK,
        amoled = o.optBoolean("amoled", false),
    )
}.getOrNull()

fun decodeThemes(s: String?): List<CustomTheme> = runCatching {
    val arr = JSONArray(s ?: "[]")
    (0 until arr.length()).mapNotNull { themeFromJson(arr.getJSONObject(it)) }
}.getOrDefault(emptyList())
enum class SortKey(val label: String) {
    TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), DURATION("Length"), ADDED("Date added"), PLAYS("Most played")
}
enum class LenFilter(val label: String) { ANY("Any"), SHORT("Under 3 min"), MEDIUM("3 to 6 min"), LONG("Over 6 min") }

enum class AppTab(val label: String) {
    HOME("Home"),
    SONGS("Songs"),
    PLAYLISTS("Playlists"),
    ALBUMS("Albums"),
    FOLDERS("Folders"),
    ARTISTS("Artists"),
}

/** Cards on the Home screen. Their order and visibility are customizable. */
/** What shaking the phone does while music plays. */
enum class ShakeAction(val label: String) {
    OFF("Off"), NEXT("Next song"), PREVIOUS("Previous song"), SHUFFLE("Toggle shuffle"),
}

/** What swiping a song row to the left or right does. */
enum class SwipeAction(val label: String) {
    NONE("Nothing"), PLAY_NEXT("Play next"), ADD_QUEUE("Add to queue"), FAVORITE("Favorite"),
}

enum class HomeSection(val label: String, val blurb: String) {
    MOST("Most played", "Your top song and its play count"),
    MIX("Daily mix", "A fresh set of songs every day"),
    FORGOTTEN("Forgotten favourites", "Favorites you have not played in 90 days"),
    RIGHT_NOW("Right now", "Songs you usually play at this hour of the day"),
    FIT("Fit my time", "A mix that ends exactly when your trip does"),
    DUEL("Song duel", "Pick the better of two songs and build your own ranking"),
    TILES("Quick tiles", "Favorites, most played and recent"),
    STATS("Listening stats", "Time listened and top artists"),
    RECENT("Recently played", "The last songs you played"),
    ON_THIS_DAY("On this day", "Songs you played on this date in past years"),
    MOODS("Mood mixes", "Play songs by the emoji sticker you gave them"),
    PASSPORT("Aurora passport", "Listening streak, badges and your listening clock"),
}

/** The tabs the Current dock shows. At least two always stay on, even if a restored backup says otherwise. */
fun AppSettings.dockTabs(): List<AppTab> =
    AppTab.entries.filter { it !in dockHidden }.let { if (it.size >= 2) it else AppTab.entries.toList() }

private fun parseHomeOrder(s: String?): List<HomeSection> {
    val parsed = s?.split(',')?.mapNotNull { n -> HomeSection.entries.firstOrNull { it.name == n } }.orEmpty().distinct()
    return parsed + HomeSection.entries.filter { it !in parsed }
}

data class AppSettings(
    // Customization
    val style: SurfaceStyle = SurfaceStyle.GLASS,
    val blur: Float = 24f,
    val glassTint: Float = 0.5f,
    val edgeHighlight: Boolean = true,
    val corner: Float = 24f,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val accent: Int = 0xFF6750A4.toInt(),
    val amoled: Boolean = false,
    val background: BackgroundStyle = BackgroundStyle.GRADIENT,
    val squiggles: SquiggleMode = SquiggleMode.ANIMATED,
    val playShape: PlayShape = PlayShape.MORPH,
    val seekStyle: SeekStyle = SeekStyle.LINE,
    val seekThickness: Float = 4f,
    val seekThumb: SeekThumb = SeekThumb.CIRCLE,
    val seekColor: SeekColor = SeekColor.PRIMARY,
    val seekWave: Float = 1f,
    val seekWaveLen: Float = 1f,
    val seekRemaining: Boolean = false,
    val design: DesignStyle = DesignStyle.MATERIAL,
    val buttonShape: ButtonShape = ButtonShape.PILL,
    val navStyle: NavStyle = NavStyle.SPLIT,
    val coverColors: Boolean = false,
    val userName: String = "",
    val greeting: Boolean = true,
    val perfMode: PerfMode = PerfMode.AUTO,
    val bgPattern: BgPattern = BgPattern.NONE,
    // Current interface only: the moving background (the old background settings are for Legacy)
    val backdrop: BackdropStyle = BackdropStyle.ORBS,
    val backdropPalette: BackdropPalette = BackdropPalette.THEME,
    val backdropSpeed: Float = 1f,
    val backdropIntensity: Float = 0.85f,
    val backdropScale: Float = 1f,
    val backdropColorA: Int = 0xFF7C4DFF.toInt(),
    val backdropColorB: Int = 0xFF00E5A8.toInt(),
    val borderWidth: Float = 2f,
    val mascot: Boolean = true,
    val pageStyle: PageStyle = PageStyle.AUTO,
    val rowStyle: RowStyle = RowStyle.CARD,
    val listArtShape: ListArtShape = ListArtShape.SOFT,
    val rowArtist: Boolean = true,
    val rowDuration: Boolean = true,
    val rowEq: Boolean = true,
    val miniSize: MiniSize = MiniSize.NORMAL,
    val miniArt: Boolean = true,
    val miniSkip: Boolean = true,
    val miniProgress: Boolean = true,
    // Floating mini player (Current interface): a design that is not joined to the dock
    val floatMini: FloatMini = FloatMini.CLASSIC,
    val floatAlign: FloatAlign = FloatAlign.CENTER,
    val floatGap: Float = 8f,
    val floatMargin: Float = 14f,
    val floatWidth: Float = 1f,
    val floatHide: Boolean = false,
    val floatTint: Boolean = true,
    val floatSwipeUp: Boolean = true,
    val npArrows: Boolean = true,
    val npAudioChip: Boolean = true,
    val playColor: ColorSource = ColorSource.AUTO,
    val navColor: ColorSource = ColorSource.AUTO,
    val mascotPalette: MascotPalette = MascotPalette.AURORA,
    val mascotHat: MascotHat = MascotHat.NONE,
    val mascotEyewear: MascotEyewear = MascotEyewear.NONE,
    val mascotHeadphones: Boolean = false,
    val mascotScarf: Boolean = false,
    val mascotBlush: Boolean = true,
    val mascotName: String = "Lumi",
    val mascotSize: Float = 64f,
    val playStyle: PlayStyle = PlayStyle.SOLID,
    val playGlow: Boolean = false,
    val playIconScale: Float = 1f,
    val npLayout: NpLayout = NpLayout.CLASSIC,
    val npGap: Float = 10f,
    val npButtonScale: Float = 1f,
    val npPlayWeight: Float = 1f,
    val npShowSkip: Boolean = true,
    val npShowShuffle: Boolean = true,
    val npShowRepeat: Boolean = true,
    val npShowFav: Boolean = true,
    val npTitleScale: Float = 1f,
    val npTitleCenter: Boolean = false,
    val npTopTitle: Boolean = true,
    val density: ListDensity = ListDensity.COMFORTABLE,
    val listArt: Boolean = true,
    val navLabels: Boolean = true,
    val artEdge: Float = 0.3f,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val spread: Float = 1f,
    val vibrancy: Float = 1f,
    val activeTheme: String = "",
    val customThemes: List<CustomTheme> = emptyList(),
    val auroraGlow: Float = 0.35f,
    val artShape: ArtShape = ArtShape.ROUNDED,
    val textScale: Float = 1f,
    val uiFont: UiFont = UiFont.DEFAULT,
    val bgFps: Int = 20,
    val batterySaver: Boolean = false,
    val homeOrder: List<HomeSection> = HomeSection.entries.toList(),
    val homeHidden: Set<HomeSection> = emptySet(),
    val mixSize: Int = 12,
    // Interface (v2.8)
    val uiVersion: UiVersion = UiVersion.CURRENT,
    val dockStyle: DockStyle = DockStyle.FLOATING,
    val headerStyle: HeaderStyle = HeaderStyle.LARGE,
    val homeHero: Boolean = true,
    val npPanel: Boolean = true,
    // Lumi (v2.8)
    val mascotEars: MascotEars = MascotEars.POINTY,
    val mascotEyes: MascotEyes = MascotEyes.CLASSIC,
    val mascotTail: MascotTail = MascotTail.CURLY,
    val mascotNeck: MascotNeck = MascotNeck.NONE,
    val mascotMark: MascotMark = MascotMark.NONE,
    val mascotWings: Boolean = false,
    val mascotSparkles: Boolean = true,
    val mascotHue: Float = -1f,
    val mascotGlow: Float = 1f,
    val mascotSpeed: Float = 1f,
    val mascotNotes: Boolean = true,
    val mascotTouch: Boolean = true,
    val mascotFlow: Boolean = true,
    // Glow, touch, Orbit player (v2.9)
    val glowOn: Boolean = true,
    val glowStrength: Float = 0.8f,
    val glowSize: Float = 14f,
    val glowTint: GlowTint = GlowTint.PRIMARY,
    val glowPulse: Boolean = true,
    val glowOrbs: Boolean = true,
    val glowDock: Boolean = true,
    val glowMini: Boolean = true,
    val glowCards: Boolean = true,
    val glowPlaying: Boolean = true,
    val glowButtons: Boolean = true,
    val glowArt: Boolean = true,
    val touchFx: TouchFx = TouchFx.GLOW,
    val touchGrow: Float = 1.05f,
    val npDesign: NpDesign = NpDesign.ORBIT,
    val orbitRing: Float = 8f,
    val orbitRingStyle: RingStyle = RingStyle.GRADIENT,
    val orbitSpin: Boolean = true,
    val orbitGestures: Boolean = true,
    val dockIndicator: DockIndicator = DockIndicator.LINE,
    val miniSwipe: Boolean = true,
    // Battery (v3.0)
    val powerProfile: PowerProfile = PowerProfile.BALANCED,
    val ambientWhenPaused: Boolean = false,
    val autoSaver: Boolean = true,
    // Playlists, scrolling, size (v3.0)
    val playlistLayout: PlaylistLayout = PlaylistLayout.GRID,
    val playlistSize: PlaylistSize = PlaylistSize.MEDIUM,
    val playlistOrder: PlaylistOrder = PlaylistOrder.MANUAL,
    val playlistShowCount: Boolean = true,
    val playlistShowNote: Boolean = true,
    val playlistSmartRow: Boolean = true,
    val hideBars: HideBars = HideBars.OFF,
    val marqueeTitles: Boolean = false,
    val sleepFade: Float = 0f,
    val uiScale: Float = 1f,
    // Radial dock, pill outline, dock tabs (v3.1)
    val radialSide: RadialSide = RadialSide.LEFT,
    val radialScale: Float = 1f,
    val pillOutline: Boolean = true,
    val dockHidden: Set<AppTab> = emptySet(),
    // Animations
    val animSet: AnimSet = AnimSet.SMOOTH,
    val animSpeed: Float = 0.8f,
    val animIntensity: Float = 0.5f,
    val listEntrance: Boolean = true,
    val artBreathing: Boolean = true,
    // Audio
    val playbackSpeed: Float = 1f,
    val playbackPitch: Float = 1f,
    val skipSilence: Boolean = false,
    val crossfadeSec: Int = 0,
    val volumeLevel: Int = 0,
    val resumeLong: Boolean = true,
    val eqPerDevice: Boolean = false,
    val eqDeviceKind: String = "speaker",
    val eqProfiles: String = "",
    val swipeRight: SwipeAction = SwipeAction.NONE,
    val swipeLeft: SwipeAction = SwipeAction.NONE,
    val lyricsSize: Int = 1,
    val lyricsCenter: Boolean = true,
    val shakeAction: ShakeAction = ShakeAction.OFF,
    val shakeStrength: Int = 1,
    val flipPause: Boolean = false,
    val seekBuddy: String = "",
    val npStory: Boolean = true,
    val bassBoost: Float = 0f,
    val loudness: Float = 0f,
    val eqEnabled: Boolean = false,
    val eqGains: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
    // Sorting and filtering
    val sortKey: SortKey = SortKey.TITLE,
    val sortAsc: Boolean = true,
    val filterFav: Boolean = false,
    val filterLen: LenFilter = LenFilter.ANY,
    // Library
    val includeNonMusic: Boolean = false,
    val minDurationSec: Int = 0,
    val excludedFolders: Set<String> = emptySet(),
    // Player
    val haptics: Boolean = true,
    val keepScreenOn: Boolean = false,
    // Startup
    val startTab: AppTab = AppTab.HOME,
    val showIntro: Boolean = true,
    val setupDone: Boolean = false,
    val tutorialDone: Boolean = false,
)

private val Context.dataStore by preferencesDataStore(name = "aurora_settings")

private inline fun <reified E : Enum<E>> Preferences.enumOf(
    key: Preferences.Key<String>,
    default: E,
): E = this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

class SettingsStore(private val context: Context) {
    private object K {
        val style = stringPreferencesKey("style")
        val blur = floatPreferencesKey("blur")
        val glassTint = floatPreferencesKey("glass_tint")
        val edge = booleanPreferencesKey("edge_highlight")
        val corner = floatPreferencesKey("corner")
        val theme = stringPreferencesKey("theme")
        val dynamic = booleanPreferencesKey("dynamic")
        val accent = intPreferencesKey("accent")
        val amoled = booleanPreferencesKey("amoled")
        val background = stringPreferencesKey("background")
        val squiggles = stringPreferencesKey("squiggles")
        val playShape = stringPreferencesKey("play_shape")
        val seekStyle = stringPreferencesKey("seek_style_v2")
        val density = stringPreferencesKey("density")
        val listArt = booleanPreferencesKey("list_art")
        val navLabels = booleanPreferencesKey("nav_labels")
        val animSet = stringPreferencesKey("anim_set")
        val animSpeed = floatPreferencesKey("anim_speed_v2")
        val animIntensity = floatPreferencesKey("anim_intensity")
        val listEntrance = booleanPreferencesKey("list_entrance")
        val artBreathing = booleanPreferencesKey("art_breathing")
        val pbSpeed = floatPreferencesKey("pb_speed")
        val pbPitch = floatPreferencesKey("pb_pitch")
        val skipSilence = booleanPreferencesKey("skip_silence")
        val crossfadeSec = intPreferencesKey("crossfade_sec")
        val volumeLevel = intPreferencesKey("volume_level")
        val resumeLong = booleanPreferencesKey("resume_long")
        val eqPerDevice = booleanPreferencesKey("eq_per_device")
        val eqDeviceKind = stringPreferencesKey("eq_device_kind")
        val eqProfiles = stringPreferencesKey("eq_profiles")
        val swipeRight = stringPreferencesKey("swipe_right")
        val swipeLeft = stringPreferencesKey("swipe_left")
        val lyricsSize = intPreferencesKey("lyrics_size")
        val lyricsCenter = booleanPreferencesKey("lyrics_center")
        val shakeAction = stringPreferencesKey("shake_action")
        val shakeStrength = intPreferencesKey("shake_strength")
        val flipPause = booleanPreferencesKey("flip_pause")
        val seekBuddy = stringPreferencesKey("seek_buddy")
        val npStory = booleanPreferencesKey("np_story")
        val bass = floatPreferencesKey("bass")
        val loudness = floatPreferencesKey("loudness")
        val nonMusic = booleanPreferencesKey("non_music")
        val eqOn = booleanPreferencesKey("eq_on")
        val eqGains = stringPreferencesKey("eq_gains")
        val sortKey = stringPreferencesKey("sort_key")
        val artEdge = floatPreferencesKey("art_edge")
        val language = stringPreferencesKey("language")
        val spread = floatPreferencesKey("spread")
        val vibrancy = floatPreferencesKey("vibrancy")
        val activeTheme = stringPreferencesKey("active_theme")
        val customThemes = stringPreferencesKey("custom_themes")
        val auroraGlow = floatPreferencesKey("aurora_glow")
        val artShape = stringPreferencesKey("art_shape")
        val textScale = floatPreferencesKey("text_scale")
        val uiFont = stringPreferencesKey("ui_font")
        val bgFps = intPreferencesKey("bg_fps")
        val batterySaver = booleanPreferencesKey("battery_saver")
        val homeOrder = stringPreferencesKey("home_order")
        val homeHidden = stringSetPreferencesKey("home_hidden")
        val mixSize = intPreferencesKey("mix_size")
        val sortAsc = booleanPreferencesKey("sort_asc")
        val filterFav = booleanPreferencesKey("filter_fav")
        val filterLen = stringPreferencesKey("filter_len")
        val minDur = intPreferencesKey("min_dur")
        val excluded = stringSetPreferencesKey("excluded_folders")
        val haptics = booleanPreferencesKey("haptics")
        val keepOn = booleanPreferencesKey("keep_on")
        val startTab = stringPreferencesKey("start_tab")
        val showIntro = booleanPreferencesKey("show_intro")
        val setupDone = booleanPreferencesKey("setup_done")
        val tutorialDone = booleanPreferencesKey("tutorial_done")
        val seekThickness = floatPreferencesKey("seek_thickness")
        val seekThumb = stringPreferencesKey("seek_thumb")
        val seekColor = stringPreferencesKey("seek_color")
        val seekWave = floatPreferencesKey("seek_wave")
        val seekWaveLen = floatPreferencesKey("seek_wave_len")
        val seekRemaining = booleanPreferencesKey("seek_remaining")
        val design = stringPreferencesKey("design_style")
        val buttonShape = stringPreferencesKey("button_shape")
        val navStyle = stringPreferencesKey("nav_style")
        val coverColors = booleanPreferencesKey("cover_colors")
        val userName = stringPreferencesKey("user_name")
        val greeting = booleanPreferencesKey("greeting")
        val perfMode = stringPreferencesKey("perf_mode")
        val bgPattern = stringPreferencesKey("bg_pattern")
        val backdrop = stringPreferencesKey("backdrop")
        val backdropPalette = stringPreferencesKey("backdrop_palette")
        val backdropSpeed = floatPreferencesKey("backdrop_speed")
        val backdropIntensity = floatPreferencesKey("backdrop_intensity")
        val backdropScale = floatPreferencesKey("backdrop_scale")
        val backdropColorA = intPreferencesKey("backdrop_a")
        val backdropColorB = intPreferencesKey("backdrop_b")
        val borderWidth = floatPreferencesKey("border_width")
        val mascot = booleanPreferencesKey("mascot")
        val pageStyle = stringPreferencesKey("page_style")
        val rowStyle = stringPreferencesKey("row_style")
        val listArtShape = stringPreferencesKey("list_art_shape")
        val rowArtist = booleanPreferencesKey("row_artist")
        val rowDuration = booleanPreferencesKey("row_duration")
        val rowEq = booleanPreferencesKey("row_eq")
        val miniSize = stringPreferencesKey("mini_size")
        val floatMini = stringPreferencesKey("float_mini")
        val floatAlign = stringPreferencesKey("float_align")
        val floatGap = floatPreferencesKey("float_gap")
        val floatMargin = floatPreferencesKey("float_margin")
        val floatWidth = floatPreferencesKey("float_width")
        val floatHide = booleanPreferencesKey("float_hide")
        val floatTint = booleanPreferencesKey("float_tint")
        val floatSwipeUp = booleanPreferencesKey("float_swipe_up")
        val miniArt = booleanPreferencesKey("mini_art")
        val miniSkip = booleanPreferencesKey("mini_skip")
        val miniProgress = booleanPreferencesKey("mini_progress")
        val npArrows = booleanPreferencesKey("np_arrows")
        val npAudioChip = booleanPreferencesKey("np_audio_chip")
        val playColor = stringPreferencesKey("play_color")
        val navColor = stringPreferencesKey("nav_color")
        val mascotPalette = stringPreferencesKey("mascot_palette")
        val mascotHat = stringPreferencesKey("mascot_hat")
        val mascotEyewear = stringPreferencesKey("mascot_eyewear")
        val mascotHeadphones = booleanPreferencesKey("mascot_headphones")
        val mascotScarf = booleanPreferencesKey("mascot_scarf")
        val mascotBlush = booleanPreferencesKey("mascot_blush")
        val mascotName = stringPreferencesKey("mascot_name")
        val mascotSize = floatPreferencesKey("mascot_size")
        val playStyle = stringPreferencesKey("play_style")
        val playGlow = booleanPreferencesKey("play_glow")
        val playIconScale = floatPreferencesKey("play_icon_scale")
        val npLayout = stringPreferencesKey("np_layout")
        val npGap = floatPreferencesKey("np_gap")
        val npButtonScale = floatPreferencesKey("np_button_scale")
        val npPlayWeight = floatPreferencesKey("np_play_weight")
        val npShowSkip = booleanPreferencesKey("np_show_skip")
        val npShowShuffle = booleanPreferencesKey("np_show_shuffle")
        val npShowRepeat = booleanPreferencesKey("np_show_repeat")
        val npShowFav = booleanPreferencesKey("np_show_fav")
        val npTitleScale = floatPreferencesKey("np_title_scale")
        val npTitleCenter = booleanPreferencesKey("np_title_center")
        val npTopTitle = booleanPreferencesKey("np_top_title")
        val uiVersion = stringPreferencesKey("ui_version")
        val dockStyle = stringPreferencesKey("dock_style")
        val headerStyle = stringPreferencesKey("header_style")
        val homeHero = booleanPreferencesKey("home_hero")
        val npPanel = booleanPreferencesKey("np_panel")
        val mascotEars = stringPreferencesKey("mascot_ears")
        val mascotEyes = stringPreferencesKey("mascot_eyes")
        val mascotTail = stringPreferencesKey("mascot_tail")
        val mascotNeck = stringPreferencesKey("mascot_neck")
        val mascotMark = stringPreferencesKey("mascot_mark")
        val mascotWings = booleanPreferencesKey("mascot_wings")
        val mascotSparkles = booleanPreferencesKey("mascot_sparkles")
        val mascotHue = floatPreferencesKey("mascot_hue")
        val mascotGlow = floatPreferencesKey("mascot_glow")
        val mascotSpeed = floatPreferencesKey("mascot_speed")
        val mascotNotes = booleanPreferencesKey("mascot_notes")
        val mascotTouch = booleanPreferencesKey("mascot_touch")
        val mascotFlow = booleanPreferencesKey("mascot_flow")
        val glowOn = booleanPreferencesKey("glow_on")
        val glowStrength = floatPreferencesKey("glow_strength")
        val glowSize = floatPreferencesKey("glow_size")
        val glowTint = stringPreferencesKey("glow_tint")
        val glowPulse = booleanPreferencesKey("glow_pulse")
        val glowOrbs = booleanPreferencesKey("glow_orbs")
        val glowDock = booleanPreferencesKey("glow_dock")
        val glowMini = booleanPreferencesKey("glow_mini")
        val glowCards = booleanPreferencesKey("glow_cards")
        val glowPlaying = booleanPreferencesKey("glow_playing")
        val glowButtons = booleanPreferencesKey("glow_buttons")
        val glowArt = booleanPreferencesKey("glow_art")
        val touchFx = stringPreferencesKey("touch_fx")
        val touchGrow = floatPreferencesKey("touch_grow")
        val npDesign = stringPreferencesKey("np_design")
        val orbitRing = floatPreferencesKey("orbit_ring")
        val orbitRingStyle = stringPreferencesKey("orbit_ring_style")
        val orbitSpin = booleanPreferencesKey("orbit_spin")
        val orbitGestures = booleanPreferencesKey("orbit_gestures")
        val dockIndicator = stringPreferencesKey("dock_indicator")
        val miniSwipe = booleanPreferencesKey("mini_swipe")
        val powerProfile = stringPreferencesKey("power_profile")
        val ambientWhenPaused = booleanPreferencesKey("ambient_when_paused")
        val autoSaver = booleanPreferencesKey("auto_saver")
        val playlistLayout = stringPreferencesKey("playlist_layout")
        val playlistSize = stringPreferencesKey("playlist_size")
        val playlistOrder = stringPreferencesKey("playlist_order")
        val playlistShowCount = booleanPreferencesKey("playlist_show_count")
        val playlistShowNote = booleanPreferencesKey("playlist_show_note")
        val playlistSmartRow = booleanPreferencesKey("playlist_smart_row")
        val hideBars = stringPreferencesKey("hide_bars")
        val marqueeTitles = booleanPreferencesKey("marquee_titles")
        val sleepFade = floatPreferencesKey("sleep_fade")
        val uiScale = floatPreferencesKey("ui_scale")
        val radialSide = stringPreferencesKey("radial_side")
        val radialScale = floatPreferencesKey("radial_scale")
        val pillOutline = booleanPreferencesKey("pill_outline")
        val dockHidden = stringSetPreferencesKey("dock_hidden")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    /** Every stored setting as JSON, for backups. New settings are included automatically. */
    suspend fun exportJson(): JSONObject {
        val prefs = context.dataStore.data.first()
        val arr = JSONArray()
        for ((k, v) in prefs.asMap()) {
            val entry = JSONObject().put("k", k.name)
            when (v) {
                is String -> entry.put("t", "s").put("v", v)
                is Boolean -> entry.put("t", "b").put("v", v)
                is Int -> entry.put("t", "i").put("v", v)
                is Long -> entry.put("t", "l").put("v", v)
                is Float -> entry.put("t", "f").put("v", v.toDouble())
                is Set<*> -> entry.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            arr.put(entry)
        }
        return JSONObject().put("prefs", arr)
    }

    suspend fun importJson(o: JSONObject) {
        val arr = o.optJSONArray("prefs") ?: return
        context.dataStore.edit { p ->
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val name = e.getString("k")
                when (e.getString("t")) {
                    "s" -> p[stringPreferencesKey(name)] = e.getString("v")
                    "b" -> p[booleanPreferencesKey(name)] = e.getBoolean("v")
                    "i" -> p[intPreferencesKey(name)] = e.getInt("v")
                    "l" -> p[longPreferencesKey(name)] = e.getLong("v")
                    "f" -> p[floatPreferencesKey(name)] = e.getDouble("v").toFloat()
                    "ss" -> {
                        val a = e.getJSONArray("v")
                        p[stringSetPreferencesKey(name)] = (0 until a.length()).map { a.getString(it) }.toSet()
                    }
                }
            }
            p[K.setupDone] = true
        }
    }

    /**
     * The preference names that make up how Aurora LOOKS: colours, fonts, layouts, the mascot, the Home cards.
     * Look profiles save and restore exactly these. What plays (speed, equalizer), which folders are scanned, the
     * language, your saved colour themes and your name are never touched by a profile.
     */
    private val lookKeys: Set<String> = setOf(
        "style", "blur", "glass_tint", "edge_highlight", "corner",
        "theme", "dynamic", "accent", "amoled", "background",
        "squiggles", "play_shape", "seek_style_v2", "density", "list_art",
        "nav_labels", "anim_set", "anim_speed_v2", "anim_intensity", "list_entrance",
        "art_breathing", "lyrics_size", "lyrics_center", "seek_buddy", "np_story",
        "art_edge", "spread", "vibrancy", "active_theme", "aurora_glow",
        "art_shape", "text_scale", "ui_font", "home_order", "home_hidden",
        "seek_thickness", "seek_thumb", "seek_color", "seek_wave", "seek_wave_len",
        "seek_remaining", "design_style", "button_shape", "nav_style", "cover_colors",
        "greeting", "bg_pattern", "border_width", "mascot", "page_style",
        "row_style", "list_art_shape", "row_artist", "row_duration", "row_eq",
        "mini_size", "mini_art", "mini_skip", "mini_progress", "np_arrows",
        "np_audio_chip", "play_color", "nav_color", "mascot_palette", "mascot_hat",
        "mascot_eyewear", "mascot_headphones", "mascot_scarf", "mascot_blush", "mascot_name",
        "mascot_size", "play_style", "play_glow", "play_icon_scale", "np_layout",
        "np_gap", "np_button_scale", "np_play_weight", "np_show_skip", "np_show_shuffle",
        "np_show_repeat", "np_show_fav", "np_title_scale", "np_title_center", "np_top_title",
        "ui_version", "dock_style", "header_style", "home_hero", "np_panel",
        "mascot_ears", "mascot_eyes", "mascot_tail", "mascot_neck", "mascot_mark",
        "mascot_wings", "mascot_sparkles", "mascot_hue", "mascot_glow",
        "glow_art", "glow_buttons", "glow_cards", "glow_dock", "glow_mini",
        "glow_on", "glow_orbs", "glow_playing", "glow_pulse", "glow_size",
        "glow_strength", "glow_tint", "dock_hidden", "dock_indicator", "hide_bars",
        "marquee_titles", "mascot_flow", "mascot_notes", "mascot_speed", "mascot_touch",
        "np_design", "orbit_ring", "orbit_ring_style", "orbit_spin", "pill_outline",
        "playlist_layout", "playlist_show_count", "playlist_show_note", "playlist_size", "playlist_smart_row",
        "radial_scale", "radial_side", "touch_fx", "touch_grow", "ui_scale",
        "ambient_when_paused", "backdrop", "backdrop_palette", "backdrop_speed", "backdrop_intensity", "backdrop_scale",
        "backdrop_a", "backdrop_b",
        "float_mini", "float_align", "float_gap", "float_margin", "float_width", "float_hide", "float_tint", "float_swipe_up",
    )

    /** The current look as a list of entries (name, type, value), ready to be stored in a profile. */
    suspend fun captureLook(): JSONArray {
        val prefs = context.dataStore.data.first()
        val arr = JSONArray()
        for ((k, v) in prefs.asMap()) {
            if (k.name !in lookKeys) continue
            val entry = JSONObject().put("k", k.name)
            when (v) {
                is String -> entry.put("t", "s").put("v", v)
                is Boolean -> entry.put("t", "b").put("v", v)
                is Int -> entry.put("t", "i").put("v", v)
                is Long -> entry.put("t", "l").put("v", v)
                is Float -> entry.put("t", "f").put("v", v.toDouble())
                is Set<*> -> entry.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            arr.put(entry)
        }
        return arr
    }

    /**
     * Switches to a saved look. Settings the profile does not mention go back to their default, because a look
     * only stores what was changed from the default when it was saved.
     */
    suspend fun applyLook(arr: JSONArray) {
        val wanted = HashSet<String>()
        for (i in 0 until arr.length()) wanted.add(arr.getJSONObject(i).getString("k"))
        context.dataStore.edit { p ->
            for (key in p.asMap().keys.toList()) {
                if (key.name in lookKeys && key.name !in wanted) p.remove(key)
            }
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val name = e.getString("k")
                if (name !in lookKeys) continue
                when (e.getString("t")) {
                    "s" -> p[stringPreferencesKey(name)] = e.getString("v")
                    "b" -> p[booleanPreferencesKey(name)] = e.getBoolean("v")
                    "i" -> p[intPreferencesKey(name)] = e.getInt("v")
                    "l" -> p[longPreferencesKey(name)] = e.getLong("v")
                    "f" -> p[floatPreferencesKey(name)] = e.getDouble("v").toFloat()
                    "ss" -> {
                        val a = e.getJSONArray("v")
                        p[stringSetPreferencesKey(name)] = (0 until a.length()).map { a.getString(it) }.toSet()
                    }
                }
            }
        }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            style = p.enumOf(K.style, d.style),
            blur = p[K.blur] ?: d.blur,
            glassTint = p[K.glassTint] ?: d.glassTint,
            edgeHighlight = p[K.edge] ?: d.edgeHighlight,
            corner = p[K.corner] ?: d.corner,
            themeMode = p.enumOf(K.theme, d.themeMode),
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            accent = p[K.accent] ?: d.accent,
            amoled = p[K.amoled] ?: d.amoled,
            background = p.enumOf(K.background, d.background),
            squiggles = p.enumOf(K.squiggles, d.squiggles),
            playShape = p.enumOf(K.playShape, d.playShape),
            seekStyle = p.enumOf(K.seekStyle, d.seekStyle),
            density = p.enumOf(K.density, d.density),
            listArt = p[K.listArt] ?: d.listArt,
            navLabels = p[K.navLabels] ?: d.navLabels,
            animSet = p.enumOf(K.animSet, d.animSet),
            animSpeed = p[K.animSpeed] ?: d.animSpeed,
            animIntensity = p[K.animIntensity] ?: d.animIntensity,
            listEntrance = p[K.listEntrance] ?: d.listEntrance,
            artBreathing = p[K.artBreathing] ?: d.artBreathing,
            playbackSpeed = p[K.pbSpeed] ?: d.playbackSpeed,
            playbackPitch = p[K.pbPitch] ?: d.playbackPitch,
            skipSilence = p[K.skipSilence] ?: d.skipSilence,
            crossfadeSec = p[K.crossfadeSec] ?: d.crossfadeSec,
            volumeLevel = p[K.volumeLevel] ?: d.volumeLevel,
            resumeLong = p[K.resumeLong] ?: d.resumeLong,
            eqPerDevice = p[K.eqPerDevice] ?: d.eqPerDevice,
            eqDeviceKind = p[K.eqDeviceKind] ?: d.eqDeviceKind,
            eqProfiles = p[K.eqProfiles] ?: d.eqProfiles,
            swipeRight = p.enumOf(K.swipeRight, d.swipeRight),
            swipeLeft = p.enumOf(K.swipeLeft, d.swipeLeft),
            lyricsSize = p[K.lyricsSize] ?: d.lyricsSize,
            lyricsCenter = p[K.lyricsCenter] ?: d.lyricsCenter,
            shakeAction = p.enumOf(K.shakeAction, d.shakeAction),
            shakeStrength = p[K.shakeStrength] ?: d.shakeStrength,
            flipPause = p[K.flipPause] ?: d.flipPause,
            seekBuddy = p[K.seekBuddy] ?: d.seekBuddy,
            npStory = p[K.npStory] ?: d.npStory,
            bassBoost = p[K.bass] ?: d.bassBoost,
            loudness = p[K.loudness] ?: d.loudness,
            includeNonMusic = p[K.nonMusic] ?: d.includeNonMusic,
            eqEnabled = p[K.eqOn] ?: d.eqEnabled,
            eqGains = p[K.eqGains]?.split(',')?.mapNotNull { it.toFloatOrNull() }?.takeIf { it.size == 5 } ?: d.eqGains,
            sortKey = p.enumOf(K.sortKey, d.sortKey),
            artEdge = p[K.artEdge] ?: d.artEdge,
            language = p.enumOf(K.language, d.language),
            spread = p[K.spread] ?: d.spread,
            vibrancy = p[K.vibrancy] ?: d.vibrancy,
            activeTheme = p[K.activeTheme] ?: d.activeTheme,
            customThemes = decodeThemes(p[K.customThemes]),
            auroraGlow = p[K.auroraGlow] ?: d.auroraGlow,
            artShape = p.enumOf(K.artShape, d.artShape),
            textScale = p[K.textScale] ?: d.textScale,
            uiFont = p.enumOf(K.uiFont, d.uiFont),
            bgFps = p[K.bgFps] ?: d.bgFps,
            batterySaver = p[K.batterySaver] ?: d.batterySaver,
            homeOrder = parseHomeOrder(p[K.homeOrder]),
            homeHidden = (p[K.homeHidden] ?: emptySet())
                .mapNotNull { n -> HomeSection.entries.firstOrNull { it.name == n } }.toSet(),
            mixSize = p[K.mixSize] ?: d.mixSize,
            sortAsc = p[K.sortAsc] ?: d.sortAsc,
            filterFav = p[K.filterFav] ?: d.filterFav,
            filterLen = p.enumOf(K.filterLen, d.filterLen),
            minDurationSec = p[K.minDur] ?: d.minDurationSec,
            excludedFolders = p[K.excluded] ?: d.excludedFolders,
            haptics = p[K.haptics] ?: d.haptics,
            keepScreenOn = p[K.keepOn] ?: d.keepScreenOn,
            startTab = p.enumOf(K.startTab, d.startTab),
            showIntro = p[K.showIntro] ?: d.showIntro,
            setupDone = p[K.setupDone] ?: d.setupDone,
            tutorialDone = p[K.tutorialDone] ?: d.tutorialDone,
            seekThickness = p[K.seekThickness] ?: d.seekThickness,
            seekThumb = p.enumOf(K.seekThumb, d.seekThumb),
            seekColor = p.enumOf(K.seekColor, d.seekColor),
            seekWave = p[K.seekWave] ?: d.seekWave,
            seekWaveLen = p[K.seekWaveLen] ?: d.seekWaveLen,
            seekRemaining = p[K.seekRemaining] ?: d.seekRemaining,
            design = p.enumOf(K.design, d.design),
            buttonShape = p.enumOf(K.buttonShape, d.buttonShape),
            navStyle = p.enumOf(K.navStyle, d.navStyle),
            coverColors = p[K.coverColors] ?: d.coverColors,
            userName = p[K.userName] ?: d.userName,
            greeting = p[K.greeting] ?: d.greeting,
            perfMode = p.enumOf(K.perfMode, d.perfMode),
            bgPattern = p.enumOf(K.bgPattern, d.bgPattern),
            backdrop = p.enumOf(K.backdrop, d.backdrop),
            backdropPalette = p.enumOf(K.backdropPalette, d.backdropPalette),
            backdropSpeed = (p[K.backdropSpeed] ?: d.backdropSpeed).coerceIn(0.2f, 2.5f),
            backdropIntensity = (p[K.backdropIntensity] ?: d.backdropIntensity).coerceIn(0.2f, 1.4f),
            backdropScale = (p[K.backdropScale] ?: d.backdropScale).coerceIn(0.6f, 1.6f),
            backdropColorA = p[K.backdropColorA] ?: d.backdropColorA,
            backdropColorB = p[K.backdropColorB] ?: d.backdropColorB,
            borderWidth = p[K.borderWidth] ?: d.borderWidth,
            mascot = p[K.mascot] ?: d.mascot,
            pageStyle = p.enumOf(K.pageStyle, d.pageStyle),
            rowStyle = p.enumOf(K.rowStyle, d.rowStyle),
            listArtShape = p.enumOf(K.listArtShape, d.listArtShape),
            rowArtist = p[K.rowArtist] ?: d.rowArtist,
            rowDuration = p[K.rowDuration] ?: d.rowDuration,
            rowEq = p[K.rowEq] ?: d.rowEq,
            miniSize = p.enumOf(K.miniSize, d.miniSize),
            floatMini = p.enumOf(K.floatMini, d.floatMini),
            floatAlign = p.enumOf(K.floatAlign, d.floatAlign),
            floatGap = (p[K.floatGap] ?: d.floatGap).coerceIn(0f, 60f),
            floatMargin = (p[K.floatMargin] ?: d.floatMargin).coerceIn(6f, 40f),
            floatWidth = (p[K.floatWidth] ?: d.floatWidth).coerceIn(0.55f, 1f),
            floatHide = p[K.floatHide] ?: d.floatHide,
            floatTint = p[K.floatTint] ?: d.floatTint,
            floatSwipeUp = p[K.floatSwipeUp] ?: d.floatSwipeUp,
            miniArt = p[K.miniArt] ?: d.miniArt,
            miniSkip = p[K.miniSkip] ?: d.miniSkip,
            miniProgress = p[K.miniProgress] ?: d.miniProgress,
            npArrows = p[K.npArrows] ?: d.npArrows,
            npAudioChip = p[K.npAudioChip] ?: d.npAudioChip,
            playColor = p.enumOf(K.playColor, d.playColor),
            navColor = p.enumOf(K.navColor, d.navColor),
            mascotPalette = p.enumOf(K.mascotPalette, d.mascotPalette),
            mascotHat = p.enumOf(K.mascotHat, d.mascotHat),
            mascotEyewear = p.enumOf(K.mascotEyewear, d.mascotEyewear),
            mascotHeadphones = p[K.mascotHeadphones] ?: d.mascotHeadphones,
            mascotScarf = p[K.mascotScarf] ?: d.mascotScarf,
            mascotBlush = p[K.mascotBlush] ?: d.mascotBlush,
            mascotName = p[K.mascotName] ?: d.mascotName,
            mascotSize = p[K.mascotSize] ?: d.mascotSize,
            playStyle = p.enumOf(K.playStyle, d.playStyle),
            playGlow = p[K.playGlow] ?: d.playGlow,
            playIconScale = p[K.playIconScale] ?: d.playIconScale,
            npLayout = p.enumOf(K.npLayout, d.npLayout),
            npGap = p[K.npGap] ?: d.npGap,
            npButtonScale = p[K.npButtonScale] ?: d.npButtonScale,
            npPlayWeight = p[K.npPlayWeight] ?: d.npPlayWeight,
            npShowSkip = p[K.npShowSkip] ?: d.npShowSkip,
            npShowShuffle = p[K.npShowShuffle] ?: d.npShowShuffle,
            npShowRepeat = p[K.npShowRepeat] ?: d.npShowRepeat,
            npShowFav = p[K.npShowFav] ?: d.npShowFav,
            npTitleScale = p[K.npTitleScale] ?: d.npTitleScale,
            npTitleCenter = p[K.npTitleCenter] ?: d.npTitleCenter,
            npTopTitle = p[K.npTopTitle] ?: d.npTopTitle,
            uiVersion = p.enumOf(K.uiVersion, d.uiVersion),
            dockStyle = p.enumOf(K.dockStyle, d.dockStyle),
            headerStyle = p.enumOf(K.headerStyle, d.headerStyle),
            homeHero = p[K.homeHero] ?: d.homeHero,
            npPanel = p[K.npPanel] ?: d.npPanel,
            mascotEars = p.enumOf(K.mascotEars, d.mascotEars),
            mascotEyes = p.enumOf(K.mascotEyes, d.mascotEyes),
            mascotTail = p.enumOf(K.mascotTail, d.mascotTail),
            mascotNeck = p.enumOf(K.mascotNeck, d.mascotNeck),
            mascotMark = p.enumOf(K.mascotMark, d.mascotMark),
            mascotWings = p[K.mascotWings] ?: d.mascotWings,
            mascotSparkles = p[K.mascotSparkles] ?: d.mascotSparkles,
            mascotHue = p[K.mascotHue] ?: d.mascotHue,
            mascotGlow = p[K.mascotGlow] ?: d.mascotGlow,
            mascotSpeed = p[K.mascotSpeed] ?: d.mascotSpeed,
            mascotNotes = p[K.mascotNotes] ?: d.mascotNotes,
            mascotTouch = p[K.mascotTouch] ?: d.mascotTouch,
            mascotFlow = p[K.mascotFlow] ?: d.mascotFlow,
            glowOn = p[K.glowOn] ?: d.glowOn,
            glowStrength = p[K.glowStrength] ?: d.glowStrength,
            glowSize = p[K.glowSize] ?: d.glowSize,
            glowTint = p.enumOf(K.glowTint, d.glowTint),
            glowPulse = p[K.glowPulse] ?: d.glowPulse,
            glowOrbs = p[K.glowOrbs] ?: d.glowOrbs,
            glowDock = p[K.glowDock] ?: d.glowDock,
            glowMini = p[K.glowMini] ?: d.glowMini,
            glowCards = p[K.glowCards] ?: d.glowCards,
            glowPlaying = p[K.glowPlaying] ?: d.glowPlaying,
            glowButtons = p[K.glowButtons] ?: d.glowButtons,
            glowArt = p[K.glowArt] ?: d.glowArt,
            touchFx = p.enumOf(K.touchFx, d.touchFx),
            touchGrow = p[K.touchGrow] ?: d.touchGrow,
            npDesign = p.enumOf(K.npDesign, d.npDesign),
            orbitRing = p[K.orbitRing] ?: d.orbitRing,
            orbitRingStyle = p.enumOf(K.orbitRingStyle, d.orbitRingStyle),
            orbitSpin = p[K.orbitSpin] ?: d.orbitSpin,
            orbitGestures = p[K.orbitGestures] ?: d.orbitGestures,
            dockIndicator = p.enumOf(K.dockIndicator, d.dockIndicator),
            miniSwipe = p[K.miniSwipe] ?: d.miniSwipe,
            powerProfile = p.enumOf(K.powerProfile, d.powerProfile),
            ambientWhenPaused = p[K.ambientWhenPaused] ?: d.ambientWhenPaused,
            autoSaver = p[K.autoSaver] ?: d.autoSaver,
            playlistLayout = p.enumOf(K.playlistLayout, d.playlistLayout),
            playlistSize = p.enumOf(K.playlistSize, d.playlistSize),
            playlistOrder = p.enumOf(K.playlistOrder, d.playlistOrder),
            playlistShowCount = p[K.playlistShowCount] ?: d.playlistShowCount,
            playlistShowNote = p[K.playlistShowNote] ?: d.playlistShowNote,
            playlistSmartRow = p[K.playlistSmartRow] ?: d.playlistSmartRow,
            hideBars = p.enumOf(K.hideBars, d.hideBars),
            marqueeTitles = p[K.marqueeTitles] ?: d.marqueeTitles,
            sleepFade = p[K.sleepFade] ?: d.sleepFade,
            uiScale = p[K.uiScale] ?: d.uiScale,
            radialSide = p.enumOf(K.radialSide, d.radialSide),
            radialScale = p[K.radialScale] ?: d.radialScale,
            pillOutline = p[K.pillOutline] ?: d.pillOutline,
            dockHidden = (p[K.dockHidden] ?: emptySet())
                .mapNotNull { n -> AppTab.entries.firstOrNull { it.name == n } }.toSet(),
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.style] = s.style.name
        p[K.blur] = s.blur
        p[K.glassTint] = s.glassTint
        p[K.edge] = s.edgeHighlight
        p[K.corner] = s.corner
        p[K.theme] = s.themeMode.name
        p[K.dynamic] = s.dynamicColor
        p[K.accent] = s.accent
        p[K.amoled] = s.amoled
        p[K.background] = s.background.name
        p[K.squiggles] = s.squiggles.name
        p[K.playShape] = s.playShape.name
        p[K.seekStyle] = s.seekStyle.name
        p[K.density] = s.density.name
        p[K.listArt] = s.listArt
        p[K.navLabels] = s.navLabels
        p[K.animSet] = s.animSet.name
        p[K.animSpeed] = s.animSpeed
        p[K.animIntensity] = s.animIntensity
        p[K.listEntrance] = s.listEntrance
        p[K.artBreathing] = s.artBreathing
        p[K.pbSpeed] = s.playbackSpeed
        p[K.pbPitch] = s.playbackPitch
        p[K.skipSilence] = s.skipSilence
        p[K.crossfadeSec] = s.crossfadeSec
        p[K.volumeLevel] = s.volumeLevel
        p[K.resumeLong] = s.resumeLong
        p[K.eqPerDevice] = s.eqPerDevice
        p[K.eqDeviceKind] = s.eqDeviceKind
        p[K.eqProfiles] = s.eqProfiles
        p[K.swipeRight] = s.swipeRight.name
        p[K.swipeLeft] = s.swipeLeft.name
        p[K.lyricsSize] = s.lyricsSize
        p[K.lyricsCenter] = s.lyricsCenter
        p[K.shakeAction] = s.shakeAction.name
        p[K.shakeStrength] = s.shakeStrength
        p[K.flipPause] = s.flipPause
        p[K.seekBuddy] = s.seekBuddy
        p[K.npStory] = s.npStory
        p[K.bass] = s.bassBoost
        p[K.loudness] = s.loudness
        p[K.nonMusic] = s.includeNonMusic
        p[K.eqOn] = s.eqEnabled
        p[K.eqGains] = s.eqGains.joinToString(",")
        p[K.sortKey] = s.sortKey.name
        p[K.artEdge] = s.artEdge
        p[K.language] = s.language.name
        p[K.spread] = s.spread
        p[K.vibrancy] = s.vibrancy
        p[K.activeTheme] = s.activeTheme
        p[K.customThemes] = encodeThemes(s.customThemes)
        p[K.auroraGlow] = s.auroraGlow
        p[K.artShape] = s.artShape.name
        p[K.textScale] = s.textScale
        p[K.uiFont] = s.uiFont.name
        p[K.bgFps] = s.bgFps
        p[K.batterySaver] = s.batterySaver
        p[K.homeOrder] = s.homeOrder.joinToString(",") { it.name }
        p[K.homeHidden] = s.homeHidden.map { it.name }.toSet()
        p[K.mixSize] = s.mixSize
        p[K.sortAsc] = s.sortAsc
        p[K.filterFav] = s.filterFav
        p[K.filterLen] = s.filterLen.name
        p[K.minDur] = s.minDurationSec
        p[K.excluded] = s.excludedFolders
        p[K.haptics] = s.haptics
        p[K.keepOn] = s.keepScreenOn
        p[K.startTab] = s.startTab.name
        p[K.showIntro] = s.showIntro
        p[K.setupDone] = s.setupDone
        p[K.tutorialDone] = s.tutorialDone
        p[K.seekThickness] = s.seekThickness
        p[K.seekThumb] = s.seekThumb.name
        p[K.seekColor] = s.seekColor.name
        p[K.seekWave] = s.seekWave
        p[K.seekWaveLen] = s.seekWaveLen
        p[K.seekRemaining] = s.seekRemaining
        p[K.design] = s.design.name
        p[K.buttonShape] = s.buttonShape.name
        p[K.navStyle] = s.navStyle.name
        p[K.coverColors] = s.coverColors
        p[K.userName] = s.userName
        p[K.greeting] = s.greeting
        p[K.perfMode] = s.perfMode.name
        p[K.bgPattern] = s.bgPattern.name
        p[K.backdrop] = s.backdrop.name
        p[K.backdropPalette] = s.backdropPalette.name
        p[K.backdropSpeed] = s.backdropSpeed
        p[K.backdropIntensity] = s.backdropIntensity
        p[K.backdropScale] = s.backdropScale
        p[K.backdropColorA] = s.backdropColorA
        p[K.backdropColorB] = s.backdropColorB
        p[K.borderWidth] = s.borderWidth
        p[K.mascot] = s.mascot
        p[K.pageStyle] = s.pageStyle.name
        p[K.rowStyle] = s.rowStyle.name
        p[K.listArtShape] = s.listArtShape.name
        p[K.rowArtist] = s.rowArtist
        p[K.rowDuration] = s.rowDuration
        p[K.rowEq] = s.rowEq
        p[K.miniSize] = s.miniSize.name
        p[K.floatMini] = s.floatMini.name
        p[K.floatAlign] = s.floatAlign.name
        p[K.floatGap] = s.floatGap
        p[K.floatMargin] = s.floatMargin
        p[K.floatWidth] = s.floatWidth
        p[K.floatHide] = s.floatHide
        p[K.floatTint] = s.floatTint
        p[K.floatSwipeUp] = s.floatSwipeUp
        p[K.miniArt] = s.miniArt
        p[K.miniSkip] = s.miniSkip
        p[K.miniProgress] = s.miniProgress
        p[K.npArrows] = s.npArrows
        p[K.npAudioChip] = s.npAudioChip
        p[K.playColor] = s.playColor.name
        p[K.navColor] = s.navColor.name
        p[K.mascotPalette] = s.mascotPalette.name
        p[K.mascotHat] = s.mascotHat.name
        p[K.mascotEyewear] = s.mascotEyewear.name
        p[K.mascotHeadphones] = s.mascotHeadphones
        p[K.mascotScarf] = s.mascotScarf
        p[K.mascotBlush] = s.mascotBlush
        p[K.mascotName] = s.mascotName
        p[K.mascotSize] = s.mascotSize
        p[K.playStyle] = s.playStyle.name
        p[K.playGlow] = s.playGlow
        p[K.playIconScale] = s.playIconScale
        p[K.npLayout] = s.npLayout.name
        p[K.npGap] = s.npGap
        p[K.npButtonScale] = s.npButtonScale
        p[K.npPlayWeight] = s.npPlayWeight
        p[K.npShowSkip] = s.npShowSkip
        p[K.npShowShuffle] = s.npShowShuffle
        p[K.npShowRepeat] = s.npShowRepeat
        p[K.npShowFav] = s.npShowFav
        p[K.npTitleScale] = s.npTitleScale
        p[K.npTitleCenter] = s.npTitleCenter
        p[K.npTopTitle] = s.npTopTitle
        p[K.uiVersion] = s.uiVersion.name
        p[K.dockStyle] = s.dockStyle.name
        p[K.headerStyle] = s.headerStyle.name
        p[K.homeHero] = s.homeHero
        p[K.npPanel] = s.npPanel
        p[K.mascotEars] = s.mascotEars.name
        p[K.mascotEyes] = s.mascotEyes.name
        p[K.mascotTail] = s.mascotTail.name
        p[K.mascotNeck] = s.mascotNeck.name
        p[K.mascotMark] = s.mascotMark.name
        p[K.mascotWings] = s.mascotWings
        p[K.mascotSparkles] = s.mascotSparkles
        p[K.mascotHue] = s.mascotHue
        p[K.mascotGlow] = s.mascotGlow
        p[K.mascotSpeed] = s.mascotSpeed
        p[K.mascotNotes] = s.mascotNotes
        p[K.mascotTouch] = s.mascotTouch
        p[K.mascotFlow] = s.mascotFlow
        p[K.glowOn] = s.glowOn
        p[K.glowStrength] = s.glowStrength
        p[K.glowSize] = s.glowSize
        p[K.glowTint] = s.glowTint.name
        p[K.glowPulse] = s.glowPulse
        p[K.glowOrbs] = s.glowOrbs
        p[K.glowDock] = s.glowDock
        p[K.glowMini] = s.glowMini
        p[K.glowCards] = s.glowCards
        p[K.glowPlaying] = s.glowPlaying
        p[K.glowButtons] = s.glowButtons
        p[K.glowArt] = s.glowArt
        p[K.touchFx] = s.touchFx.name
        p[K.touchGrow] = s.touchGrow
        p[K.npDesign] = s.npDesign.name
        p[K.orbitRing] = s.orbitRing
        p[K.orbitRingStyle] = s.orbitRingStyle.name
        p[K.orbitSpin] = s.orbitSpin
        p[K.orbitGestures] = s.orbitGestures
        p[K.dockIndicator] = s.dockIndicator.name
        p[K.miniSwipe] = s.miniSwipe
        p[K.powerProfile] = s.powerProfile.name
        p[K.ambientWhenPaused] = s.ambientWhenPaused
        p[K.autoSaver] = s.autoSaver
        p[K.playlistLayout] = s.playlistLayout.name
        p[K.playlistSize] = s.playlistSize.name
        p[K.playlistOrder] = s.playlistOrder.name
        p[K.playlistShowCount] = s.playlistShowCount
        p[K.playlistShowNote] = s.playlistShowNote
        p[K.playlistSmartRow] = s.playlistSmartRow
        p[K.hideBars] = s.hideBars.name
        p[K.marqueeTitles] = s.marqueeTitles
        p[K.sleepFade] = s.sleepFade
        p[K.uiScale] = s.uiScale
        p[K.radialSide] = s.radialSide.name
        p[K.radialScale] = s.radialScale
        p[K.pillOutline] = s.pillOutline
        p[K.dockHidden] = s.dockHidden.map { it.name }.toSet()
    }
}
